/**
 * Browser-Direct Zabbix JSON-RPC & Compliance Engine (Standalone & Hybrid Mode)
 * Enables Zabbix_Monitoring_Standalone.html (single-file) to work 100% in the browser
 * without Python installed, and provides automatic browser-direct fallback when the
 * user's browser is on a corporate VPN (e.g. Kasikornbank VPN) that the Python host cannot resolve.
 */
(function () {
  "use strict";

  const SESSION_KEY = "mz_standalone_session_v1";
  const SETTINGS_KEY = "mz_standalone_settings_v1";
  const WAIVERS_KEY = "mz_standalone_waivers_v1";
  const ES_SETTINGS_KEY = "mz_standalone_es_settings_v1";
  const ES_HOST_CFG_KEY = "mz_standalone_es_hostcfg_v1";

  const MONITORED = "Monitored";
  const NOT_MONITORED = "Not Monitored";
  const NOT_REQUIRED = "Not Required";

  const ISSUE_TEXT = {
    disabled: "Item ถูกปิดใช้งาน (Disabled)",
    unsupported: "Item ไม่รองรับ (Unsupported)",
    no_data: "ยังไม่มีข้อมูลเข้ามา",
    stale: "ข้อมูลไม่อัปเดต (Stale)"
  };

  const DEFAULT_SETTINGS = {
    pass_threshold: 100,
    warn_threshold: 80,
    direct_agent: false,
    agent_port: 10050,
    organization: ""
  };

  // =========================================================================
  // 1. Standard Catalog (OS Checks, Baseline Services, Software Catalog)
  // =========================================================================
  const OS_CHECKS = [
    {
      id: "agent_availability", expected: "agent.ping", name: "Agent availability", category: "Availability",
      match: ["^agent\\.ping$", "^zabbix\\[host,agent,available\\]$", "^icmpping(\\[|$)"],
      required: { windows: true, linux: true, aix: true },
      add: { "*": { key: "agent.ping", name: "Zabbix agent ping", value_type: 3, delay: "1m" } },
      trigger: { expr: "nodata(/{host}/{key},5m)=1", desc: "Zabbix agent is not available on {HOST.NAME}", priority: 3 }
    },
    {
      id: "cpu_util", expected: "system.cpu.util", name: "CPU utilization", category: "CPU",
      match: ["^system\\.cpu\\.util", "^perf_counter(_en)?\\[.*processor.*% processor time"],
      required: { windows: true, linux: true, aix: true },
      add: { "*": { key: "system.cpu.util", name: "CPU utilization", value_type: 0, units: "%", delay: "1m" } },
      trigger: { expr: "min(/{host}/{key},5m)>90", desc: "High CPU utilization on {HOST.NAME} (>90% for 5m)", priority: 2 }
    },
    {
      id: "cpu_load", expected: "system.cpu.load[all,avg5]", name: "CPU load / queue", category: "CPU",
      match: ["^system\\.cpu\\.load", "^perf_counter(_en)?\\[.*processor queue length"],
      required: { windows: false, linux: true, aix: true },
      add: { "*": { key: "system.cpu.load[all,avg5]", name: "CPU load average (5m)", value_type: 0, delay: "1m" } }
    },
    {
      id: "memory", expected: "vm.memory.util / vm.memory.size[pused]", name: "Memory utilization", category: "Memory",
      match: ["^vm\\.memory\\.(util|size)", "^perf_counter(_en)?\\[.*\\\\memory\\\\"],
      required: { windows: true, linux: true, aix: true },
      add: {
        windows: { key: "vm.memory.size[pused]", name: "Memory utilization", value_type: 0, units: "%", delay: "1m" },
        linux: { key: "vm.memory.util", name: "Memory utilization", value_type: 0, units: "%", delay: "1m" },
        aix: { key: "vm.memory.size[available]", name: "Available memory", value_type: 3, units: "B", delay: "1m" }
      }
    },
    {
      id: "swap", expected: "system.swap.size[,pfree]", name: "Swap / paging file", category: "Memory",
      match: ["^system\\.swap\\.(size|in|out)", "^perf_counter(_en)?\\[.*paging file"],
      required: { windows: false, linux: true, aix: true },
      add: { "*": { key: "system.swap.size[,pfree]", name: "Free swap space in %", value_type: 0, units: "%", delay: "1m" } }
    },
    {
      id: "fs_usage", expected: "vfs.fs.size[<fs>,pused]", name: "Filesystem space", category: "Disk",
      match: ["^vfs\\.fs\\.(size|dependent\\.size)\\[", "^vfs\\.fs\\.get$"],
      required: { windows: true, linux: true, aix: true },
      add: {
        windows: { key: "vfs.fs.size[C:,pused]", name: "C: Space utilization", value_type: 0, units: "%", delay: "5m" },
        linux: { key: "vfs.fs.size[/,pused]", name: "/: Space utilization", value_type: 0, units: "%", delay: "5m" },
        aix: { key: "vfs.fs.size[/,pused]", name: "/: Space utilization", value_type: 0, units: "%", delay: "5m" }
      },
      trigger: { expr: "last(/{host}/{key})>90", desc: "Disk space is critically low on {HOST.NAME} (>90%)", priority: 3 }
    },
    {
      id: "fs_inode", expected: "vfs.fs.inode[<fs>,pfree]", name: "Filesystem inodes", category: "Disk",
      match: ["^vfs\\.fs\\.(inode|dependent\\.inode)\\["],
      required: { windows: false, linux: true, aix: true },
      add: {
        linux: { key: "vfs.fs.inode[/,pfree]", name: "/: Free inodes in %", value_type: 0, units: "%", delay: "5m" },
        aix: { key: "vfs.fs.inode[/,pfree]", name: "/: Free inodes in %", value_type: 0, units: "%", delay: "5m" }
      }
    },
    {
      id: "disk_io", expected: "vfs.dev.read/write[<disk>] (OS template)", name: "Disk I/O", category: "Disk",
      match: ["^vfs\\.dev\\.(read|write)", "^perf_counter(_en)?\\[.*physicaldisk"],
      required: { windows: true, linux: true, aix: true },
      add: null
    },
    {
      id: "network", expected: "net.if.in/out[<if>] (OS template)", name: "Network interface traffic", category: "Network",
      match: ["^net\\.if\\.(in|out|total)\\[", "^perf_counter(_en)?\\[.*network interface"],
      required: { windows: true, linux: true, aix: true },
      add: null
    },
    {
      id: "uptime", expected: "system.uptime", name: "System uptime", category: "System",
      match: ["^system\\.uptime$"],
      required: { windows: true, linux: true, aix: true },
      add: { "*": { key: "system.uptime", name: "System uptime", value_type: 3, units: "uptime", delay: "1m" } }
    },
    {
      id: "process_count", expected: "proc.num[]", name: "Number of processes", category: "System",
      match: ["^proc\\.num$", "^proc\\.num\\[\\s*\\]$", "^proc\\.num\\[,"],
      required: { windows: true, linux: true, aix: true },
      add: { "*": { key: "proc.num[]", name: "Number of processes", value_type: 3, delay: "1m" } }
    },
    {
      id: "os_info", expected: "system.uname", name: "OS identification", category: "System",
      match: ["^system\\.uname$", "^system\\.sw\\.os"],
      required: { windows: true, linux: true, aix: true },
      add: { "*": { key: "system.uname", name: "System description", value_type: 4, delay: "1h" } }
    }
  ];

  const OS_TEMPLATES = {
    windows: ["Windows by Zabbix agent", "Windows by Zabbix agent active"],
    linux: ["Linux by Zabbix agent", "Linux by Zabbix agent active"],
    aix: ["AIX by Zabbix agent"]
  };
  const OS_TEMPLATE_KEYWORDS = { windows: ["windows"], linux: ["linux"], aix: ["aix"] };

  const BASELINE_SERVICES = {
    windows: [
      { id: "eventlog", names: ["EventLog"], display: "Windows Event Log" },
      { id: "w32time", names: ["W32Time"], display: "Windows Time" }
    ],
    linux: [
      { id: "sshd", names: ["sshd"], display: "OpenSSH server" },
      { id: "cron", names: ["crond", "cron"], display: "Cron scheduler" },
      { id: "syslog", names: ["rsyslogd", "syslog-ng", "systemd-journald"], display: "System logging" },
      { id: "timesync", names: ["chronyd", "ntpd", "systemd-timesyncd"], display: "Time synchronization" }
    ],
    aix: [
      { id: "sshd", names: ["sshd"], display: "OpenSSH server" },
      { id: "cron", names: ["cron"], display: "Cron scheduler" },
      { id: "syslog", names: ["syslogd"], display: "System logging" },
      { id: "timesync", names: ["xntpd", "chronyd", "ntpd"], display: "Time synchronization" }
    ]
  };

  const SOFTWARE_CATALOG = [
    {
      id: "mssql", name: "Microsoft SQL Server", kind: "Database", required: true,
      include: ["^microsoft sql server \\d{4}", "^sql server \\d{4} database engine services"],
      exclude: ["setup", "management studio", "native client", "odbc", "browser", "vss", "writer", "tools", "shared", "localdb", "compact", "report", "polic", "t-sql", "language", "dac", "redist", "clr types", "command line", "common files", "batch parser", "connection info", "sql server agent", "rsfx", "driver", "dmf", "xevent", "sql writer"],
      services: ["^mssqlserver$", "^mssql\\$"], processes: ["sqlservr"],
      templates: ["MSSQL by Zabbix agent 2", "MSSQL by ODBC"], template_keywords: ["mssql", "sql server"],
      item_patterns: ["^mssql\\.", "perf_counter(_en)?\\[.*(mssql|sqlserver)"]
    },
    {
      id: "oracle", name: "Oracle Database", kind: "Database", required: true,
      include: ["^oracle database", "^oracle \\d+c", "^oracle.*database server"],
      exclude: ["client", "instant", "odbc", "java"],
      services: ["^oracleservice"], processes: ["ora_pmon", "tnslsnr"],
      templates: ["Oracle by Zabbix Agent 2", "Oracle by ODBC"], template_keywords: ["oracle"],
      item_patterns: ["^oracle\\."]
    },
    {
      id: "mysql", name: "MySQL / MariaDB", kind: "Database", required: true,
      include: ["^mysql server", "^mysql(-community)?-server", "^mariadb(-server)?($|[\\s-]\\d)", "^mariadb server"],
      exclude: ["connector", "workbench", "client", "libs?$", "common"],
      services: ["^mysql\\d*$", "^mariadb"], processes: ["mysqld", "mariadbd"],
      templates: ["MySQL by Zabbix agent 2", "MySQL by Zabbix agent", "MySQL by ODBC"], template_keywords: ["mysql", "mariadb"],
      item_patterns: ["^mysql\\."]
    },
    {
      id: "postgresql", name: "PostgreSQL", kind: "Database", required: true,
      include: ["^postgresql\\d*(-server)?$", "^postgresql \\d+", "^postgresql\\d*-server"],
      exclude: ["libs?$", "jdbc", "odbc", "contrib", "client"],
      services: ["^postgresql"], processes: ["postgres", "postmaster"],
      templates: ["PostgreSQL by Zabbix agent 2", "PostgreSQL by Zabbix agent"], template_keywords: ["postgres", "pgsql"],
      item_patterns: ["^pgsql\\.", "^postgresql\\."]
    },
    {
      id: "db2", name: "IBM Db2", kind: "Database", required: true,
      include: ["^db2", "^ibm db2"], exclude: ["client", "driver"],
      services: ["^db2"], processes: ["db2sysc"],
      templates: [], template_keywords: ["db2"], item_patterns: ["db2"]
    },
    {
      id: "iis", name: "Microsoft IIS", kind: "Web server", required: true,
      include: ["internet information services"], exclude: ["express", "url rewrite", "arr"],
      services: ["^w3svc$"], processes: ["w3wp"],
      templates: ["IIS by Zabbix agent", "IIS by Zabbix agent active"], template_keywords: ["iis"],
      item_patterns: ["perf_counter(_en)?\\[.*web service", "^iis\\."]
    },
    {
      id: "apache", name: "Apache HTTP Server", kind: "Web server", required: true,
      include: ["^httpd$", "^httpd-\\d", "^apache2$", "^apache http server"],
      exclude: ["tomcat", "tools", "filesystem", "utils", "devel", "doc"],
      services: ["^apache\\d*$"], processes: ["httpd", "apache2"],
      templates: ["Apache by Zabbix agent", "Apache by HTTP"], template_keywords: ["apache"],
      item_patterns: ["^apache\\.", "^web\\.page\\.get\\[.*server-status"]
    },
    {
      id: "nginx", name: "Nginx", kind: "Web server", required: true,
      include: ["^nginx($|[\\s-]\\d|-core|-full)"], exclude: ["filesystem", "mod-", "module"],
      services: ["^nginx"], processes: ["nginx"],
      templates: ["Nginx by Zabbix agent", "Nginx by HTTP"], template_keywords: ["nginx"],
      item_patterns: ["^nginx\\.", "^web\\.page\\.get\\[.*(basic_status|stub_status)"]
    },
    {
      id: "tomcat", name: "Apache Tomcat", kind: "Middleware", required: true,
      include: ["tomcat"], exclude: ["native", "docs", "lib"],
      services: ["^tomcat\\d*$"], processes: [],
      templates: ["Apache Tomcat by JMX"], template_keywords: ["tomcat"],
      item_patterns: ["^jmx\\[.*catalina"]
    },
    {
      id: "weblogic", name: "Oracle WebLogic / IBM WebSphere", kind: "Middleware", required: true,
      include: ["weblogic", "websphere"], exclude: [],
      services: ["weblogic", "^ibmwas"], processes: [],
      templates: ["Generic Java JMX"], template_keywords: ["weblogic", "websphere", "jmx"],
      item_patterns: ["^jmx\\["]
    },
    {
      id: "docker", name: "Docker Engine", kind: "Container", required: true,
      include: ["^docker(-ce|-engine|\\.io)?$", "^docker engine", "^docker desktop", "^moby-engine"],
      exclude: ["cli$", "compose", "buildx"],
      services: ["^docker$", "^com\\.docker\\.service$"], processes: ["dockerd"],
      templates: ["Docker by Zabbix agent 2"], template_keywords: ["docker"],
      item_patterns: ["^docker\\."]
    },
    {
      id: "redis", name: "Redis", kind: "Database", required: true,
      include: ["^redis(-server)?($|[\\s-]\\d)"], exclude: ["tools", "client"],
      services: ["^redis"], processes: ["redis-server"],
      templates: ["Redis by Zabbix agent 2"], template_keywords: ["redis"], item_patterns: ["^redis\\."]
    },
    {
      id: "mongodb", name: "MongoDB", kind: "Database", required: true,
      include: ["^mongodb(-org)?(-server)?($|[\\s-]\\d)", "^mongodb \\d"], exclude: ["compass", "shell", "tools", "mongosh"],
      services: ["^mongodb"], processes: ["mongod"],
      templates: ["MongoDB node by Zabbix agent 2"], template_keywords: ["mongo"], item_patterns: ["^mongodb\\."]
    },
    {
      id: "rabbitmq", name: "RabbitMQ", kind: "Middleware", required: true,
      include: ["rabbitmq(-server)?"], exclude: [],
      services: ["^rabbitmq"], processes: [],
      templates: ["RabbitMQ node by Zabbix agent", "RabbitMQ node by HTTP"], template_keywords: ["rabbitmq"],
      item_patterns: ["^rabbitmq\\."]
    },
    {
      id: "elasticsearch", name: "Elasticsearch", kind: "Database", required: true,
      include: ["^elasticsearch"], exclude: ["curator"],
      services: ["^elasticsearch"], processes: [],
      templates: ["Elasticsearch Cluster by HTTP"], template_keywords: ["elasticsearch"], item_patterns: ["^es\\."]
    },
    {
      id: "exchange", name: "Microsoft Exchange Server", kind: "Application", required: true,
      include: ["^microsoft exchange server"], exclude: ["language", "update", "pack"],
      services: ["^msexchange"], processes: [],
      templates: ["Microsoft Exchange Server 2016 by Zabbix agent", "Microsoft Exchange Server 2016 by Zabbix agent active"],
      template_keywords: ["exchange"], item_patterns: ["perf_counter(_en)?\\[.*msexchange"]
    },
    {
      id: "ad_ds", name: "Active Directory Domain Services", kind: "Application", required: true,
      include: [], exclude: [],
      services: ["^ntds$"], processes: [],
      templates: ["Active Directory DS by Zabbix agent", "Active Directory DS by Zabbix agent active"],
      template_keywords: ["active directory"], item_patterns: ["perf_counter(_en)?\\[.*ntds"]
    },
    {
      id: "hyperv", name: "Microsoft Hyper-V", kind: "Virtualization", required: true,
      include: [], exclude: [],
      services: ["^vmms$"], processes: [],
      templates: ["Hyper-V by Zabbix agent", "Hyper-V by Zabbix agent active"],
      template_keywords: ["hyper-v"], item_patterns: ["perf_counter(_en)?\\[.*hyper-v"]
    },
    {
      id: "sap", name: "SAP / SAP Business One", kind: "Application", required: true,
      include: ["^sap ", "sap business one"], exclude: ["gui", "crystal", "client"],
      services: ["^sbo", "^sap"], processes: [],
      templates: [], template_keywords: ["sap"], item_patterns: []
    },
    {
      id: "zabbix_agent", name: "Zabbix Agent", kind: "Monitoring", required: false,
      include: ["^zabbix agent", "^zabbix-agent"], exclude: [],
      services: ["^zabbix agent"], processes: ["zabbix_agentd", "zabbix_agent2"],
      templates: [], template_keywords: [], item_patterns: []
    },
    {
      id: "vmware_tools", name: "VMware Tools", kind: "Virtualization", required: false,
      include: ["^vmware tools", "^open-vm-tools"], exclude: [],
      services: ["^vmtools$"], processes: ["vmtoolsd"],
      templates: [], template_keywords: [], item_patterns: []
    },
    {
      id: "java", name: "Java Runtime", kind: "Runtime", required: false,
      include: ["^java(\\(tm\\))? (se )?(\\d+ )?(runtime|development|update)", "^jdk", "openjdk", "^java-\\d+-openjdk", "^temurin"],
      exclude: [], services: [], processes: [],
      templates: ["Generic Java JMX"], template_keywords: ["jmx"], item_patterns: ["^jmx\\["]
    }
  ];

  // Compile regexes once
  const compileRxList = (arr) => (arr || []).map((p) => new RegExp(p, "i"));
  OS_CHECKS.forEach((c) => { c._rx = compileRxList(c.match); });
  SOFTWARE_CATALOG.forEach((s) => {
    s._inc = compileRxList(s.include);
    s._exc = compileRxList(s.exclude);
    s._svc = compileRxList(s.services);
    s._items = compileRxList(s.item_patterns);
  });

  // =========================================================================
  // 2. LocalStorage Stores (Session, Settings, Waivers)
  // =========================================================================
  function readStore(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function writeStore(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
    } catch (_) {}
  }

  function loadSettings() {
    const data = readStore(SETTINGS_KEY, {});
    return { ...DEFAULT_SETTINGS, ...(data || {}) };
  }

  function saveSettings(update) {
    const cur = loadSettings();
    if (update && typeof update === "object") {
      if (update.pass_threshold !== undefined) cur.pass_threshold = Math.max(0, Math.min(100, parseInt(update.pass_threshold, 10) || 100));
      if (update.warn_threshold !== undefined) cur.warn_threshold = Math.max(0, Math.min(100, parseInt(update.warn_threshold, 10) || 80));
      if (update.organization !== undefined) cur.organization = String(update.organization).slice(0, 200);
    }
    if (cur.warn_threshold > cur.pass_threshold) cur.warn_threshold = cur.pass_threshold;
    writeStore(SETTINGS_KEY, cur);
    return cur;
  }

  function loadWaivers(hostid) {
    const all = readStore(WAIVERS_KEY, {});
    return (all && all[String(hostid)]) || {};
  }

  function setWaiver(hostid, checkKey, reason, remove = false) {
    const all = readStore(WAIVERS_KEY, {});
    const hKey = String(hostid);
    if (!all[hKey]) all[hKey] = {};
    if (remove) {
      delete all[hKey][checkKey];
    } else {
      const now = new Date();
      const stamp = now.toISOString().slice(0, 16).replace("T", " ");
      all[hKey][checkKey] = { reason: String(reason || "Not required").trim().slice(0, 300), at: stamp };
    }
    writeStore(WAIVERS_KEY, all);
    return all[hKey];
  }

  // =========================================================================
  // 3. BrowserZabbixClient (Direct JSON-RPC 2.0 via fetch)
  // =========================================================================
  class BrowserZabbixClient {
    constructor(url) {
      this.rawUrl = (url || "").trim();
      this.url = BrowserZabbixClient.normalizeUrl(this.rawUrl);
      this.authToken = null;
      this.isApiToken = false;
      this.useBearer = false;
      this.apiVersion = "7.0";
      this.userInfo = {};
      this.requestId = 1;
      this._templatesCache = null;
      this._proxiesCache = null;
    }

    static normalizeUrl(rawUrl) {
      let clean = (rawUrl || "").trim();
      if (!clean) return "";
      if (!/^https?:\/\//i.test(clean)) {
        clean = "http://" + clean;
      }
      clean = clean.split("?")[0].split("#")[0].replace(/\/+$/, "");
      const suffixes = ["/index.php", "/zabbix.php", "/index_http.php"];
      for (const sfx of suffixes) {
        if (clean.toLowerCase().endsWith(sfx)) {
          clean = clean.slice(0, -sfx.length).replace(/\/+$/, "");
          break;
        }
      }
      if (!clean.toLowerCase().endsWith("api_jsonrpc.php")) {
        clean = clean + "/api_jsonrpc.php";
      }
      return clean;
    }

    static candidateUrls(rawUrl) {
      const primary = BrowserZabbixClient.normalizeUrl(rawUrl);
      if (!primary) return [];
      const candidates = [primary];
      try {
        const u = new URL(primary);
        if (u.pathname === "/api_jsonrpc.php") {
          candidates.push(`${u.origin}/zabbix/api_jsonrpc.php`);
        } else if (u.pathname.toLowerCase() === "/zabbix/api_jsonrpc.php") {
          candidates.push(`${u.origin}/api_jsonrpc.php`);
        }
        // Also try protocol flip if needed
        const altProto = u.protocol === "https:" ? "http:" : "https:";
        candidates.push(`${altProto}//${u.host}${u.pathname}`);
      } catch (_) {}
      return Array.from(new Set(candidates));
    }

    versionTuple() {
      const parts = String(this.apiVersion || "7.0").split(".");
      const maj = parseInt(parts[0], 10) || 7;
      const min = parseInt(parts[1], 10) || 0;
      return [maj, min];
    }

    isVerAtLeast(maj, min = 0) {
      const [vMaj, vMin] = this.versionTuple();
      return vMaj > maj || (vMaj === maj && vMin >= min);
    }

    async rpcRequest(endpointUrl, method, params, useAuth = true, forceBearer = null) {
      const payload = {
        jsonrpc: "2.0",
        method: method,
        params: params || {},
        id: this.requestId++
      };
      const headers = { "Content-Type": "application/json-rpc" };
      const bearer = forceBearer !== null ? forceBearer : (this.useBearer || this.isApiToken);
      if (useAuth && this.authToken) {
        if (bearer) {
          headers["Authorization"] = `Bearer ${this.authToken}`;
        } else {
          payload.auth = this.authToken;
        }
      }
      const resp = await fetch(endpointUrl, {
        method: "POST",
        headers: headers,
        body: JSON.stringify(payload)
      });
      if (!resp.ok) {
        throw new Error(`HTTP ${resp.status} (${resp.statusText || "Error"}) from ${endpointUrl}`);
      }
      const data = await resp.json();
      return data;
    }

    async call(method, params = {}, useAuth = true) {
      let data = await this.rpcRequest(this.url, method, params, useAuth);
      if (data && data.error && useAuth && this.authToken) {
        const errStr = ((data.error.message || "") + " " + (data.error.data || "")).toLowerCase();
        // Automatic fallback between Bearer header and auth body parameter
        if (errStr.includes("auth") || errStr.includes("not authorized") || errStr.includes("unexpected parameter")) {
          const altBearer = !(this.useBearer || this.isApiToken);
          const retry = await this.rpcRequest(this.url, method, params, useAuth, altBearer);
          if (retry && !retry.error) {
            this.useBearer = altBearer;
            return retry;
          }
        }
      }
      return data;
    }

    async login({ username = "", password = "", apiToken = "" }) {
      const candidates = BrowserZabbixClient.candidateUrls(this.rawUrl);
      let lastError = "ไม่สามารถเชื่อมต่อ Zabbix API ได้";
      let workingUrl = null;

      for (const cand of candidates) {
        try {
          const verRes = await this.rpcRequest(cand, "apiinfo.version", {}, false);
          if (verRes && verRes.result) {
            workingUrl = cand;
            this.url = cand;
            this.apiVersion = String(verRes.result);
            break;
          } else if (verRes && verRes.error) {
            workingUrl = cand;
            this.url = cand;
            break;
          }
        } catch (err) {
          lastError = err.message || String(err);
        }
      }

      if (!workingUrl) {
        return {
          success: false,
          message: `ไม่สามารถเชื่อมต่อ Zabbix API ที่ ${this.url} ได้ (${lastError}) — โปรดตรวจสอบ URL หรือ VPN`
        };
      }

      const [maj, min] = this.versionTuple();

      // 1) API Token Login
      if (apiToken) {
        this.authToken = apiToken.trim();
        this.isApiToken = true;
        this.useBearer = maj > 6 || (maj === 6 && min >= 4);

        let test = await this.call("host.get", { output: ["hostid"], limit: 1 }, true);
        if (test && test.error) {
          // Try flipping bearer vs body auth
          this.useBearer = !this.useBearer;
          test = await this.call("host.get", { output: ["hostid"], limit: 1 }, true);
        }
        if (test && test.result !== undefined) {
          await this.fetchCurrentUser("API Token");
          return { success: true, message: `Connected to Zabbix ${this.apiVersion} via API Token` };
        }
        const err = (test && test.error) || {};
        this.authToken = null;
        return {
          success: false,
          message: `API Token ไม่ถูกต้องหรือไม่มีสิทธิ์: ${err.data || err.message || "Unauthorized"}`
        };
      }

      // 2) Username / Password Login
      const cleanUser = (username || "").trim();
      if (!cleanUser || !password) {
        return { success: false, message: "กรุณากรอก Username และ Password ให้ครบถ้วน" };
      }

      const loginAttempts = maj >= 6
        ? [
            { username: cleanUser, password: password, userData: true },
            { username: cleanUser, password: password },
            { user: cleanUser, password: password }
          ]
        : [
            { user: cleanUser, password: password },
            { username: cleanUser, password: password }
          ];

      let loginRes = null;
      for (const params of loginAttempts) {
        try {
          loginRes = await this.rpcRequest(this.url, "user.login", params, false);
          if (loginRes && loginRes.result) break;
          const errData = ((loginRes?.error?.data || "") + " " + (loginRes?.error?.message || "")).toLowerCase();
          if (errData.includes("incorrect") || errData.includes("invalid") || errData.includes("blocked")) {
            break;
          }
        } catch (e) {
          lastError = e.message;
        }
      }

      if (loginRes && loginRes.result) {
        const res = loginRes.result;
        if (typeof res === "object" && res !== null) {
          this.authToken = res.sessionid || res.token || "";
          const uName = res.username || res.alias || cleanUser;
          const fullName = `${res.name || ""} ${res.surname || ""}`.trim();
          this.userInfo = {
            userid: String(res.userid || ""),
            username: uName,
            name: res.name || "",
            surname: res.surname || "",
            display_name: fullName ? `${uName} (${fullName})` : uName
          };
        } else {
          this.authToken = String(res);
        }
        this.isApiToken = false;
        this.useBearer = maj > 6 || (maj === 6 && min >= 4);
        if (!this.userInfo || !this.userInfo.username) {
          await this.fetchCurrentUser(cleanUser);
        }
        return { success: true, message: `Connected to Zabbix ${this.apiVersion}` };
      }

      const err = (loginRes && loginRes.error) || {};
      return {
        success: false,
        message: `เข้าสู่ระบบไม่สำเร็จ: ${err.data || err.message || lastError}`
      };
    }

    async fetchCurrentUser(fallbackName = "admin") {
      try {
        const res = await this.call("user.get", {
          output: ["userid", "username", "name", "surname"],
          limit: 1
        });
        const users = (res && res.result) || [];
        if (users.length === 1) {
          const u = users[0];
          const uName = u.username || u.alias || fallbackName;
          const full = `${u.name || ""} ${u.surname || ""}`.trim();
          this.userInfo = {
            userid: String(u.userid || ""),
            username: uName,
            display_name: full ? `${uName} (${full})` : uName
          };
          return;
        }
      } catch (_) {}
      this.userInfo = {
        userid: "",
        username: fallbackName,
        display_name: fallbackName
      };
    }

    async getHostGroups() {
      const res = await this.call("hostgroup.get", {
        output: ["groupid", "name"],
        sortfield: "name"
      });
      return (res && res.result) || [];
    }

    async getTemplates(force = false) {
      if (!force && this._templatesCache && (Date.now() - this._templatesCache.at < 300000)) {
        return this._templatesCache.data;
      }
      const res = await this.call("template.get", {
        output: ["templateid", "host", "name"],
        sortfield: "name"
      });
      const data = (res && res.result) || [];
      this._templatesCache = { at: Date.now(), data };
      return data;
    }

    async getProxiesMap() {
      if (this._proxiesCache && (Date.now() - this._proxiesCache.at < 120000)) {
        return this._proxiesCache;
      }
      const proxyMap = {};
      const proxyGroupMap = {};
      const is70 = this.isVerAtLeast(7, 0);

      try {
        const pRes = await this.call("proxy.get", {
          output: is70 ? ["proxyid", "name"] : ["proxyid", "host", "name"]
        });
        let rows = (pRes && pRes.result) || [];
        if (!rows.length && !pRes?.result) {
          const fb = await this.call("proxy.get", { output: "extend" });
          rows = (fb && fb.result) || [];
        }
        rows.forEach((p) => {
          const pid = String(p.proxyid || "");
          const pname = p.name || p.host || "";
          if (pid && pid !== "0" && pname) proxyMap[pid] = pname;
        });
      } catch (_) {}

      if (is70) {
        try {
          const pgRes = await this.call("proxygroup.get", { output: ["proxy_groupid", "name"] });
          ((pgRes && pgRes.result) || []).forEach((pg) => {
            const pgid = String(pg.proxy_groupid || "");
            const pgname = pg.name || "";
            if (pgid && pgid !== "0" && pgname) proxyGroupMap[pgid] = pgname;
          });
        } catch (_) {}
      }

      this._proxiesCache = { at: Date.now(), proxyMap, proxyGroupMap };
      return this._proxiesCache;
    }

    enrichHosts(hosts, proxyMap, proxyGroupMap, agentAvailMap = {}) {
      return (hosts || []).map((h) => {
        h.groups = h.groups || h.hostgroups || [];
        let proxyName = "";
        const pid = String(h.proxyid || h.assigned_proxyid || h.proxy_hostid || "0");
        const pgid = String(h.proxy_groupid || "0");
        if (pid !== "0" && proxyMap[pid]) {
          proxyName = proxyMap[pid];
          if (pgid !== "0" && proxyGroupMap[pgid]) {
            proxyName = `${proxyName} (${proxyGroupMap[pgid]})`;
          }
        } else if (pgid !== "0" && proxyGroupMap[pgid]) {
          proxyName = proxyGroupMap[pgid];
        }
        h.proxy_name = proxyName;

        const hid = String(h.hostid || "");
        const ifaces = h.interfaces || [];
        const ifaceAvail = ifaces.map((i) => String(i.available || "0"));
        const ifaceErrors = ifaces.map((i) => String(i.error || "").trim()).filter(Boolean);
        const actAvail = String(h.active_available || h.available || "0");
        const itemAvail = agentAvailMap[hid] || "";

        if (ifaceAvail.includes("1") || actAvail === "1" || itemAvail === "connected") {
          h.zbx_connected = "connected";
        } else if (ifaceAvail.includes("2") || actAvail === "2" || itemAvail === "disconnected") {
          h.zbx_connected = "disconnected";
        } else {
          h.zbx_connected = "unknown";
        }
        h.zbx_error = ifaceErrors[0] || "";
        return h;
      });
    }

    async getHosts(limit = 2000) {
      const is70 = this.isVerAtLeast(7, 0);
      const is64 = this.isVerAtLeast(6, 4);
      const is62 = this.isVerAtLeast(6, 2);
      const outFields = ["hostid", "host", "name", "status", "description"];
      if (is70) {
        outFields.push("proxyid", "assigned_proxyid", "proxy_groupid", "monitored_by", "active_available");
      } else if (is64) {
        outFields.push("proxy_hostid", "active_available");
      } else {
        outFields.push("proxy_hostid", "available");
      }

      const params = {
        output: outFields,
        selectInterfaces: ["interfaceid", "ip", "dns", "port", "type", "main", "useip", "available", "error"],
        selectParentTemplates: ["templateid", "name"],
        limit: limit,
        sortfield: "name"
      };
      if (is62) params.selectHostGroups = ["groupid", "name"];
      else params.selectGroups = ["groupid", "name"];

      let res = await this.call("host.get", params);
      if ((!res || !res.result) && is62) {
        delete params.selectHostGroups;
        params.selectGroups = ["groupid", "name"];
        res = await this.call("host.get", params);
      }
      const rows = (res && res.result) || [];
      const hostids = rows.map((h) => String(h.hostid)).filter(Boolean);
      const agentAvailMap = {};
      if (hostids.length) {
        try {
          const ir = await this.call("item.get", {
            hostids: hostids,
            output: ["hostid", "key_", "status", "state", "lastvalue", "lastclock"],
            search: { key_: ["zabbix[host,agent,available]", "agent.ping", "icmpping"] },
            searchByAny: true
          });
          ((ir && ir.result) || []).forEach((it) => {
            if (String(it.status || "0") !== "0") return;
            const hid = String(it.hostid || "");
            const lv = String(it.lastvalue || "").trim();
            const lc = parseInt(it.lastclock || "0", 10);
            if (lv === "1" && lc > 0) {
              agentAvailMap[hid] = "connected";
            } else if ((lv === "0" || lv === "2") && lc > 0 && agentAvailMap[hid] !== "connected") {
              agentAvailMap[hid] = "disconnected";
            }
          });
        } catch (_) {}
      }
      const { proxyMap, proxyGroupMap } = await this.getProxiesMap();
      return this.enrichHosts(rows, proxyMap, proxyGroupMap, agentAvailMap);
    }

    async getHostDetail(hostid) {
      const is70 = this.isVerAtLeast(7, 0);
      const is62 = this.isVerAtLeast(6, 2);
      const outFields = ["hostid", "host", "name", "status", "description"];
      if (is70) {
        outFields.push("proxyid", "assigned_proxyid", "proxy_groupid", "monitored_by");
      } else {
        outFields.push("proxy_hostid");
      }

      const params = {
        hostids: [String(hostid)],
        output: outFields,
        selectInterfaces: ["interfaceid", "ip", "dns", "port", "type", "useip", "main", "available", "error"],
        selectParentTemplates: ["templateid", "name"],
        selectMacros: "extend"
      };
      if (is62) params.selectHostGroups = ["groupid", "name"];
      else params.selectGroups = ["groupid", "name"];

      let res = await this.call("host.get", params);
      if ((!res || !res.result) && is62) {
        delete params.selectHostGroups;
        params.selectGroups = ["groupid", "name"];
        res = await this.call("host.get", params);
      }
      const rows = (res && res.result) || [];
      if (!rows.length) return null;
      const { proxyMap, proxyGroupMap } = await this.getProxiesMap();
      return this.enrichHosts(rows, proxyMap, proxyGroupMap)[0];
    }

    async getHostValuemaps(hostid) {
      const res = await this.call("valuemap.get", {
        hostids: [String(hostid)],
        output: ["valuemapid", "name", "hostid"],
        selectMappings: "extend"
      });
      return (res && res.result) || [];
    }

    async getHostItems(hostid) {
      const res = await this.call("item.get", {
        hostids: [String(hostid)],
        output: ["itemid", "name", "key_", "status", "state", "error", "units", "lastvalue", "lastclock",
                 "value_type", "delay", "valuemapid", "type", "templateid"],
        selectValueMap: ["valuemapid", "name"],
        sortfield: "name"
      });
      const items = (res && res.result) || [];
      const hInfo = await this.call("host.get", {
        hostids: [String(hostid)],
        output: ["hostid", "host", "name"],
        selectParentTemplates: ["templateid", "name"]
      });
      const parentTemplates = (hInfo?.result?.[0]?.parentTemplates) || [];
      const valuemaps = await this.getHostValuemaps(hostid);

      return {
        success: true,
        hostid: String(hostid),
        total_items: items.length,
        items: items,
        parent_templates: parentTemplates,
        valuemaps: valuemaps
      };
    }

    async getHostTriggers(hostid) {
      const res = await this.call("trigger.get", {
        hostids: [String(hostid)],
        output: ["triggerid", "description", "expression", "priority", "status", "value", "lastchange", "comments", "templateid"],
        selectItems: ["itemid", "name", "key_", "status"],
        selectHosts: ["hostid", "name", "host"],
        expandExpression: true,
        expandDescription: true,
        sortfield: "priority",
        sortorder: "DESC"
      });
      return (res && res.result) || [];
    }
  }

  // =========================================================================
  // 4. Inventory & Compliance Evaluator (Matching monitoring_standard.py)
  // =========================================================================
  function parseKeyParams(key) {
    if (!key || !key.includes("[") || !key.endsWith("]")) return [key || "", []];
    const idx = key.indexOf("[");
    const name = key.slice(0, idx);
    const raw = key.slice(idx + 1, -1);
    const params = [];
    let cur = "";
    let quoted = false;
    for (let i = 0; i < raw.length; i++) {
      const ch = raw[i];
      if (quoted) {
        if (ch === "\\" && i + 1 < raw.length && raw[i + 1] === '"') {
          cur += '"';
          i++;
        } else if (ch === '"') {
          quoted = false;
        } else {
          cur += ch;
        }
      } else if (ch === '"' && !cur.trim()) {
        quoted = true;
        cur = "";
      } else if (ch === ",") {
        params.push(cur.trim());
        cur = "";
      } else {
        cur += ch;
      }
    }
    params.push(cur.trim());
    return [name, params];
  }

  function normProc(name) {
    const n = String(name || "").trim().toLowerCase();
    return n.endsWith(".exe") ? n.slice(0, -4) : n;
  }

  function parseDelay(delay) {
    const m = String(delay || "").trim().match(/^(\d+)\s*([smhdw]?)$/i);
    if (!m) return 3600;
    const mult = { "": 1, s: 1, m: 60, h: 3600, d: 86400, w: 604800 }[m[2].toLowerCase()] || 1;
    return parseInt(m[1], 10) * mult;
  }

  function itemHealth(item, nowSec) {
    if (String(item.status || "0") !== "0") return "disabled";
    if (String(item.state || "0") === "1") return "unsupported";
    const lastclock = parseInt(item.lastclock || "0", 10) || 0;
    if (lastclock <= 0) return "no_data";
    if (nowSec - lastclock > Math.max(3 * parseDelay(item.delay), 3600)) return "stale";
    return null;
  }

  function pickBest(cands, nowSec) {
    if (!cands || !cands.length) return null;
    const order = { null: 0, no_data: 1, stale: 2, unsupported: 3, disabled: 4 };
    return cands.slice().sort((a, b) => {
      const ha = itemHealth(a, nowSec);
      const hb = itemHealth(b, nowSec);
      return (order[ha] ?? 9) - (order[hb] ?? 9);
    })[0];
  }

  function statusFromItem(item, nowSec) {
    if (!item) return [NOT_MONITORED, null];
    const issue = itemHealth(item, nowSec);
    if (issue === "disabled" || issue === "unsupported") return [NOT_MONITORED, issue];
    return [MONITORED, issue];
  }

  function fmtClock(ts) {
    const n = parseInt(ts || "0", 10) || 0;
    if (n <= 0) return "";
    const d = new Date(n * 1000);
    const pad = (x) => String(x).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  function detectOsFamily(templates, items, uname = "", hint = "") {
    const text = String(uname || "").toLowerCase();
    if (text) {
      if (text.startsWith("aix") || ` ${text} `.includes(" aix ")) return "aix";
      if (text.includes("windows")) return "windows";
      if (text.includes("linux")) return "linux";
    }
    for (const t of templates || []) {
      const n = String(t.name || "").toLowerCase();
      if (n.includes("aix")) return "aix";
      if (n.includes("windows")) return "windows";
      if (n.includes("linux")) return "linux";
    }
    for (const it of items || []) {
      const k = String(it.key_ || "").toLowerCase();
      if (k.startsWith("perf_counter") || k.startsWith("service.info") || k.startsWith("wmi.") || k.startsWith("registry.") || k.startsWith("eventlog")) {
        return "windows";
      }
      if (k === "system.uname" && it.lastvalue) {
        return detectOsFamily([], [], it.lastvalue, hint);
      }
    }
    const h = String(hint || "").toLowerCase();
    if (h.includes("aix")) return "aix";
    if (h.includes("win")) return "windows";
    return h ? "linux" : "windows";
  }

  function parseServicesRaw(raw) {
    const out = [];
    const text = String(raw || "").trim();
    if (!text) return out;
    try {
      if (text[0] === "[" || text[0] === "{") {
        let data = JSON.parse(text);
        if (!Array.isArray(data)) data = data.data || Object.values(data);
        for (const s of data) {
          if (!s || typeof s !== "object") continue;
          const name = s["{#SERVICE.NAME}"] || s.Name || "";
          if (name) {
            out.push({
              name,
              display_name: s["{#SERVICE.DISPLAYNAME}"] || s.DisplayName || name,
              state: String(s["{#SERVICE.STATENAME}"] || s.State || "").toLowerCase(),
              startup: String(s["{#SERVICE.STARTUPNAME}"] || s.StartMode || "").toLowerCase()
            });
          }
        }
        return out;
      }
    } catch (_) {}
    for (const line of text.split(/\r?\n/)) {
      const f = line.split("\t");
      if (f[0]) {
        out.push({
          name: f[0],
          display_name: f[1] || f[0],
          state: (f[2] || "").toLowerCase(),
          startup: (f[3] || "").toLowerCase()
        });
      }
    }
    return out;
  }

  function parseProcessesRaw(raw) {
    const text = String(raw || "").trim();
    if (!text) return [];
    const counts = {};
    try {
      if (text[0] === "[") {
        const arr = JSON.parse(text);
        for (const p of arr) {
          const n = String(p.name || "").trim();
          if (n) counts[n] = (counts[n] || 0) + (parseInt(p.processes, 10) || 1);
        }
        return Object.keys(counts).sort().map((n) => ({ name: n, count: counts[n] }));
      }
    } catch (_) {}
    for (const line of text.split(/\r?\n/)) {
      const f = line.split("\t");
      const n = (f[0] || "").trim();
      if (n) counts[n] = (counts[n] || 0) + (parseInt(f[1], 10) || 1);
    }
    return Object.keys(counts).sort().map((n) => ({ name: n, count: counts[n] }));
  }

  function parseSoftwareRaw(raw, key) {
    const text = String(raw || "").trim();
    if (!text) return [];
    const out = [];
    const kl = String(key || "").toLowerCase();
    try {
      if (text[0] === "[") {
        const data = JSON.parse(text);
        if (kl.startsWith("registry.get")) {
          const grouped = {};
          for (const r of data) {
            const fk = r.fullkey || r.key || "";
            if (!grouped[fk]) grouped[fk] = {};
            grouped[fk][r.name || ""] = r.data !== undefined ? r.data : (r.value || "");
          }
          for (const g of Object.values(grouped)) {
            if (g.DisplayName) {
              out.push({ name: String(g.DisplayName), version: String(g.DisplayVersion || ""), publisher: String(g.Publisher || "") });
            }
          }
        } else {
          for (const p of data) {
            if (p.name) out.push({ name: String(p.name), version: String(p.version || ""), publisher: String(p.manager || "") });
          }
        }
        return out;
      }
    } catch (_) {}

    if (kl.startsWith("system.sw.packages[") || kl === "system.sw.packages") {
      for (let part of text.replace(/\n/g, ",").split(",")) {
        part = part.trim();
        if (part.startsWith("[") && part.includes("]")) part = part.split("]")[1].trim();
        if (part) out.push({ name: part, version: "", publisher: "" });
      }
    } else {
      for (const line of text.split(/\r?\n/)) {
        const f = line.split("\t");
        if (f[0] && f[0].trim()) {
          out.push({ name: f[0].trim(), version: (f[1] || "").trim(), publisher: (f[2] || "").trim() });
        }
      }
    }
    const dedup = {};
    for (const s of out) {
      const k = s.name.toLowerCase();
      if (!dedup[k]) dedup[k] = s;
    }
    return Object.values(dedup).sort((a, b) => a.name.localeCompare(b.name));
  }

  function parsePortsRaw(raw) {
    const text = String(raw || "").trim();
    if (!text) return [];
    const out = [];
    if (text[0] === "[" || text[0] === "{") {
      try {
        const data = JSON.parse(text);
        const arr = Array.isArray(data) ? data : Object.values(data);
        for (const r of arr) {
          if (!r || typeof r !== "object") continue;
          const p = String(r.LocalPort || r.port || "").trim();
          if (!p || !/^\d+$/.test(p)) continue;
          const addr = String(r.LocalAddress || r.ip || "0.0.0.0").trim();
          const pid = String(r.OwningProcess || r.pid || "").trim();
          out.push({ port: p, address: addr, pid, state: "LISTEN" });
        }
      } catch (_) {}
    } else if (text.includes("local_address") && text.includes("rem_address")) {
      const lines = text.split(/\r?\n/);
      for (let i = 1; i < lines.length; i++) {
        const f = lines[i].trim().split(/\s+/);
        if (f.length < 4 || f[3].toUpperCase() !== "0A") continue;
        const lp = f[1].split(":");
        if (lp.length < 2) continue;
        const pNum = parseInt(lp[1], 16);
        if (pNum > 0) out.push({ port: String(pNum), address: "0.0.0.0", pid: "", state: "LISTEN" });
      }
    } else {
      for (const line of text.split(/\r?\n/)) {
        const f = line.split("\t");
        const p = (f[0] || "").trim();
        if (!p || !/^\d+$/.test(p)) continue;
        const addr = (f[1] || "").trim() || "0.0.0.0";
        const pid = (f[2] || "").trim();
        const state = (f[3] || "").trim() || "LISTEN";
        out.push({ port: p, address: addr, pid, state });
      }
    }
    const dedup = {};
    for (const item of out) {
      const p = item.port;
      if (!dedup[p] || (dedup[p].address.includes(":") && !item.address.includes(":"))) {
        dedup[p] = item;
      }
    }
    return Object.values(dedup).sort((a, b) => (parseInt(a.port, 10) || 0) - (parseInt(b.port, 10) || 0));
  }

  function collectInventoryFromItems(host, items) {
    const templates = host.parentTemplates || [];
    const byKey = {};
    (items || []).forEach((it) => { byKey[it.key_ || ""] = it; });

    const uname = (byKey["system.uname"] || {}).lastvalue || "";
    const osName = (byKey["system.sw.os"] || byKey["system.sw.os[name]"] || {}).lastvalue || "";
    const family = detectOsFamily(templates, items, uname, `${host.host || ""} ${host.name || ""}`);

    const software = [];
    const services = [];
    const processes = [];
    const ports = [];
    const source = { software: null, services: null, processes: null, ports: null };

    for (const it of items || []) {
      if (String(it.status || "0") !== "0" || !it.lastvalue) continue;
      const k = it.key_ || "";
      const kl = k.toLowerCase();
      if (kl.startsWith("system.sw.packages") || (kl.startsWith("registry.get[") && kl.includes("uninstall")) || kl.startsWith("system.run[lslpp")) {
        const parsed = parseSoftwareRaw(it.lastvalue, k);
        if (parsed.length) {
          software.push(...parsed);
          source.software = "zabbix";
        }
      } else if (kl === "service.discovery" || (kl.startsWith("wmi.getall[") && kl.includes("win32_service")) || (kl.startsWith("vfs.dir.get[") && kl.includes(".service"))) {
        const parsed = parseServicesRaw(it.lastvalue);
        if (parsed.length) {
          services.push(...parsed);
          source.services = "zabbix";
        }
      } else if (kl.startsWith("proc.get[") || kl.startsWith("system.run[ps ")) {
        const parsed = parseProcessesRaw(it.lastvalue);
        if (parsed.length) {
          processes.push(...parsed);
          source.processes = "zabbix";
        }
      } else if ((kl.startsWith("wmi.getall[") && kl.includes("msft_nettcpconnection")) || kl.startsWith("vfs.file.contents[/proc/net/tcp")) {
        const parsed = parsePortsRaw(it.lastvalue);
        if (parsed.length) {
          ports.push(...parsed);
          source.ports = "zabbix";
        }
      }
    }

    const notes = [];
    if (!uname) {
      notes.push(`OS (${family.toUpperCase()}) ประเมินจาก template หรือชื่อเครื่อง`);
    }
    if (!source.software && !source.services && !source.processes && !source.ports) {
      notes.push("ประเมินจากรายการ Items และ Templates บน Zabbix (กด 'เก็บ Inventory ผ่าน Zabbix' หากต้องการดึงรายชื่อ Software ทั้งหมดจากเครื่อง)");
    }

    const iface = (host.interfaces || []).find((i) => String(i.type) === "1") || (host.interfaces || [])[0];
    const addr = iface ? `${iface.ip || iface.dns || ""}:${iface.port || "10050"}` : "";

    return {
      os_family: family,
      os_name: osName || (uname ? uname.split("\n")[0].slice(0, 120) : ""),
      uname: uname.slice(0, 300),
      software,
      services,
      processes,
      ports,
      source,
      errors: [],
      notes,
      agent_address: addr,
      collected_at: fmtClock(Math.floor(Date.now() / 1000))
    };
  }

  function resolveTemplate(names, keywords, allTemplates) {
    const byName = {};
    (allTemplates || []).forEach((t) => { byName[String(t.name || "").toLowerCase()] = t; });
    for (const n of names || []) {
      const t = byName[n.toLowerCase()];
      if (t) return t;
    }
    for (const kw of keywords || []) {
      const kwLow = kw.toLowerCase();
      for (const t of allTemplates || []) {
        if (String(t.name || "").toLowerCase().includes(kwLow)) return t;
      }
    }
    return null;
  }

  function summarizeChecks(checks) {
    const total = checks.length;
    const mon = checks.filter((c) => c.status === MONITORED).length;
    const nr = checks.filter((c) => c.status === NOT_REQUIRED).length;
    const nm = total - mon - nr;
    const denom = total - nr;
    const pct = denom > 0 ? Math.round((mon * 100) / denom) : null;
    const configured = checks.filter((c) => c.status === MONITORED);
    const healthy = configured.filter((c) => !c.issue).length;
    const health_pct = configured.length ? Math.round((healthy * 100) / configured.length) : null;
    return { total, monitored: mon, not_monitored: nm, not_required: nr, pct, healthy, health_pct, checks };
  }

  function evaluateCompliance(host, items, templates, inventory, allTemplates, settings, waivers) {
    const nowSec = Math.floor(Date.now() / 1000);
    const family = inventory.os_family || "linux";
    const linkedNames = (templates || []).map((t) => t.name || "");
    const linkedLower = linkedNames.map((n) => n.toLowerCase());
    const osChecks = [];

    for (const spec of OS_CHECKS) {
      const cands = (items || []).filter((it) => spec._rx.some((rx) => rx.test(it.key_ || "")));
      const best = pickBest(cands, nowSec);
      let [status, issue] = statusFromItem(best, nowSec);
      const required = spec.required[family] !== undefined ? spec.required[family] : true;
      let reason = "";
      if (status !== MONITORED && !required) {
        status = NOT_REQUIRED;
        reason = "ไม่บังคับสำหรับ OS นี้ตามมาตรฐาน";
      } else if (status === NOT_MONITORED) {
        reason = ISSUE_TEXT[issue] || "ไม่มี item ตามมาตรฐาน";
      } else if (issue) {
        reason = ISSUE_TEXT[issue] || "";
      }

      const addSpec = spec.add ? (spec.add[family] || spec.add["*"]) : null;
      const osTpl = resolveTemplate(OS_TEMPLATES[family] || [], [], allTemplates);
      let action = null;
      if (status === NOT_MONITORED) {
        if (addSpec) {
          action = { type: "add_item", check_id: spec.id, label: `เพิ่ม ${addSpec.key}` };
        } else if (osTpl) {
          action = { type: "link_template", templateid: osTpl.templateid, name: osTpl.name, label: `ผูก ${osTpl.name}` };
        } else {
          action = { type: "none", label: "ต้องใช้ OS template" };
        }
      }

      const check = {
        check_key: `os:${spec.id}`, section: "os", id: spec.id, kind: "os",
        name: spec.name, category: spec.category, status, issue, reason,
        expected: addSpec ? addSpec.key : (spec.expected || ""),
        actual: best ? (best.key_ || "") : "",
        item_name: best ? (best.name || "") : "",
        itemid: best ? best.itemid : null,
        lastvalue: best ? (best.lastvalue || "") : "",
        units: best ? (best.units || "") : "",
        lastclock: best ? fmtClock(best.lastclock) : "",
        error: best ? (best.error || "") : "",
        action,
        waivable: status === NOT_MONITORED
      };
      const w = waivers[check.check_key];
      if (w && check.status !== MONITORED) {
        check.status = NOT_REQUIRED;
        check.waived = true;
        check.reason = `Waiver: ${w.reason || ""} (${w.at || ""})`;
      }
      osChecks.push(check);
    }

    // Service & Process items index
    const svcItems = {};
    const procItems = {};
    for (const it of items || []) {
      const [knameRaw, params] = parseKeyParams(it.key_ || "");
      const kname = knameRaw.toLowerCase();
      if ((kname === "service.info" || kname === "service_state") && params[0]) {
        const k = params[0].toLowerCase();
        if (!svcItems[k]) svcItems[k] = [];
        svcItems[k].push(it);
      } else if (["proc.num", "proc_info", "proc.mem", "proc.cpu.util"].includes(kname) && params.length) {
        if (params[0]) {
          const k = normProc(params[0]);
          if (!procItems[k]) procItems[k] = [];
          procItems[k].push(it);
        }
        if (params.length > 3 && params[3]) {
          const k = normProc(params[3]);
          if (!procItems[k]) procItems[k] = [];
          procItems[k].push(it);
        }
      }
    }

    const invServices = inventory.services || [];
    const invProcesses = inventory.processes || [];
    const invSoftware = inventory.software || [];
    const hasServices = Boolean(inventory.source?.services);
    const hasProcesses = Boolean(inventory.source?.processes);
    const svcIndex = {};
    invServices.forEach((s) => { svcIndex[String(s.name || "").toLowerCase()] = s; });
    const procIndex = {};
    invProcesses.forEach((p) => { procIndex[normProc(p.name)] = p; });
    const isWin = family === "windows";
    const usedItemIds = new Set();

    function serviceItemFor(names, kind) {
      const pool = kind === "service" ? svcItems : procItems;
      let cands = [];
      for (const n of names) {
        const key = kind === "service" ? n.toLowerCase() : normProc(n);
        if (pool[key]) cands = cands.concat(pool[key]);
      }
      cands.forEach((it) => usedItemIds.add(it.itemid));
      return pickBest(cands, nowSec);
    }

    const serviceChecks = [];
    const seenServiceKeys = new Set();

    function addServiceCheck(cid, names, display, kind, origin, required = true) {
      let nameList = names.slice();
      if (kind === "service" && display && !nameList.includes(display)) {
        nameList.push(display);
      }
      let presentName = null;
      let presentObj = null;
      for (const n of nameList) {
        const obj = kind === "service" ? svcIndex[n.toLowerCase()] : procIndex[normProc(n)];
        if (obj) {
          presentName = obj.name || n;
          presentObj = obj;
          break;
        }
      }
      const target = presentName || nameList[0];
      const dedup = `${kind}:${kind === "service" ? target.toLowerCase() : normProc(target)}`;
      if (seenServiceKeys.has(dedup)) return;
      seenServiceKeys.add(dedup);

      const best = serviceItemFor(nameList, kind);
      let [status, issue] = statusFromItem(best, nowSec);
      const invKnown = kind === "service" ? hasServices : hasProcesses;
      let reason = "";
      let state = "";
      if (presentObj) {
        state = kind === "service" ? (presentObj.state || "") : `${presentObj.count || 1} process`;
      }
      if (status !== MONITORED) {
        if (!required) {
          status = NOT_REQUIRED;
          reason = "ไม่บังคับตามมาตรฐาน";
        } else if (invKnown && !presentObj) {
          status = NOT_REQUIRED;
          reason = "ไม่พบบนเครื่อง";
        } else if (kind === "service" && presentObj && presentObj.startup === "disabled") {
          status = NOT_REQUIRED;
          reason = "Service ถูกตั้งเป็น Disabled";
        } else {
          reason = ISSUE_TEXT[issue] || "ยังไม่ได้ Monitor";
          if (!invKnown) reason += " (ยังไม่ยืนยันว่ามีบนเครื่อง)";
        }
      } else if (issue) {
        reason = ISSUE_TEXT[issue] || "";
      }

      let key = kind === "service"
        ? `service.info[${target},state]`
        : `proc.num[${!isWin ? normProc(target) : target}]`;
      if (kind === "process" && isWin && !target.toLowerCase().endsWith(".exe")) {
        key = `proc.num[${target}.exe]`;
      }
      if (best && best.key_) key = best.key_;

      const check = {
        check_key: `service:${dedup}`, section: "service", id: cid, kind,
        name: display, category: origin, status, issue, reason,
        expected: key, actual: best ? (best.key_ || "") : "",
        itemid: best ? best.itemid : null,
        lastvalue: best ? (best.lastvalue || "") : "", units: "",
        lastclock: best ? fmtClock(best.lastclock) : "",
        error: best ? (best.error || "") : "", state,
        action: status === NOT_MONITORED ? { type: "add_service", name: target, display_name: display, kind, key, label: "Add Monitor" } : null,
        waivable: status === NOT_MONITORED
      };
      const w = waivers[check.check_key];
      if (w && check.status !== MONITORED) {
        check.status = NOT_REQUIRED;
        check.waived = true;
        check.reason = `Waiver: ${w.reason || ""} (${w.at || ""})`;
      }
      serviceChecks.push(check);
    }

    const baseKind = isWin ? "service" : "process";
    for (const b of BASELINE_SERVICES[family] || []) {
      addServiceCheck(b.id, b.names, b.display, baseKind, "Baseline");
    }

    // Software checks
    const softwareChecks = [];
    const matchedSwNames = new Set();

    for (const cat of SOFTWARE_CATALOG) {
      const hits = invSoftware.filter((sw) => {
        const low = String(sw.name || "").trim().toLowerCase();
        return cat._inc.some((rx) => rx.test(low)) && !cat._exc.some((rx) => rx.test(low));
      });
      const svcHits = invServices.filter((s) => cat._svc.some((rx) => rx.test(String(s.name || "").toLowerCase())));
      const catProcs = new Set((cat.processes || []).map(normProc));
      const procHits = invProcesses.filter((p) => catProcs.has(normProc(p.name)));
      const itemSvcHits = Object.keys(svcItems).filter((n) => cat._svc.some((rx) => rx.test(n)));
      const itemProcHits = Object.keys(procItems).filter((n) => catProcs.has(n));

      if (!hits.length && !svcHits.length && !procHits.length && !itemSvcHits.length && !itemProcHits.length) {
        continue;
      }
      hits.forEach((h) => matchedSwNames.add(String(h.name || "").toLowerCase()));

      const evidence = [];
      if (hits.length) evidence.push("installed: " + hits.slice(0, 3).map((h) => h.name).join(", "));
      if (svcHits.length || itemSvcHits.length) {
        const names = Array.from(new Set([...svcHits.map((s) => s.name), ...itemSvcHits])).slice(0, 3);
        evidence.push("service: " + names.join(", "));
      }
      if (procHits.length || itemProcHits.length) {
        const names = Array.from(new Set([...procHits.map((p) => p.name), ...itemProcHits])).slice(0, 3);
        evidence.push("process: " + names.join(", "));
      }
      const version = (hits.find((h) => h.version) || {}).version || "";

      const linkedTpl = linkedNames.find((ln, idx) => {
        const low = linkedLower[idx];
        return (cat.templates || []).some((t) => t.toLowerCase() === low) ||
               (cat.template_keywords || []).some((kw) => low.includes(kw.toLowerCase()));
      }) || "";

      const appItems = (items || []).filter((it) => cat._items.some((rx) => rx.test(it.key_ || "")));
      const bestAppItem = pickBest(appItems, nowSec);
      const expectedTpl = resolveTemplate(cat.templates || [], cat.template_keywords || [], allTemplates);

      let status = NOT_MONITORED;
      let actual = "";
      let reason = "";
      let issue = null;

      if (linkedTpl) {
        status = MONITORED;
        actual = linkedTpl;
        reason = "ผูก Template แล้ว";
      } else if (bestAppItem && !["disabled", "unsupported"].includes(itemHealth(bestAppItem, nowSec))) {
        status = MONITORED;
        actual = bestAppItem.key_ || "";
        issue = itemHealth(bestAppItem, nowSec);
        reason = "มี application items" + (issue ? ` (${ISSUE_TEXT[issue]})` : "");
      } else if (!cat.required) {
        status = NOT_REQUIRED;
        reason = "ไม่บังคับตามมาตรฐาน";
      } else {
        status = NOT_MONITORED;
        reason = "ยังไม่ผูก Template ของ software นี้";
        if (!expectedTpl && !(cat.templates || []).length) {
          reason = "ไม่มี Template มาตรฐาน ให้ Monitor ผ่าน service/process";
        }
      }

      let action = null;
      if (status === NOT_MONITORED) {
        if (expectedTpl) {
          action = { type: "link_template", templateid: expectedTpl.templateid, name: expectedTpl.name, label: `ผูก ${expectedTpl.name}` };
        } else if ((cat.templates || []).length) {
          action = { type: "none", label: `ไม่พบ Template '${cat.templates[0]}' บน Zabbix` };
        }
      }

      const check = {
        check_key: `software:${cat.id}`, section: "software", id: cat.id, kind: "software",
        name: cat.name, category: cat.kind, status, issue, reason,
        version, evidence: evidence.join("; "),
        expected: expectedTpl ? expectedTpl.name : ((cat.templates || [])[0] || "service/process"),
        actual, lastvalue: "", units: "", lastclock: "", error: "",
        action, waivable: status === NOT_MONITORED
      };
      const w = waivers[check.check_key];
      if (w && check.status !== MONITORED) {
        check.status = NOT_REQUIRED;
        check.waived = true;
        check.reason = `Waiver: ${w.reason || ""} (${w.at || ""})`;
      }
      softwareChecks.push(check);
    }

    // Existing monitored service/process items on the host
    if (isWin) {
      for (const [name, its] of Object.entries(svcItems)) {
        if (its.every((it) => usedItemIds.has(it.itemid))) continue;
        const raw = parseKeyParams(its[0].key_)[1][0] || name;
        const label = String(its[0].name || raw).replace(/^(state of service|status of service)\s+/i, "");
        addServiceCheck(`existing:${name}`, [raw], label, "service", "Existing item");
      }
    }
    for (const [name, its] of Object.entries(procItems)) {
      if (name && !its.every((it) => usedItemIds.has(it.itemid))) {
        addServiceCheck(`existing:${name}`, [name], its[0].name || name, "process", "Existing item");
      }
    }

    const osSum = summarizeChecks(osChecks);
    const svcSum = summarizeChecks(serviceChecks);
    svcSum.others = [];
    const swSum = summarizeChecks(softwareChecks);
    swSum.other_installed = Math.max(0, invSoftware.length - matchedSwNames.size);

    const allChecks = [...osChecks, ...serviceChecks, ...softwareChecks];
    const overall = summarizeChecks(allChecks);
    delete overall.checks;

    const pct = overall.pct;
    let verdict;
    if (pct === null) verdict = { status: "N/A", label: "ไม่มีรายการให้ประเมิน" };
    else if (pct >= settings.pass_threshold) verdict = { status: "PASS", label: "พร้อมตามมาตรฐาน" };
    else if (pct >= settings.warn_threshold) verdict = { status: "PARTIAL", label: "พร้อมบางส่วน" };
    else verdict = { status: "FAIL", label: "ยังไม่พร้อมตามมาตรฐาน" };

    const healthIssues = [];
    for (const it of items || []) {
      const iss = itemHealth(it, nowSec);
      if (iss && iss !== "disabled") {
        healthIssues.push({
          itemid: it.itemid, name: it.name, key: it.key_,
          issue: iss, issue_text: ISSUE_TEXT[iss],
          error: it.error || "", lastclock: fmtClock(it.lastclock)
        });
      }
    }

    const osTplLinked = linkedNames.filter((n) => (OS_TEMPLATE_KEYWORDS[family] || []).some((kw) => n.toLowerCase().includes(kw)));
    const recOsTpl = resolveTemplate(OS_TEMPLATES[family] || [], [], allTemplates);

    return {
      host: {
        hostid: host.hostid, host: host.host, name: host.name,
        status: host.status, description: host.description || "",
        proxy_name: host.proxy_name || "",
        zbx_connected: host.zbx_connected || "unknown",
        zbx_error: host.zbx_error || "",
        groups: (host.groups || []).map((g) => ({ groupid: g.groupid, name: g.name })),
        interfaces: (host.interfaces || []).map((i) => ({
          ip: i.ip, dns: i.dns, port: i.port, type: i.type, main: i.main, useip: i.useip
        })),
        parentTemplates: (host.parentTemplates || []).map((t) => ({ templateid: t.templateid, name: t.name })),
        macros: (host.macros || []).map((m) => ({
          hostmacroid: m.hostmacroid || "",
          macro: m.macro || "",
          value: String(m.type || "0") === "1" && m.value === undefined ? "******" : (m.value || ""),
          description: m.description || "",
          type: String(m.type || "0")
        }))
      },
      os_family: family,
      os_name: inventory.os_name || "",
      templates: (templates || []).map((t) => ({ templateid: t.templateid, name: t.name })),
      os_template: {
        linked: osTplLinked,
        recommended: recOsTpl ? recOsTpl.name : ((OS_TEMPLATES[family] || [""])[0]),
        recommended_id: recOsTpl ? recOsTpl.templateid : null
      },
      inventory: {
        source: inventory.source,
        confidence: (inventory.source.software || inventory.source.services || inventory.source.processes) ? "partial" : "estimated",
        errors: inventory.errors || [],
        software_count: invSoftware.length,
        services_count: invServices.length,
        processes_count: invProcesses.length,
        ports_count: (inventory.ports || []).length,
        collected_at: inventory.collected_at,
        notes: inventory.notes || [],
        agent_address: inventory.agent_address || ""
      },
      template_mismatch: [],
      sections: { os: osSum, service: svcSum, software: swSum },
      overall,
      verdict,
      health: { count: healthIssues.length, issues: healthIssues.slice(0, 300) },
      items_total: (items || []).length,
      settings: { pass_threshold: settings.pass_threshold, warn_threshold: settings.warn_threshold },
      generated_at: fmtClock(nowSec)
    };
  }

  function buildSoftwareInventoryRows(inventory, items, linkedTemplates, allTemplates) {
    const invSoftware = inventory.software || [];
    const invServices = inventory.services || [];
    const invProcesses = inventory.processes || [];
    const invPorts = inventory.ports || [];
    const linkedLower = (linkedTemplates || []).map((t) => String(t.name || "").toLowerCase());

    const monServices = {};
    const monProcs = {};
    const monPorts = {};

    for (const it of items || []) {
      const [knameRaw, params] = parseKeyParams(it.key_ || "");
      const kl = knameRaw.toLowerCase();
      if ((kl === "service.info" || kl === "service_state") && params[0]) {
        const k = params[0].toLowerCase();
        if (!monServices[k]) monServices[k] = it;
      } else if (kl.startsWith("proc.num") || ["proc.mem", "proc.cpu.util", "proc_info"].includes(kl)) {
        if (params[0]) {
          const k = normProc(params[0]);
          if (!monProcs[k]) monProcs[k] = it;
        }
        if (params.length > 3 && params[3]) {
          const k = normProc(params[3]);
          if (!monProcs[k]) monProcs[k] = it;
        }
      } else if (["net.tcp.port", "net.tcp.listen", "net.tcp.service"].includes(kl)) {
        let p = "";
        if (kl === "net.tcp.port" && params.length > 1 && params[1]) p = params[1];
        else if (kl === "net.tcp.service" && params.length > 2 && params[2]) p = params[2];
        else if (params[0]) p = params[0];
        if (p && !monPorts[String(p).trim()]) monPorts[String(p).trim()] = it;
      }
    }

    function catalogFor(name, svcName = "", procName = "") {
      const low = String(name || "").toLowerCase();
      for (const cat of SOFTWARE_CATALOG) {
        if (low && cat._inc.some((rx) => rx.test(low)) && !cat._exc.some((rx) => rx.test(low))) return cat;
        if (svcName && cat._svc.some((rx) => rx.test(svcName.toLowerCase()))) return cat;
        if (procName && (cat.processes || []).some((x) => normProc(x) === normProc(procName))) return cat;
      }
      return null;
    }

    function expectedFor(cat, kind, svcName, procName) {
      if (cat) {
        const tpl = resolveTemplate(cat.templates || [], cat.template_keywords || [], allTemplates);
        if (tpl) return [tpl.name, tpl];
        if ((cat.templates || []).length) return [`${cat.templates[0]} (ไม่มีบน Zabbix)`, null];
      }
      if (kind === "Service") return [`service.info[${svcName},state]`, null];
      if (kind === "Process") return [`proc.num[${procName}]`, null];
      return ["", null];
    }

    const rows = [];
    const seen = new Set();

    function addRow(kind, name, version, svcName = "", procName = "", state = "", startup = "") {
      if (!name) return;
      const key = `${kind}:${(svcName || procName || name).toLowerCase()}`;
      if (seen.has(key)) return;
      seen.add(key);

      const cat = catalogFor(kind === "Software" ? name : "", svcName, procName);
      const [expected, expTpl] = expectedFor(cat, kind, svcName, procName);
      let status = NOT_MONITORED;
      let template = "";
      let itemName = "";
      let itemKey = "";
      let lastclock = 0;

      let it = null;
      if (kind === "Service") {
        it = monServices[(svcName || "").toLowerCase()] || monServices[name.toLowerCase()];
      } else if (kind === "Process") {
        it = monProcs[normProc(procName)];
      }
      if (it) {
        const enabled = String(it.status || "0") === "0" && String(it.state || "0") === "0";
        status = enabled ? MONITORED : NOT_MONITORED;
        template = it._template || (String(it.templateid || "0") !== "0" ? "Template" : "Host (สร้างบน host)");
        itemName = it.name || "";
        itemKey = it.key_ || "";
        lastclock = parseInt(it.lastclock || "0", 10) || 0;
      }

      if (status !== MONITORED && cat) {
        for (let idx = 0; idx < linkedLower.length; idx++) {
          const ln = linkedLower[idx];
          if ((cat.templates || []).some((t) => t.toLowerCase() === ln) ||
              (cat.template_keywords || []).some((kw) => ln.includes(kw.toLowerCase()))) {
            status = MONITORED;
            template = linkedTemplates[idx].name || "";
            itemName = itemName || "(items ทั้งหมดของ template)";
            break;
          }
        }
        if (status !== MONITORED) {
          const appItems = (items || []).filter((x) => cat._items.some((rx) => rx.test(x.key_ || "")));
          if (appItems.length) {
            status = MONITORED;
            template = appItems[0]._template || "Template";
            itemName = appItems[0].name || "";
            itemKey = appItems[0].key_ || "";
            lastclock = parseInt(appItems[0].lastclock || "0", 10) || 0;
          }
        }
      }

      let action = null;
      if (status !== MONITORED) {
        if (expTpl) action = { type: "link_template", templateid: expTpl.templateid, name: expTpl.name };
        else if (kind === "Service" && svcName) action = { type: "add_service", name: svcName, display_name: name, key: `service.info[${svcName},state]` };
        else if (kind === "Process" && procName) action = { type: "add_service", name: procName, display_name: procName, key: `proc.num[${procName}]` };
      }

      rows.push({
        name, kind, version: version || "", state: state || "", startup: startup || "",
        service_name: svcName, expected: expected || "-", template, item: itemName,
        item_key: itemKey, status, action, last_checked: fmtClock(lastclock),
        category: cat ? cat.kind : ""
      });
    }

    const kernelPrefixes = ["kworker/", "ksoftirqd/", "migration/", "rcu_", "cpuhp/", "irq/", "scsi_", "ext4-", "jbd2/"];
    const kernelNames = new Set(["kthreadd", "pool_workqueue_release", "mm_percpu_wq", "kdevtmpfs", "netns", "kauditd", "khungtaskd", "oom_reaper", "writeback", "kcompactd0", "ksmd", "khugepaged", "kintegrityd", "kblockd", "blkcg_punt_bio", "tpm_dev_wq", "ata_sff", "md", "edac-poller", "devfreq_wq", "watchdogd", "kswapd0"]);

    for (const sw of invSoftware) addRow("Software", sw.name, sw.version);
    for (const sv of invServices) addRow("Service", sv.display_name || sv.name, "", sv.name, "", sv.state, sv.startup);
    for (const pr of invProcesses) {
      const pn = (pr.name || "").trim();
      if (!pn) continue;
      const pnl = pn.toLowerCase();
      if (kernelNames.has(pnl) || kernelPrefixes.some((px) => pnl.startsWith(px))) continue;
      addRow("Process", pn, "", "", pn, `${pr.count || 1} process`);
    }
    for (const [sname, it] of Object.entries(monServices)) {
      const raw = parseKeyParams(it.key_)[1][0] || sname;
      const disp = String(it.name || sname).replace(/^(state|status) of service\s+/i, "");
      addRow("Service", disp, "", raw, "");
    }
    for (const [pname] of Object.entries(monProcs)) {
      addRow("Process", pname, "", "", pname);
    }

    const wellKnownPorts = {
      "21": "FTP", "22": "SSH", "25": "SMTP", "53": "DNS", "80": "HTTP / Web",
      "110": "POP3", "135": "MS RPC", "139": "NetBIOS", "143": "IMAP", "389": "LDAP",
      "443": "HTTPS / SSL", "445": "SMB", "636": "LDAPS", "1433": "SQL Server",
      "1521": "Oracle DB", "3306": "MySQL / MariaDB", "3389": "Remote Desktop (RDP)",
      "5432": "PostgreSQL", "5672": "RabbitMQ", "5985": "WinRM HTTP", "5986": "WinRM HTTPS",
      "6379": "Redis", "8000": "HTTP App", "8080": "HTTP Proxy / Tomcat", "8443": "HTTPS Alt",
      "9000": "App / PHP-FPM", "9200": "Elasticsearch HTTP", "9300": "Elasticsearch Transport",
      "10050": "Zabbix Agent", "10051": "Zabbix Server / Trapper", "10052": "Zabbix Java Gateway",
      "27017": "MongoDB", "33060": "MySQL X Protocol"
    };
    const seenPorts = new Set();
    for (const pt of invPorts) {
      const pStr = String(pt.port || "").trim();
      if (!pStr || seenPorts.has(pStr)) continue;
      seenPorts.add(pStr);
      const addr = pt.address || "0.0.0.0";
      const hint = wellKnownPorts[pStr] || "";
      const label = `TCP Port ${pStr}${hint ? ` (${hint})` : ""}`;
      const it = monPorts[pStr];
      if (it) {
        const enabled = String(it.status || "0") === "0" && String(it.state || "0") === "0";
        const status = enabled ? MONITORED : NOT_MONITORED;
        rows.push({
          name: label, kind: "Port", version: "", state: `${addr}:${pStr} · LISTEN`,
          startup: "", service_name: pStr, expected: `net.tcp.port[,${pStr}]`,
          template: it._template || "Host (สร้างบน host)",
          item: it.name || `TCP Port ${pStr} state`,
          item_key: it.key_ || `net.tcp.port[,${pStr}]`,
          status,
          action: status === MONITORED ? null : { type: "add_port", port: pStr, name: label, key: `net.tcp.port[,${pStr}]` },
          last_checked: fmtClock(it.lastclock),
          category: "port"
        });
      } else {
        rows.push({
          name: label, kind: "Port", version: "", state: `${addr}:${pStr} · LISTEN`,
          startup: "", service_name: pStr, expected: `net.tcp.port[,${pStr}]`,
          template: "", item: "", item_key: "", status: NOT_MONITORED,
          action: { type: "add_port", port: pStr, name: label, key: `net.tcp.port[,${pStr}]` },
          last_checked: "", category: "port"
        });
      }
    }
    for (const [port, it] of Object.entries(monPorts)) {
      const pStr = String(port).trim();
      if (seenPorts.has(pStr)) continue;
      seenPorts.add(pStr);
      const enabled = String(it.status || "0") === "0" && String(it.state || "0") === "0";
      const status = enabled ? MONITORED : NOT_MONITORED;
      rows.push({
        name: `TCP Port ${pStr}`, kind: "Port", version: "", state: "Listening",
        startup: "", service_name: pStr, expected: `net.tcp.port[,${pStr}]`,
        template: it._template || "Host (สร้างบน host)",
        item: it.name || `TCP Port ${pStr} state`,
        item_key: it.key_ || `net.tcp.port[,${pStr}]`,
        status,
        action: status === MONITORED ? null : { type: "add_port", port: pStr, name: `TCP Port ${pStr}`, key: `net.tcp.port[,${pStr}]` },
        last_checked: fmtClock(it.lastclock),
        category: "port"
      });
    }

    const order = { [MONITORED]: 0, [NOT_MONITORED]: 1 };
    const kindOrder = { Software: 0, Service: 1, Process: 2, Port: 3 };
    rows.sort((a, b) => (order[a.status] ?? 2) - (order[b.status] ?? 2) || (kindOrder[a.kind] ?? 4) - (kindOrder[b.kind] ?? 4) || a.name.localeCompare(b.name));
    return rows;
  }

  // =========================================================================
  // 5. Client-Side Report Builder (HTML / Print-PDF / CSV / JSON)
  // =========================================================================
  function escHtml(s) {
    return String(s ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function buildReportHtml(reports, meta) {
    const total = reports.length;
    const generated = meta.generated_at || fmtClock(Math.floor(Date.now() / 1000));
    const title = meta.title || "Monitoring Readiness Report";
    const thresholds = reports[0]?.settings || { pass_threshold: 100, warn_threshold: 80 };
    const verdictCls = { PASS: "ok", PARTIAL: "warn", FAIL: "bad", "N/A": "na" };
    const statusCls = { Monitored: "ok", "Not Monitored": "bad", "Not Required": "na" };

    const combineSec = (a, b) => {
      const tot = a.total + b.total;
      const mon = a.monitored + b.monitored;
      const nm = a.not_monitored + b.not_monitored;
      const nr = a.not_required + b.not_required;
      const den = tot - nr;
      return { total: tot, monitored: mon, not_monitored: nm, not_required: nr, pct: den > 0 ? Math.round((mon * 100) / den) : null };
    };

    const pctTxt = (p) => (p === null || p === undefined ? "—" : `${p}%`);

    let summaryHtml = "";
    if (total > 1) {
      const passed = reports.filter((r) => r.verdict.status === "PASS").length;
      const rows = reports.map((r, i) => {
        const sw = combineSec(r.sections.service, r.sections.software);
        return `<tr><td>${i + 1}</td><td>${escHtml(r.host.name)}</td><td>${escHtml(r.os_family.toUpperCase())}</td>
          <td>${pctTxt(r.sections.os.pct)}</td><td>${pctTxt(sw.pct)}</td>
          <td><b>${pctTxt(r.overall.pct)}</b></td>
          <td><span class="tag ${verdictCls[r.verdict.status] || "na"}">${escHtml(r.verdict.status)}</span></td></tr>`;
      }).join("");
      summaryHtml = `<section class="summary"><h2>Summary — ${total} hosts · PASS ${passed} / ${total}</h2>
        <table class="grid"><thead><tr><th>#</th><th>Host</th><th>OS</th><th>OS Monitoring</th><th>Software Monitoring</th><th>Overall</th><th>Verdict</th></tr></thead>
        <tbody>${rows}</tbody></table></section>`;
    }

    const hostBlocks = reports.map((r, idx) => {
      const h = r.host;
      const s = r.sections;
      const swAll = combineSec(s.service, s.software);
      const v = r.verdict;
      const iface = (h.interfaces || []).find((i) => String(i.type) === "1") || (h.interfaces || [{}])[0] || {};
      const groups = (h.groups || []).map((g) => g.name).join(", ");
      const tpl = (r.templates || []).map((t) => t.name).join(", ") || "—";

      const renderSecTable = (key, titleText, sec) => {
        const heads = key === "os"
          ? ["Category", "Metric", "Standard item", "Zabbix item", "Last value", "Last check"]
          : key === "service"
            ? ["Type", "Service / Process", "Source", "Zabbix item", "State", "Last check"]
            : ["Type", "Software", "Version", "Expected template", "Monitored by", "Evidence"];
        const th = ["#", ...heads, "Status"].map((x) => `<th>${escHtml(x)}</th>`).join("");
        const trs = (sec.checks || []).map((c, i) => {
          const val = key === "os" ? `${c.lastvalue || ""}${c.units && c.lastvalue ? " " + c.units : ""}`.trim() : "";
          const cols = key === "os"
            ? [c.category, c.name, c.expected || "", c.actual || "-", val || "-", c.lastclock || "-"]
            : key === "service"
              ? [c.kind || "", c.name, c.category || "", c.actual || c.expected || "", c.state || "-", c.lastclock || "-"]
              : [c.category || "", c.name, c.version || "-", c.expected || "-", c.actual || "-", c.evidence || "-"];
          return `<tr><td class="num">${i + 1}</td>${cols.map((col) => `<td>${escHtml(col)}</td>`).join("")}
            <td><span class="tag ${statusCls[c.status] || "na"}">${escHtml(c.status)}</span>${c.reason ? `<div class="note">${escHtml(c.reason)}</div>` : ""}</td></tr>`;
        }).join("") || `<tr><td colspan="8" class="muted center">ไม่มีรายการ</td></tr>`;
        return `<h3>${escHtml(titleText)} <span class="pill">${pctTxt(sec.pct)}</span></h3>
          <table class="grid"><thead><tr>${th}</tr></thead><tbody>${trs}</tbody></table>`;
      };

      return `<section class="host" ${idx > 0 ? 'style="page-break-before:always"' : ""}>
        <div class="host-head">
          <div>
            <div class="eyebrow">HOST ${idx + 1} / ${total}</div>
            <h2>${escHtml(h.name || h.host)}</h2>
            <div class="muted">${escHtml(h.host)} · Zabbix ID ${escHtml(h.hostid)} ${h.proxy_name ? `· Proxy: ${escHtml(h.proxy_name)}` : ""}</div>
          </div>
          <div class="verdict ${verdictCls[v.status] || "na"}">
            <div class="v-status">${escHtml(v.status)}</div><div class="v-label">${escHtml(v.label)}</div>
            <div class="v-pct">${pctTxt(r.overall.pct)}</div>
          </div>
        </div>
        <table class="meta">
          <tr><th>IP / Interface</th><td>${escHtml(iface.ip || iface.dns || "-")}:${escHtml(iface.port || "")}</td>
              <th>OS family</th><td>${escHtml(r.os_family.toUpperCase())} ${escHtml(r.os_name || "")}</td></tr>
          <tr><th>Host groups</th><td>${escHtml(groups || "-")}</td><th>Linked templates</th><td>${escHtml(tpl)}</td></tr>
        </table>
        ${renderSecTable("os", "OS Monitoring", s.os)}
        ${renderSecTable("service", "Service / Process Monitoring", s.service)}
        ${renderSecTable("software", "Software Monitoring", s.software)}
      </section>`;
    }).join("");

    return `<!DOCTYPE html><html lang="th"><head><meta charset="utf-8"><title>${escHtml(title)}</title>
    <style>
      @page { size: A4; margin: 12mm 10mm; }
      * { box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      body { margin: 0; font: 11px/1.45 "Segoe UI", "Tahoma", sans-serif; color: #1c2434; background: #fff; }
      .wrap { max-width: 1180px; margin: 0 auto; padding: 22px 26px; }
      header.doc { display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 3px solid #2f6fed; padding-bottom: 12px; margin-bottom: 14px; }
      header.doc h1 { margin: 0; font-size: 22px; }
      .eyebrow { font-size: 9.5px; letter-spacing: .12em; color: #6b7690; font-weight: 700; }
      .muted { color: #6b7690; } .center { text-align: center; }
      .doc-meta { text-align: right; font-size: 10px; color: #4b5670; }
      h2 { font-size: 17px; margin: 4px 0; }
      h3 { font-size: 13px; margin: 18px 0 6px; padding-bottom: 4px; border-bottom: 1px solid #e3e8f0; }
      .host-head { display: flex; justify-content: space-between; align-items: center; gap: 16px; margin: 6px 0 10px; }
      .verdict { min-width: 190px; text-align: center; border-radius: 12px; padding: 10px 14px; color: #fff; }
      .verdict.ok { background: #16a37f; } .verdict.warn { background: #d97706; } .verdict.bad { background: #dc3545; } .verdict.na { background: #8a94a8; }
      .v-status { font-size: 18px; font-weight: 800; } .v-label { font-size: 11px; } .v-pct { font-size: 24px; font-weight: 800; }
      table { border-collapse: collapse; width: 100%; }
      table.meta th { text-align: left; width: 16%; background: #f4f6fb; color: #4b5670; font-weight: 600; }
      table.meta td, table.meta th { border: 1px solid #e3e8f0; padding: 6px 8px; vertical-align: top; }
      table.grid th { background: #2f3b56; color: #fff; text-align: left; font-weight: 600; padding: 6px 7px; font-size: 10px; }
      table.grid td { border-bottom: 1px solid #e8ecf3; padding: 5px 7px; vertical-align: top; word-break: break-word; }
      table.grid tr:nth-child(even) td { background: #fafbfd; }
      td.num { color: #8a94a8; width: 26px; }
      .tag { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 9.5px; font-weight: 700; }
      .tag.ok { background: #dff5ec; color: #0f7a5c; } .tag.bad { background: #fde3e6; color: #b42335; }
      .tag.warn { background: #fff1d6; color: #9a5a00; } .tag.na { background: #eceff4; color: #5b657a; }
      .note { font-size: 9px; color: #6b7690; margin-top: 2px; }
      .pill { display: inline-block; background: #2f6fed; color: #fff; border-radius: 10px; padding: 1px 8px; font-size: 11px; margin-left: 6px; }
      .standard { margin: 16px 0; padding: 10px 12px; background: #f4f6fb; border-radius: 10px; font-size: 10px; color: #4b5670; }
      .print-bar { display: flex; justify-content: flex-end; gap: 10px; margin-bottom: 14px; }
      .print-btn { background: #2f6fed; color: #fff; border: none; padding: 8px 16px; border-radius: 8px; font-weight: 700; cursor: pointer; }
      @media print { .print-bar { display: none !important; } }
    </style></head><body><div class="wrap">
      <div class="print-bar"><button class="print-btn" onclick="window.print()">🖨️ Print / Save as PDF</button></div>
      <header class="doc">
        <div>
          <div class="eyebrow">MONITORING ZABBIX · EVIDENCE</div>
          <h1>${escHtml(title)}</h1>
          <div class="muted">${escHtml(meta.subtitle || "")}</div>
        </div>
        <div class="doc-meta">
          Generated: <b>${escHtml(generated)}</b><br>
          Zabbix: ${escHtml(meta.zabbix_url || "-")} (v${escHtml(meta.zabbix_version || "-")})<br>
          Prepared by: ${escHtml(meta.prepared_by || "-")}
        </div>
      </header>
      <div class="standard">
        <b>เกณฑ์ประเมิน:</b> Coverage = Monitored ÷ (Total − Not Required). PASS ≥ ${thresholds.pass_threshold}% · PARTIAL ≥ ${thresholds.warn_threshold}%.
      </div>
      ${summaryHtml}
      ${hostBlocks}
    </div></body></html>`;
  }

  function buildReportCsv(reports) {
    const rows = [["Host", "Zabbix ID", "OS", "Section", "Category", "Check", "Status", "Reason", "Expected", "Zabbix item / template", "Last value", "Last check", "Host overall %", "Verdict"]];
    const secTitles = { os: "OS Monitoring", service: "Service / Process Monitoring", software: "Software Monitoring" };
    for (const r of reports) {
      const h = r.host;
      for (const [k, sec] of Object.entries(r.sections)) {
        for (const c of sec.checks || []) {
          rows.push([
            h.name || "", h.hostid || "", r.os_family || "", secTitles[k] || k,
            c.category || "", c.name || "", c.status || "", c.reason || "",
            c.expected || "", c.actual || "", c.lastvalue || "", c.lastclock || "",
            r.overall.pct ?? "", r.verdict.status || ""
          ]);
        }
      }
    }
    const csvText = rows.map((r) => r.map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`).join(",")).join("\r\n");
    return "\ufeff" + csvText;
  }

  // =========================================================================
  // 6. Browser Engine State & Router
  // =========================================================================
  let activeClient = null;

  function saveBrowserSession(client) {
    if (!client || !client.authToken) return;
    writeStore(SESSION_KEY, {
      url: client.url,
      rawUrl: client.rawUrl,
      token: client.authToken,
      is_token: client.isApiToken,
      use_bearer: client.useBearer,
      version: client.apiVersion,
      user_info: client.userInfo
    });
  }

  function loadBrowserSession() {
    const s = readStore(SESSION_KEY, null);
    if (!s || !s.url || !s.token) return null;
    const c = new BrowserZabbixClient(s.rawUrl || s.url);
    c.url = s.url;
    c.authToken = s.token;
    c.isApiToken = Boolean(s.is_token);
    c.useBearer = Boolean(s.use_bearer);
    c.apiVersion = s.version || "7.0";
    c.userInfo = s.user_info || {};
    return c;
  }

  function clearBrowserSession() {
    try { localStorage.removeItem(SESSION_KEY); } catch (_) {}
  }

  async function ensureClient() {
    if (!activeClient) {
      activeClient = loadBrowserSession();
    }
    if (!activeClient || !activeClient.authToken) {
      throw new Error("ยังไม่ได้เชื่อมต่อ Zabbix Server กรุณาเข้าสู่ระบบใหม่");
    }
    return activeClient;
  }

  async function buildComplianceForHost(client, hostid) {
    const host = await client.getHostDetail(hostid);
    if (!host) throw new Error(`Host ${hostid} not found`);
    const itemData = await client.getHostItems(hostid);
    const items = itemData.items || [];
    const allTemplates = await client.getTemplates();
    const settings = loadSettings();
    const waivers = loadWaivers(hostid);
    const inv = collectInventoryFromItems(host, items);
    return evaluateCompliance(host, items, host.parentTemplates || [], inv, allTemplates, settings, waivers);
  }

  async function buildSoftwareInventoryForHost(client, hostid) {
    const host = await client.getHostDetail(hostid);
    if (!host) throw new Error(`Host ${hostid} not found`);
    const itemData = await client.getHostItems(hostid);
    const items = itemData.items || [];
    const allTemplates = await client.getTemplates();
    const linked = host.parentTemplates || [];
    const inv = collectInventoryFromItems(host, items);

    // Resolve template names for templated items
    const tplItemIds = Array.from(new Set(items.map((it) => String(it.templateid || "0")).filter((id) => id !== "0")));
    const origin = {};
    if (tplItemIds.length) {
      try {
        const res = await client.call("item.get", {
          itemids: tplItemIds,
          output: ["itemid", "templateid"],
          selectHosts: ["name"],
          templated: true
        });
        for (const ti of (res && res.result) || []) {
          origin[String(ti.itemid)] = ((ti.hosts || [{}])[0]).name || "";
        }
      } catch (_) {}
    }
    items.forEach((it) => { it._template = origin[String(it.templateid || "")] || ""; });

    const rows = buildSoftwareInventoryRows(inv, items, linked, allTemplates);
    return {
      host: { hostid: host.hostid, name: host.name, host: host.host },
      os_family: inv.os_family,
      inventory: {
        source: inv.source,
        confidence: (inv.source.software || inv.source.services || inv.source.processes) ? "partial" : "estimated",
        software_count: inv.software.length,
        services_count: inv.services.length,
        processes_count: inv.processes.length,
        collected_at: inv.collected_at,
        errors: inv.errors,
        notes: inv.notes
      },
      rows,
      generated_at: inv.collected_at
    };
  }

  async function getHostAgentInterface(client, hostid) {
    const host = await client.getHostDetail(hostid);
    if (!host) throw new Error(`Host ${hostid} not found`);
    const ifaces = host.interfaces || [];
    const agentIface = ifaces.find((i) => String(i.type) === "1" && String(i.main) === "1") ||
                       ifaces.find((i) => String(i.type) === "1") ||
                       ifaces[0];
    return { host, iface: agentIface };
  }

  async function addServiceItemsBrowser(client, hostid, services, osType = "linux") {
    const { host, iface } = await getHostAgentInterface(client, hostid);
    const existingRes = await client.call("item.get", {
      hostids: [String(hostid)],
      output: ["itemid", "name", "key_", "status"]
    });
    const existingByKey = {};
    for (const it of (existingRes && existingRes.result) || []) {
      existingByKey[it.key_] = it;
    }

    const isWin = String(osType || "").toLowerCase().includes("win");
    let created = 0;
    const base = iface ? { type: 0, interfaceid: String(iface.interfaceid) } : { type: 7 };

    for (const svc of services || []) {
      const sName = String(svc.name || "").trim();
      const dName = String(svc.display_name || sName).trim();
      if (!sName) continue;
      const key = svc.key || (isWin ? `service.info[${sName},state]` : `proc.num[${sName}]`);
      if (existingByKey[key]) {
        if (String(existingByKey[key].status) !== "0") {
          await client.call("item.update", { itemid: existingByKey[key].itemid, status: 0 });
        }
        created++;
        continue;
      }
      const itemName = key.startsWith("service.info[")
        ? `State of service "${sName}" (${dName})`
        : `Process count of ${dName} (${sName})`;
      const res = await client.call("item.create", {
        hostid: String(hostid),
        name: itemName,
        key_: key,
        value_type: 3,
        delay: "1m",
        status: 0,
        ...base
      });
      if (res && res.result) {
        created++;
        const trigExpr = key.startsWith("service.info[")
          ? `last(/${host.host}/${key})<>0`
          : `last(/${host.host}/${key})=0`;
        const trigDesc = key.startsWith("service.info[")
          ? `Service "${dName}" (${sName}) is not running on {HOST.NAME}`
          : `Process "${dName}" (${sName}) is not running on {HOST.NAME}`;
        await client.call("trigger.create", {
          description: trigDesc,
          expression: trigExpr,
          priority: 3,
          status: 0
        });
      }
    }
    return { ok: created > 0, count: created, msg: `เพิ่ม Monitor สำเร็จ ${created} รายการ` };
  }

  async function addCustomMonitorsBrowser(client, hostid, monitorType, itemsList, softwareName = "", createTrigger = true, severity = 3) {
    const { host, iface } = await getHostAgentInterface(client, hostid);
    const existingRes = await client.call("item.get", {
      hostids: [String(hostid)],
      output: ["itemid", "name", "key_", "status"]
    });
    const existingByKey = {};
    for (const it of (existingRes && existingRes.result) || []) {
      existingByKey[it.key_] = it;
    }

    const base = iface ? { type: 0, interfaceid: String(iface.interfaceid) } : { type: 7 };
    const mtype = String(monitorType || "process").toLowerCase();
    const prefix = softwareName ? `[${softwareName}] ` : "";
    let count = 0;

    for (const raw of itemsList || []) {
      const val = String(raw || "").trim();
      if (!val) continue;
      let key = "";
      let itemName = "";
      let trigExpr = "";
      let trigDesc = "";

      if (mtype === "port" || mtype === "tcp") {
        const port = val.replace(/\D/g, "");
        if (!port) continue;
        key = `net.tcp.port[,${port}]`;
        itemName = `${prefix}TCP Port ${port} state`;
        trigExpr = `last(/${host.host}/${key})=0`;
        trigDesc = `${prefix}TCP Port ${port} is down on {HOST.NAME}`;
      } else if (mtype === "service" || mtype === "svc") {
        key = `service.info[${val},state]`;
        itemName = `${prefix}State of service "${val}"`;
        trigExpr = `last(/${host.host}/${key})<>0`;
        trigDesc = `${prefix}Service "${val}" is not running on {HOST.NAME}`;
      } else {
        key = `proc.num[${val}]`;
        itemName = `${prefix}Process ${val} running count`;
        trigExpr = `last(/${host.host}/${key})=0`;
        trigDesc = `${prefix}Process "${val}" is not running on {HOST.NAME}`;
      }

      if (existingByKey[key]) {
        if (String(existingByKey[key].status) !== "0") {
          await client.call("item.update", { itemid: existingByKey[key].itemid, status: 0 });
        }
        count++;
      } else {
        const res = await client.call("item.create", {
          hostid: String(hostid),
          name: itemName,
          key_: key,
          value_type: 3,
          delay: "1m",
          status: 0,
          ...base
        });
        if (res && res.result) count++;
      }

      if (createTrigger && trigExpr) {
        await client.call("trigger.create", {
          description: trigDesc,
          expression: trigExpr,
          priority: parseInt(severity, 10) || 3,
          status: 0
        });
      }
    }
    return { ok: count > 0, count, msg: `เพิ่ม Custom Monitor สำเร็จ ${count} รายการ` };
  }

  async function linkTemplatesBrowser(client, hostid, templateIds) {
    const ids = (templateIds || []).map((t) => String(t).trim()).filter(Boolean);
    if (!ids.length) return { ok: false, msg: "ไม่มี Template ที่จะผูก", count: 0 };
    const hInfo = await client.call("host.get", {
      hostids: [String(hostid)],
      output: ["hostid"],
      selectParentTemplates: ["templateid", "name"]
    });
    const existing = hInfo?.result?.[0]?.parentTemplates || [];
    const existingIds = new Set(existing.map((t) => String(t.templateid)));
    const newIds = ids.filter((id) => !existingIds.has(id));
    if (!newIds.length) return { ok: true, msg: "Template ที่เลือกถูกผูกกับเครื่องนี้อยู่แล้ว", count: 0 };

    const merged = Array.from(new Set([...existingIds, ...newIds])).map((tid) => ({ templateid: tid }));
    const res = await client.call("host.update", {
      hostid: String(hostid),
      templates: merged
    });
    if (res && res.result) {
      return { ok: true, msg: `ผูก Template สำเร็จ ${newIds.length} ชุด`, count: newIds.length };
    }
    const err = res?.error || {};
    return { ok: false, msg: `ไม่สามารถผูก Template ได้: ${err.data || err.message || "Error"}`, count: 0 };
  }

  async function unlinkTemplatesBrowser(client, hostid, templateIds) {
    const hInfo = await client.call("host.get", {
      hostids: [String(hostid)],
      output: ["hostid"],
      selectParentTemplates: ["templateid", "name"]
    });
    const existing = hInfo?.result?.[0]?.parentTemplates || [];
    if (!existing.length) return { ok: true, msg: "เครื่องนี้ไม่มี Template ผูกอยู่แล้ว", count: 0 };
    const targetIds = (templateIds || []).map(String);
    const toClear = targetIds.length
      ? existing.filter((t) => targetIds.includes(String(t.templateid)))
      : existing;
    if (!toClear.length) return { ok: true, msg: "ไม่พบ Template ที่ต้องการปลด", count: 0 };

    const res = await client.call("host.update", {
      hostid: String(hostid),
      templates_clear: toClear.map((t) => ({ templateid: String(t.templateid) }))
    });
    if (res && res.result) {
      const names = toClear.map((t) => t.name).join(", ");
      return { ok: true, msg: `ปลด Template (${names}) เรียบร้อยแล้ว`, count: toClear.length };
    }
    const err = res?.error || {};
    return { ok: false, msg: `ไม่สามารถปลด Template ได้: ${err.data || err.message || "Error"}`, count: 0 };
  }

  // =========================================================================
  // 7. Main Endpoint Dispatcher (handleApiRequest)
  // =========================================================================
  async function handleApiRequest(endpoint, method = "GET", body = null) {
    const u = new URL(endpoint, "http://localhost");
    const path = u.pathname;
    const q = Object.fromEntries(u.searchParams.entries());
    const data = body || {};

    if (method === "GET" && path === "/api/status") {
      if (!activeClient) activeClient = loadBrowserSession();
      if (activeClient && activeClient.authToken) {
        return {
          connected: true,
          version: activeClient.apiVersion,
          url: activeClient.url,
          user: activeClient.userInfo?.username || "admin",
          display_name: activeClient.userInfo?.display_name || activeClient.userInfo?.username || "admin"
        };
      }
      return { connected: false };
    }

    if (method === "POST" && path === "/api/connect") {
      const url = String(data.url || "").trim();
      const username = String(data.username || "").trim();
      const password = String(data.password || "");
      const apiToken = String(data.api_token || "").trim();
      if (!url) throw new Error("กรุณาระบุ Zabbix Server URL");

      const client = new BrowserZabbixClient(url);
      const res = await client.login({ username, password, apiToken });
      if (!res.success) {
        throw new Error(res.message);
      }
      activeClient = client;
      saveBrowserSession(client);
      const groups = await client.getHostGroups();
      const templates = await client.getTemplates();
      return {
        success: true,
        message: res.message,
        version: client.apiVersion,
        url: client.url,
        user: client.userInfo?.username || username || "API Token",
        display_name: client.userInfo?.display_name || username || "API Token",
        groups,
        templates
      };
    }

    if (method === "POST" && path === "/api/disconnect") {
      activeClient = null;
      clearBrowserSession();
      return { success: true, message: "Disconnected" };
    }

    if (path === "/api/settings") {
      if (method === "GET") return { success: true, settings: loadSettings(), browser: "Browser Built-in Print/PDF" };
      if (method === "POST") return { success: true, settings: saveSettings(data.settings || {}) };
    }

    // All endpoints below require an authenticated Zabbix client
    const client = await ensureClient();

    if (method === "GET" && path === "/api/hosts") {
      const [hosts, groups] = await Promise.all([
        client.getHosts(2000),
        client.getHostGroups()
      ]);
      return { success: true, hosts, groups };
    }

    if (method === "GET" && path === "/api/groups") {
      const groups = await client.getHostGroups();
      return { success: true, groups };
    }

    if (method === "GET" && path === "/api/templates") {
      const templates = await client.getTemplates();
      return { success: true, templates };
    }

    if (method === "GET" && path === "/api/host/items") {
      return await client.getHostItems(q.hostid);
    }

    if (method === "GET" && path === "/api/host/triggers") {
      const hostid = q.hostid;
      const triggers = await client.getHostTriggers(hostid);
      const ht = await client.call("host.get", {
        hostids: [String(hostid)],
        output: ["hostid", "name", "host"],
        selectParentTemplates: ["templateid", "name", "host"]
      });
      const templates = ht?.result?.[0]?.parentTemplates || [];
      const bySeverity = { "0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0 };
      let problems = 0;
      let enabledCnt = 0;
      for (const t of triggers) {
        const pri = String(t.priority || "0");
        bySeverity[pri] = (bySeverity[pri] || 0) + 1;
        if (String(t.value) === "1" && String(t.status) === "0") problems++;
        if (String(t.status) === "0") enabledCnt++;
      }
      return {
        success: true,
        hostid,
        triggers,
        templates,
        summary: {
          total: triggers.length,
          problems,
          enabled: enabledCnt,
          disabled: triggers.length - enabledCnt,
          by_severity: bySeverity
        }
      };
    }

    if (method === "GET" && path === "/api/host/compliance") {
      const comp = await buildComplianceForHost(client, q.hostid);
      return { success: true, ...comp };
    }

    if (method === "GET" && path === "/api/host/software-inventory") {
      const inv = await buildSoftwareInventoryForHost(client, q.hostid);
      return { success: true, ...inv };
    }

    if (method === "POST" && path === "/api/host/templates/link") {
      const res = await linkTemplatesBrowser(client, data.hostid, data.template_ids);
      return { success: res.ok, message: res.msg, linked_count: res.count };
    }

    if (method === "POST" && path === "/api/host/templates/unlink") {
      const res = await unlinkTemplatesBrowser(client, data.hostid, data.template_ids);
      return { success: res.ok, message: res.msg, cleared_count: res.count };
    }

    if (method === "POST" && path === "/api/host/compliance/fix") {
      const hostid = String(data.hostid || "").trim();
      const action = data.action || {};
      const atype = action.type;
      const osFamily = action.os_family || "linux";
      if (atype === "link_template") {
        const r = await linkTemplatesBrowser(client, hostid, [action.templateid]);
        return { success: r.ok, message: r.msg };
      }
      if (atype === "add_service") {
        const r = await addServiceItemsBrowser(client, hostid, [{
          name: action.name,
          display_name: action.display_name || action.name,
          key: action.key
        }], osFamily);
        return { success: r.ok, message: r.msg };
      }
      if (atype === "add_port") {
        const p = String(action.port || action.name || "").trim();
        const r = await addCustomMonitorsBrowser(client, hostid, "port", [p]);
        return { success: r.ok, message: r.msg };
      }
      if (atype === "add_item") {
        const spec = OS_CHECKS.find((c) => c.id === action.check_id);
        const add = spec?.add ? (spec.add[osFamily] || spec.add["*"]) : null;
        if (!add) return { success: false, message: "ต้องผูก OS Template" };
        const { iface } = await getHostAgentInterface(client, hostid);
        const base = iface ? { type: 0, interfaceid: String(iface.interfaceid) } : { type: 7 };
        const cRes = await client.call("item.create", {
          hostid, name: add.name, key_: add.key, value_type: add.value_type ?? 0, delay: add.delay || "1m", ...base
        });
        return { success: Boolean(cRes?.result), message: cRes?.result ? `เพิ่ม ${add.key} แล้ว` : (cRes?.error?.data || "ไม่สามารถสร้าง Item ได้") };
      }
      if (atype === "waive" || atype === "unwaive") {
        setWaiver(hostid, action.check_key, action.reason || "", atype === "unwaive");
        return { success: true, message: atype === "unwaive" ? "ยกเลิก Waiver แล้ว" : "บันทึกเป็น Not Required แล้ว" };
      }
      return { success: false, message: `Unknown action: ${atype}` };
    }

    if (method === "POST" && path === "/api/host/compliance/fix-batch") {
      const hostid = String(data.hostid || "").trim();
      const actions = data.actions || [];
      const osFamily = data.os_family || "linux";
      let total = 0;
      const tmplIds = [];
      const svcList = [];
      const portList = [];
      for (const a of actions) {
        if (a.type === "link_template" && a.templateid) tmplIds.push(String(a.templateid));
        else if (a.type === "add_service" && a.name) svcList.push({ name: a.name, display_name: a.display_name || a.name, key: a.key });
        else if (a.type === "add_port" && (a.port || a.name)) portList.push(String(a.port || a.name));
      }
      if (tmplIds.length) {
        const r = await linkTemplatesBrowser(client, hostid, tmplIds);
        total += r.count;
      }
      if (svcList.length) {
        const r = await addServiceItemsBrowser(client, hostid, svcList, osFamily);
        total += r.count;
      }
      if (portList.length) {
        const r = await addCustomMonitorsBrowser(client, hostid, "port", portList);
        total += r.count;
      }
      return { success: true, count: total, message: `เพิ่ม Monitoring สำเร็จ ${total} รายการ` };
    }

    if (method === "POST" && path === "/api/host/custom-monitor/add") {
      const hostid = String(data.hostid || "").trim();
      const swName = String(data.software_name || "").trim();
      const createTrig = data.create_trigger !== false;
      const severity = parseInt(data.severity, 10) || 3;
      const splitList = (v) => Array.isArray(v) ? v : String(v || "").split(",").map((x) => x.trim()).filter(Boolean);

      let procs = splitList(data.processes);
      let ports = splitList(data.ports);
      let svcs = splitList(data.services);
      if (!procs.length && !ports.length && !svcs.length) {
        const mtype = String(data.monitor_type || "process").toLowerCase();
        const items = splitList(data.items);
        if (mtype.startsWith("port") || mtype === "tcp") ports = items;
        else if (mtype.startsWith("serv") || mtype === "svc") svcs = items;
        else procs = items;
      }
      let total = 0;
      const msgs = [];
      if (procs.length) {
        const r = await addCustomMonitorsBrowser(client, hostid, "process", procs, swName, createTrig, severity);
        total += r.count; msgs.push(r.msg);
      }
      if (ports.length) {
        const r = await addCustomMonitorsBrowser(client, hostid, "port", ports, swName, createTrig, severity);
        total += r.count; msgs.push(r.msg);
      }
      if (svcs.length) {
        const r = await addCustomMonitorsBrowser(client, hostid, "service", svcs, swName, createTrig, severity);
        total += r.count; msgs.push(r.msg);
      }
      return { success: total > 0, count: total, message: msgs.join(" · ") || "ไม่มีรายการที่เพิ่ม" };
    }

    if (method === "POST" && path === "/api/host/items/delete") {
      const hostid = String(data.hostid || "");
      const keys = (data.keys || []).map((k) => String(k).toLowerCase());
      const res = await client.call("item.get", { hostids: [hostid], output: ["itemid", "key_", "templateid"] });
      const matched = ((res && res.result) || []).filter((it) => keys.includes(String(it.key_ || "").toLowerCase()));
      const standalone = matched.filter((it) => String(it.templateid || "0") === "0");
      if (!standalone.length) {
        return { success: false, count: 0, message: "Item นี้มาจาก Template กรุณาปลด Template แทน" };
      }
      const ids = standalone.map((it) => it.itemid);
      const delRes = await client.call("item.delete", ids);
      return { success: Boolean(delRes?.result), count: ids.length, message: `ลบ ${ids.length} item เรียบร้อยแล้ว` };
    }

    if (method === "POST" && path === "/api/host/triggers/create") {
      const host = await client.getHostDetail(data.hostid);
      if (!host) throw new Error("ไม่พบ Host");
      let expr = String(data.expression || "").trim();
      const funcs = ["last(", "nodata(", "avg(", "min(", "max(", "sum(", "count(", "find("];
      const fn = funcs.find((f) => expr.startsWith(f));
      if (fn && !expr.startsWith(`${fn}/`)) expr = expr.replace(fn, `${fn}/${host.host}/`);
      else if (!expr.includes("/")) expr = `last(/${host.host}/${expr})<>0`;
      const res = await client.call("trigger.create", {
        description: String(data.description || "").trim(),
        expression: expr,
        priority: parseInt(data.priority, 10) || 3,
        status: 0
      });
      if (res && res.result) {
        return { success: true, triggerid: res.result.triggerids?.[0], message: `สร้าง Trigger สำเร็จ!` };
      }
      throw new Error(res?.error?.data || res?.error?.message || "สร้าง Trigger ไม่สำเร็จ");
    }

    if (method === "POST" && path === "/api/host/triggers/toggle") {
      let count = 0;
      for (const u of data.updates || []) {
        const r = await client.call("trigger.update", { triggerid: String(u.triggerid), status: parseInt(u.status, 10) || 0 });
        if (r && r.result) count++;
      }
      return { success: count > 0, count, message: `อัปเดต ${count} triggers แล้ว` };
    }

    if (method === "POST" && path === "/api/host/triggers/delete") {
      const ids = (data.triggerids || data.trigger_ids || (data.triggerid ? [data.triggerid] : [])).map(String);
      const r = await client.call("trigger.delete", ids);
      if (r && r.result) return { success: true, count: ids.length, message: `ลบ Trigger ${ids.length} รายการแล้ว` };
      throw new Error(r?.error?.data || r?.error?.message || "ไม่สามารถลบ Trigger ได้");
    }

    if (method === "POST" && path === "/api/host/inventory/probe") {
      const hostid = String(data.hostid || "");
      const osFamily = data.os_family || "linux";
      const { iface } = await getHostAgentInterface(client, hostid);
      const base = iface ? { type: 0, interfaceid: String(iface.interfaceid) } : { type: 7 };
      const probes = osFamily === "windows"
        ? [
            { name: "[Inventory] Windows services", key: 'wmi.getall[root\\cimv2,"SELECT Name,DisplayName,State,StartMode FROM Win32_Service"]' },
            { name: "[Inventory] Running processes", key: "proc.get[,,,summary]" },
            { name: "[Inventory] System description", key: "system.uname" }
          ]
        : [
            { name: "[Inventory] Installed packages", key: "system.sw.packages.get" },
            { name: "[Inventory] Running processes", key: "proc.get[,,,summary]" },
            { name: "[Inventory] System description", key: "system.uname" }
          ];
      let created = 0;
      for (const p of probes) {
        const r = await client.call("item.create", {
          hostid, name: p.name, key_: p.key, value_type: 4, delay: "1h", status: 0, ...base
        });
        if (r && r.result) created++;
      }
      return { success: true, count: created, message: `สร้าง Inventory Probe ${created} รายการแล้ว` };
    }

    // Basic Elastic endpoints support in Standalone mode
    if (path.startsWith("/api/elastic/")) {
      return await handleElasticStandalone(client, method, path, q, data);
    }

    throw new Error(`Endpoint ${path} not supported in standalone mode`);
  }

  async function handleElasticStandalone(client, method, path, q, data) {
    const defSettings = { es_url: "", kibana_url: "", auth_type: "none", username: "", default_env: "prod" };
    if (path === "/api/elastic/settings") {
      if (method === "GET") return { success: true, settings: { ...defSettings, ...readStore(ES_SETTINGS_KEY, {}) } };
      if (method === "POST") {
        const s = { ...defSettings, ...readStore(ES_SETTINGS_KEY, {}), ...(data.settings || {}) };
        writeStore(ES_SETTINGS_KEY, s);
        return { success: true, settings: s };
      }
    }
    if (path === "/api/elastic/host-config") {
      const allCfg = readStore(ES_HOST_CFG_KEY, {});
      if (method === "GET") {
        const host = await client.getHostDetail(q.hostid);
        const cfg = allCfg[q.hostid] || { inputs: [], env: "prod" };
        return {
          success: true,
          app: { appid: "", appname: host?.name || "", group: "" },
          config: cfg,
          env: cfg.env || "prod",
          index_names: { json: "filebeat-json-*", plaintext: "filebeat-plain-*" },
          space: "default"
        };
      }
      if (method === "POST") {
        allCfg[data.hostid] = { inputs: data.inputs || [], env: data.env || "prod" };
        writeStore(ES_HOST_CFG_KEY, allCfg);
        return { success: true, config: allCfg[data.hostid], message: "บันทึกการตั้งค่าแล้ว" };
      }
    }
    if (path === "/api/elastic/host-status") {
      const host = await client.getHostDetail(q.hostid);
      const itemData = await client.getHostItems(q.hostid);
      const fbItems = (itemData.items || []).filter((it) => String(it.key_ || "").toLowerCase().includes("filebeat"));
      const running = fbItems.some((it) => parseFloat(it.lastvalue || "0") > 0);
      return {
        success: true,
        host: { hostid: host.hostid, name: host.name, host: host.host },
        app: { appid: "", appname: "", group: "" },
        env: "prod",
        os_family: "linux",
        pct: fbItems.length ? (running ? 100 : 50) : 0,
        filebeat: { installed: fbItems.length > 0 ? true : null, running: fbItems.length > 0 ? running : null, config_source: "none", instances: [], config_paths: [] },
        checks: [
          { id: "installed", title: "Filebeat process item", status: fbItems.length ? "OK" : "Unknown", detail: fbItems.length ? `พบ ${fbItems.length} items` : "ไม่พบ item proc.num[,,,filebeat]" },
          { id: "running", title: "Filebeat running", status: running ? "OK" : (fbItems.length ? "Missing" : "Unknown"), detail: running ? "กำลังทำงาน" : "ไม่ได้ทำงานหรือไม่มีข้อมูล" }
        ],
        paths: []
      };
    }
    return { success: true, indices: [], spaces: [] };
  }

  // =========================================================================
  // 8. Client-Side Report Download Handler
  // =========================================================================
  async function downloadReportStandalone(hostids, fmt, btn, title) {
    if (!hostids || !hostids.length) {
      if (typeof showToast === "function") showToast("กรุณาเลือกเครื่องก่อน", true);
      return;
    }
    const label = btn ? btn.textContent : "";
    if (btn) { btn.disabled = true; btn.textContent = "กำลังสร้าง..."; }
    try {
      const client = await ensureClient();
      const reports = [];
      for (const hid of hostids) {
        try {
          reports.push(await buildComplianceForHost(client, hid));
        } catch (e) {
          console.warn("Report compliance error for host", hid, e);
        }
      }
      if (!reports.length) throw new Error("ไม่พบข้อมูลเครื่องที่เลือก");

      const preparedBy = (document.querySelector("#repPreparedBy")?.value || "").trim();
      const settings = loadSettings();
      const meta = {
        title: "Monitoring Readiness Report",
        subtitle: title || (reports.length === 1 ? reports[0].host.name : `${reports.length} hosts`),
        generated_at: fmtClock(Math.floor(Date.now() / 1000)),
        zabbix_url: client.url.replace("/api_jsonrpc.php", ""),
        zabbix_version: client.apiVersion,
        prepared_by: preparedBy,
        organization: settings.organization || ""
      };

      const baseName = String(title || reports[0].host.name || "report").replace(/[^A-Za-z0-9._-]+/g, "_");
      if (fmt === "html" || fmt === "pdf" || fmt === "png") {
        const htmlText = buildReportHtml(reports, meta);
        const win = window.open("", "_blank");
        if (win) {
          win.document.open();
          win.document.write(htmlText);
          win.document.close();
          if (fmt === "pdf" || fmt === "png") {
            setTimeout(() => { try { win.focus(); win.print(); } catch (_) {} }, 500);
          }
        } else {
          const blob = new Blob([htmlText], { type: "text/html;charset=utf-8" });
          const a = document.createElement("a");
          a.href = URL.createObjectURL(blob);
          a.download = `${baseName}_readiness.html`;
          a.click();
        }
      } else if (fmt === "csv") {
        const csvContent = buildReportCsv(reports);
        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = `${baseName}_readiness.csv`;
        a.click();
      } else if (fmt === "json") {
        const jsonContent = JSON.stringify({ meta, reports }, null, 2);
        const blob = new Blob([jsonContent], { type: "application/json;charset=utf-8" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = `${baseName}_readiness.json`;
        a.click();
      }
      if (typeof showToast === "function") showToast(`สร้างรายงาน ${fmt.toUpperCase()} สำเร็จ`);
    } catch (err) {
      if (typeof showToast === "function") showToast(`สร้างรายงานไม่สำเร็จ: ${err.message}`, true);
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = label; }
    }
  }

  window.BrowserZabbixEngine = {
    isActive: Boolean(window.STANDALONE_MODE || window.location.protocol === "file:"),
    handleApiRequest,
    downloadReportStandalone
  };
})();

