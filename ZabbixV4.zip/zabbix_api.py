"""
Zabbix API Client Wrapper
Compatible with Zabbix 4.x, 5.x, 6.x, and 7.x
Supports username/password login and API Token authentication.
"""
import os
import socket
import struct
import subprocess
import json
import logging
import re
from typing import Dict, List, Any, Optional, Tuple
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger("ZabbixAPI")
logging.basicConfig(level=logging.INFO)

class ZabbixClient:
    def __init__(self, url: str, timeout: int = 15, verify_ssl: bool = True):
        raw = url.strip()
        # Strip query string and fragment if user pasted a browser URL (e.g. .../zabbix.php?action=dashboard.view)
        raw = raw.split("?", 1)[0].split("#", 1)[0].strip().rstrip("/")
        # Strip trailing web UI PHP script names if present
        for ui_suffix in ("/zabbix.php", "/index.php", "/index_http.php", "/ index.php"):
            if raw.lower().endswith(ui_suffix):
                raw = raw[: -len(ui_suffix)].rstrip("/")

        # Ensure scheme(s)
        if re.match(r"^https?://", raw, re.I):
            base_urls = [raw]
        else:
            base_urls = [f"http://{raw}", f"https://{raw}"]

        # Build candidate URLs in priority order
        self.candidates: List[str] = []
        for base in base_urls:
            if base.endswith("api_jsonrpc.php"):
                cands = [base]
            elif base.lower().endswith("/zabbix"):
                cands = [
                    f"{base}/api_jsonrpc.php",
                    f"{base[:-7]}/api_jsonrpc.php",
                ]
            else:
                cands = [
                    f"{base}/zabbix/api_jsonrpc.php",
                    f"{base}/api_jsonrpc.php",
                ]
            for c in cands:
                if c not in self.candidates:
                    self.candidates.append(c)

        self.url = self.candidates[0]
        self.timeout = timeout
        self.session = requests.Session()
        self.session.verify = verify_ssl
        self.session.headers.update({
            "Content-Type": "application/json-rpc",
            "User-Agent": "Zabbix-Bulk-Host-Manager/1.0"
        })
        self.auth_token: Optional[str] = None
        self.is_api_token: bool = False
        self.use_bearer: bool = False
        self.auth_expired: bool = False
        self.api_version: Optional[str] = None
        self.user_info: Dict[str, Any] = {}
        self.request_id: int = 1

    def _version_tuple(self) -> Tuple[int, int]:
        if not self.api_version:
            return (6, 0)
        parts = re.findall(r"\d+", self.api_version)
        major = int(parts[0]) if len(parts) > 0 else 6
        minor = int(parts[1]) if len(parts) > 1 else 0
        return (major, minor)

    def _send_rpc(self, method: str, params: Any, token_to_use: Optional[str], use_bearer: bool) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params if params is not None else {},
            "id": self.request_id
        }
        self.request_id += 1

        if token_to_use:
            if use_bearer:
                self.session.headers["Authorization"] = f"Bearer {token_to_use}"
            else:
                if "Authorization" in self.session.headers:
                    del self.session.headers["Authorization"]
                payload["auth"] = token_to_use
        else:
            if "Authorization" in self.session.headers:
                del self.session.headers["Authorization"]

        try:
            resp = self.session.post(self.url, data=json.dumps(payload), timeout=self.timeout)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.SSLError:
            # Automatically fallback if server uses self-signed SSL certificate
            self.session.verify = False
            try:
                resp = self.session.post(self.url, data=json.dumps(payload), timeout=self.timeout)
                resp.raise_for_status()
                return resp.json()
            except Exception as e2:
                return {"error": {"message": f"SSL/Network error connecting to Zabbix: {str(e2)}", "data": str(e2)}}
        except requests.exceptions.RequestException as e:
            return {"error": {"message": f"Network error connecting to Zabbix: {str(e)}", "data": str(e)}}
        except json.JSONDecodeError as e:
            return {"error": {"message": f"Invalid JSON response from server (Check if URL is correct): {str(e)}"}}

    def _call(self, method: str, params: Any = None, auth: Optional[str] = None) -> Dict[str, Any]:
        """Send JSON-RPC 2.0 request to Zabbix API with automatic Bearer vs auth-param compatibility."""
        token_to_use = auth if auth is not None else self.auth_token
        data = self._send_rpc(method, params, token_to_use, self.use_bearer)

        # If authenticated call fails due to auth format mismatch (e.g. Zabbix 7.0 disallowing 'auth' param
        # or older Zabbix / Apache stripping 'Authorization: Bearer'), automatically flip and retry once.
        if token_to_use and "error" in data:
            err = data["error"]
            err_msg = (str(err.get("data", "")) + " " + str(err.get("message", ""))).lower()
            if any(k in err_msg for k in ["unexpected parameter \"auth\"", "invalid params", "not authorized", "re-login", "authorisation"]):
                alt_data = self._send_rpc(method, params, token_to_use, not self.use_bearer)
                if "result" in alt_data:
                    self.use_bearer = not self.use_bearer
                    return alt_data

        if "error" in data:
            err = data["error"]
            err_msg = str(err.get("data", "")) + " " + str(err.get("message", ""))
            if any(term in err_msg.lower() for term in ["token expired", "session terminated", "not authorized", "re-login"]):
                self.auth_expired = True

        return data

    def is_token_valid(self) -> bool:
        """Check if current session token or API token is alive and valid"""
        if not self.auth_token:
            return False
        try:
            res = self._call("hostgroup.get", {"output": ["groupid"], "limit": 1})
            if "result" in res:
                self.auth_expired = False
                return True
            return False
        except Exception:
            return False

    def get_api_version(self) -> str:
        """Retrieve Zabbix API version, auto-detecting candidate endpoints if needed"""
        last_error = None
        for candidate in self.candidates:
            self.url = candidate
            res = self._send_rpc("apiinfo.version", {}, token_to_use=None, use_bearer=False)
            if "result" in res:
                self.api_version = str(res["result"])
                # Successfully discovered active endpoint
                self.candidates = [self.url]
                return self.api_version
            err = res.get("error", {})
            err_msg = err.get("data") or err.get("message") or "Unknown error"
            last_error = err_msg

        raise RuntimeError(f"Failed to get API version: {last_error}")

    def _fetch_logged_in_user(self, fallback_username: str = "") -> Dict[str, Any]:
        """Fetch authenticated user profile from Zabbix API."""
        try:
            params: Dict[str, Any] = {"output": ["userid", "username", "alias", "name", "surname"]}
            if fallback_username:
                # Filter by username or alias depending on Zabbix version
                ver = self._version_tuple()
                field = "username" if ver >= (5, 4) else "alias"
                params["filter"] = {field: [fallback_username]}
            else:
                params["limit"] = 1
            res = self._call("user.get", params)
            users = res.get("result") or []
            if not users and fallback_username:
                res = self._call("user.get", {"output": ["userid", "username", "alias", "name", "surname"], "limit": 1})
                users = res.get("result") or []
            if users and isinstance(users[0], dict):
                u = users[0]
                uname = u.get("username") or u.get("alias") or fallback_username or "admin"
                full = " ".join(filter(None, [u.get("name", "").strip(), u.get("surname", "").strip()])).strip()
                return {
                    "userid": str(u.get("userid", "")),
                    "username": uname,
                    "name": u.get("name", ""),
                    "surname": u.get("surname", ""),
                    "display_name": f"{uname} ({full})" if full else uname,
                }
        except Exception:
            pass
        uname = fallback_username or ("API Token" if self.is_api_token else "admin")
        return {"username": uname, "display_name": uname}

    def login(self, username: Optional[str] = None, password: Optional[str] = None, api_token: Optional[str] = None) -> Tuple[bool, str]:
        """
        Authenticate with Zabbix Server.
        Can use direct API Token OR username & password.
        Returns: (success: bool, message/token: str)
        """
        try:
            self.get_api_version()
        except Exception as e:
            return False, f"Cannot connect to Zabbix API: {str(e)}"

        ver = self._version_tuple()

        # 1) API Token login
        if api_token and api_token.strip():
            self.auth_token = api_token.strip()
            self.is_api_token = True
            self.use_bearer = True
            # Test direct token validity ( _call will auto-fallback between Bearer header and auth param )
            test_res = self._call("hostgroup.get", {"output": ["groupid"], "limit": 1})
            if "result" not in test_res:
                test_res = self._call("host.get", {"output": ["hostid"], "limit": 1})
            if "result" in test_res:
                self.auth_expired = False
                self.user_info = self._fetch_logged_in_user()
                return True, self.auth_token
            # Failed with token
            err = test_res.get("error", {}).get("data") or test_res.get("error", {}).get("message") or "Invalid API Token"
            self.auth_token = None
            self.is_api_token = False
            return False, f"API Token invalid: {err}"

        # 2) Username / Password login
        if not username or not password:
            return False, "Username and password are required if API Token is not provided."

        self.is_api_token = False
        # Zabbix 6.4+ and 7.0+ prefer Bearer header; older Zabbix uses 'auth' param in payload
        self.use_bearer = ver >= (6, 4)

        # Try modern 'username' parameter with userData first (Zabbix 5.4+)
        login_attempts = [
            {"username": username, "password": password, "userData": True},
            {"username": username, "password": password},
            {"user": username, "password": password, "userData": True},
            {"user": username, "password": password},
        ]

        last_res: Dict[str, Any] = {}
        for params in login_attempts:
            res = self._send_rpc("user.login", params, token_to_use=None, use_bearer=False)
            last_res = res
            if "result" in res and res["result"]:
                result_val = res["result"]
                if isinstance(result_val, dict):
                    self.auth_token = str(result_val.get("sessionid") or "")
                    uname = result_val.get("username") or result_val.get("alias") or username
                    full = " ".join(filter(None, [str(result_val.get("name") or "").strip(), str(result_val.get("surname") or "").strip()])).strip()
                    self.user_info = {
                        "userid": str(result_val.get("userid") or ""),
                        "username": uname,
                        "name": str(result_val.get("name") or ""),
                        "surname": str(result_val.get("surname") or ""),
                        "display_name": f"{uname} ({full})" if full else uname,
                    }
                else:
                    self.auth_token = str(result_val)
                    self.user_info = self._fetch_logged_in_user(fallback_username=username)

                # Verify and lock in the working auth transport mode (Bearer vs 'auth' param)
                self._call("hostgroup.get", {"output": ["groupid"], "limit": 1})
                self.auth_expired = False
                return True, self.auth_token

            # If error is explicitly wrong password / user, no need to try other parameter names if the param name itself was accepted
            err_data = str(res.get("error", {}).get("data", "")).lower()
            if "incorrect user name or password" in err_data or "temporarily blocked" in err_data:
                break

        err = (last_res.get("error", {}).get("data") or
               last_res.get("error", {}).get("message") or
               "Invalid username or password")
        return False, f"Authentication failed: {err}"

    def get_host_groups(self) -> List[Dict[str, str]]:
        """Fetch all Host Groups sorted by name"""
        res = self._call("hostgroup.get", {
            "output": ["groupid", "name"],
            "sortfield": "name"
        })
        if "result" in res:
            return res["result"]
        return []

    def get_templates(self) -> List[Dict[str, str]]:
        """Fetch all Templates sorted by name"""
        res = self._call("template.get", {
            "output": ["templateid", "name"],
            "sortfield": "name"
        })
        if "result" in res:
            return res["result"]
        return []

    def get_proxies_map(self) -> Tuple[Dict[str, str], Dict[str, str]]:
        """Return (proxy_id_to_name, proxy_group_id_to_name) from Zabbix Server."""
        proxy_map: Dict[str, str] = {}
        proxy_group_map: Dict[str, str] = {}
        try:
            res = self._call("proxy.get", {"output": "extend"})
            for p in res.get("result") or []:
                pid = str(p.get("proxyid") or "")
                pname = p.get("name") or p.get("host") or ""
                if pid and pname:
                    proxy_map[pid] = pname
        except Exception:
            pass
        if self._version_tuple() >= (7, 0):
            try:
                res_pg = self._call("proxygroup.get", {"output": "extend"})
                for pg in res_pg.get("result") or []:
                    pgid = str(pg.get("proxy_groupid") or "")
                    pgname = pg.get("name") or ""
                    if pgid and pgname:
                        proxy_group_map[pgid] = pgname
            except Exception:
                pass
        return proxy_map, proxy_group_map

    def _enrich_host_groups_and_proxy(
        self,
        host_list: List[Dict[str, Any]],
        proxy_map: Dict[str, str],
        proxy_group_map: Dict[str, str],
        agent_avail_map: Optional[Dict[str, str]] = None,
    ) -> List[Dict[str, Any]]:
        avail_map = agent_avail_map or {}
        for h in host_list:
            # Normalize hostgroups -> groups (Zabbix 6.2+ / 7.0 returns 'hostgroups' when using selectHostGroups)
            groups = h.get("groups") or h.get("hostgroups") or []
            h["groups"] = groups

            # Resolve Zabbix Proxy name
            proxyid = str(h.get("proxyid") or h.get("assigned_proxyid") or h.get("proxy_hostid") or "0")
            proxy_groupid = str(h.get("proxy_groupid") or "0")
            proxy_name = ""
            if proxyid not in ("0", "", "None"):
                p_label = proxy_map.get(proxyid, f"Proxy #{proxyid}")
                if proxy_groupid not in ("0", "", "None") and proxy_groupid in proxy_group_map:
                    proxy_name = f"{p_label} ({proxy_group_map[proxy_groupid]})"
                else:
                    proxy_name = p_label
            elif proxy_groupid not in ("0", "", "None"):
                pg_label = proxy_group_map.get(proxy_groupid, f"Proxy Group #{proxy_groupid}")
                proxy_name = f"Proxy Group: {pg_label}"
            h["proxy_name"] = proxy_name

            # Resolve Zabbix Connection Status (Available / Unavailable / Unknown)
            hid = str(h.get("hostid") or "")
            ifaces = h.get("interfaces") or []
            iface_avail = [str(i.get("available") or "0") for i in ifaces]
            iface_errors = [str(i.get("error") or "").strip() for i in ifaces if str(i.get("error") or "").strip()]
            act_avail = str(h.get("active_available") or h.get("available") or "0")
            item_avail = avail_map.get(hid, "")

            if "1" in iface_avail or act_avail == "1" or item_avail == "connected":
                h["zbx_connected"] = "connected"
            elif "2" in iface_avail or act_avail == "2" or item_avail == "disconnected":
                h["zbx_connected"] = "disconnected"
            else:
                h["zbx_connected"] = "unknown"
            h["zbx_error"] = iface_errors[0] if iface_errors else ""
        return host_list

    def get_hosts(self, limit: int = 2000) -> List[Dict[str, Any]]:
        """Fetch existing hosts with interface, group, proxy, and availability info"""
        ver = self._version_tuple()
        out_fields = ["hostid", "host", "name", "status", "description"]
        if ver >= (7, 0):
            out_fields.extend(["proxyid", "assigned_proxyid", "proxy_groupid", "monitored_by", "active_available"])
        elif ver >= (6, 4):
            out_fields.extend(["proxy_hostid", "active_available"])
        else:
            out_fields.extend(["proxy_hostid", "available"])

        params: Dict[str, Any] = {
            "output": out_fields,
            "selectInterfaces": ["interfaceid", "ip", "port", "type", "useip", "dns", "main", "available", "error"],
            "selectParentTemplates": ["templateid", "name"],
            "selectMacros": "extend",
            "sortfield": "name",
            "limit": limit
        }
        if ver >= (6, 2):
            params["selectHostGroups"] = ["groupid", "name"]
        else:
            params["selectGroups"] = ["groupid", "name"]

        res = self._call("host.get", params)
        if "result" not in res and ver >= (6, 2):
            params.pop("selectHostGroups", None)
            params["selectGroups"] = ["groupid", "name"]
            res = self._call("host.get", params)

        if "result" in res:
            raw_hosts = res["result"]
            hostids = [str(h.get("hostid")) for h in raw_hosts if h.get("hostid")]
            agent_avail_map: Dict[str, str] = {}
            if hostids:
                try:
                    ir = self._call("item.get", {
                        "hostids": hostids,
                        "output": ["hostid", "key_", "status", "state", "lastvalue", "lastclock"],
                        "search": {"key_": ["zabbix[host,agent,available]", "agent.ping", "icmpping"]},
                        "searchByAny": True,
                    })
                    for it in ir.get("result") or []:
                        if str(it.get("status", "0")) != "0":
                            continue
                        hid = str(it.get("hostid") or "")
                        lv = str(it.get("lastvalue") or "").strip()
                        lc = int(it.get("lastclock") or 0)
                        if lv == "1" and lc > 0:
                            agent_avail_map[hid] = "connected"
                        elif lv in ("0", "2") and lc > 0 and agent_avail_map.get(hid) != "connected":
                            agent_avail_map[hid] = "disconnected"
                except Exception:
                    pass
            proxy_map, proxy_group_map = self.get_proxies_map()
            return self._enrich_host_groups_and_proxy(raw_hosts, proxy_map, proxy_group_map, agent_avail_map)
        return []

    def find_or_create_hostgroup(self, group_name: str) -> Optional[str]:
        """Find group by name or create if it doesn't exist"""
        group_name = group_name.strip()
        if not group_name:
            return None
        res = self._call("hostgroup.get", {
            "filter": {"name": [group_name]},
            "output": ["groupid", "name"]
        })
        if "result" in res and len(res["result"]) > 0:
            return res["result"][0]["groupid"]

        # Create group
        create_res = self._call("hostgroup.create", {"name": group_name})
        if "result" in create_res and "groupids" in create_res["result"]:
            return create_res["result"]["groupids"][0]
        return None

    def create_host(
        self,
        host: str,
        ip: str,
        port: str = "10050",
        name: Optional[str] = None,
        group_ids: Optional[List[str]] = None,
        group_names: Optional[List[str]] = None,
        template_ids: Optional[List[str]] = None,
        template_names: Optional[List[str]] = None,
        interface_type: int = 1,  # 1 = Zabbix Agent, 2 = SNMP
        use_ip: int = 1,
        dns: str = "",
        description: str = "",
        tags: Optional[List[Dict[str, str]]] = None,
        macros: Optional[List[Dict[str, str]]] = None,
        snmp_version: int = 2,
        snmp_community: str = "public"
    ) -> Tuple[bool, str, Optional[str]]:
        """
        Create a host in Zabbix.
        Returns: (success: bool, message: str, hostid: Optional[str])
        """
        host = host.strip()
        ip = ip.strip()
        if not host:
            return False, "Host technical name is required", None
        if not ip:
            return False, "Host IP address is required", None

        visible_name = name.strip() if name and name.strip() else host

        # Resolve Host Groups
        target_group_ids: List[Dict[str, str]] = []
        if group_ids:
            for gid in group_ids:
                if gid:
                    target_group_ids.append({"groupid": str(gid)})

        if group_names:
            for gname in group_names:
                if gname.strip():
                    gid = self.find_or_create_hostgroup(gname.strip())
                    if gid and not any(g["groupid"] == gid for g in target_group_ids):
                        target_group_ids.append({"groupid": gid})

        # Default fallback to "Discovered hosts" or "Linux servers" if none provided
        if not target_group_ids:
            groups = self.get_host_groups()
            if groups:
                target_group_ids.append({"groupid": groups[0]["groupid"]})
            else:
                default_gid = self.find_or_create_hostgroup("General Hosts")
                if default_gid:
                    target_group_ids.append({"groupid": default_gid})
                else:
                    return False, "No Host Group specified and cannot create default group.", None

        # Resolve Templates
        target_template_ids: List[Dict[str, str]] = []
        if template_ids:
            for tid in template_ids:
                if tid:
                    target_template_ids.append({"templateid": str(tid)})

        if template_names:
            all_templates = self.get_templates()
            name_map = {t["name"].lower(): t["templateid"] for t in all_templates}
            for tname in template_names:
                tname_clean = tname.strip()
                if tname_clean.lower() in name_map:
                    tid = name_map[tname_clean.lower()]
                    if not any(t["templateid"] == tid for t in target_template_ids):
                        target_template_ids.append({"templateid": tid})

        # Construct Interface object
        interface_obj: Dict[str, Any] = {
            "type": interface_type,
            "main": 1,
            "useip": use_ip,
            "ip": ip,
            "dns": dns,
            "port": str(port)
        }

        # If SNMP interface (type 2)
        if interface_type == 2:
            interface_obj["details"] = {
                "version": snmp_version,
                "community": snmp_community
            }

        params: Dict[str, Any] = {
            "host": host,
            "name": visible_name,
            "interfaces": [interface_obj],
            "groups": target_group_ids,
            "status": 0,  # 0 = Monitored
            "description": description
        }

        if target_template_ids:
            params["templates"] = target_template_ids

        if tags:
            params["tags"] = tags

        if macros:
            valid_macros = [
                {"macro": str(m.get("macro", "")).strip(), "value": str(m.get("value", "")).strip()}
                for m in macros
                if m.get("macro") and m.get("value") is not None and str(m.get("value", "")).strip() != ""
            ]
            if valid_macros:
                params["macros"] = valid_macros

        # Execute host.create
        res = self._call("host.create", params)
        if "result" in res and "hostids" in res["result"]:
            created_id = res["result"]["hostids"][0]
            return True, f"Host '{host}' created successfully (ID: {created_id})", created_id

        error_data = res.get("error", {})
        err_msg = error_data.get("data") or error_data.get("message") or "Unknown error"
        return False, f"Failed to create host '{host}': {err_msg}", None

    def scan_host(self, ip: str) -> Dict[str, Any]:
        """
        Scan and probe target client IP to detect available capabilities,
        open ports, operating system, and suggested monitoring items.
        """
        import socket
        import struct
        from concurrent.futures import ThreadPoolExecutor

        ip = ip.strip()
        ports_to_check = {
            10050: "zabbix_agent",
            80: "http",
            443: "https",
            3306: "mysql",
            5432: "postgresql",
            1433: "mssql",
            6379: "redis",
            2375: "docker",
            161: "snmp",
            22: "ssh",
            3389: "rdp"
        }

        open_ports = {}

        def probe_port(p):
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(0.7)
                res = s.connect_ex((ip, p))
                s.close()
                return p, (res == 0)
            except Exception:
                return p, False

        with ThreadPoolExecutor(max_workers=10) as executor:
            results = executor.map(probe_port, ports_to_check.keys())
            for p, is_open in results:
                if is_open:
                    open_ports[p] = ports_to_check[p]

        is_online = len(open_ports) > 0
        os_name = "Unknown"
        agent_info = None

        # If Zabbix Agent port 10050 is open, query uname and ping
        if 10050 in open_ports:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(1.0)
                s.connect((ip, 10050))
                cmd = b"system.uname"
                packet = b"ZBXD\x01" + struct.pack("<Q", len(cmd)) + cmd
                s.sendall(packet)
                header = s.recv(13)
                if len(header) >= 13 and header.startswith(b"ZBXD\x01"):
                    data_len = struct.unpack("<Q", header[5:13])[0]
                    uname_data = s.recv(min(data_len, 2048)).decode("utf-8", errors="replace").strip()
                    agent_info = uname_data
                    if "linux" in uname_data.lower():
                        os_name = "Linux"
                    elif "windows" in uname_data.lower():
                        os_name = "Windows"
                s.close()
            except Exception:
                pass

        # Fallback OS guess from SSH (22) vs RDP (3389)
        if os_name == "Unknown":
            if 22 in open_ports and 3389 not in open_ports:
                os_name = "Linux (ตรวจพบจากพอร์ต SSH 22)"
            elif 3389 in open_ports and 22 not in open_ports:
                os_name = "Windows (ตรวจพบจากพอร์ต RDP 3389)"

        # Prepare suggested monitor capabilities with checkboxes
        capabilities = []

        # 1. OS & Core Resources
        os_template = "Linux by Zabbix agent" if "windows" not in os_name.lower() else "Windows by Zabbix agent"
        has_agent = 10050 in open_ports
        capabilities.append({
            "id": "os_metrics",
            "category": "OS & Resources",
            "name": f"ระบบปฏิบัติการและทรัพยากรหลัก ({os_name})",
            "description": "วัดการทำงานของ CPU, Memory/RAM, พื้นที่ Disk ทุกไดรฟ์, Network Traffic, และ Process ทำงาน",
            "template_name": os_template,
            "detected": has_agent,
            "checked": False,  # Default: Not checked, user selects manually
            "badge": "Agent Active" if has_agent else "Agent Port Closed"
        })

        # 2. ICMP Ping Availability
        capabilities.append({
            "id": "icmp_ping",
            "category": "Availability",
            "name": "ความพร้อมใช้งานและการเชื่อมต่อ (ICMP Ping & Uptime)",
            "description": "ตรวจสอบสถานะเปิด/ปิดเครื่อง, ความเร็วการตอบสนอง (Response time) และ Packet Loss",
            "template_name": "ICMP Ping",
            "detected": True,
            "checked": False,  # Default: Not checked, user selects manually
            "badge": "ICMP Ping"
        })

        # 3. Web Server
        has_web = (80 in open_ports or 443 in open_ports)
        capabilities.append({
            "id": "web_server",
            "category": "Web Service",
            "name": "เว็บเซิร์ฟเวอร์ (HTTP / HTTPS Web Status)",
            "description": "ตรวจจับสถานะเว็บเซิร์ฟเวอร์, ความพร้อมใช้งานของพอร์ต 80/443 และปริมาณ Request",
            "template_name": "Nginx by Zabbix agent",
            "detected": has_web,
            "checked": False,  # Default: Not checked, user selects manually
            "badge": "ตรวจพบ Port 80/443" if has_web else "ไม่พบพอร์ตเว็บ"
        })

        # 4. Database Server
        has_mysql = 3306 in open_ports
        has_postgres = 5432 in open_ports
        has_mssql = 1433 in open_ports
        db_detected = has_mysql or has_postgres or has_mssql

        db_template = "MySQL by Zabbix agent"
        db_name = "ฐานข้อมูล (Database Metrics)"
        if has_mysql:
            db_name = "MySQL / MariaDB Database (Port 3306)"
            db_template = "MySQL by Zabbix agent"
        elif has_postgres:
            db_name = "PostgreSQL Database (Port 5432)"
            db_template = "PostgreSQL by Zabbix agent"
        elif has_mssql:
            db_name = "Microsoft SQL Server (Port 1433)"
            db_template = "MSSQL by Zabbix agent"

        capabilities.append({
            "id": "database",
            "category": "Database",
            "name": db_name,
            "description": "วัดจำนวน Connections, Queries/วินาที, ขนาด Database และ Cache Hit Rate",
            "template_name": db_template,
            "detected": db_detected,
            "checked": False,  # Default: Not checked, user selects manually
            "badge": "ตรวจพบ Database" if db_detected else "ไม่พบพอร์ต Database"
        })

        # 5. Docker Containers
        has_docker = 2375 in open_ports
        capabilities.append({
            "id": "docker",
            "category": "Containers",
            "name": "Docker Containers & Daemon",
            "description": "วัดการทำงานของ Container แต่ละตัว, CPU/Memory per Container และ Uptime",
            "template_name": "Docker",
            "detected": has_docker,
            "checked": False,  # Default: Not checked, user selects manually
            "badge": "ตรวจพบ Docker" if has_docker else "ไม่พบ Docker"
        })

        return {
            "success": True,
            "ip": ip,
            "is_online": is_online,
            "os_detected": os_name,
            "agent_info": agent_info,
            "open_ports": open_ports,
            "capabilities": capabilities
        }

    STANDARD_VALUE_MAPS = {
        "Windows service state": [
            {"value": "0", "newvalue": "Running", "type": 0},
            {"value": "1", "newvalue": "Paused", "type": 0},
            {"value": "2", "newvalue": "Start pending", "type": 0},
            {"value": "3", "newvalue": "Pause pending", "type": 0},
            {"value": "4", "newvalue": "Continue pending", "type": 0},
            {"value": "5", "newvalue": "Stop pending", "type": 0},
            {"value": "6", "newvalue": "Stopped", "type": 0},
            {"value": "7", "newvalue": "Unknown", "type": 0},
            {"value": "255", "newvalue": "No such service", "type": 0}
        ],
        "Windows service startup": [
            {"value": "0", "newvalue": "Automatic", "type": 0},
            {"value": "1", "newvalue": "Automatic (delayed)", "type": 0},
            {"value": "2", "newvalue": "Manual", "type": 0},
            {"value": "3", "newvalue": "Disabled", "type": 0},
            {"value": "4", "newvalue": "Unknown", "type": 0}
        ],
        "Service state": [
            {"value": "0", "newvalue": "Down", "type": 0},
            {"value": "1", "newvalue": "Up", "type": 0}
        ],
        "Zabbix agent ping status": [
            {"value": "0", "newvalue": "Cannot be reached", "type": 0},
            {"value": "1", "newvalue": "Up / Available", "type": 0}
        ],
        "Host availability": [
            {"value": "0", "newvalue": "Not available", "type": 0},
            {"value": "1", "newvalue": "Available", "type": 0},
            {"value": "2", "newvalue": "Unknown", "type": 0}
        ],
        "ICMP Ping status": [
            {"value": "0", "newvalue": "Down (No response)", "type": 0},
            {"value": "1", "newvalue": "Up (Responding)", "type": 0}
        ]
    }

    def get_host_items(self, hostid: str) -> Dict[str, Any]:
        """
        Fetch all monitor items configured on a host,
        grouped into clean user-friendly categories.
        """
        res = self._call("item.get", {
            "hostids": [str(hostid)],
            "output": ["itemid", "name", "key_", "status", "state", "error", "units", "lastvalue", "lastclock",
                       "value_type", "delay", "valuemapid", "type", "templateid"],
            "selectValueMap": ["valuemapid", "name"],
            "sortfield": "name"
        })

        items = res.get("result", [])

        # Categorize items
        categories = {
            "cpu": {"title": "💻 ซีพียู (CPU & Processor)", "items": []},
            "memory": {"title": "🧠 หน่วยความจำ (Memory & Swap)", "items": []},
            "disk": {"title": "💾 พื้นที่จัดเก็บ (Disk & Storage)", "items": []},
            "network": {"title": "🌐 เครือข่าย (Network Interfaces)", "items": []},
            "availability": {"title": "⚡ การเชื่อมต่อ & Uptime (Availability)", "items": []},
            "system": {"title": "⚙️ ระบบและโปรเซส (System & Processes)", "items": []},
            "other": {"title": "📦 เมทริกซ์อื่นๆ (Other Metrics)", "items": []}
        }

        for item in items:
            key = item.get("key_", "").lower()
            name = item.get("name", "").lower()

            if any(k in key or k in name for k in ["cpu", "load", "processor"]):
                categories["cpu"]["items"].append(item)
            elif any(k in key or k in name for k in ["memory", "swap", "vfs.fs.size", "ram", "vm.memory"]):
                if "vfs.fs" in key:
                    categories["disk"]["items"].append(item)
                else:
                    categories["memory"]["items"].append(item)
            elif any(k in key or k in name for k in ["disk", "vfs.fs", "storage", "filesystem"]):
                categories["disk"]["items"].append(item)
            elif any(k in key or k in name for k in ["net.if", "network", "interface", "traffic", "bandwidth"]):
                categories["network"]["items"].append(item)
            elif any(k in key or k in name for k in ["ping", "uptime", "status", "agent.ping", "nodata"]):
                categories["availability"]["items"].append(item)
            elif any(k in key or k in name for k in ["proc", "service", "system.", "uname", "users", "sw."]):
                categories["system"]["items"].append(item)
            else:
                categories["other"]["items"].append(item)

        # Remove empty categories
        active_categories = {k: v for k, v in categories.items() if len(v["items"]) > 0}

        # Query parent templates attached to this host
        parent_templates = []
        try:
            h_info = self._call("host.get", {
                "hostids": [str(hostid)],
                "output": ["hostid", "host", "name"],
                "selectParentTemplates": ["templateid", "name"]
            })
            if h_info.get("result"):
                parent_templates = h_info["result"][0].get("parentTemplates", [])
        except Exception:
            pass

        valuemaps = self.get_host_valuemaps(hostid)

        return {
            "success": True,
            "hostid": hostid,
            "total_items": len(items),
            "categories": active_categories,
            "items": items,
            "parent_templates": parent_templates,
            "valuemaps": valuemaps
        }

    def get_host_valuemaps(self, hostid: str) -> List[Dict[str, Any]]:
        """Fetch all value maps configured on a host with their full mappings"""
        res = self._call("valuemap.get", {
            "hostids": [str(hostid)],
            "output": ["valuemapid", "name", "hostid"],
            "selectMappings": "extend"
        })
        return res.get("result", [])

    def get_or_create_valuemap(self, hostid: str, name: str, custom_mappings: Optional[List[Dict[str, Any]]] = None) -> Optional[str]:
        """Find existing valuemap by name on this host, or create it if missing"""
        existing = self._call("valuemap.get", {
            "hostids": [str(hostid)],
            "filter": {"name": [name]},
            "output": ["valuemapid", "name"]
        }).get("result", [])
        if existing:
            return str(existing[0]["valuemapid"])

        mappings = custom_mappings or self.STANDARD_VALUE_MAPS.get(name)
        if not mappings:
            return None

        res = self._call("valuemap.create", {
            "hostid": str(hostid),
            "name": name,
            "mappings": mappings
        })
        if "result" in res and "valuemapids" in res["result"]:
            return str(res["result"]["valuemapids"][0])
        return None

    def ensure_standard_valuemaps(self, hostid: str) -> Tuple[bool, int, str]:
        """
        Creates all standard Value Maps (Windows service state, startup, service state, agent ping, host availability)
        on the host and links any matching items.
        """
        created = 0
        vm_map = {}
        for name, mappings in self.STANDARD_VALUE_MAPS.items():
            existing = self._call("valuemap.get", {
                "hostids": [str(hostid)],
                "filter": {"name": [name]},
                "output": ["valuemapid", "name"]
            }).get("result", [])
            if existing:
                vm_map[name] = str(existing[0]["valuemapid"])
            else:
                c_res = self._call("valuemap.create", {
                    "hostid": str(hostid),
                    "name": name,
                    "mappings": mappings
                })
                if "result" in c_res and "valuemapids" in c_res["result"]:
                    vm_map[name] = str(c_res["result"]["valuemapids"][0])
                    created += 1

        # Auto-link items that should have these value maps
        items = self._call("item.get", {
            "hostids": [str(hostid)],
            "output": ["itemid", "name", "key_", "valuemapid"]
        }).get("result", [])

        linked_count = 0
        for it in items:
            key = it.get("key_", "")
            target_vmid = None
            if "service.info[" in key and key.endswith(",state]"):
                target_vmid = vm_map.get("Windows service state")
            elif "service.info[" in key and key.endswith(",startup]"):
                target_vmid = vm_map.get("Windows service startup")
            elif key == "agent.ping":
                target_vmid = vm_map.get("Zabbix agent ping status")
            elif key == "icmpping":
                target_vmid = vm_map.get("ICMP Ping status")

            if target_vmid and str(it.get("valuemapid")) != str(target_vmid):
                self._call("item.update", {"itemid": it["itemid"], "valuemapid": str(target_vmid)})
                linked_count += 1

        msg = f"สร้าง Value Mapping ใหม่ {created} ชุด และผูกเข้ากับ Items {linked_count} รายการเรียบร้อยแล้ว"
        return True, created + linked_count, msg

    def unlink_templates(self, hostid: str, template_ids: Optional[List[str]] = None) -> Tuple[bool, str, int]:
        """
        Unlinks and clears parent templates from a host.
        Clearing removes all items, triggers, and graphs inherited from the templates,
        while strictly preserving all standalone custom service items.
        """
        host_info = self._call("host.get", {
            "hostids": [str(hostid)],
            "output": ["hostid", "host", "name"],
            "selectParentTemplates": ["templateid", "name"]
        })
        if not host_info.get("result"):
            return False, f"Host ID {hostid} ไม่พบในระบบ Zabbix", 0

        parent_templates = host_info["result"][0].get("parentTemplates", [])
        if not parent_templates:
            return True, "เครื่องนี้ไม่มี Template ผูกอยู่แล้ว", 0

        if template_ids:
            target_ids = [str(tid) for tid in template_ids]
            t_to_clear = [t for t in parent_templates if str(t.get("templateid")) in target_ids]
        else:
            t_to_clear = parent_templates

        if not t_to_clear:
            return True, "ไม่พบ Template ที่ตรงกับที่ต้องการปลด", 0

        res = self._call("host.update", {
            "hostid": str(hostid),
            "templates_clear": [{"templateid": str(t["templateid"])} for t in t_to_clear]
        })

        if "result" in res and "hostids" in res["result"]:
            tmpl_names = ", ".join(t.get("name", "") for t in t_to_clear)
            return True, f"ปลด Template ({tmpl_names}) และลบ Items ที่มาจากแม่แบบทั้งหมดเรียบร้อยแล้ว", len(t_to_clear)
        else:
            err = res.get("error", {})
            err_msg = err.get("data") or err.get("message") or "Failed to unlink templates"
            return False, f"ไม่สามารถปลด Template ได้: {err_msg}", 0

    def link_templates(self, hostid: str, template_ids: List[str]) -> Tuple[bool, str, int]:
        """
        Link (attach) one or more templates to a host without removing existing ones.
        Merges requested template IDs with the host's current parent templates.
        Returns: (success, message, newly_linked_count)
        """
        template_ids = [str(t) for t in (template_ids or []) if str(t).strip()]
        if not template_ids:
            return False, "ไม่มี Template ที่จะผูก", 0

        host_info = self._call("host.get", {
            "hostids": [str(hostid)],
            "output": ["hostid", "host", "name"],
            "selectParentTemplates": ["templateid", "name"]
        })
        if not host_info.get("result"):
            return False, f"Host ID {hostid} ไม่พบในระบบ Zabbix", 0

        existing = host_info["result"][0].get("parentTemplates", [])
        existing_ids = {str(t.get("templateid")) for t in existing}

        new_ids = [tid for tid in template_ids if tid not in existing_ids]
        if not new_ids:
            return True, "Template ที่เลือกถูกผูกกับเครื่องนี้อยู่แล้ว", 0

        # Resolve names of the templates being added (for a friendly message)
        tmpl_lookup = self._call("template.get", {
            "templateids": new_ids,
            "output": ["templateid", "name"]
        })
        added_names = [t.get("name", "") for t in tmpl_lookup.get("result", [])]

        merged = [{"templateid": tid} for tid in (existing_ids | set(new_ids))]
        res = self._call("host.update", {
            "hostid": str(hostid),
            "templates": merged
        })

        if "result" in res and "hostids" in res["result"]:
            names = ", ".join(n for n in added_names if n) or "Template"
            return True, f"ผูก Template ({names}) เข้ากับเครื่องเรียบร้อยแล้ว", len(new_ids)
        else:
            err = res.get("error", {})
            err_msg = err.get("data") or err.get("message") or "Failed to link templates"
            return False, f"ไม่สามารถผูก Template ได้: {err_msg}", 0

    def update_items_status(self, item_updates: List[Dict[str, Any]]) -> Tuple[bool, int, str]:
        """
        Enable or disable specific items on a host.
        item_updates format: [{"itemid": "123", "status": 0}, {"itemid": "124", "status": 1}]
        status 0 = Enabled, 1 = Disabled
        """
        success_count = 0
        last_error = ""

        for update in item_updates:
            itemid = str(update.get("itemid"))
            status = int(update.get("status", 0))

            res = self._call("item.update", {
                "itemid": itemid,
                "status": status
            })

            if "result" in res and "itemids" in res["result"]:
                success_count += 1
            else:
                err = res.get("error", {})
                last_error = err.get("data") or err.get("message") or "Failed to update item"

        return (success_count > 0), success_count, last_error

    def execute_items_now(self, itemids: List[str]) -> Tuple[bool, str]:
        """Trigger 'Check now' task (type 6) for items to immediately fetch data"""
        tasks = []
        for iid in itemids:
            tasks.append({
                "type": 6,
                "request": {"itemid": str(iid)}
            })

        res = self._call("task.create", tasks)
        if "result" in res and "taskids" in res["result"]:
            return True, f"Triggered {len(res['result']['taskids'])} item checks immediately"
        err = res.get("error", {})
        return False, err.get("data") or err.get("message") or "Failed to trigger check now"

    STANDARD_LINUX_SERVICES = [
        # Remote & Security
        {"name": "sshd", "display_name": "OpenSSH Server Daemon (sshd)", "category": "Remote & Security", "key": "proc.num[sshd]"},
        {"name": "cron", "display_name": "Cron Job Scheduler (cron / crond)", "category": "System", "key": "proc.num[cron]"},
        {"name": "ufw", "display_name": "Uncomplicated Firewall (ufw)", "category": "Security", "key": "proc.num[ufw]"},
        {"name": "fail2ban", "display_name": "Fail2Ban Intrusion Prevention", "category": "Security", "key": "proc.num[fail2ban-server]"},
        {"name": "rsyslog", "display_name": "System Logging Service (rsyslogd)", "category": "System", "key": "proc.num[rsyslogd]"},
        {"name": "systemd-journald", "display_name": "Systemd Journal Daemon", "category": "System", "key": "proc.num[systemd-journald]"},
        {"name": "chrony", "display_name": "Chrony NTP Time Synchronization", "category": "System", "key": "proc.num[chronyd]"},

        # Monitoring
        {"name": "zabbix-agent", "display_name": "Zabbix Agent Daemon (zabbix_agentd)", "category": "Monitoring", "key": "proc.num[zabbix_agentd]"},
        {"name": "zabbix-agent2", "display_name": "Zabbix Agent 2 Daemon (zabbix_agent2)", "category": "Monitoring", "key": "proc.num[zabbix_agent2]"},
        {"name": "zabbix-server", "display_name": "Zabbix Server Daemon (zabbix_server)", "category": "Monitoring", "key": "proc.num[zabbix_server]"},

        # Web & App Servers
        {"name": "nginx", "display_name": "Nginx Web Server", "category": "Web Server", "key": "proc.num[nginx]"},
        {"name": "apache2", "display_name": "Apache HTTP Server (apache2 / httpd)", "category": "Web Server", "key": "proc.num[apache2]"},
        {"name": "php-fpm", "display_name": "PHP FastCGI Process Manager (php-fpm)", "category": "Web & App", "key": "proc.num[php-fpm]"},
        {"name": "tomcat", "display_name": "Apache Tomcat Application Server", "category": "Web & App", "key": "proc.num[java]"},
        {"name": "node", "display_name": "Node.js Application Runtime", "category": "Web & App", "key": "proc.num[node]"},
        {"name": "pm2", "display_name": "PM2 Process Manager for Node.js", "category": "Web & App", "key": "proc.num[PM2]"},

        # Databases & In-Memory Stores
        {"name": "mysql", "display_name": "MySQL Database Server (mysqld)", "category": "Database", "key": "proc.num[mysqld]"},
        {"name": "mariadb", "display_name": "MariaDB Database Server (mariadbd)", "category": "Database", "key": "proc.num[mariadbd]"},
        {"name": "postgresql", "display_name": "PostgreSQL Database Server (postgres)", "category": "Database", "key": "proc.num[postgres]"},
        {"name": "redis", "display_name": "Redis In-Memory Data Store (redis-server)", "category": "Database", "key": "proc.num[redis-server]"},
        {"name": "mongod", "display_name": "MongoDB Document Database (mongod)", "category": "Database", "key": "proc.num[mongod]"},
        {"name": "elasticsearch", "display_name": "Elasticsearch Search Engine", "category": "Database", "key": "proc.num[elasticsearch]"},

        # Containers & Orchestration
        {"name": "docker", "display_name": "Docker Container Engine (dockerd)", "category": "Containers", "key": "proc.num[dockerd]"},
        {"name": "containerd", "display_name": "containerd Container Runtime", "category": "Containers", "key": "proc.num[containerd]"},
        {"name": "kubelet", "display_name": "Kubernetes Node Agent (kubelet)", "category": "Containers", "key": "proc.num[kubelet]"},

        # Messaging & File
        {"name": "rabbitmq-server", "display_name": "RabbitMQ Message Broker", "category": "Messaging", "key": "proc.num[beam.smp]"},
        {"name": "smbd", "display_name": "Samba SMB/CIFS File Sharing (smbd)", "category": "File Sharing", "key": "proc.num[smbd]"},
        {"name": "nfs-server", "display_name": "Network File System (nfsd)", "category": "File Sharing", "key": "proc.num[nfsd]"},
        {"name": "postfix", "display_name": "Postfix Mail Transfer Agent (master)", "category": "Mail", "key": "proc.num[master]"},
        {"name": "named", "display_name": "BIND9 Domain Name Server (named)", "category": "DNS", "key": "proc.num[named]"}
    ]

    STANDARD_WINDOWS_SERVICES = [
        {"name": "Spooler", "display_name": "Print Spooler (บริการจัดการคิวพิมพ์)", "category": "System"},
        {"name": "TermService", "display_name": "Remote Desktop Services (บริการรีโมทเดสก์ท็อป RDP)", "category": "Remote"},
        {"name": "MSSQLSERVER", "display_name": "SQL Server (MSSQLSERVER ฐานข้อมูลหลัก)", "category": "Database"},
        {"name": "SQLSERVERAGENT", "display_name": "SQL Server Agent (งานตั้งเวลาของ SQL)", "category": "Database"},
        {"name": "W3SVC", "display_name": "World Wide Web Publishing Service (IIS เว็บเซิร์ฟเวอร์)", "category": "Web"},
        {"name": "W32Time", "display_name": "Windows Time (ซิงก์เวลาเครื่อง)", "category": "System"},
        {"name": "wuauserv", "display_name": "Windows Update (บริการอัปเดตระบบ)", "category": "System"},
        {"name": "LanmanServer", "display_name": "Server (บริการแชร์ไฟล์และปริ้นเตอร์ SMB)", "category": "System"},
        {"name": "LanmanWorkstation", "display_name": "Workstation (การเชื่อมต่อเครือข่ายภายนอก)", "category": "System"},
        {"name": "Dnscache", "display_name": "DNS Client (แคชชื่อโดเมน)", "category": "Network"},
        {"name": "Dhcp", "display_name": "DHCP Client (รับไอพีอัตโนมัติ)", "category": "Network"},
        {"name": "EventLog", "display_name": "Windows Event Log (บันทึกเหตุการณ์ระบบ)", "category": "System"},
        {"name": "Schedule", "display_name": "Task Scheduler (งานตั้งเวลาของ Windows)", "category": "System"},
        {"name": "Zabbix Agent", "display_name": "Zabbix Agent (ตัวตรวจวัดระบบ)", "category": "Monitoring"},
        {"name": "SBOClientAgent", "display_name": "SAP Business One Client Agent", "category": "Business"}
    ]

    def discover_host_services(self, ip: str, hostid: Optional[str] = None, os_type: Optional[str] = None) -> Dict[str, Any]:
        """
        Discovers actual services and applications running on the target machine (Linux & Windows).
        Uses multithreaded network inspection, OS-level query (Win32 Get-Service), and curated system services.
        Cross-references with Zabbix to indicate if each service is already monitored.
        """
        from concurrent.futures import ThreadPoolExecutor
        clean_ip = ip.strip()
        # Only plain IPs / hostnames may reach sockets or the PowerShell command below
        if not self.is_safe_address(clean_ip):
            return {"success": False, "ip": clean_ip, "hostid": hostid, "total_services": 0,
                    "running_count": 0, "services": [], "open_ports": {}, "os_type": os_type or "",
                    "error": "Invalid IP address or hostname"}

        # Check existing monitored service items on this host in Zabbix
        existing_keys = set()
        existing_service_items = {}
        if hostid:
            try:
                res = self._call("item.get", {
                    "hostids": [str(hostid)],
                    "output": ["itemid", "name", "key_", "status", "lastvalue"]
                })
                for it in res.get("result", []):
                    k = it.get("key_", "")
                    existing_keys.add(k)
                    val = str(it.get("lastvalue", "0")).strip()
                    is_run = (val == "0") if "service.info[" in k else (val != "0")
                    raw_name = ""
                    if "service.info[" in k and ",state" in k:
                        raw_name = k.split("service.info[", 1)[1].split(",")[0].strip()
                    elif "proc.num[" in k:
                        raw_name = k.split("proc.num[", 1)[1].split("]")[0].strip()

                    if raw_name:
                        existing_service_items[raw_name.lower()] = {
                            "name": raw_name,
                            "display_name": it.get("name") or raw_name,
                            "status": "Running" if is_run else "Stopped",
                            "status_code": 4 if is_run else 1,
                            "startup_type": "Monitored Item",
                            "key": k,
                            "is_running": is_run,
                            "monitored": True
                        }
            except Exception:
                pass

        # Fast multithreaded port check to find open services
        common_ports = {
            22: ("sshd", "OpenSSH Server Daemon (sshd)", "proc.num[sshd]", "Linux"),
            80: ("apache2", "Apache / HTTP Web Server (Port 80)", "proc.num[apache2]", "Web"),
            443: ("nginx", "Nginx / SSL Web Server (Port 443)", "proc.num[nginx]", "Web"),
            3306: ("mysql", "MySQL / MariaDB Database Server (Port 3306)", "proc.num[mysqld]", "Database"),
            5432: ("postgresql", "PostgreSQL Database Server (Port 5432)", "proc.num[postgres]", "Database"),
            6379: ("redis-server", "Redis In-Memory Key-Value Store (Port 6379)", "proc.num[redis-server]", "Cache"),
            27017: ("mongod", "MongoDB Document Database (Port 27017)", "proc.num[mongod]", "Database"),
            10050: ("zabbix-agent", "Zabbix Agent Daemon (Port 10050)", "proc.num[zabbix_agentd]", "Monitoring"),
            10051: ("zabbix-server", "Zabbix Server Daemon (Port 10051)", "proc.num[zabbix_server]", "Monitoring"),
            9000: ("php-fpm", "PHP FastCGI Process Manager (Port 9000)", "proc.num[php-fpm]", "Web & App"),
            8080: ("tomcat", "Apache Tomcat / Java Web Service (Port 8080)", "proc.num[java]", "Web & App"),
            3000: ("node", "Node.js Application Runtime (Port 3000)", "proc.num[node]", "Web & App"),
            53: ("named", "BIND DNS Server Daemon (Port 53)", "proc.num[named]", "DNS"),
            21: ("vsftpd", "FTP File Transfer Protocol (Port 21)", "proc.num[vsftpd]", "FTP"),
            25: ("postfix", "Postfix Mail Transfer Agent (Port 25)", "proc.num[master]", "Mail"),
            2375: ("docker", "Docker Container Daemon (Port 2375)", "proc.num[dockerd]", "Containers"),
            9200: ("elasticsearch", "Elasticsearch Search Engine (Port 9200)", "proc.num[elasticsearch]", "Search"),
            5672: ("rabbitmq-server", "RabbitMQ Message Broker (Port 5672)", "proc.num[beam.smp]", "Messaging"),
            3389: ("TermService", "Remote Desktop Services (RDP Port 3389)", "service.info[TermService,state]", "Windows"),
            1433: ("MSSQLSERVER", "Microsoft SQL Server (Port 1433)", "service.info[MSSQLSERVER,state]", "Windows"),
            445: ("LanmanServer", "Server SMB File Sharing (Port 445)", "service.info[LanmanServer,state]", "Windows")
        }

        open_port_services = {}
        open_ports_map = {}

        def check_port(port):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.3)
                res = sock.connect_ex((clean_ip, port))
                sock.close()
                return port if res == 0 else None
            except Exception:
                return None

        with ThreadPoolExecutor(max_workers=25) as executor:
            found_ports = list(executor.map(check_port, list(common_ports.keys())))

        for p in found_ports:
            if p is not None and p in common_ports:
                s_name, d_name, key, cat = common_ports[p]
                open_port_services[s_name.lower()] = {
                    "name": s_name,
                    "display_name": d_name,
                    "status": "Running",
                    "status_code": 4,
                    "startup_type": f"Port {p}",
                    "key": key,
                    "is_running": True,
                    "monitored": (key in existing_keys) or (s_name.lower() in existing_service_items)
                }
                open_ports_map[p] = d_name

        # Determine target OS
        if os_type:
            # AIX and other Unix systems use the same proc.num based checks as Linux
            is_linux = any(k in os_type.lower() for k in ("linux", "aix", "unix"))
        else:
            if 22 in open_ports_map and 3389 not in open_ports_map:
                is_linux = True
            elif 3389 in open_ports_map or 1433 in open_ports_map:
                is_linux = False
            else:
                is_linux = False

        discovered_map = {}

        if is_linux:
            # 1. Add services detected active from open ports
            for k, svc in open_port_services.items():
                discovered_map[k] = svc

            # 2. Add standard curated Linux server services
            for lsvc in self.STANDARD_LINUX_SERVICES:
                k_name = lsvc["name"].lower()
                if k_name not in discovered_map:
                    zbx_key = lsvc.get("key", f"proc.num[{lsvc['name']}]")
                    discovered_map[k_name] = {
                        "name": lsvc["name"],
                        "display_name": lsvc["display_name"],
                        "status": "พร้อม Monitor",
                        "status_code": 1,
                        "startup_type": lsvc.get("category", "Linux Service"),
                        "key": zbx_key,
                        "is_running": False,
                        "monitored": (zbx_key in existing_keys) or (k_name in existing_service_items)
                    }
        else:
            # Target is Windows: Query live Win32 Services if possible
            local_ips = {"127.0.0.1", "localhost", "::1"}
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(("8.8.8.8", 80))
                local_ips.add(s.getsockname()[0])
                s.close()
            except Exception:
                pass

            is_local = clean_ip in local_ips

            if os.name == "nt":
                try:
                    import subprocess
                    ps_cmd = "Get-Service | Select-Object -Property Name, DisplayName, Status, StartType | ConvertTo-Json -Compress"
                    if not is_local:
                        ps_cmd = f"Get-Service -ComputerName '{clean_ip}' -ErrorAction Stop | Select-Object -Property Name, DisplayName, Status, StartType | ConvertTo-Json -Compress"

                    proc = subprocess.run(
                        ["powershell", "-NoProfile", "-Command", ps_cmd],
                        capture_output=True,
                        text=True,
                        encoding="utf-8",
                        timeout=4
                    )
                    if proc.returncode == 0 and proc.stdout.strip():
                        raw_svc = json.loads(proc.stdout)
                        if isinstance(raw_svc, dict):
                            raw_svc = [raw_svc]

                        for s in raw_svc:
                            s_name = s.get("Name", "")
                            d_name = s.get("DisplayName", "") or s_name
                            raw_status = s.get("Status", 1)
                            raw_start = s.get("StartType", 3)

                            status_str = "Running" if raw_status == 4 else "Stopped"
                            start_str = "Automatic" if raw_start == 2 else ("Manual" if raw_start == 3 else ("Disabled" if raw_start == 4 else "Other"))
                            zbx_key = f"service.info[{s_name},state]"

                            is_mon = (zbx_key in existing_keys) or (s_name.lower() in existing_service_items)

                            discovered_map[s_name.lower()] = {
                                "name": s_name,
                                "display_name": d_name,
                                "status": status_str,
                                "status_code": raw_status,
                                "startup_type": start_str,
                                "key": zbx_key,
                                "is_running": (raw_status == 4),
                                "monitored": is_mon
                            }
                except Exception:
                    pass

            # Merge services from open ports
            for k, svc in open_port_services.items():
                if k not in discovered_map:
                    discovered_map[k] = svc

            # If Get-Service didn't populate (e.g. remote Windows without WinRM), add standard Windows services
            if len(discovered_map) < 5:
                for wsvc in self.STANDARD_WINDOWS_SERVICES:
                    k_name = wsvc["name"].lower()
                    if k_name not in discovered_map:
                        zbx_key = f"service.info[{wsvc['name']},state]"
                        discovered_map[k_name] = {
                            "name": wsvc["name"],
                            "display_name": wsvc["display_name"],
                            "status": "พร้อม Monitor",
                            "status_code": 1,
                            "startup_type": wsvc.get("category", "Windows Service"),
                            "key": zbx_key,
                            "is_running": False,
                            "monitored": (zbx_key in existing_keys) or (k_name in existing_service_items)
                        }

        # Merge existing Zabbix service items
        for k_name, zbx_svc in existing_service_items.items():
            if k_name not in discovered_map:
                discovered_map[k_name] = zbx_svc

        services = list(discovered_map.values())

        # Keywords for business, server, database, and monitoring application services
        app_keywords = [
            "sbo", "sap", "zabbix", "agent", "sql", "oracle", "db", "mysql", "postgres",
            "nginx", "apache", "http", "iis", "w3svc", "tomcat", "java", "node", "spooler",
            "remote desktop", "termservice", "ssh", "docker", "redis", "elasticsearch"
        ]

        def service_priority(s):
            if s.get("monitored"):
                return 0
            name_lower = (s.get("name", "") + " " + s.get("display_name", "")).lower()
            if any(k in name_lower for k in app_keywords):
                return 1 if s.get("is_running") else 2
            if s.get("is_running"):
                return 3
            return 4

        services.sort(key=lambda x: (service_priority(x), x.get("display_name", "").lower()))

        return {
            "success": True,
            "ip": clean_ip,
            "hostid": hostid,
            "total_services": len(services),
            "running_count": sum(1 for s in services if s.get("is_running")),
            "services": services,
            "open_ports": open_ports_map,
            "os_type": "Linux" if is_linux else "Windows"
        }

    def add_service_items(self, hostid: str, service_items: List[Dict[str, str]], os_type: str = "windows") -> Tuple[bool, int, str]:
        """
        Creates or enables monitoring items in Zabbix for the selected services (Linux or Windows).
        service_items format: [{"name": "sshd", "display_name": "OpenSSH Server"}, ...]
        """
        if not service_items:
            return False, 0, "ไม่มีเซอร์วิสที่เลือกสำหรับ Monitor"

        host_info = self._call("host.get", {
            "hostids": [str(hostid)],
            "output": ["hostid", "host", "name"],
            "selectInterfaces": ["interfaceid", "type", "main"]
        })
        if not host_info.get("result"):
            return False, 0, f"Host {hostid} not found"

        host_data = host_info["result"][0]
        host_tech_name = host_data.get("host") or ""
        interfaces = host_data.get("interfaces", [])
        if not interfaces:
            return False, 0, "Host นี้ไม่มี Network Interface เชื่อมต่ออยู่"

        target_iface_id = interfaces[0]["interfaceid"]
        for iface in interfaces:
            if str(iface.get("type")) == "1":
                target_iface_id = iface["interfaceid"]
                break

        existing_items = self._call("item.get", {
            "hostids": [str(hostid)],
            "output": ["itemid", "name", "key_", "status"]
        }).get("result", [])
        key_map = {it["key_"]: it for it in existing_items}

        existing_triggers = self._call("trigger.get", {
            "hostids": [str(hostid)],
            "output": ["triggerid", "description", "expression", "status"]
        }).get("result", [])
        existing_trigger_descs = {t["description"]: t for t in existing_triggers}

        created_count = 0
        enabled_count = 0
        triggers_created = 0
        errors = []

        is_win = "win" in os_type.lower()
        vm_id = self.get_or_create_valuemap(hostid, "Windows service state") if is_win else None

        for svc in service_items:
            s_name = svc.get("name", "").strip()
            d_name = svc.get("display_name", "").strip() or s_name
            if not s_name:
                continue

            if is_win:
                zbx_key = svc.get("key") or f"service.info[{s_name},state]"
            else:
                zbx_key = svc.get("key") or f"proc.num[{s_name}]"
            # Trigger logic follows the key type (a Windows host can also have proc.num items)
            is_service_key = zbx_key.startswith("service.info[")
            if is_service_key:
                t_expr = f"last(/{host_tech_name}/{zbx_key})<>0"
            else:
                t_expr = f"last(/{host_tech_name}/{zbx_key})=0"

            if zbx_key in key_map:
                item = key_map[zbx_key]
                update_payload = {"itemid": item["itemid"], "status": 0}
                if vm_id and is_service_key:
                    update_payload["valuemapid"] = str(vm_id)
                self._call("item.update", update_payload)
                enabled_count += 1
            else:
                create_payload = {
                    "name": (f"Status of service {d_name}" if is_service_key else f"Number of {d_name} processes"),
                    "key_": zbx_key,
                    "hostid": str(hostid),
                    "type": 0,
                    "value_type": 3,
                    "interfaceid": str(target_iface_id),
                    "delay": "1m",
                    "status": 0
                }
                if vm_id and is_service_key:
                    create_payload["valuemapid"] = str(vm_id)

                res = self._call("item.create", create_payload)
                if "result" in res and "itemids" in res["result"]:
                    created_count += 1
                else:
                    err = res.get("error", {})
                    err_msg = err.get("data") or err.get("message") or "Unknown error"
                    errors.append(f"{s_name}: {err_msg}")

            # Auto-create or enable Trigger for this service
            t_desc = (f'Service "{d_name}" is not running on {{HOST.NAME}}' if is_service_key
                      else f'Process "{d_name}" is not running on {{HOST.NAME}}')

            if t_desc in existing_trigger_descs:
                t_obj = existing_trigger_descs[t_desc]
                if str(t_obj.get("status")) != "0":
                    self._call("trigger.update", {"triggerid": t_obj["triggerid"], "status": 0})
            else:
                t_res = self._call("trigger.create", {
                    "description": t_desc,
                    "expression": t_expr,
                    "priority": 3,
                    "status": 0
                })
                if "result" in t_res and "triggerids" in t_res["result"]:
                    triggers_created += 1

        total_affected = created_count + enabled_count
        msg = f"เพิ่ม Monitor สำเร็จ {created_count} เซอร์วิส"
        if triggers_created > 0:
            msg += f" (พร้อมสร้าง Trigger แจ้งเตือนให้อัตโนมัติ {triggers_created} รายการ)"
        if enabled_count > 0:
            msg += f" (และเปิดใช้งานที่เคยปิดไว้อีก {enabled_count} เซอร์วิส)"
        if errors:
            msg += f" (ข้อผิดพลาด: {errors[0]})"

        return (total_affected > 0 or len(errors) == 0), total_affected, msg

    def add_custom_monitors(self, hostid: str, monitor_type: str, items: List[str],
                            software_name: str = "", create_trigger: bool = True,
                            severity: int = 3, os_type: str = "linux") -> Tuple[bool, int, str]:
        """
        Creates custom monitoring items and triggers in Zabbix for Process, Port, or Service.
        Supports comma-separated or list of multiple items.
        """
        if not items:
            return False, 0, "ไม่มีรายการที่ระบุสำหรับ Monitor"

        host_info = self._call("host.get", {
            "hostids": [str(hostid)],
            "output": ["hostid", "host", "name"],
            "selectInterfaces": ["interfaceid", "type", "main"]
        })
        if not host_info.get("result"):
            return False, 0, f"Host {hostid} not found"

        host_data = host_info["result"][0]
        host_tech_name = host_data.get("host") or ""
        interfaces = host_data.get("interfaces", [])
        if not interfaces:
            return False, 0, "Host นี้ไม่มี Network Interface เชื่อมต่ออยู่"

        target_iface_id = interfaces[0]["interfaceid"]
        for iface in interfaces:
            if str(iface.get("type")) == "1":
                target_iface_id = iface["interfaceid"]
                break

        existing_items = self._call("item.get", {
            "hostids": [str(hostid)],
            "output": ["itemid", "name", "key_", "status"]
        }).get("result", [])
        key_map = {it["key_"]: it for it in existing_items}

        existing_triggers = self._call("trigger.get", {
            "hostids": [str(hostid)],
            "output": ["triggerid", "description", "expression", "status"]
        }).get("result", [])
        existing_trigger_descs = {t["description"]: t for t in existing_triggers}

        created_count = 0
        enabled_count = 0
        triggers_created = 0
        errors = []

        is_win = "win" in os_type.lower()
        sw_tag = f" ({software_name})" if software_name else ""
        mtype = monitor_type.lower()

        for raw in items:
            raw_val = str(raw).strip()
            if not raw_val:
                continue

            if mtype in ("proc", "process"):
                zbx_key = f"proc.num[{raw_val}]"
                item_name = f"Process [{raw_val}]{sw_tag}"
                t_desc = f'Process "{raw_val}"{sw_tag} is not running on {{HOST.NAME}}'
                t_expr = f"last(/{host_tech_name}/{zbx_key})=0"
                val_type = 3
                vm_id = None
            elif mtype in ("port", "tcp", "listen"):
                port_num = re.sub(r"[^\d]", "", raw_val)
                if not port_num:
                    continue
                zbx_key = f"net.tcp.port[,{port_num}]"
                item_name = f"TCP Port {port_num} state{sw_tag}"
                t_desc = f'TCP Port {port_num}{sw_tag} is not responding on {{HOST.NAME}}'
                t_expr = f"last(/{host_tech_name}/{zbx_key})=0"
                val_type = 3
                vm_id = None
            elif mtype in ("svc", "service"):
                zbx_key = f"service.info[{raw_val},state]"
                item_name = f"Status of service {raw_val}{sw_tag}"
                t_desc = f'Service "{raw_val}"{sw_tag} is not running on {{HOST.NAME}}'
                t_expr = f"last(/{host_tech_name}/{zbx_key})<>0"
                val_type = 3
                vm_id = self.get_or_create_valuemap(hostid, "Windows service state") if is_win else None
            else:
                errors.append(f"ประเภท {monitor_type} ไม่ถูกต้อง")
                continue

            if zbx_key in key_map:
                it = key_map[zbx_key]
                update_payload = {"itemid": it["itemid"], "status": 0}
                if vm_id:
                    update_payload["valuemapid"] = str(vm_id)
                self._call("item.update", update_payload)
                enabled_count += 1
            else:
                create_payload = {
                    "name": item_name,
                    "key_": zbx_key,
                    "hostid": str(hostid),
                    "type": 0,
                    "value_type": val_type,
                    "interfaceid": str(target_iface_id),
                    "delay": "1m",
                    "status": 0
                }
                if vm_id:
                    create_payload["valuemapid"] = str(vm_id)

                res = self._call("item.create", create_payload)
                if "result" in res and "itemids" in res["result"]:
                    created_count += 1
                else:
                    err = res.get("error", {})
                    err_msg = err.get("data") or err.get("message") or "Unknown error"
                    errors.append(f"{raw_val}: {err_msg}")

            if create_trigger:
                if t_desc in existing_trigger_descs:
                    t_obj = existing_trigger_descs[t_desc]
                    if str(t_obj.get("status")) != "0":
                        self._call("trigger.update", {"triggerid": t_obj["triggerid"], "status": 0})
                else:
                    prio = int(severity) if str(severity) in ("1", "2", "3", "4", "5") else 3
                    t_res = self._call("trigger.create", {
                        "description": t_desc,
                        "expression": t_expr,
                        "priority": prio,
                        "status": 0
                    })
                    if "result" in t_res and "triggerids" in t_res["result"]:
                        triggers_created += 1

        total_affected = created_count + enabled_count
        label_type = "Process" if mtype in ("proc", "process") else ("Port" if mtype in ("port", "tcp") else "Service")
        msg = f"เพิ่ม Monitor {label_type} สำเร็จ {created_count} รายการ"
        if triggers_created > 0:
            msg += f" (พร้อมสร้าง Trigger แจ้งเตือน {triggers_created} รายการ)"
        if enabled_count > 0:
            msg += f" (เปิดใช้งานเดิมอีก {enabled_count} รายการ)"
        if errors:
            msg += f" [ข้อผิดพลาด: {errors[0]}]"

        return (total_affected > 0 or len(errors) == 0), total_affected, msg

    def get_host_triggers(self, hostid: str) -> List[Dict[str, Any]]:
        """Fetch all triggers linked to a host with human-readable expressions, items, and priorities"""
        res = self._call("trigger.get", {
            "hostids": [str(hostid)],
            "output": ["triggerid", "description", "expression", "priority", "status", "value", "lastchange", "comments", "templateid"],
            "selectItems": ["itemid", "name", "key_", "status"],
            "selectHosts": ["hostid", "name", "host"],
            "expandExpression": True,
            "expandDescription": True,
            "sortfield": "priority",
            "sortorder": "DESC"
        })
        if "result" in res:
            return res["result"]
        return []

    def create_standard_host_triggers(self, hostid: str) -> Tuple[bool, int, str]:
        """
        Creates standard server monitoring triggers for host:
        - Zabbix agent ping timeout (nodata 5m)
        - Windows/Linux services stopped (last <> 0)
        - System restart alert (uptime < 10m)
        """
        import re
        host_info = self._call("host.get", {
            "hostids": [str(hostid)],
            "output": ["hostid", "host", "name"],
            "selectInterfaces": ["interfaceid", "type", "main"]
        })
        if not host_info.get("result"):
            return False, 0, f"Host {hostid} not found"

        host_tech_name = host_info["result"][0].get("host")
        items = self._call("item.get", {
            "hostids": [str(hostid)],
            "output": ["itemid", "name", "key_", "status"]
        }).get("result", [])

        existing_triggers = self._call("trigger.get", {
            "hostids": [str(hostid)],
            "output": ["triggerid", "description", "expression", "status"]
        }).get("result", [])
        existing_descs = {t["description"]: t for t in existing_triggers}

        triggers_created = 0

        for it in items:
            key = it.get("key_", "")
            name = it.get("name", "")

            # 1. Agent Ping timeout trigger
            if "agent.ping" in key:
                t_desc = f"Zabbix agent on {host_tech_name} is unavailable (nodata 5m)"
                if t_desc not in existing_descs:
                    t_res = self._call("trigger.create", {
                        "description": t_desc,
                        "expression": f"nodata(/{host_tech_name}/agent.ping,5m)=1",
                        "priority": 3,
                        "status": 0
                    })
                    if "result" in t_res and "triggerids" in t_res["result"]:
                        triggers_created += 1

            # 2. Service Monitoring items trigger
            elif key.startswith("service.info["):
                m = re.search(r"service\.info\[([^,]+),", key)
                s_name = m.group(1) if m else key
                clean_dname = name.replace("Status of service ", "").replace("State of service ", "").replace("State of ", "")
                t_desc = f'Service "{clean_dname}" is not running on {{HOST.NAME}}'
                if t_desc not in existing_descs:
                    t_res = self._call("trigger.create", {
                        "description": t_desc,
                        "expression": f"last(/{host_tech_name}/{key})<>0",
                        "priority": 3,
                        "status": 0
                    })
                    if "result" in t_res and "triggerids" in t_res["result"]:
                        triggers_created += 1

            # 3. System Uptime (Restart alert)
            elif "system.uptime" in key:
                t_desc = f"Server {host_tech_name} has just been restarted"
                if t_desc not in existing_descs:
                    t_res = self._call("trigger.create", {
                        "description": t_desc,
                        "expression": f"last(/{host_tech_name}/{key})<10m",
                        "priority": 2,
                        "status": 0
                    })
                    if "result" in t_res and "triggerids" in t_res["result"]:
                        triggers_created += 1

        return True, triggers_created, f"สร้าง Triggers มาตรฐานสำเร็จ {triggers_created} รายการ"

    def update_trigger_status(self, trigger_updates: List[Dict[str, Any]]) -> Tuple[bool, int, str]:
        """
        Enable/disable triggers: [{"triggerid": "123", "status": 0}]
        status 0 = Enabled, 1 = Disabled
        """
        count = 0
        last_err = ""
        for upd in trigger_updates:
            tid = str(upd.get("triggerid"))
            status = int(upd.get("status", 0))
            res = self._call("trigger.update", {"triggerid": tid, "status": status})
            if "result" in res and "triggerids" in res["result"]:
                count += 1
            else:
                last_err = res.get("error", {}).get("data") or "Failed to update trigger"
        return count > 0, count, last_err

    def create_custom_trigger(self, hostid: str, description: str, expression: str, priority: int = 3) -> Tuple[bool, str, str]:
        """Create a custom trigger on a host"""
        if not description or not expression:
            return False, "", "กรุณาระบุชื่อและเงื่อนไข (Expression) ของ Trigger"

        host_info = self._call("host.get", {
            "hostids": [str(hostid)],
            "output": ["hostid", "host", "name"]
        })
        if not host_info.get("result"):
            return False, "", f"ไม่พบ Host ID {hostid}"

        host_tech_name = host_info["result"][0].get("host")
        clean_expr = expression.strip()

        # Handle expression formatting for Zabbix 7.0 / 6.0
        funcs = ["last(", "nodata(", "avg(", "min(", "max(", "sum(", "count(", "find("]
        matched_fn = None
        for fn in funcs:
            if clean_expr.startswith(fn):
                matched_fn = fn
                break

        if matched_fn and not clean_expr.startswith(f"{matched_fn}/"):
            clean_expr = clean_expr.replace(matched_fn, f"{matched_fn}/{host_tech_name}/", 1)
        elif "/" not in clean_expr:
            # If user passed just an item key e.g. "net.tcp.service[http,,80]"
            clean_expr = f"last(/{host_tech_name}/{clean_expr})<>0"

        res = self._call("trigger.create", {
            "description": description.strip(),
            "expression": clean_expr,
            "priority": int(priority),
            "status": 0
        })

        if "result" in res and "triggerids" in res["result"]:
            return True, str(res["result"]["triggerids"][0]), f"สร้าง Trigger '{description}' สำเร็จ!"
        else:
            err = res.get("error", {})
            err_msg = err.get("data") or err.get("message") or "Unknown error"
            return False, "", f"Zabbix ปฏิเสธการสร้าง Trigger: {err_msg}"

    def delete_triggers(self, trigger_ids: List[str]) -> Tuple[bool, int, str]:
        """Delete triggers by triggerids from Zabbix"""
        if not trigger_ids:
            return False, 0, "ไม่ได้ระบุ ID ของ Trigger ที่ต้องการลบ"

        t_ids = [str(tid).strip() for tid in trigger_ids if str(tid).strip().isdigit()]
        if not t_ids:
            return False, 0, "Trigger ID ไม่ถูกต้อง"

        # Check which triggers are templated
        t_info = self._call("trigger.get", {
            "triggerids": t_ids,
            "output": ["triggerid", "description", "templateid"]
        })
        results = t_info.get("result", [])
        templated = [t for t in results if str(t.get("templateid") or "0") != "0"]
        direct = [t["triggerid"] for t in results if str(t.get("templateid") or "0") == "0"]

        if not direct and templated:
            t_names = ", ".join([f"'{t.get('description')}'" for t in templated[:2]])
            return False, 0, f"Trigger ({t_names}) สืบทอดมาจาก Zabbix Template จึงไม่สามารถลบเฉพาะเครื่องนี้ได้ (แนะนำให้กดปิดการใช้งาน / Disable หรือยกเลิก Template แทน)"

        target_ids = direct if direct else t_ids
        res = self._call("trigger.delete", target_ids)
        if "result" in res and "triggerids" in res["result"]:
            del_cnt = len(res["result"]["triggerids"])
            msg = f"ลบ Trigger สำเร็จ {del_cnt} รายการ"
            if templated:
                msg += f" (ข้าม {len(templated)} รายการเนื่องจากเป็น Template Trigger)"
            return True, del_cnt, msg

        err = res.get("error", {})
        err_msg = err.get("data") or err.get("message") or "Unknown error"
        return False, 0, f"Zabbix ปฏิเสธการลบ Trigger: {err_msg}"

    def delete_host(self, hostid: str) -> Tuple[bool, str]:
        """Delete a host by hostid from Zabbix"""
        res = self._call("host.delete", [str(hostid)])
        if "result" in res and "hostids" in res["result"]:
            return True, f"ลบ Host ID {hostid} ออกจาก Zabbix เรียบร้อยแล้ว"
        err = res.get("error", {})
        err_msg = err.get("data") or err.get("message") or "Failed to delete host"
        return False, f"ไม่สามารถลบ Host ได้: {err_msg}"

    def delete_items_by_key(self, hostid: str, keys: List[str]) -> Tuple[bool, int, str]:
        """
        Delete monitor items on a host matched by their key_ (service.info[...], proc.num[...], etc.).
        Triggers that depend only on the deleted items are removed first so no orphan
        trigger is left behind (the inverse of add_service_items, which creates a trigger
        per service). Items that are inherited from a Template cannot be deleted here;
        the caller must unlink the Template instead.
        Returns: (success, deleted_count, message)
        """
        keys = [k for k in (keys or []) if k]
        if not keys:
            return False, 0, "ไม่มี item ที่จะลบ"

        res = self._call("item.get", {
            "hostids": [str(hostid)],
            "output": ["itemid", "name", "key_", "templateid"]
        })
        all_items = res.get("result", [])
        key_set = {k.lower() for k in keys}
        matched = [it for it in all_items if (it.get("key_") or "").lower() in key_set]

        # Items that are inherited from a template cannot be deleted individually.
        standalone = [it for it in matched if str(it.get("templateid") or "0") == "0"]
        inherited = [it for it in matched if str(it.get("templateid") or "0") != "0"]

        if not standalone:
            if inherited:
                return False, 0, ("Item นี้มาจาก Template จึงลบรายตัวไม่ได้ — "
                                  "ให้ปลด (Unlink) Template ที่หน้า Template Mapping แทน")
            return False, 0, "ไม่พบ item ที่ตรงกับที่ต้องการลบบนเครื่องนี้"

        target_ids = [it["itemid"] for it in standalone]

        # Remove triggers that reference these items (so no orphan trigger remains)
        triggers_deleted = 0
        try:
            trg = self._call("trigger.get", {
                "itemids": target_ids,
                "output": ["triggerid", "templateid"]
            }).get("result", [])
            trigger_ids = [t["triggerid"] for t in trg if str(t.get("templateid") or "0") == "0"]
            if trigger_ids:
                tdel = self._call("trigger.delete", trigger_ids)
                if "result" in tdel and "triggerids" in tdel["result"]:
                    triggers_deleted = len(trigger_ids)
        except Exception:
            pass  # trigger cleanup is best-effort; item deletion is what matters

        del_res = self._call("item.delete", target_ids)
        if "result" in del_res and "itemids" in del_res["result"]:
            msg = f"ลบ {len(target_ids)} item ออกจากเครื่องเรียบร้อยแล้ว"
            if triggers_deleted:
                msg += f" (พร้อมลบ Trigger ที่เกี่ยวข้อง {triggers_deleted} รายการ)"
            if inherited:
                msg += f" — หมายเหตุ: อีก {len(inherited)} item มาจาก Template ต้องปลด Template เพื่อเอาออก"
            return True, len(target_ids), msg
        err = del_res.get("error", {})
        err_msg = err.get("data") or err.get("message") or "Failed to delete items"
        return False, 0, f"ไม่สามารถลบ item ได้: {err_msg}"

    def add_standalone_metrics(self, hostid: str, metrics: List[str], os_type: str = "windows") -> Tuple[bool, int, str]:
        """
        Add clean standalone metrics (CPU, Memory, Disk, Ping) to a host without template bloat.
        metrics can contain: 'cpu', 'memory', 'disk', 'ping'
        """
        host_info = self._call("host.get", {
            "hostids": [str(hostid)],
            "output": ["hostid", "host", "name"],
            "selectInterfaces": ["interfaceid", "type", "main"]
        })
        if not host_info.get("result"):
            return False, 0, f"Host {hostid} not found"

        host_data = host_info["result"][0]
        host_tech_name = host_data.get("host") or ""
        interfaces = host_data.get("interfaces", [])
        if not interfaces:
            return False, 0, "Host นี้ไม่มี Interface เชื่อมต่ออยู่"

        target_iface_id = interfaces[0]["interfaceid"]
        for iface in interfaces:
            if str(iface.get("type")) == "1":
                target_iface_id = iface["interfaceid"]
                break

        is_win = "win" in os_type.lower()
        items_to_create = []

        if "ping" in metrics or "icmp" in metrics:
            vm_ping = self.get_or_create_valuemap(hostid, "Zabbix agent ping status")
            items_to_create.append({
                "name": "Agent ping (สถานะการเชื่อมต่อ)",
                "key_": "agent.ping",
                "type": 0,
                "value_type": 3,
                "interfaceid": str(target_iface_id),
                "delay": "1m",
                "valuemapid": str(vm_ping) if vm_ping else None,
                "trigger_desc": "Zabbix agent is not available on {HOST.NAME}",
                "trigger_expr": f"nodata(/{host_tech_name}/agent.ping,3m)=1",
                "trigger_priority": 3
            })

        if "cpu" in metrics:
            cpu_key = "perf_counter[\\Processor(_Total)\\% Processor Time]" if is_win else "system.cpu.util"
            items_to_create.append({
                "name": "CPU percentage busy time (การทำงานของ CPU)",
                "key_": cpu_key,
                "type": 0,
                "value_type": 0,
                "units": "%",
                "interfaceid": str(target_iface_id),
                "delay": "1m",
                "trigger_desc": "High CPU utilization on {HOST.NAME} (>90%)",
                "trigger_expr": f"avg(/{host_tech_name}/{cpu_key},5m)>90",
                "trigger_priority": 2
            })

        if "memory" in metrics:
            mem_key = "vm.memory.size[pused]" if is_win else "vm.memory.util"
            items_to_create.append({
                "name": "Memory used % (การใช้งานแรม)",
                "key_": mem_key,
                "type": 0,
                "value_type": 0,
                "units": "%",
                "interfaceid": str(target_iface_id),
                "delay": "1m",
                "trigger_desc": "High memory usage on {HOST.NAME} (>90%)",
                "trigger_expr": f"last(/{host_tech_name}/{mem_key})>90",
                "trigger_priority": 2
            })

        if "disk" in metrics:
            disk_key = "vfs.fs.size[C:,pused]" if is_win else "vfs.fs.size[/,pused]"
            disk_drive = "C:" if is_win else "/"
            items_to_create.append({
                "name": f"Disk percentage used {disk_drive} (พื้นที่ดิสก์)",
                "key_": disk_key,
                "type": 0,
                "value_type": 0,
                "units": "%",
                "interfaceid": str(target_iface_id),
                "delay": "5m",
                "trigger_desc": f"Low free disk space on {disk_drive} on {{HOST.NAME}} (>90%)",
                "trigger_expr": f"last(/{host_tech_name}/{disk_key})>90",
                "trigger_priority": 3
            })

        created = 0
        for it in items_to_create:
            payload = {
                "name": it["name"],
                "key_": it["key_"],
                "hostid": str(hostid),
                "type": it["type"],
                "value_type": it["value_type"],
                "interfaceid": it["interfaceid"],
                "delay": it["delay"],
                "status": 0
            }
            if it.get("units"):
                payload["units"] = it["units"]
            if it.get("valuemapid"):
                payload["valuemapid"] = it["valuemapid"]

            res = self._call("item.create", payload)
            if "result" in res and "itemids" in res["result"]:
                created += 1
                if it.get("trigger_desc") and it.get("trigger_expr"):
                    self._call("trigger.create", {
                        "description": it["trigger_desc"],
                        "expression": it["trigger_expr"],
                        "priority": it.get("trigger_priority", 2),
                        "status": 0
                    })

        return True, created, f"สร้างรายการตรวจวัดเฉพาะที่เลือกสำเร็จ {created} รายการ"




    # ======================================================================
    # Inventory collection (installed software, Windows services, processes)
    # ======================================================================
    _inventory_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}
    INVENTORY_CACHE_SECONDS = 300
    PROBE_MARKER = "Created by Monitoring Zabbix inventory probe"

    # Item keys used to read inventory. Probe items store a compact
    # tab-separated form (produced by JavaScript preprocessing) so values
    # fit in the history_text column; direct agent queries return raw JSON.
    _JS_SERVICES = (
        "var d = JSON.parse(value); if (!Array.isArray(d)) { d = d.data || []; } var out = [];"
        "for (var i = 0; i < d.length; i++) { var s = d[i]; out.push([s['{#SERVICE.NAME}'], s['{#SERVICE.DISPLAYNAME}'],"
        " s['{#SERVICE.STATENAME}'], s['{#SERVICE.STARTUPNAME}']].join('\\t')); } return out.join('\\n');"
    )
    _JS_REGISTRY = (
        "var d = JSON.parse(value); var m = {}; for (var i = 0; i < d.length; i++) { var r = d[i];"
        " var k = r.fullkey || r.key || ''; if (!m[k]) { m[k] = {}; } m[k][r.name] = (r.data !== undefined ? r.data : r.value); }"
        " var out = []; for (var k in m) { if (m[k].DisplayName) { out.push([m[k].DisplayName, m[k].DisplayVersion || '',"
        " m[k].Publisher || ''].join('\\t')); } } return out.join('\\n');"
    )
    _JS_PROC = (
        "var d = JSON.parse(value); var out = []; for (var i = 0; i < d.length; i++) {"
        " out.push(d[i].name + '\\t' + (d[i].processes || 1)); } return out.join('\\n');"
    )
    _JS_PACKAGES = (
        "var d = JSON.parse(value); var out = []; for (var i = 0; i < d.length; i++) {"
        " out.push([d[i].name, d[i].version || '', d[i].manager || ''].join('\\t')); } return out.join('\\n');"
    )
    _JS_LSLPP = (
        "var l = value.split('\\n'); var out = []; for (var i = 0; i < l.length; i++) { var f = l[i].split(':');"
        " if (f.length > 2 && l[i].charAt(0) !== '#') { out.push(f[1] + '\\t' + f[2]); } } return out.join('\\n');"
    )
    _JS_PS = (
        "var l = value.split('\\n'); var c = {}; for (var i = 0; i < l.length; i++) { var n = l[i].trim();"
        " if (n) { c[n] = (c[n] || 0) + 1; } } var out = []; for (var k in c) { out.push(k + '\\t' + c[k]); }"
        " return out.join('\\n');"
    )
    # wmi.getall returns {"0":{...}} or [{...}] of Win32_Service rows
    _JS_WMI_SVC = (
        "var d = JSON.parse(value); var arr = Array.isArray(d) ? d : Object.keys(d).map(function(k){return d[k];});"
        " var out = []; for (var i = 0; i < arr.length; i++) { var s = arr[i]; if (!s || !s.Name) continue;"
        " out.push([s.Name, s.DisplayName || s.Name, (s.State || '').toLowerCase(), (s.StartMode || '').toLowerCase()].join('\\t')); }"
        " return out.join('\\n');"
    )
    _JS_WIN_PORTS = (
        "var d = JSON.parse(value); var arr = Array.isArray(d) ? d : Object.keys(d).map(function(k){return d[k];});"
        " var map = {}; for (var i = 0; i < arr.length; i++) { var r = arr[i]; if (!r || !r.LocalPort) continue;"
        " var p = String(r.LocalPort); var addr = String(r.LocalAddress || '0.0.0.0');"
        " if (!map[p] || map[p].addr.indexOf(':') !== -1) { map[p] = {port: p, addr: addr, pid: String(r.OwningProcess || '')}; } }"
        " var out = []; for (var k in map) { out.push([map[k].port, map[k].addr, map[k].pid, 'LISTEN'].join('\\t')); }"
        " return out.join('\\n');"
    )
    _JS_LINUX_PORTS = (
        "var lines = value.split('\\n'); var seen = {}; var out = [];"
        " for (var i = 1; i < lines.length; i++) { var f = lines[i].trim().split(/\\s+/);"
        " if (f.length < 4 || f[3].toUpperCase() !== '0A') continue;"
        " var lp = f[1].split(':'); if (lp.length < 2) continue;"
        " var port = parseInt(lp[1], 16); if (!port || seen[port]) continue; seen[port] = true;"
        " var h = lp[0]; var ip = h.length === 8 ? [parseInt(h.substr(6,2),16), parseInt(h.substr(4,2),16), parseInt(h.substr(2,2),16), parseInt(h.substr(0,2),16)].join('.') : '0.0.0.0';"
        " out.push([String(port), ip, '', 'LISTEN'].join('\\t')); } return out.join('\\n');"
    )
    _JS_LINUX_SERVICES = (
        "var d = JSON.parse(value); var seen = {}; var out = [];"
        " for (var i = 0; i < d.length; i++) { var b = (d[i] && d[i].basename) ? String(d[i].basename) : '';"
        " if (!b || b.indexOf('@.') !== -1) continue; var name = b.replace(/\\.service$/i, '');"
        " if (!name || seen[name]) continue; seen[name] = true;"
        " out.push([name, b, 'enabled', 'systemd'].join('\\t')); } return out.join('\\n');"
    )

    INVENTORY_PROBES: Dict[str, List[Dict[str, str]]] = {
        "windows": [
            # service.discovery is an LLD rule key on many hosts; wmi.getall lists every service as a normal item
            {"kind": "services", "key": 'wmi.getall[root\\cimv2,"SELECT Name,DisplayName,State,StartMode FROM Win32_Service"]',
             "name": "[Inventory] Windows services", "js": "_JS_WMI_SVC"},
            {"kind": "software", "key": 'registry.get[HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall,values,"^(DisplayName|DisplayVersion|Publisher)$"]',
             "name": "[Inventory] Installed software (64-bit)", "js": "_JS_REGISTRY"},
            {"kind": "software", "key": 'registry.get[HKLM\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall,values,"^(DisplayName|DisplayVersion|Publisher)$"]',
             "name": "[Inventory] Installed software (32-bit)", "js": "_JS_REGISTRY"},
            {"kind": "processes", "key": "proc.get[,,,summary]", "name": "[Inventory] Running processes", "js": "_JS_PROC"},
            {"kind": "ports", "key": 'wmi.getall[root\\StandardCimv2,"SELECT LocalAddress,LocalPort,OwningProcess,State FROM MSFT_NetTCPConnection WHERE State=2"]',
             "name": "[Inventory] Listening TCP ports", "js": "_JS_WIN_PORTS"},
            {"kind": "uname", "key": "system.uname", "name": "[Inventory] System description", "js": ""},
        ],
        "linux": [
            {"kind": "software", "key": "system.sw.packages.get[.*]", "name": "[Inventory] Installed packages", "js": "_JS_PACKAGES"},
            {"kind": "services", "key": "vfs.dir.get[/etc/systemd/system,.*\\.service$,,,0,2]", "name": "[Inventory] Linux services (systemd)", "js": "_JS_LINUX_SERVICES"},
            {"kind": "processes", "key": "proc.get[,,,summary]", "name": "[Inventory] Running processes", "js": "_JS_PROC"},
            {"kind": "ports", "key": "vfs.file.contents[/proc/net/tcp]", "name": "[Inventory] Listening TCP ports", "js": "_JS_LINUX_PORTS"},
            {"kind": "uname", "key": "system.uname", "name": "[Inventory] System description", "js": ""},
        ],
        "aix": [
            # AIX has no proc.get / system.sw.packages; system.run needs AllowKey=system.run[*] on the agent
            {"kind": "software", "key": "system.run[lslpp -Lcq]", "name": "[Inventory] Installed filesets", "js": "_JS_LSLPP"},
            {"kind": "processes", "key": "system.run[ps -e -o comm=]", "name": "[Inventory] Running processes", "js": "_JS_PS"},
            {"kind": "uname", "key": "system.uname", "name": "[Inventory] System description", "js": ""},
        ],
    }

    @staticmethod
    def is_safe_address(addr: str) -> bool:
        """Allow only IPv4/IPv6 literals or DNS names (no spaces, quotes or shell metacharacters)."""
        import ipaddress
        import re
        addr = (addr or "").strip()
        if not addr or len(addr) > 253:
            return False
        try:
            ipaddress.ip_address(addr)
            return True
        except ValueError:
            return bool(re.fullmatch(r"[A-Za-z0-9]([A-Za-z0-9\-]{0,62})(\.[A-Za-z0-9]([A-Za-z0-9\-]{0,62}))*", addr))

    @classmethod
    def query_agent(cls, ip: str, key: str, port: int = 10050, timeout: float = 3.0) -> str:
        """Read one passive Zabbix agent key (the agent's Server= must allow this machine)."""
        import zlib
        if not cls.is_safe_address(ip):
            raise ValueError("Invalid agent address")
        command = key.encode("utf-8")
        with socket.create_connection((ip, int(port)), timeout=2.0) as agent:
            agent.settimeout(timeout)
            agent.sendall(b"ZBXD\x01" + struct.pack("<Q", len(command)) + command)
            def read_exact(n: int) -> bytes:
                buf = bytearray()
                while len(buf) < n:
                    chunk = agent.recv(min(65536, n - len(buf)))
                    if not chunk:
                        raise ConnectionError("Agent closed the connection (check Server= in the agent config)")
                    buf.extend(chunk)
                return bytes(buf)

            # Header: "ZBXD" + flags + datalen(4) + reserved(4); large packets (0x04) use 8+8 bytes
            header = read_exact(13)
            if not header.startswith(b"ZBXD"):
                raise ValueError("Invalid Zabbix agent response header")
            flags = header[4]
            if flags & 0x04:
                header += read_exact(8)
                data_length = struct.unpack("<Q", header[5:13])[0]
            else:
                data_length = struct.unpack("<I", header[5:9])[0]
            if data_length > 16 * 1024 * 1024:
                raise ValueError("Agent response exceeded 16 MB")
            payload = read_exact(data_length)
        result = bytes(payload)
        if flags & 0x02:
            result = zlib.decompress(result)
        text = result.decode("utf-8", errors="replace").strip()
        if text.startswith("ZBX_NOTSUPPORTED"):
            reason = text.split("\x00", 1)[1] if "\x00" in text else "not supported"
            raise RuntimeError(f"{key}: {reason.strip() or 'not supported'}")
        return text

    # ---------------- parsers (accept raw agent JSON or compact TSV) ----------------
    @staticmethod
    def _parse_services(raw: str) -> List[Dict[str, str]]:
        out = []
        raw = (raw or "").strip()
        if not raw:
            return out
        if raw[0] in "[{":
            data = json.loads(raw)
            if isinstance(data, dict):
                data = data.get("data") or list(data.values())   # LLD {"data":[...]} or wmi.getall {"0":{...}}
            for s in data:
                if not isinstance(s, dict):
                    continue
                # LLD macro form OR Win32_Service (wmi.getall) form
                name = s.get("{#SERVICE.NAME}") or s.get("Name") or ""
                out.append({"name": name,
                            "display_name": s.get("{#SERVICE.DISPLAYNAME}") or s.get("DisplayName") or name,
                            "state": str(s.get("{#SERVICE.STATENAME}") or s.get("State") or "").lower(),
                            "startup": str(s.get("{#SERVICE.STARTUPNAME}") or s.get("StartMode") or "").lower()})
        else:
            for line in raw.splitlines():
                f = line.split("\t")
                if f and f[0]:
                    out.append({"name": f[0], "display_name": f[1] if len(f) > 1 else f[0],
                                "state": (f[2] if len(f) > 2 else "").lower(),
                                "startup": (f[3] if len(f) > 3 else "").lower()})
        return [s for s in out if s["name"]]

    @staticmethod
    def _parse_processes(raw: str) -> List[Dict[str, Any]]:
        raw = (raw or "").strip()
        counts: Dict[str, int] = {}
        if not raw:
            return []
        if raw[0] == "[":
            for p in json.loads(raw):
                n = str(p.get("name", "")).strip()
                if n:
                    counts[n] = counts.get(n, 0) + int(p.get("processes", 1) or 1)
        else:
            for line in raw.splitlines():
                f = line.split("\t")
                n = f[0].strip()
                if not n:
                    continue
                try:
                    c = int(f[1]) if len(f) > 1 else 1
                except ValueError:
                    c = 1
                counts[n] = counts.get(n, 0) + c
        return [{"name": n, "count": c} for n, c in sorted(counts.items(), key=lambda x: x[0].lower())]

    @staticmethod
    def _parse_software(raw: str, key: str) -> List[Dict[str, str]]:
        raw = (raw or "").strip()
        out = []
        if not raw:
            return out
        k = key.lower()
        if raw[0] == "[":
            data = json.loads(raw)
            if k.startswith("registry.get"):
                grouped: Dict[str, Dict[str, str]] = {}
                for r in data:
                    fk = r.get("fullkey") or r.get("key") or ""
                    grouped.setdefault(fk, {})[r.get("name", "")] = r.get("data", r.get("value", ""))
                for g in grouped.values():
                    if g.get("DisplayName"):
                        out.append({"name": str(g["DisplayName"]), "version": str(g.get("DisplayVersion", "")),
                                    "publisher": str(g.get("Publisher", ""))})
            else:
                for p in data:
                    out.append({"name": str(p.get("name", "")), "version": str(p.get("version", "")),
                                "publisher": str(p.get("manager", ""))})
        elif k.startswith("system.run[lslpp"):
            for line in raw.splitlines():
                f = line.split("\t") if "\t" in line else line.split(":")
                if line.startswith("#") or len(f) < 2:
                    continue
                name, ver = (f[0], f[1]) if "\t" in line else (f[1], f[2] if len(f) > 2 else "")
                out.append({"name": name.strip(), "version": ver.strip(), "publisher": "lslpp"})
        elif k.startswith("system.sw.packages[") or k == "system.sw.packages":
            # "[rpm] a, b, c" or "a, b, c"
            for part in raw.replace("\n", ",").split(","):
                part = part.strip()
                if part.startswith("[") and "]" in part:
                    part = part.split("]", 1)[1].strip()
                if part:
                    out.append({"name": part, "version": "", "publisher": ""})
        else:
            for line in raw.splitlines():
                f = line.split("\t")
                if f and f[0].strip():
                    out.append({"name": f[0].strip(), "version": f[1].strip() if len(f) > 1 else "",
                                "publisher": f[2].strip() if len(f) > 2 else ""})
        dedup: Dict[str, Dict[str, str]] = {}
        for s in out:
            if s["name"]:
                dedup.setdefault(s["name"].casefold(), s)
        return sorted(dedup.values(), key=lambda s: s["name"].casefold())

    @staticmethod
    def _parse_ports(raw: str, key: str = "") -> List[Dict[str, str]]:
        raw = (raw or "").strip()
        if not raw:
            return []
        out: List[Dict[str, str]] = []
        if raw[0] in "[{":
            try:
                data = json.loads(raw)
                arr = data if isinstance(data, list) else list(data.values())
                for r in arr:
                    if not isinstance(r, dict):
                        continue
                    p = str(r.get("LocalPort") or r.get("port") or "").strip()
                    if not p or not p.isdigit():
                        continue
                    addr = str(r.get("LocalAddress") or r.get("ip") or "0.0.0.0").strip()
                    pid = str(r.get("OwningProcess") or r.get("pid") or "").strip()
                    out.append({"port": p, "address": addr, "pid": pid, "state": "LISTEN"})
            except Exception:
                pass
        elif "local_address" in raw and "rem_address" in raw:
            # Raw /proc/net/tcp or /proc/net/tcp6 without preprocessing
            for line in raw.splitlines()[1:]:
                f = line.strip().split()
                if len(f) < 4 or f[3].upper() != "0A":
                    continue
                lp = f[1].split(":")
                if len(lp) < 2:
                    continue
                try:
                    p_num = int(lp[1], 16)
                except ValueError:
                    continue
                if p_num > 0:
                    out.append({"port": str(p_num), "address": "0.0.0.0", "pid": "", "state": "LISTEN"})
        else:
            for line in raw.splitlines():
                f = line.split("\t")
                p = f[0].strip() if f else ""
                if not p or not p.isdigit():
                    continue
                addr = f[1].strip() if len(f) > 1 and f[1].strip() else "0.0.0.0"
                pid = f[2].strip() if len(f) > 2 else ""
                state = f[3].strip() if len(f) > 3 and f[3].strip() else "LISTEN"
                out.append({"port": p, "address": addr, "pid": pid, "state": state})
        dedup: Dict[str, Dict[str, str]] = {}
        for item in out:
            p = item["port"]
            if p not in dedup or (":" in dedup[p]["address"] and ":" not in item["address"]):
                dedup[p] = item
        return sorted(dedup.values(), key=lambda x: int(x["port"]) if x["port"].isdigit() else 999999)

    def get_host_detail(self, hostid: str) -> Optional[Dict[str, Any]]:
        ver = self._version_tuple()
        out_fields = ["hostid", "host", "name", "status", "description"]
        if ver >= (7, 0):
            out_fields.extend(["proxyid", "assigned_proxyid", "proxy_groupid", "monitored_by", "active_available"])
        elif ver >= (6, 4):
            out_fields.extend(["proxy_hostid", "active_available"])
        else:
            out_fields.extend(["proxy_hostid", "available"])

        params: Dict[str, Any] = {
            "hostids": [str(hostid)],
            "output": out_fields,
            "selectInterfaces": ["interfaceid", "ip", "dns", "port", "type", "useip", "main", "available", "error"],
            "selectParentTemplates": ["templateid", "name"],
            "selectMacros": "extend",
        }
        if ver >= (6, 2):
            params["selectHostGroups"] = ["groupid", "name"]
        else:
            params["selectGroups"] = ["groupid", "name"]

        res = self._call("host.get", params)
        if "result" not in res and ver >= (6, 2):
            params.pop("selectHostGroups", None)
            params["selectGroups"] = ["groupid", "name"]
            res = self._call("host.get", params)

        rows = res.get("result") or []
        if not rows:
            return None
        proxy_map, proxy_group_map = self.get_proxies_map()
        enriched = self._enrich_host_groups_and_proxy(rows, proxy_map, proxy_group_map)
        return enriched[0] if enriched else None

    @classmethod
    def agent_availability(cls, host: Dict[str, Any]) -> Dict[str, Any]:
        """Zabbix's own view of the agent interface: available 1=OK, 2=unavailable, 0=unknown."""
        iface = cls._agent_interface(host)
        if not iface:
            return {"state": "none", "error": "ไม่มี Zabbix agent interface", "address": ""}
        state = {"1": "ok", "2": "unavailable"}.get(str(iface.get("available", "0")), "unknown")
        return {"state": state, "error": iface.get("error") or "",
                "address": f"{iface.get('ip') or iface.get('dns')}:{iface.get('port')}"}

    @staticmethod
    def _agent_interface(host: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        ifaces = [i for i in (host.get("interfaces") or []) if str(i.get("type")) == "1"]
        ifaces.sort(key=lambda i: 0 if str(i.get("main")) == "1" else 1)
        return ifaces[0] if ifaces else None

    def collect_inventory(self, host: Dict[str, Any], items: List[Dict[str, Any]], settings: Dict[str, Any],
                          refresh: bool = False, direct: Optional[bool] = None) -> Dict[str, Any]:
        """
        Build an inventory snapshot. Sources, in order:
          1) values already collected in Zabbix (probe items or any item with a matching key)
          2) a direct passive query to the agent (if allowed by settings and agent Server=)
        """
        from concurrent.futures import ThreadPoolExecutor
        import time as _time
        from monitoring_standard import detect_os_family

        hostid = str(host.get("hostid"))
        cache_key = f"{self.url}|{hostid}"
        cached = self._inventory_cache.get(cache_key)
        cached_snap = cached[1] if (cached and not refresh and _time.time() - cached[0] < self.INVENTORY_CACHE_SECONDS) else None

        templates = host.get("parentTemplates") or []
        by_key = {(it.get("key_") or ""): it for it in items}
        errors: List[str] = []
        notes: List[str] = []
        source: Dict[str, Optional[str]] = {"software": None, "services": None, "processes": None, "ports": None}
        software: List[Dict[str, str]] = []
        services: List[Dict[str, str]] = []
        processes: List[Dict[str, Any]] = []
        ports: List[Dict[str, str]] = []

        uname = (by_key.get("system.uname") or {}).get("lastvalue") or ""
        os_name = (by_key.get("system.sw.os") or by_key.get("system.sw.os[name]") or {}).get("lastvalue") or ""
        if not uname and cached_snap and cached_snap.get("uname"):
            uname = cached_snap["uname"]
        iface = self._agent_interface(host)
        addr = ""
        port = int(settings.get("agent_port") or 10050)
        if iface:
            addr = iface.get("ip") if str(iface.get("useip", "1")) == "1" else (iface.get("dns") or iface.get("ip"))
            try:
                port = int(iface.get("port") or port)
            except ValueError:
                pass
        use_direct = settings.get("direct_agent", True) if direct is None else direct
        use_direct = bool(use_direct and addr and self.is_safe_address(addr) and (refresh or cached_snap is None))

        agent_ok = None
        if use_direct and not uname:
            try:
                uname = self.query_agent(addr, "system.uname", port)
                agent_ok = True
            except Exception as exc:  # noqa: BLE001 - report reason to the user
                agent_ok = False
                errors.append(f"Direct agent {addr}:{port} — {exc}")

        family = detect_os_family(templates, items, uname, host.get("host", "") + " " + host.get("name", ""))
        # Where the OS decision came from: real uname beats a guess from linked templates
        if uname:
            os_source = "uname"
        elif any(k in (t.get("name") or "").lower() for t in templates for k in ("windows", "linux", "aix")):
            os_source = "template"
        else:
            os_source = "guess"
        availability = self.agent_availability(host)
        if availability["state"] == "unavailable":
            notes.insert(0, f"Zabbix agent ที่ {availability['address']} ไม่ตอบ Zabbix server: {availability['error']} "
                            "— ตรวจ Server= ใน zabbix_agentd.conf ว่ามี IP ของ Zabbix server")
        if os_source != "uname":
            notes.append(f"OS ({family.upper()}) ประเมินจาก {'template ที่ผูกไว้' if os_source == 'template' else 'ชื่อเครื่อง'} "
                         "เพราะยังไม่มีค่า system.uname — ถ้าผิดให้แก้ template ของ host")
        probes = self.INVENTORY_PROBES.get(family, [])

        def matches_probe(k: str, kind: str) -> bool:
            kl = k.lower()
            if any(p["kind"] == kind and k == p["key"] for p in probes):
                return True
            if kind == "software":
                return kl.startswith("system.sw.packages") or (kl.startswith("registry.get[") and "uninstall" in kl) \
                    or kl.startswith("system.run[lslpp")
            if kind == "services":
                return kl == "service.discovery" or (kl.startswith("wmi.getall[") and "win32_service" in kl) \
                    or (kl.startswith("vfs.dir.get[") and ".service" in kl)
            if kind == "processes":
                return kl.startswith("proc.get[") or kl.startswith("system.run[ps ")
            if kind == "ports":
                return (kl.startswith("wmi.getall[") and "msft_nettcpconnection" in kl) \
                    or kl.startswith("vfs.file.contents[/proc/net/tcp")
            return False

        def from_item(kind: str) -> List[Tuple[str, str]]:
            vals = []
            for it in items:
                k = it.get("key_") or ""
                if matches_probe(k, kind) and str(it.get("status", "0")) == "0" and it.get("lastvalue"):
                    vals.append((k, it["lastvalue"]))
            return vals

        def ingest(kind: str, pairs: List[Tuple[str, str]], origin: str) -> bool:
            got = False
            for key, raw in pairs:
                try:
                    if kind == "software":
                        software.extend(self._parse_software(raw, key))
                    elif kind == "services":
                        services.extend(self._parse_services(raw))
                    elif kind == "processes":
                        processes.extend(self._parse_processes(raw))
                    elif kind == "ports":
                        ports.extend(self._parse_ports(raw, key))
                    got = True
                except (ValueError, TypeError, KeyError) as exc:
                    errors.append(f"{key}: parse error {exc}")
            if got:
                source[kind] = origin
            return got

        for kind in ("software", "services", "processes", "ports"):
            ingest(kind, from_item(kind), "zabbix")

        missing = [p for p in probes if p["kind"] in source and not source[p["kind"]]]
        if use_direct and agent_ok is not False and missing:
            def fetch(p):
                try:
                    return p, self.query_agent(addr, p["key"], port, timeout=6.0), None
                except Exception as exc:  # noqa: BLE001
                    return p, None, str(exc)
            with ThreadPoolExecutor(max_workers=4) as pool:
                results = list(pool.map(fetch, missing))
            for p, raw, err in results:
                if err:
                    errors.append(f"Direct agent: {err}")
                    continue
                ingest(p["kind"], [(p["key"], raw)], "agent")

        if family == "aix" and not source["processes"]:
            notes.append("AIX: ต้องเปิด AllowKey=system.run[*] (หรือเฉพาะ ps/lslpp) บน agent เพื่ออ่านรายการ process/software")
        if family == "windows" and not source["software"]:
            notes.append("Windows: ใช้ registry.get (Zabbix agent 6.2+) เพื่ออ่านรายการ software ที่ติดตั้ง")
        if not any(source.values()):
            notes.append("ยังไม่มีข้อมูล inventory จริง — กด 'เก็บ Inventory ผ่าน Zabbix' หรืออนุญาต Server= ของ agent ให้เครื่องนี้")

        # de-duplicate merged lists
        seen = set()
        software = [s for s in software if not (s["name"].casefold() in seen or seen.add(s["name"].casefold()))]
        seen_svc = set()
        services = [s for s in services if not (s["name"].lower() in seen_svc or seen_svc.add(s["name"].lower()))]
        seen_port: Dict[str, Dict[str, str]] = {}
        for pt in ports:
            p_num = pt["port"]
            if p_num not in seen_port or (":" in seen_port[p_num]["address"] and ":" not in pt["address"]):
                seen_port[p_num] = pt
        ports = sorted(seen_port.values(), key=lambda x: int(x["port"]) if x["port"].isdigit() else 999999)

        snapshot = {
            "os_family": family,
            "os_name": os_name or (uname.split("\n")[0][:120] if uname else ""),
            "uname": uname[:300],
            "software": software,
            "services": services,
            "processes": processes,
            "ports": ports,
            "source": source,
            "errors": errors,
            "notes": notes,
            "agent_address": f"{addr}:{port}" if addr else "",
            "os_source": os_source,
            "agent": availability,
            "collected_at": _time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        self._inventory_cache[cache_key] = (_time.time(), snapshot)
        return snapshot

    def invalidate_inventory(self, hostid: str) -> None:
        self._inventory_cache.pop(f"{self.url}|{hostid}", None)

    def _item_base(self, hostid: str) -> Tuple[Optional[Dict[str, Any]], Dict[str, Any], str]:
        """Return (host, base item fields, error). Uses a passive agent item if an agent interface exists."""
        host = self.get_host_detail(hostid)
        if not host:
            return None, {}, f"Host {hostid} not found"
        iface = self._agent_interface(host)
        if iface:
            return host, {"type": 0, "interfaceid": str(iface["interfaceid"])}, ""
        return host, {"type": 7}, ""  # Zabbix agent (active)

    def create_inventory_probes(self, hostid: str, os_family: str) -> Tuple[bool, int, str]:
        """Create (or re-enable) inventory probe items on the host and request an immediate check."""
        host, base, err = self._item_base(hostid)
        if not host:
            return False, 0, err
        probes = self.INVENTORY_PROBES.get(os_family) or self.INVENTORY_PROBES["linux"]
        existing = self._call("item.get", {"hostids": [str(hostid)], "output": ["itemid", "key_", "status"]}).get("result", [])
        by_key = {it["key_"]: it for it in existing}
        created, touched, errors = 0, [], []
        for p in probes:
            if p["key"] in by_key:
                it = by_key[p["key"]]
                if str(it.get("status")) != "0":
                    self._call("item.update", {"itemid": it["itemid"], "status": 0})
                touched.append(it["itemid"])
                continue
            payload = {
                "hostid": str(hostid), "name": p["name"], "key_": p["key"], "value_type": 4,
                "delay": "1h", "history": "7d", "description": self.PROBE_MARKER, **base,
            }
            if p["js"]:
                payload["preprocessing"] = [{"type": 21, "params": getattr(self, p["js"]),
                                             "error_handler": 0, "error_handler_params": ""}]
            res = self._call("item.create", payload)
            if "result" in res:
                created += 1
                touched.extend(res["result"].get("itemids", []))
            else:
                e = res.get("error", {})
                errors.append(f"{p['key']}: {e.get('data') or e.get('message')}")
        if touched and base.get("type") == 0:
            self.execute_items_now(touched)
        self.invalidate_inventory(hostid)
        msg = f"สร้าง inventory probe {created} รายการ"
        if base.get("type") == 7:
            msg += " (active agent: ข้อมูลจะเข้าตามรอบของ agent)"
        else:
            msg += " และสั่ง Check now แล้ว (รอประมาณ 1 นาทีแล้วรีเฟรช)"
        if errors:
            msg += f" — ข้อผิดพลาด: {errors[0]}"
        return (created > 0 or bool(touched)), created, msg

    def add_os_standard_item(self, hostid: str, check_id: str, os_family: str) -> Tuple[bool, str]:
        """Create the standard item (and trigger) for one OS check."""
        from monitoring_standard import os_add_spec
        spec = os_add_spec(check_id, os_family)
        if not spec:
            return False, "รายการนี้ต้องใช้ OS template (ไม่มี item มาตรฐานแบบเดี่ยว)"
        host, base, err = self._item_base(hostid)
        if not host:
            return False, err
        exists = self._call("item.get", {"hostids": [str(hostid)], "filter": {"key_": spec["key"]},
                                         "output": ["itemid", "status"]}).get("result", [])
        if exists:
            if str(exists[0].get("status")) != "0":
                self._call("item.update", {"itemid": exists[0]["itemid"], "status": 0})
                return True, f"เปิดใช้งาน {spec['key']} แล้ว"
            return True, f"{spec['key']} มีอยู่แล้ว"
        payload = {"hostid": str(hostid), "name": spec["name"], "key_": spec["key"],
                   "value_type": spec.get("value_type", 0), "delay": spec.get("delay", "1m"), **base}
        if spec.get("units"):
            payload["units"] = spec["units"]
        if spec["key"] == "agent.ping":
            vm = self.get_or_create_valuemap(hostid, "Zabbix agent ping status")
            if vm:
                payload["valuemapid"] = str(vm)
        res = self._call("item.create", payload)
        if "result" not in res:
            e = res.get("error", {})
            return False, f"สร้าง item ไม่สำเร็จ: {e.get('data') or e.get('message')}"
        trig = spec.get("trigger")
        if trig:
            self._call("trigger.create", {
                "description": trig["desc"],
                "expression": trig["expr"].replace("{host}", host.get("host", "")).replace("{key}", spec["key"]),
                "priority": trig.get("priority", 2), "status": 0,
            })
        if base.get("type") == 0:
            self.execute_items_now(res["result"].get("itemids", []))
        return True, f"เพิ่ม {spec['key']} แล้ว"

    # ======================================================================
    # Generic probe items (used by the Elastic / Filebeat checks)
    # ======================================================================
    def ensure_probe_items(self, hostid: str, specs: List[Dict[str, Any]], marker: str = "") -> Tuple[bool, int, str]:
        """Create or re-enable read-only probe items, then request an immediate check (passive agents)."""
        host, base, err = self._item_base(hostid)
        if not host:
            return False, 0, err
        existing = self._call("item.get", {"hostids": [str(hostid)], "output": ["itemid", "key_", "status"]}).get("result", [])
        by_key = {it["key_"]: it for it in existing}
        created, touched, errors = 0, [], []
        for sp in specs:
            it = by_key.get(sp["key"])
            if it:
                if str(it.get("status")) != "0":
                    self._call("item.update", {"itemid": it["itemid"], "status": 0})
                touched.append(it["itemid"])
                continue
            payload = {"hostid": str(hostid), "name": sp["name"], "key_": sp["key"],
                       "value_type": sp.get("value_type", 4), "delay": sp.get("delay", "10m"),
                       "history": "7d", "description": marker or self.PROBE_MARKER, **base}
            res = self._call("item.create", payload)
            if "result" in res:
                created += 1
                touched.extend(res["result"].get("itemids", []))
            else:
                e = res.get("error", {})
                errors.append(f"{sp['key']}: {e.get('data') or e.get('message')}")
        if touched and base.get("type") == 0:
            self.execute_items_now(touched)
        msg = f"สร้าง probe {created} รายการ" + (" และสั่ง Check now แล้ว" if base.get("type") == 0 else " (active agent รอรอบถัดไป)")
        if errors:
            msg += f" — ข้อผิดพลาด: {errors[0]}"
        return (created > 0 or bool(touched)), created, msg

    def query_probe_values(self, host: Dict[str, Any], specs: List[Dict[str, Any]], port: int = 10050) -> Dict[str, Any]:
        """Direct passive agent reads for probe specs: {kind: value | Exception}. Empty if no reachable agent."""
        from concurrent.futures import ThreadPoolExecutor
        iface = self._agent_interface(host)
        if not iface or not specs:
            return {}
        addr = iface.get("ip") if str(iface.get("useip", "1")) == "1" else (iface.get("dns") or iface.get("ip"))
        try:
            port = int(iface.get("port") or port)
        except ValueError:
            pass
        if not self.is_safe_address(addr):
            return {}
        try:  # fail fast when the agent does not accept this machine
            self.query_agent(addr, "agent.ping", port, timeout=3.0)
        except Exception as exc:  # noqa: BLE001
            return {sp["kind"]: exc for sp in specs}

        def one(sp):
            try:
                return sp["kind"], self.query_agent(addr, sp["key"], port, timeout=6.0)
            except Exception as exc:  # noqa: BLE001
                return sp["kind"], exc
        with ThreadPoolExecutor(max_workers=4) as pool:
            return dict(pool.map(one, specs))
