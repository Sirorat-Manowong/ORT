# Changelog - Zabbix & Elastic Host Manager

บันทึกประวัติการปรับปรุง แก้ไข และพัฒนาฟีเจอร์ในระบบ

---

## [v80 / ZabbixV4] - 2026-11-11

### 1. ระบบกวาดข้อมูล Inventory ครบ 4 ประเภท (`Software`, `Service`, `Process`, `Port`)
- **Zabbix Host Inventory Scanner (`zabbix_api.py`, `monitoring_standard.py`, `web/standalone_engine.js`):**
  - รองรับการดึงข้อมูลจากเครื่องจริงผ่าน Zabbix Agent (ไม่ต้องลงโปรแกรมเพิ่มบนเครื่องปลายทาง) แยกเป็น 4 หมวดหมู่: `📦 Software`, `⚙ Service`, `⚡ Process`, และ `🔌 Port`
  - เพิ่มแถบปุ่มหมวดหมู่พร้อมตัวเลขสรุป (`#swCategoryTabs`), เปลี่ยนปุ่มเป็น `▶ Execute`, และจัดระเบียบตาราง 8 คอลัมน์พร้อม Sticky Header ทึบแสงไม่ซ้อนทับกัน (`web/index.html`, `web/app.js`, `web/styles.css`)

### 2. ปรับปรุง `Server Information` แบบเรียลไทม์ & กางดูข้อมูลเกิน 2 บรรทัด
- **กางออกเพื่อดูข้อมูลทั้งหมด / เลื่อนสกรอลล์เมาส์ (`enhanceServerInfoCells()` ใน `web/app.js`, `.srv-info-cell` ใน `web/styles.css`):**
  - ข้อมูลใน `Server Information` ที่ยาวเกิน 2 บรรทัดจะแสดงปุ่ม `▾ ดูทั้งหมด` / `▴ ย่อเก็บ` และรองรับการหมุนลูกกลิ้งเมาส์เพื่อเลื่อนดูข้อความทั้งหมดโดยไม่ทำให้การ์ดยืดยาวเกินไป
- **แสดงรายการ `Macro = Value` และซิงค์ข้อมูลจาก Zabbix แบบเรียลไทม์ (`_public_host()` ใน `app.py`, `pollSelectedHostRealtime()` ใน `web/app.js`):**
  - แสดงรายการ Host Macros ทุกตัว (`Macro = Value`) ตามที่ตั้งค่าไว้บนเครื่องใน Zabbix และดึงข้อมูลอัปเดตอัตโนมัติทุก 3 วินาทีแบบไม่ติด Cache (`Cache-Control: no-store`)

---

## [v71 / ZabbixV3] - 2026-11-05

### 1. ส่วน `All Server From : <กลุ่มที่ค้นหา>` และสถานะการเชื่อมต่อ Zabbix
- **แสดงส่วน `All Server From : <App / Group>` ใต้ `Application & Server` (`web/index.html`, `web/app.js`, `web/styles.css`):**
  - เมื่อเลือก `Server Name` เป็น `"ทั้งหมด"` จะแสดงส่วน `All Server From : <ชื่อกลุ่มที่ค้นหา>`
  - ด้านบนแสดงแถบสรุปจำนวนเครื่องทั้งหมดในกลุ่ม, จำนวนเครื่องที่ **Enable / Active (เชื่อมต่อ Zabbix อยู่)** และจำนวนเครื่องที่ **Disable / ไม่เชื่อมต่อ Zabbix** โดยดึงสถานะจริงจาก Zabbix (`zabbix_api.py`, `web/standalone_engine.js`)
  - รายการเครื่องด้านล่างแสดงผลแบบบรรทัด (`#`, `ชื่อเครื่อง (Server Name)`, `IP Address`, `Status (สถานะเชื่อมต่อ Zabbix)`) คลิกเลือกดูรายละเอียดของแต่ละเครื่องได้ทันที

### 2. โลโก้ด้านบนสุดเปลี่ยนตามประเภทเมนู (`Zabbix` / `Elastic`)
- **Dynamic Brand Logo (`web/logo-zabbix.png`, `web/logo-elastic.png`, `web/app.js`):**
  - เมื่ออยู่ในเมนูฝั่ง Zabbix แสดงโลโก้ตัว `Z` สีแดงของ Zabbix และเมื่อสลับไปเมนูฝั่ง Elastic แสดงโลโก้ของ Elastic อัตโนมัติ

### 3. ธีมเริ่มต้นสีสว่าง (Light Theme Default) & ตัวกรอง Status ใน OS Monitoring Details
- **Light Theme Default & Readability (`web/index.html`, `web/styles.css`, `web/app.js`):**
  - ตั้งค่าเริ่มต้นของระบบเป็นธีมสีสว่าง (`data-theme="light"`) และปรับสีตัวอักษร/โดนัทชาร์ตให้อ่านง่ายชัดเจนทุกส่วน
- **ตัวกรอง Status ใน `OS Monitoring Details` (`#osStatusFilter`):**
  - เพิ่มตัวเลือกกรองสถานะ (`ทุกสถานะ`, `Monitored`, `Not Monitored`, `Not Required`) พร้อมแสดงจำนวนรายการ

---

## [v63 / ZabbixV3] - 2026-11-04

### 1. หน้า Login โทนสีน้ำเงินเข้มเรียบหรู & Direct Zabbix Authentication
- **Plain Deep Navy Login UI (`web/styles.css`, `web/index.html`):**
  - ปรับพื้นหลังหน้า Login (`#loginOverlay`) เป็นสีน้ำเงินเข้มทึบเรียบหรู (`#071126`) ไม่มีลวดลายกวนสายตา และเน้นกล่อง Login (`.login-card`) ด้วยโทนสี Royal Sapphire (`#132852` ➔ `#0d1d3d`) ขอบเรืองแสงสีฟ้าชัดเจน
- **Direct Zabbix User/Pass & API Token Authentication (`zabbix_api.py`, `app.py`):**
  - รองรับการเข้าสู่ระบบผ่าน `user.login` (ดึงข้อมูลผู้ใช้จริงจาก Zabbix ตาม URL ที่ระบุ) และ `API Token`
  - รองรับทั้ง Zabbix 7.0+ (`Authorization: Bearer <token>`) และ Zabbix รุ่นก่อนหน้า (`"auth"` parameter) พร้อมระบบสลับโหมดอัตโนมัติและรองรับ Self-Signed SSL

### 2. การปรับปรุงหน้า Dashboard & Server Information
- **ค้นหาได้ทั้ง `AppID : AppName` และ `Group` (`web/app.js`, `zabbix_api.py`):**
  - รองรับ `selectHostGroups` สำหรับ Zabbix 7.0+ และดึงรายชื่อ Host Groups ทั้งหมดจาก Zabbix เพื่อให้ช่องค้นหา Application / Group กรองข้อมูลได้ครบถ้วน
- **ปรับตาราง Server Information (`web/app.js`):**
  - นำแถว `Technical Name` ออกตามความต้องการของผู้ใช้
  - เพิ่มการดึงข้อมูล **Zabbix Proxy / Proxy Group** (`proxy.get` และ `proxygroup.get`) ที่แต่ละ Server เกาะอยู่ และจัดวางแถว `Zabbix Proxy` ต่อจาก `OS Template`

### 3. Single-File Standalone HTML & Hybrid Browser-Direct Engine
- **สร้างไฟล์ `Zabbix_Monitoring_Standalone.html` (`build_standalone.py`, `web/standalone_engine.js`):**
  - รวม HTML, CSS, JS และ Zabbix JSON-RPC Client ไว้ในไฟล์เดียว สามารถก๊อปปี้ไปเปิดบนเครื่องอื่น (เช่น เครื่องที่ต่อ VPN ธนาคาร) ด้วย Chrome/Edge ได้ทันทีโดยไม่ต้องติดตั้ง Python

---

## [v57] - 2026-10-31

### 1. Trigger Explorer & UI Full-Width Extension (ขยายเต็มจอฝั่งขวา)
- **HTML Container Fix (`web/app.js`):**
  - แก้ไขการปิดแท็ก `</div>` ของ `.trig-toolbar` ก่อนคอนเทนเนอร์ `#trigResultsContainer` ป้องกันไม่ให้ผลลัพธ์ของการ์ดตกไปอยู่ใน Flex container บรรทัดเดียวกัน ซึ่งเดิมส่งผลให้การ์ดถูกบีบให้แคบและเหลือพื้นที่ว่างด้านขวา
- **CSS Grid & Width Expansion (`web/styles.css`):**
  - กำหนด `width: 100%; box-sizing: border-box;` ให้กับ `.trig-explorer`, `#trigResultsContainer`, `.trig-correlate-list`, และ `.trig-correlate-card`
  - ปรับ Grid ภายใน `.trig-card-grid-compact` เป็น `grid-template-columns: minmax(260px, 30%) 1fr;` ส่งผลให้คอลัมน์ฝั่งขวา (**3. TRIGGER & เงื่อนไขแจ้งเตือน**) ยืดเต็มพื้นที่ด้านขวาอย่างสมดุล
  - ปรับขนาดของ Snippet สูตร Expression (`.trig-expr-snippet`) ให้ขยายได้สูงสุดถึง `88%` พร้อมโฮเวอร์ไฮไลต์ชัดเจน

### 2. Trigger Explorer Modern & Compact Redesign (ปรับการ์ดให้กระชับ สะอาดตา)
- **Top Ribbon (Step 1):** รวมข้อมูล Template, จำนวน Metrics และจำนวน Triggers ไว้ในแถบด้านบน (`.trig-card-topbar`) ในบรรทัดเดียว
- **2-Column Split:** แบ่งโครงสร้างชัดเจนระหว่างฝั่งซ้าย (Items ที่ตรวจวัด) และฝั่งขวา (Trigger & Actions) พร้อม Scrollbar ขนาดกะทัดรัด
- **Card Accordion / Folding:** สามารถคลิกส่วนหัวของการ์ด (`.trig-card-head`) เพื่อย่อ/ขยาย (Fold/Unfold) ซ่อนเนื้อหาเพื่อความสะอาดตา

### 3. Interactive Help Dropdowns (`?`) (คำอธิบายส่วนต่างๆ)
- ซ่อนข้อความอธิบายยาวๆ ในหน้าทั้งหมดไว้ในปุ่ม `?` ท้ายชื่อหัวข้อ (`.section-help-btn`)
- รองรับการเปิด/ปิด Accordion แบบลอยตัว (`.section-help-box`) โดยไม่กระทบหรือเปลี่ยนแปลงเมนูหลักด้านซ้าย (Left Sidebar)
- รองรับครอบคลุมทุกหน้า:
  - Dashboard (Server Information, Resource Utilization, KPI Compliance, Monitoring Health)
  - Template Mapping (App Servers, Official Template, Custom Monitor, Trigger Explorer)
  - Reports
  - Elastic Overview, Elastic Config, Elastic Indices
  - System Settings

### 4. Cache-Busting Version Bump
- อัปเดต version query string ใน `web/index.html` เป็น `?v=57` ทั้งไฟล์ CSS และ JS
