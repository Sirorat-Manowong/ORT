"""
Build a single-file, self-contained HTML application:
  c:\\Project\\ZabbixV2\\Zabbix_Monitoring_Standalone.html

Bundles:
  - web/index.html
  - web/styles.css
  - web/standalone_engine.js (Browser-direct Zabbix JSON-RPC + Monitoring Standard engine)
  - web/app.js
  - web/elastic.js
"""
import base64
import os
import re

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(BASE_DIR, "web")
OUT_FILE = os.path.join(BASE_DIR, "Zabbix_Monitoring_Standalone.html")


def read_utf8(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def read_data_uri(filename: str) -> str:
    path = os.path.join(WEB_DIR, filename)
    if not os.path.exists(path):
        return filename
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("ascii")
    return f"data:image/png;base64,{b64}"


def build_standalone_html() -> str:
    html = read_utf8(os.path.join(WEB_DIR, "index.html"))
    css = read_utf8(os.path.join(WEB_DIR, "styles.css"))
    engine_js = read_utf8(os.path.join(WEB_DIR, "standalone_engine.js"))
    app_js = read_utf8(os.path.join(WEB_DIR, "app.js"))
    elastic_js = read_utf8(os.path.join(WEB_DIR, "elastic.js"))

    # Inline logo PNGs as base64 data URIs for single-file portability
    for logo_name in ("logo-zabbix.png", "logo-elastic.png"):
        uri = read_data_uri(logo_name)
        html = html.replace(f'src="{logo_name}"', f'src="{uri}"')
        app_js = app_js.replace(f'src="{logo_name}"', f'src="{uri}"')

    # Remove external stylesheet and script tags from index.html
    html = re.sub(r'<link\s+rel="stylesheet"\s+href="styles\.css[^"]*"\s*/?>\s*', "", html)
    html = re.sub(r'<script\s+src="standalone_engine\.js[^"]*"[^>]*></script>\s*', "", html)
    html = re.sub(r'<script\s+src="app\.js[^"]*"[^>]*></script>\s*', "", html)
    html = re.sub(r'<script\s+src="elastic\.js[^"]*"[^>]*></script>\s*', "", html)

    # Guard against accidental </script> or </style> inside JS/CSS strings
    safe_css = css.replace("</style>", "<\\/style>")
    safe_engine = engine_js.replace("</script>", "<\\/script>")
    safe_app = app_js.replace("</script>", "<\\/script>")
    safe_elastic = elastic_js.replace("</script>", "<\\/script>")

    head_inject = f"<style>\n{safe_css}\n</style>\n</head>"
    html = html.replace("</head>", head_inject, 1)

    body_inject = (
        "<script>\nwindow.STANDALONE_MODE = true;\n</script>\n"
        f"<script>\n{safe_engine}\n</script>\n"
        f"<script>\n{safe_app}\n</script>\n"
        f"<script>\n{safe_elastic}\n</script>\n"
        "</body>"
    )
    html = html.replace("</body>", body_inject, 1)
    return html


if __name__ == "__main__":
    content = build_standalone_html()
    with open(OUT_FILE, "w", encoding="utf-8") as f:
        f.write(content)
    size_kb = os.path.getsize(OUT_FILE) / 1024.0
    print(f"[OK] Generated {OUT_FILE} ({size_kb:.1f} KB)")

