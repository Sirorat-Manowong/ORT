"""
Zabbix Host Manager Web Server
Provides a Web Dashboard and REST API for Zabbix server login and bulk host addition.
Runs with standard Python library and 'requests'.
"""
import os
import sys

# Ensure current script directory is in python search path
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

import json
import csv
import io
import mimetypes
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from urllib.parse import urlparse, parse_qs
from concurrent.futures import ThreadPoolExecutor
import time
from zabbix_api import ZabbixClient
import monitoring_standard as ms
import artifact_report
import elastic_manager as em
import remote_check
import re

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

PORT = 5000
for arg in sys.argv[1:]:
    if arg.isdigit():
        PORT = int(arg)
        break
    elif arg.startswith("--port="):
        try:
            PORT = int(arg.split("=")[1])
            break
        except Exception:
            pass
if "PORT" in os.environ:
    try:
        PORT = int(os.environ["PORT"])
    except Exception:
        pass

if getattr(sys, "frozen", False):
    EXE_DIR = os.path.dirname(sys.executable)
    BUNDLE_DIR = getattr(sys, "_MEIPASS", EXE_DIR)
    if os.path.exists(os.path.join(EXE_DIR, "web")):
        WEB_DIR = os.path.join(EXE_DIR, "web")
    elif os.path.exists(os.path.join(BUNDLE_DIR, "web")):
        WEB_DIR = os.path.join(BUNDLE_DIR, "web")
    elif os.path.exists(os.path.join(EXE_DIR, "_internal", "web")):
        WEB_DIR = os.path.join(EXE_DIR, "_internal", "web")
    else:
        WEB_DIR = os.path.join(EXE_DIR, "web")
    SESSION_FILE = os.path.join(EXE_DIR, ".session.json")
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    WEB_DIR = os.path.join(BASE_DIR, "web")
    SESSION_FILE = os.path.join(BASE_DIR, ".session.json")

# In-memory client session
current_client: ZabbixClient = None

def clear_saved_session():
    if os.path.exists(SESSION_FILE):
        try:
            os.remove(SESSION_FILE)
        except OSError as exc:
            raise RuntimeError(f"Unable to remove saved session file: {exc}") from exc


def save_session(client: ZabbixClient):
    try:
        payload = {
            "url": client.url,
            "token": client.auth_token,
            "is_token": client.is_api_token,
            "use_bearer": getattr(client, "use_bearer", False),
            "version": client.api_version,
            "user_info": getattr(client, "user_info", {}),
            "verify_ssl": bool(client.session.verify),
        }
        with open(SESSION_FILE, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[!] Could not save session file: {e}")


def load_saved_session():
    if not os.path.exists(SESSION_FILE):
        return None
    try:
        with open(SESSION_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        url = data.get("url", "").strip()
        token = data.get("token", "").strip()
        if not url or not token:
            return None
        client = ZabbixClient(url=url, verify_ssl=bool(data.get("verify_ssl", True)))
        client.auth_token = token
        client.is_api_token = bool(data.get("is_token", False))
        client.use_bearer = bool(data.get("use_bearer", client.is_api_token))
        client.api_version = data.get("version") or "6.0"
        client.user_info = data.get("user_info") or {}
        return client
    except Exception:
        return None

# ---------------------------------------------------------------------------
# Monitoring standard / compliance helpers
# ---------------------------------------------------------------------------
_templates_cache = {"at": 0.0, "url": "", "data": []}


def all_templates_cached(force: bool = False):
    """Zabbix template catalog (used to resolve recommended template names), cached 10 minutes."""
    if (force or not _templates_cache["data"] or time.time() - _templates_cache["at"] > 600
            or _templates_cache["url"] != current_client.url):
        _templates_cache["data"] = current_client.get_templates()
        _templates_cache["at"] = time.time()
        _templates_cache["url"] = current_client.url
    return _templates_cache["data"]


def _public_host(host: dict) -> dict:
    """Host fields to show in Server Information & reports (including all host macros from Zabbix)."""
    all_macros = [
        {
            "hostmacroid": m.get("hostmacroid", ""),
            "macro": m.get("macro", ""),
            "value": "******" if str(m.get("type", "0")) == "1" and "value" not in m else m.get("value", ""),
            "description": m.get("description", ""),
            "type": str(m.get("type", "0")),
        }
        for m in (host.get("macros") or [])
        if m.get("macro")
    ]
    return {
        "hostid": host.get("hostid"), "host": host.get("host"), "name": host.get("name"),
        "status": host.get("status"), "description": host.get("description", ""),
        "proxy_name": host.get("proxy_name", ""),
        "zbx_connected": host.get("zbx_connected", "unknown"),
        "zbx_error": host.get("zbx_error", ""),
        "groups": [{"groupid": g.get("groupid"), "name": g.get("name")} for g in host.get("groups", [])],
        "interfaces": [{k: i.get(k) for k in ("interfaceid", "ip", "dns", "port", "type", "main", "useip", "available", "error")} for i in host.get("interfaces", [])],
        "parentTemplates": [{"templateid": t.get("templateid"), "name": t.get("name")} for t in host.get("parentTemplates", [])],
        "macros": all_macros,
    }


def build_compliance(hostid: str, refresh: bool = False, direct=None) -> dict:
    host = current_client.get_host_detail(hostid)
    if not host:
        raise LookupError(f"Host {hostid} not found")
    items = current_client.get_host_items(hostid).get("items", [])
    settings = ms.load_settings()
    if direct is None:
        direct = bool(refresh)
    inventory = current_client.collect_inventory(host, items, settings, refresh=refresh, direct=direct)
    return ms.evaluate(_public_host(host), items, host.get("parentTemplates", []), inventory,
                       all_templates_cached(), settings, ms.load_waivers(hostid))


def build_software_inventory(hostid: str, refresh: bool = False) -> dict:
    """
    Every software / service / process discovered ON THE MACHINE (via Zabbix agent inventory),
    mapped to Zabbix: expected template (from the catalog), the real linked template / item if any,
    and Monitored / Not Monitored.
    """
    host = current_client.get_host_detail(hostid)
    if not host:
        raise LookupError(f"Host {hostid} not found")
    items = current_client.get_host_items(hostid).get("items", [])
    settings = ms.load_settings()
    inventory = current_client.collect_inventory(host, items, settings, refresh=refresh)
    all_tpls = all_templates_cached()
    linked = host.get("parentTemplates", [])
    linked_lower = [(t.get("name") or "").lower() for t in linked]
    # Which template each inherited item comes from (item.templateid -> template item -> template host)
    tpl_item_ids = sorted({str(it.get("templateid")) for it in items if str(it.get("templateid") or "0") != "0"})
    origin = {}
    if tpl_item_ids:
        res = current_client._call("item.get", {"itemids": tpl_item_ids, "output": ["itemid", "templateid"],
                                                "selectHosts": ["name"], "templated": True})
        for ti in res.get("result", []):
            origin[str(ti["itemid"])] = ((ti.get("hosts") or [{}])[0]).get("name", "")
    for it in items:
        it["_template"] = origin.get(str(it.get("templateid") or ""), "")
    rows = ms.software_inventory_rows(inventory, items, linked, linked_lower, all_tpls)
    return {
        "host": {"hostid": host.get("hostid"), "name": host.get("name"), "host": host.get("host")},
        "os_family": inventory.get("os_family"),
        "inventory": {"source": inventory.get("source", {}), "confidence": inventory.get("confidence"),
                      "software_count": len(inventory.get("software", [])),
                      "services_count": len(inventory.get("services", [])),
                      "processes_count": len(inventory.get("processes", [])),
                      "collected_at": inventory.get("collected_at", ""), "errors": inventory.get("errors", [])[:10],
                      "notes": inventory.get("notes", [])},
        "rows": rows,
        "generated_at": inventory.get("collected_at", ""),
    }


# ---------------------------------------------------------------------------
# Elastic / Filebeat helpers (server inventory always comes from Zabbix)
# ---------------------------------------------------------------------------
def app_of(host: dict) -> dict:
    """Application from the Zabbix host group pattern '1234 : appname'."""
    for g in host.get("groups", []):
        m = re.match(r"^\s*(\d+)\s*:\s*(.+?)\s*$", g.get("name") or "")
        if m:
            return {"appid": m.group(1), "appname": m.group(2), "group": g.get("name")}
    return {"appid": "", "appname": "", "group": ""}


def elastic_client_or_none():
    s = em.load_settings()
    return em.ElasticClient(s) if s.get("es_url") else None


def host_address(host: dict) -> str:
    """IP/DNS to reach the real machine: the agent interface first, otherwise any interface."""
    ifaces = sorted(host.get("interfaces", []), key=lambda i: (str(i.get("type")) != "1", str(i.get("main")) != "1"))
    for i in ifaces:
        addr = i.get("ip") if str(i.get("useip", "1")) == "1" else (i.get("dns") or i.get("ip"))
        if addr:
            return addr
    return ""


def filebeat_from_zabbix(hostid: str) -> dict:
    """
    Read Filebeat status from the host's Zabbix items (proc.num[,,,<cmdline>]):
      proc.num[,,,filebeat]                  -> running state (count of filebeat processes)
      proc.num[,,,/etc/filebeat/filebeat.]   -> process started with that config path
    Any other proc.num[,,,<x>] whose cmdline mentions filebeat is treated as a named instance.
    """
    import re as _re
    items = current_client.get_host_items(hostid).get("items", [])
    procs = []  # (cmdline, item)
    config_text, config_from = "", ""
    for it in items:
        key = it.get("key_") or ""
        name = (it.get("name") or "")
        # filebeat.yml content item: key vfs.file.contents[...filebeat.yml] or name "Config filebeat.yml"
        is_cfg = (_re.match(r"^vfs\.file\.contents\[.*filebeat\.ya?ml.*\]$", key, _re.I)
                  or ("config" in name.lower() and "filebeat" in name.lower()))
        if is_cfg and str(it.get("state", "0")) == "0" and str(it.get("status", "0")) == "0":
            lv = it.get("lastvalue") or ""
            if lv.strip() and len(lv) > len(config_text):
                config_text, config_from = lv, key
        m = _re.match(r"^proc\.num\[([^\]]*)\]$", key)
        if not m:
            continue
        params = m.group(1).split(",")
        cmd = params[3].strip() if len(params) > 3 else ""
        name = params[0].strip() if params else ""
        token = cmd or name
        if "filebeat" in token.lower():
            procs.append((token, it))

    def _collecting(it):
        return str(it.get("state", "0")) == "0" and str(it.get("status", "0")) == "0" and int(it.get("lastclock") or 0) > 0

    def _count(it):
        try:
            return int(float(it.get("lastvalue")))
        except (TypeError, ValueError):
            return None

    config_paths, instances, running_any, any_data, newest = [], [], False, False, 0
    for token, it in procs:
        collecting = _collecting(it)
        cnt = _count(it)
        if collecting:
            any_data = True
            newest = max(newest, int(it.get("lastclock") or 0))
        up = collecting and cnt is not None and cnt > 0
        running_any = running_any or up
        looks_path = ("/" in token or "\\" in token or token.lower().endswith("filebeat."))
        entry = {"cmdline": token, "name": (it.get("name") or token), "count": cnt,
                 "running": up, "collecting": collecting, "lastclock": int(it.get("lastclock") or 0),
                 "key": it.get("key_")}
        if looks_path:
            config_paths.append(token.rstrip("."))
        instances.append(entry)
    return {"items_found": len(procs), "has_data": any_data, "running": running_any,
            "config_paths": sorted(set(config_paths)), "instances": instances,
            "config_text": config_text, "config_from": config_from, "lastclock": newest}


def elastic_host_status(hostid: str, refresh: bool = False) -> dict:
    """Zabbix = identity (host name, IP, appid : appname) + Filebeat process items. Config detail still read on the machine when available."""
    host = current_client.get_host_detail(hostid)
    if not host:
        raise LookupError(f"Host {hostid} not found")
    settings = em.load_settings()
    paths = [i["path"] for i in (em.load_host_config(hostid).get("inputs") or [])]
    fb_zbx = filebeat_from_zabbix(hostid)
    addr = host_address(host)
    # Only reach into the machine for config/registry when SSH/WinRM credentials are configured
    want_remote = bool(settings.get("ssh_user") or settings.get("win_user"))
    if not addr:
        remote = {"reachable": False, "method": "ssh", "address": "", "error": "Host ใน Zabbix ไม่มี IP / DNS"}
    elif not want_remote:
        remote = {"reachable": False, "method": "ssh", "address": addr, "error": "",
                  "skipped": True}
    else:
        ssh_open = remote_check.port_open(addr, int(settings.get("ssh_port") or 22))
        winrm_open = remote_check.port_open(addr, 5985) or remote_check.port_open(addr, 5986)
        if ssh_open and not winrm_open:
            order = ["linux"]
        elif winrm_open and not ssh_open:
            order = ["windows"]
        else:
            order = ["linux", "windows"]
        remote = None
        for hint in order:
            res = remote_check.check_host(hostid, addr, hint, settings, paths, refresh=refresh)
            if remote is None or res.get("reachable"):
                remote = res
            if res.get("reachable"):
                break
        if not ssh_open and not winrm_open and not remote.get("reachable"):
            remote["error"] = f"{addr}: พอร์ต SSH ({settings.get('ssh_port') or 22}) และ WinRM (5985/5986) ปิดหรือถูก firewall กั้น — " + remote.get("error", "")
    return em.evaluate_host(_public_host(host), app_of(host), remote, elastic_client_or_none(), settings, fb_zbx)


class ZabbixRequestHandler(BaseHTTPRequestHandler):
    def end_headers(self):
        # Enable CORS and disable aggressive caching for API
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def _send_json(self, data: dict, status_code: int = 200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> dict:
        content_length = int(self.headers.get("Content-Length", 0))
        if content_length == 0:
            return {}
        post_data = self.rfile.read(content_length)
        try:
            return json.loads(post_data.decode("utf-8"))
        except Exception:
            return {}

    def do_GET(self):
        try:
            parsed = urlparse(self.path)
            path = parsed.path

            if path == "/api/status":
                global current_client
                if not current_client:
                    current_client = load_saved_session()
                is_connected = False
                if current_client and current_client.auth_token:
                    if current_client.is_token_valid():
                        is_connected = True
                    elif current_client.auth_expired:
                        print("[!] Active session token expired or invalid. Disconnecting.")
                        current_client = None
                        clear_saved_session()
                    else:
                        is_connected = True

                u_info = getattr(current_client, "user_info", {}) if current_client else {}
                self._send_json({
                    "connected": is_connected,
                    "version": current_client.api_version if current_client else None,
                    "url": current_client.url if current_client else None,
                    "user": u_info.get("username") if is_connected else None,
                    "display_name": u_info.get("display_name") if is_connected else None,
                })
                return

            elif path == "/api/groups":
                if not current_client or not current_client.auth_token:
                    self._send_json({"error": "Not connected to Zabbix"}, 401)
                    return
                groups = current_client.get_host_groups()
                if current_client.auth_expired:
                    current_client = None
                    clear_saved_session()
                    self._send_json({"error": "Session expired, please log in again"}, 401)
                    return
                self._send_json({"success": True, "groups": groups})
                return

            elif path == "/api/templates":
                if not current_client or not current_client.auth_token:
                    self._send_json({"error": "Not connected to Zabbix"}, 401)
                    return
                templates = current_client.get_templates()
                if current_client.auth_expired:
                    current_client = None
                    clear_saved_session()
                    self._send_json({"error": "Session expired, please log in again"}, 401)
                    return
                self._send_json({"success": True, "templates": templates})
                return

            elif path == "/api/hosts":
                if not current_client or not current_client.auth_token:
                    self._send_json({"error": "Not connected to Zabbix"}, 401)
                    return
                hosts = current_client.get_hosts(limit=2000)
                groups = current_client.get_host_groups()
                if current_client.auth_expired:
                    current_client = None
                    clear_saved_session()
                    self._send_json({"error": "Session expired, please log in again"}, 401)
                    return
                self._send_json({"success": True, "hosts": hosts, "groups": groups})
                return

            elif path == "/api/host/items":
                if not current_client or not current_client.auth_token:
                    self._send_json({"error": "Not connected to Zabbix"}, 401)
                    return
                query_params = parse_qs(parsed.query)
                hostid = query_params.get("hostid", [""])[0]
                if not hostid:
                    self._send_json({"error": "hostid is required"}, 400)
                    return
                data = current_client.get_host_items(hostid)
                self._send_json(data)
                return

            elif path == "/api/host/triggers":
                if not current_client or not current_client.auth_token:
                    self._send_json({"error": "Not connected to Zabbix"}, 401)
                    return
                query_params = parse_qs(parsed.query)
                hostid = query_params.get("hostid", [""])[0]
                if not hostid:
                    self._send_json({"error": "hostid is required"}, 400)
                    return
                triggers = current_client.get_host_triggers(hostid)
                templates = []
                try:
                    ht = current_client._call("host.get", {
                        "hostids": [str(hostid)],
                        "output": ["hostid", "name", "host"],
                        "selectParentTemplates": ["templateid", "name", "host"]
                    })
                    if ht.get("result"):
                        templates = ht["result"][0].get("parentTemplates", [])
                except Exception:
                    pass

                by_severity = {"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0}
                problems = 0
                enabled_cnt = 0
                for t in triggers:
                    pri = str(t.get("priority", "0"))
                    by_severity[pri] = by_severity.get(pri, 0) + 1
                    if str(t.get("value")) == "1" and str(t.get("status")) == "0":
                        problems += 1
                    if str(t.get("status")) == "0":
                        enabled_cnt += 1

                self._send_json({
                    "success": True,
                    "hostid": hostid,
                    "triggers": triggers,
                    "templates": templates,
                    "summary": {
                        "total": len(triggers),
                        "problems": problems,
                        "enabled": enabled_cnt,
                        "disabled": len(triggers) - enabled_cnt,
                        "by_severity": by_severity
                    }
                })
                return

            elif path == "/api/host/valuemaps":
                if not current_client or not current_client.auth_token:
                    self._send_json({"error": "Not connected to Zabbix"}, 401)
                    return
                query_params = parse_qs(parsed.query)
                hostid = query_params.get("hostid", [""])[0]
                if not hostid:
                    self._send_json({"error": "hostid is required"}, 400)
                    return
                valuemaps = current_client.get_host_valuemaps(hostid)
                self._send_json({"success": True, "hostid": hostid, "valuemaps": valuemaps})
                return

            elif path == "/api/host/compliance":
                if not current_client or not current_client.auth_token:
                    self._send_json({"error": "Not connected to Zabbix"}, 401)
                    return
                q = parse_qs(parsed.query)
                hostid = q.get("hostid", [""])[0].strip()
                if not hostid.isdigit():
                    self._send_json({"error": "hostid is required"}, 400)
                    return
                refresh = q.get("refresh", ["0"])[0] == "1"
                try:
                    self._send_json({"success": True, **build_compliance(hostid, refresh=refresh)})
                except LookupError as e:
                    self._send_json({"error": str(e)}, 404)
                return

            elif path == "/api/host/software-inventory":
                if not current_client or not current_client.auth_token:
                    self._send_json({"error": "Not connected to Zabbix"}, 401)
                    return
                q = parse_qs(parsed.query)
                hostid = q.get("hostid", [""])[0].strip()
                if not hostid.isdigit():
                    self._send_json({"error": "hostid is required"}, 400)
                    return
                try:
                    self._send_json({"success": True, **build_software_inventory(hostid, refresh=q.get("refresh", ["0"])[0] == "1")})
                except LookupError as e:
                    self._send_json({"error": str(e)}, 404)
                return

            elif path == "/api/settings":
                self._send_json({"success": True, "settings": ms.load_settings(),
                                 "browser": artifact_report.find_browser() or ""})
                return

            elif path == "/api/artifact/report":
                if not current_client or not current_client.auth_token:
                    self._send_json({"error": "Not connected to Zabbix"}, 401)
                    return
                q = parse_qs(parsed.query)
                fmt = q.get("format", ["html"])[0].lower()
                if fmt not in ("html", "pdf", "png", "csv", "json"):
                    self._send_json({"error": "format must be html, pdf, png, csv or json"}, 400)
                    return
                raw_ids = q.get("hostids", [""])[0] or q.get("hostid", [""])[0]
                hostids = [h for h in raw_ids.split(",") if h.strip().isdigit()][:50]
                if not hostids:
                    self._send_json({"error": "hostid or hostids is required"}, 400)
                    return
                multi = len(hostids) > 1
                # Multi-host reports use Zabbix data only (no direct agent calls) to stay fast
                with ThreadPoolExecutor(max_workers=4) as pool:
                    results = list(pool.map(lambda h: self._safe_compliance(h, direct=False if multi else None), hostids))
                reports = [r for r in results if r]
                if not reports:
                    self._send_json({"error": "ไม่พบข้อมูล host ที่เลือก"}, 404)
                    return
                settings = ms.load_settings()
                title_suffix = q.get("title", [""])[0][:120]
                meta = {
                    "title": "Monitoring Readiness Report",
                    "subtitle": title_suffix or (reports[0]["host"].get("name") if not multi else f"{len(reports)} hosts"),
                    "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "zabbix_url": current_client.url.replace("/api_jsonrpc.php", ""),
                    "zabbix_version": current_client.api_version,
                    "prepared_by": q.get("prepared_by", [""])[0][:80],
                    "organization": settings.get("organization", ""),
                }
                base = artifact_report.safe_filename(
                    (title_suffix or reports[0]["host"].get("name") or "host") + ("_readiness" if not multi else "_app_readiness"))
                stamp = time.strftime("%Y%m%d_%H%M")
                try:
                    if fmt == "json":
                        body, ctype = artifact_report.build_json(reports, meta), "application/json; charset=utf-8"
                    elif fmt == "csv":
                        body, ctype = artifact_report.build_csv(reports), "text/csv; charset=utf-8"
                    else:
                        html_text = artifact_report.build_html(reports, meta)
                        if fmt == "html":
                            body, ctype = html_text.encode("utf-8"), "text/html; charset=utf-8"
                        else:
                            height = artifact_report.estimate_height(reports)
                            body = artifact_report.render_with_browser(html_text, fmt, height)
                            ctype = "application/pdf" if fmt == "pdf" else "image/png"
                except RuntimeError as e:
                    self._send_json({"error": str(e)}, 503)
                    return
                inline = q.get("inline", ["0"])[0] == "1"
                self.send_response(200)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Disposition",
                                 f'{"inline" if inline else "attachment"}; filename="{base}_{stamp}.{fmt}"')
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)
                return

            elif path.startswith("/api/elastic/"):
                if not current_client or not current_client.auth_token:
                    self._send_json({"error": "Not connected to Zabbix"}, 401)
                    return
                self._elastic_dispatch("GET", path, parse_qs(parsed.query), {})
                return

            elif path == "/favicon.ico":
                self.send_response(204)
                self.end_headers()
                return

            elif path == "/api/template.csv":
                csv_content = (
                    "host,name,ip,port,group_name,template_name,description\r\n"
                    "db-server-01,Database Server 01,192.168.1.50,10050,Linux servers,Linux by Zabbix agent,Production DB\r\n"
                    "web-server-01,Web Server 01,192.168.1.51,10050,Linux servers,Linux by Zabbix agent,Nginx Web Server\r\n"
                    "app-server-01,Application Server 01,192.168.1.52,10050,Linux servers,Linux by Zabbix agent,NodeJS App\r\n"
                    "sw-core-01,Core Switch 01,192.168.1.254,161,Network/Switches,Generic SNMP,Main Switch\r\n"
                ).encode("utf-8-sig") # BOM for Excel
                self.send_response(200)
                self.send_header("Content-Type", "text/csv; charset=utf-8")
                self.send_header("Content-Disposition", 'attachment; filename="zabbix_hosts_template.csv"')
                self.send_header("Content-Length", str(len(csv_content)))
                self.end_headers()
                self.wfile.write(csv_content)
                return

            elif path in ("/download/standalone", "/Zabbix_Monitoring_Standalone.html"):
                standalone_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Zabbix_Monitoring_Standalone.html")
                if os.path.exists(standalone_path):
                    with open(standalone_path, "rb") as f:
                        content = f.read()
                    self._send_file(content, "text/html; charset=utf-8", "Zabbix_Monitoring_Standalone.html", inline=False)
                    return
                else:
                    self.send_error(404, "Zabbix_Monitoring_Standalone.html not found")
                    return

            elif path in ("/download", "/ZabbixV3.zip", "/Zabbix_Full_Program.zip", "/download/full", "/ZabbixHostManager_Portable.zip"):
                base_dir = os.path.dirname(os.path.abspath(__file__))
                zip_path = os.path.join(base_dir, "ZabbixV3.zip")
                if not os.path.exists(zip_path):
                    zip_path = os.path.join(base_dir, "Zabbix_Full_Program.zip")
                if not os.path.exists(zip_path):
                    zip_path = os.path.join(base_dir, "ZabbixHostManager_Portable.zip")
                if os.path.exists(zip_path):
                    file_size = os.path.getsize(zip_path)
                    filename = os.path.basename(zip_path)
                    self.send_response(200)
                    self.send_header("Content-Type", "application/zip")
                    self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                    self.send_header("Content-Length", str(file_size))
                    self.end_headers()
                    with open(zip_path, "rb") as f:
                        while chunk := f.read(65536):
                            self.wfile.write(chunk)
                    return
                else:
                    self.send_error(404, "Portable ZIP package not found on server")
                    return

            # Serve static web frontend
            if path == "/" or path == "":
                file_path = os.path.join(WEB_DIR, "index.html")
            else:
                file_path = os.path.join(WEB_DIR, path.lstrip("/"))

            if os.path.exists(file_path) and os.path.isfile(file_path):
                mime_type, _ = mimetypes.guess_type(file_path)
                mime_type = mime_type or "application/octet-stream"
                with open(file_path, "rb") as f:
                    content = f.read()
                self.send_response(200)
                self.send_header("Content-Type", f"{mime_type}; charset=utf-8" if "text" in mime_type or "javascript" in mime_type else mime_type)
                self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)
            else:
                self.send_error(404, f"File {path} not found")
        except Exception as e:
            self._send_json({"error": f"Internal Server Error: {str(e)}"}, 500)

    def _send_file(self, body: bytes, ctype: str, filename: str, inline: bool = False):
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Disposition", f'{"inline" if inline else "attachment"}; filename="{filename}"')
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _elastic_dispatch(self, method: str, path: str, q: dict, data: dict):
        """All /api/elastic/* routes. Server data comes from Zabbix; Elastic calls use elastic_settings.json."""
        arg = lambda k, d="": (q.get(k, [d])[0] if q else d)  # noqa: E731
        try:
            if method == "GET" and path == "/api/elastic/settings":
                self._send_json({"success": True, "settings": em.public_settings()})
            elif method == "POST" and path == "/api/elastic/settings":
                self._send_json({"success": True, "settings": em.save_settings(data.get("settings") or {})})
            elif method == "POST" and path == "/api/elastic/test":
                self._send_json({"success": True, **em.ElasticClient().info()})

            elif method == "GET" and path == "/api/elastic/host-config":
                hostid = arg("hostid").strip()
                if not hostid.isdigit():
                    raise ValueError("hostid is required")
                host = current_client.get_host_detail(hostid)
                if not host:
                    raise LookupError("host not found")
                app = app_of(host)
                cfg = em.load_host_config(hostid)
                env = cfg.get("env") or em.load_settings()["default_env"]
                names = {t: em.index_name(app["appid"], app["appname"], env, t) for t in em.LOG_TYPES}
                self._send_json({"success": True, "app": app, "config": cfg, "env": env, "index_names": names,
                                 "space": em.space_id(app["appid"], app["appname"])})
            elif method == "POST" and path == "/api/elastic/host-config":
                hostid = str(data.get("hostid") or "").strip()
                if not hostid.isdigit():
                    raise ValueError("hostid is required")
                rec = em.save_host_config(hostid, {"inputs": data.get("inputs") or [], "env": data.get("env")})
                self._send_json({"success": True, "config": rec, "message": f"บันทึก {len(rec['inputs'])} log path แล้ว"})

            elif method == "GET" and path == "/api/elastic/file":
                hostid, kind = arg("hostid").strip(), arg("kind", "yml")
                if not hostid.isdigit() or kind not in ("yml", "script"):
                    raise ValueError("hostid and kind=yml|script are required")
                family = arg("os", "linux")
                if family not in ("linux", "windows", "aix"):
                    raise ValueError("os must be linux, windows or aix")
                host = current_client.get_host_detail(hostid)
                if not host:
                    raise LookupError("host not found")
                app = app_of(host)
                cfg = em.load_host_config(hostid)
                yml = em.build_filebeat_yml(_public_host(host), app, cfg, family)
                base = artifact_report.safe_filename(host.get("host") or "host")
                if kind == "yml":
                    self._send_file(yml.encode("utf-8"), "text/yaml; charset=utf-8", f"{base}_filebeat.yml",
                                    inline=arg("inline") == "1")
                else:
                    ext, script = em.build_install_script(family, yml, _public_host(host))
                    fname = f"{base}_filebeat_install.{ext}"
                    self._send_file(script.encode("utf-8"), "text/plain; charset=utf-8", fname, inline=arg("inline") == "1")

            elif method == "GET" and path == "/api/elastic/host-status":
                hostid = arg("hostid").strip()
                if not hostid.isdigit():
                    raise ValueError("hostid is required")
                self._send_json({"success": True, **elastic_host_status(hostid, refresh=arg("refresh") == "1")})
            elif method == "GET" and path == "/api/elastic/indices":
                pattern = arg("pattern", "*").strip() or "*"
                self._send_json({"success": True, "indices": em.ElasticClient().list_indices(pattern)})
            elif method == "POST" and path == "/api/elastic/index":
                action, name = data.get("action"), str(data.get("name") or "").strip()
                client = em.ElasticClient()
                if action == "create":
                    res = client.create_index(name)
                    self._send_json({"success": True, "message": f"Index {name} " + ("มีอยู่แล้ว" if res.get("existed") else "สร้างแล้ว")})
                elif action == "delete":
                    if data.get("confirm") != name:
                        raise ValueError("ต้องพิมพ์ชื่อ index ให้ตรงเพื่อยืนยันการลบ")
                    client.delete_index(name)
                    self._send_json({"success": True, "message": f"ลบ index {name} แล้ว"})
                else:
                    raise ValueError("action must be create or delete")

            elif method == "GET" and path == "/api/elastic/spaces":
                self._send_json({"success": True, "spaces": em.ElasticClient().list_spaces()})
            elif method == "POST" and path == "/api/elastic/space":
                appid, appname = str(data.get("appid") or ""), str(data.get("appname") or "")
                if not appid.isdigit():
                    raise ValueError("appid is required")
                env = data.get("env") or em.load_settings()["default_env"]
                client = em.ElasticClient()
                sid = em.space_id(appid, appname)
                sp = client.create_space(sid, f"{appid} : {appname}", f"Logs of application {appid} : {appname}")
                title = em.index_name(appid, appname, env, "*")
                dv = client.create_data_view(sid, title, f"{appid} {appname} logs ({em.env_code(env)})")
                self._send_json({"success": True, "space": sid, "data_view": title,
                                 "message": f"Space {sid} " + ("มีอยู่แล้ว" if sp.get("existed") else "สร้างแล้ว")
                                            + f" · data view {title} " + ("มีอยู่แล้ว" if dv.get("existed") else "สร้างแล้ว")})
            else:
                self._send_json({"error": "Endpoint not found"}, 404)
        except em.ElasticError as e:
            self._send_json({"success": False, "error": str(e)}, 502)
        except LookupError as e:
            self._send_json({"success": False, "error": str(e)}, 404)
        except (ValueError, TypeError) as e:
            self._send_json({"success": False, "error": str(e)}, 400)

    def _safe_compliance(self, hostid, direct=None):
        try:
            return build_compliance(hostid, direct=direct)
        except Exception as e:  # one bad host must not break a multi-host report
            print(f"[!] compliance failed for host {hostid}: {e}")
            return None

    def do_POST(self):
        try:
            self._handle_post()
        except Exception as e:
            import traceback
            traceback.print_exc()
            self._send_json({"success": False, "message": f"Server Error: {str(e)}"}, 500)

    def _handle_post(self):
        parsed = urlparse(self.path)
        path = parsed.path
        global current_client

        if path == "/api/connect":
            data = self._read_json()
            url = data.get("url", "").strip()
            username = data.get("username", "").strip()
            password = data.get("password", "")
            api_token = data.get("api_token", "").strip()
            verify_ssl = data.get("verify_ssl", True)

            if not url:
                self._send_json({"success": False, "message": "Zabbix Server URL is required"}, 400)
                return
            if not isinstance(verify_ssl, bool):
                self._send_json({"success": False, "message": "verify_ssl must be a boolean"}, 400)
                return

            client = ZabbixClient(url=url, verify_ssl=verify_ssl)
            success, msg = client.login(username=username, password=password, api_token=api_token)
            if success:
                current_client = client
                save_session(client)
                groups = client.get_host_groups()
                templates = client.get_templates()
                u_info = getattr(client, "user_info", {}) or {}
                self._send_json({
                    "success": True,
                    "message": "Connected successfully!",
                    "version": client.api_version,
                    "url": client.url,
                    "user": u_info.get("username") or username or "API Token",
                    "display_name": u_info.get("display_name") or username or "API Token",
                    "groups": groups,
                    "templates": templates
                })
            else:
                self._send_json({"success": False, "message": msg}, 400)
            return

        elif path == "/api/disconnect":
            current_client = None
            clear_saved_session()
            self._send_json({"success": True, "message": "Disconnected successfully"})
            return

        elif path == "/api/parse-csv":
            data = self._read_json()
            raw_text = data.get("csv_text", "")
            if not raw_text:
                self._send_json({"success": False, "message": "CSV content is empty"}, 400)
                return

            try:
                reader = csv.DictReader(io.StringIO(raw_text))
                parsed_rows = []
                for row in reader:
                    clean_row = {k.strip().lower(): v.strip() for k, v in row.items() if k}
                    host = clean_row.get("host") or clean_row.get("hostname") or clean_row.get("server") or ""
                    ip = clean_row.get("ip") or clean_row.get("ip_address") or clean_row.get("address") or ""
                    name = clean_row.get("name") or clean_row.get("visible_name") or host
                    port = clean_row.get("port", "10050")
                    group = clean_row.get("group_name") or clean_row.get("group") or ""
                    template = clean_row.get("template_name") or clean_row.get("template") or ""
                    desc = clean_row.get("description") or clean_row.get("desc") or ""

                    if host or ip:
                        parsed_rows.append({
                            "host": host,
                            "name": name,
                            "ip": ip,
                            "port": port,
                            "group_name": group,
                            "template_name": template,
                            "description": desc
                        })

                self._send_json({
                    "success": True,
                    "count": len(parsed_rows),
                    "rows": parsed_rows
                })
            except Exception as e:
                self._send_json({"success": False, "message": f"Failed to parse CSV: {str(e)}"}, 400)
            return

        if path == "/api/host/scan":
            data = self._read_json()
            ip = data.get("ip", "").strip()
            if not ip:
                self._send_json({"error": "IP address is required"}, 400)
                return
            if current_client:
                scan_res = current_client.scan_host(ip)
            else:
                dummy = ZabbixClient("http://127.0.0.1")
                scan_res = dummy.scan_host(ip)
            self._send_json(scan_res)
            return

        if not current_client or not current_client.auth_token:
            self._send_json({"error": "Zabbix session not active. Please connect first."}, 401)
            return

        if path.startswith("/api/elastic/"):
            self._elastic_dispatch("POST", path, {}, self._read_json())
            return

        if path == "/api/host/create":
            data = self._read_json()
            host = data.get("host", "").strip()
            # IP Manage goes directly to Agent interface
            ip_manage = data.get("ip_manage", "").strip() or data.get("ip", "").strip()
            # IP Service is recorded in Macro {$HOST.IP2}
            ip_service = data.get("ip_service", "").strip()
            port = str(data.get("port", "10050")).strip()
            name = data.get("name", "").strip() or host
            group_ids = data.get("group_ids", [])
            group_names = data.get("group_names", [])
            template_ids = data.get("template_ids", [])
            template_names = data.get("template_names", [])
            interface_type = int(data.get("interface_type", 1))
            user_desc = data.get("description", "").strip()
            workload = data.get("workload", "general").strip()
            db_type = data.get("db_type", "").strip()
            oracle_mode = data.get("oracle_mode", "").strip()
            oracle_sid = data.get("oracle_sid", "").strip()
            snmp_community = data.get("snmp_community", "public")

            # Construct team-standard Host Macros
            macros = []
            if host:
                macros.append({"macro": "{$ACTION_HOST}", "value": host})
            if ip_service:
                macros.append({"macro": "{$HOST.IP2}", "value": ip_service})
            if oracle_sid:
                macros.append({"macro": "{$ORACLE_SID}", "value": oracle_sid})

            # Merge any extra custom macros
            if "macros" in data and isinstance(data["macros"], list):
                for m in data["macros"]:
                    if isinstance(m, dict) and m.get("macro") and not any(ex["macro"] == m["macro"] for ex in macros):
                        macros.append(m)

            # Construct comprehensive description
            desc_parts = []
            if user_desc:
                desc_parts.append(user_desc)
            if workload and workload != "general":
                desc_parts.append(f"Workload: {workload.upper()}")
            if db_type:
                db_info = f"DB: {db_type.upper()}"
                if oracle_mode:
                    db_info += f" ({oracle_mode.upper()})"
                desc_parts.append(db_info)
            if oracle_sid:
                desc_parts.append(f"SID: {oracle_sid}")
            if ip_service:
                desc_parts.append(f"Service IP: {ip_service}")
            description = " | ".join(desc_parts)

            success, msg, hostid = current_client.create_host(
                host=host,
                ip=ip_manage,
                port=port,
                name=name,
                group_ids=group_ids,
                group_names=group_names,
                template_ids=template_ids,
                template_names=template_names,
                interface_type=interface_type,
                description=description,
                macros=macros,
                snmp_community=snmp_community
            )

            # If created successfully and user specified custom metrics or services
            if success and hostid:
                metrics = data.get("metrics", [])
                if metrics:
                    current_client.add_standalone_metrics(str(hostid), metrics, data.get("os_type", "windows"))

                services = data.get("services", [])
                if services:
                    current_client.add_service_items(str(hostid), services)

            self._send_json({"success": success, "message": msg, "hostid": hostid})
            return

        elif path == "/api/host/delete":
            data = self._read_json()
            hostid = data.get("hostid")
            if not hostid:
                self._send_json({"error": "hostid is required"}, 400)
                return
            ok, msg = current_client.delete_host(str(hostid))
            self._send_json({"success": ok, "message": msg})
            return


        elif path == "/api/hosts/batch":
            data = self._read_json()
            hosts_to_create = data.get("hosts", [])
            if not isinstance(hosts_to_create, list) or len(hosts_to_create) == 0:
                self._send_json({"success": False, "message": "No hosts provided"}, 400)
                return

            results = []
            success_count = 0
            failed_count = 0

            # Default fallback group/template if row doesn't have it
            default_group_ids = data.get("default_group_ids", [])
            default_template_ids = data.get("default_template_ids", [])
            default_port = str(data.get("default_port", "10050"))
            default_interface_type = int(data.get("default_interface_type", 1))

            for item in hosts_to_create:
                host = item.get("host", "").strip()
                ip = item.get("ip", "").strip()
                if not host or not ip:
                    results.append({
                        "host": host or "(empty)",
                        "ip": ip or "(empty)",
                        "success": False,
                        "message": "Host technical name and IP are required."
                    })
                    failed_count += 1
                    continue

                name = item.get("name", "").strip() or host
                port = str(item.get("port", default_port)).strip()
                desc = item.get("description", "")

                # Groups
                row_gids = item.get("group_ids") or default_group_ids
                row_gnames = item.get("group_names") or []
                if "group_name" in item and item["group_name"]:
                    row_gnames.append(item["group_name"])

                # Templates
                row_tids = item.get("template_ids") or default_template_ids
                row_tnames = item.get("template_names") or []
                if "template_name" in item and item["template_name"]:
                    row_tnames.append(item["template_name"])

                itype = int(item.get("interface_type", default_interface_type))
                snmp_comm = item.get("snmp_community", "public")

                ok, msg, hid = current_client.create_host(
                    host=host,
                    ip=ip,
                    port=port,
                    name=name,
                    group_ids=row_gids,
                    group_names=row_gnames,
                    template_ids=row_tids,
                    template_names=row_tnames,
                    interface_type=itype,
                    description=desc,
                    snmp_community=snmp_comm
                )

                if ok:
                    success_count += 1
                else:
                    failed_count += 1

                results.append({
                    "host": host,
                    "name": name,
                    "ip": ip,
                    "success": ok,
                    "message": msg,
                    "hostid": hid
                })

            self._send_json({
                "success": True,
                "summary": {
                    "total": len(hosts_to_create),
                    "success": success_count,
                    "failed": failed_count
                },
                "results": results
            })
            return

        elif path == "/api/host/items/toggle":
            data = self._read_json()
            updates = data.get("updates", [])
            ok, count, err = current_client.update_items_status(updates)
            self._send_json({"success": ok, "count": count, "message": err if not ok else f"Updated {count} items"})
            return

        elif path == "/api/host/items/check-now":
            data = self._read_json()
            itemids = data.get("itemids", [])
            ok, msg = current_client.execute_items_now(itemids)
            self._send_json({"success": ok, "message": msg})
            return

        elif path == "/api/host/discover-services":
            data = self._read_json()
            ip = data.get("ip", "").strip()
            hostid = data.get("hostid")
            os_type = data.get("os_type")
            if not ip:
                self._send_json({"error": "IP address is required"}, 400)
                return
            if current_client:
                disc_res = current_client.discover_host_services(ip, hostid, os_type=os_type)
            else:
                dummy = ZabbixClient("http://127.0.0.1")
                disc_res = dummy.discover_host_services(ip, hostid, os_type=os_type)
            self._send_json(disc_res)
            return

        elif path == "/api/host/add-services":
            data = self._read_json()
            hostid = data.get("hostid")
            services = data.get("services", [])
            os_type = data.get("os_type", "windows")
            if not hostid:
                self._send_json({"error": "hostid is required"}, 400)
                return
            ok, count, msg = current_client.add_service_items(hostid, services, os_type=os_type)
            self._send_json({"success": ok, "count": count, "message": msg})
            return

        elif path == "/api/host/items/delete":
            data = self._read_json()
            hostid = data.get("hostid")
            keys = data.get("keys", [])
            if not hostid:
                self._send_json({"error": "hostid is required"}, 400)
                return
            if not keys:
                self._send_json({"error": "keys is required"}, 400)
                return
            ok, count, msg = current_client.delete_items_by_key(str(hostid), keys)
            self._send_json({"success": ok, "count": count, "message": msg})
            return

        elif path == "/api/host/triggers/create-standard":
            data = self._read_json()
            hostid = data.get("hostid")
            if not hostid:
                self._send_json({"error": "hostid is required"}, 400)
                return
            ok, count, msg = current_client.create_standard_host_triggers(hostid)
            self._send_json({"success": ok, "count": count, "message": msg})
            return

        elif path == "/api/host/triggers/create":
            data = self._read_json()
            hostid = data.get("hostid")
            description = data.get("description", "").strip()
            expression = data.get("expression", "").strip()
            priority = data.get("priority", 3)
            if not hostid or not description or not expression:
                self._send_json({"error": "กรุณาระบุ hostid, ชื่อ Trigger และ Expression"}, 400)
                return
            ok, tid, msg = current_client.create_custom_trigger(hostid, description, expression, priority)
            self._send_json({"success": ok, "triggerid": tid, "message": msg})
            return

        elif path == "/api/host/triggers/toggle":
            data = self._read_json()
            updates = data.get("updates", [])
            ok, count, err = current_client.update_trigger_status(updates)
            self._send_json({"success": ok, "count": count, "message": err if not ok else f"Updated {count} triggers"})
            return

        elif path == "/api/host/triggers/delete":
            data = self._read_json()
            trigger_ids = data.get("triggerids") or data.get("trigger_ids") or []
            if not trigger_ids and data.get("triggerid"):
                trigger_ids = [data.get("triggerid")]
            if not trigger_ids:
                self._send_json({"error": "triggerids is required"}, 400)
                return
            ok, count, msg = current_client.delete_triggers(trigger_ids)
            self._send_json({"success": ok, "count": count, "message": msg})
            return

        elif path == "/api/host/templates/unlink":
            data = self._read_json()
            hostid = data.get("hostid")
            template_ids = data.get("template_ids")
            if not hostid:
                self._send_json({"error": "hostid is required"}, 400)
                return
            ok, msg, count = current_client.unlink_templates(str(hostid), template_ids)
            self._send_json({"success": ok, "message": msg, "cleared_count": count})
            return

        elif path == "/api/host/templates/link":
            data = self._read_json()
            hostid = data.get("hostid")
            template_ids = data.get("template_ids")
            if not hostid:
                self._send_json({"error": "hostid is required"}, 400)
                return
            if not template_ids:
                self._send_json({"error": "template_ids is required"}, 400)
                return
            ok, msg, count = current_client.link_templates(str(hostid), template_ids)
            self._send_json({"success": ok, "message": msg, "linked_count": count})
            return

        elif path == "/api/host/compliance/fix":
            # Apply one recommended action from the compliance result
            if not current_client or not current_client.auth_token:
                self._send_json({"error": "Not connected to Zabbix"}, 401)
                return
            data = self._read_json()
            hostid = str(data.get("hostid") or "").strip()
            action = data.get("action") or {}
            atype = action.get("type")
            if not hostid.isdigit() or not atype:
                self._send_json({"error": "hostid and action.type are required"}, 400)
                return
            os_family = action.get("os_family") or "linux"
            if os_family not in ms.OS_FAMILIES:
                os_family = "linux"
            if atype == "add_item":
                ok, msg = current_client.add_os_standard_item(hostid, str(action.get("check_id", "")), os_family)
            elif atype == "link_template":
                tid = str(action.get("templateid") or "")
                if not tid.isdigit():
                    self._send_json({"error": "templateid is required"}, 400)
                    return
                ok, msg, _ = current_client.link_templates(hostid, [tid])
            elif atype == "add_service":
                name = str(action.get("name") or "").strip()
                key = str(action.get("key") or "").strip()
                if not key and name:
                    key = f"service.info[{name},state]" if os_family == "windows" else f"proc.num[{name}]"
                if not name or not key.startswith(("service.info[", "proc.num[")):
                    self._send_json({"error": "name and a service.info/proc.num key are required"}, 400)
                    return
                ok, _, msg = current_client.add_service_items(
                    hostid, [{"name": name, "display_name": action.get("display_name") or name, "key": key}],
                    os_type=os_family)
            elif atype == "add_port":
                p = str(action.get("port") or action.get("name") or "").strip()
                if not p:
                    self._send_json({"error": "port is required"}, 400)
                    return
                ok, _, msg = current_client.add_custom_monitors(hostid, "port", [p], os_type=os_family)
            elif atype in ("waive", "unwaive"):
                check_key = str(action.get("check_key") or "").strip()
                if not check_key:
                    self._send_json({"error": "check_key is required"}, 400)
                    return
                ms.set_waiver(hostid, check_key, str(action.get("reason") or ""), remove=(atype == "unwaive"))
                ok, msg = True, ("ยกเลิก Waiver แล้ว" if atype == "unwaive" else "บันทึกเป็น Not Required แล้ว")
            else:
                self._send_json({"error": f"Unknown action type: {atype}"}, 400)
                return

            self._send_json({"success": ok, "message": msg})
            return
        elif path == "/api/host/compliance/fix-batch":
            if not current_client or not current_client.auth_token:
                self._send_json({"error": "Not connected to Zabbix"}, 401)
                return
            data = self._read_json()
            hostid = str(data.get("hostid") or "").strip()
            if not hostid.isdigit():
                self._send_json({"error": "hostid is required"}, 400)
                return
            actions = data.get("actions") or []
            if not actions:
                self._send_json({"error": "ไม่มีรายการที่เลือกสำหรับเพิ่ม Monitor"}, 400)
                return
            os_family = data.get("os_family") or "linux"
            if os_family not in ms.OS_FAMILIES:
                os_family = "linux"

            svc_items = []
            tmpl_ids = []
            port_items = []
            messages = []
            errors = []
            total_added = 0

            for a in actions:
                atype = a.get("type")
                if atype == "add_service":
                    sname = str(a.get("name") or "").strip()
                    skey = str(a.get("key") or "").strip()
                    dname = str(a.get("display_name") or sname)
                    if sname:
                        svc_items.append({"name": sname, "display_name": dname, "key": skey})
                elif atype == "link_template":
                    tid = str(a.get("templateid") or "").strip()
                    if tid.isdigit() and tid not in tmpl_ids:
                        tmpl_ids.append(tid)
                elif atype == "add_port":
                    p = str(a.get("port") or a.get("name") or "").strip()
                    if p:
                        port_items.append(p)
                elif atype == "add_item":
                    cid = str(a.get("check_id") or "").strip()
                    if cid:
                        ok, msg = current_client.add_os_standard_item(hostid, cid, os_family)
                        if ok:
                            total_added += 1
                        else:
                            errors.append(msg)

            if svc_items:
                ok, count, msg = current_client.add_service_items(hostid, svc_items, os_type=os_family)
                total_added += count
                messages.append(f"Service/Process {count} รายการ")
                if not ok and not count:
                    errors.append(msg)

            if tmpl_ids:
                ok, msg, count = current_client.link_templates(hostid, tmpl_ids)
                total_added += count
                messages.append(f"ผูก Template {count} ชุด")
                if not ok and not count:
                    errors.append(msg)

            if port_items:
                ok, count, msg = current_client.add_custom_monitors(hostid, "port", port_items, os_type=os_family)
                total_added += count
                messages.append(f"Port {count} พอร์ต")
                if not ok and not count:
                    errors.append(msg)

            detail_str = f" ({', '.join(messages)})" if messages else ""
            self._send_json({
                "success": total_added > 0 or not errors,
                "count": total_added,
                "message": f"เพิ่ม Monitoring สำเร็จ {total_added} รายการ{detail_str}",
                "errors": errors
            })
            return
        elif path == "/api/host/custom-monitor/add":
            if not current_client or not current_client.auth_token:
                self._send_json({"error": "Not connected to Zabbix"}, 401)
                return
            data = self._read_json()
            hostid = str(data.get("hostid") or "").strip()
            if not hostid.isdigit():
                self._send_json({"error": "hostid is required"}, 400)
                return
            sw_name = str(data.get("software_name") or "").strip()
            create_trig = bool(data.get("create_trigger", True))
            severity = int(data.get("severity") or 3)
            os_type = str(data.get("os_type") or "linux")

            total_items = 0
            messages = []
            has_error = False

            proc_list = data.get("processes") or []
            port_list = data.get("ports") or []
            svc_list = data.get("services") or []

            if isinstance(proc_list, str):
                proc_list = [x.strip() for x in proc_list.split(",") if x.strip()]
            if isinstance(port_list, str):
                port_list = [x.strip() for x in port_list.split(",") if x.strip()]
            if isinstance(svc_list, str):
                svc_list = [x.strip() for x in svc_list.split(",") if x.strip()]

            if not proc_list and not port_list and not svc_list:
                mtype = (data.get("monitor_type") or "process").lower()
                items = data.get("items") or []
                if isinstance(items, str):
                    items = [x.strip() for x in items.split(",") if x.strip()]
                if mtype in ("proc", "process"):
                    proc_list = items
                elif mtype in ("port", "tcp"):
                    port_list = items
                elif mtype in ("svc", "service"):
                    svc_list = items

            if not proc_list and not port_list and not svc_list:
                self._send_json({"error": "กรุณาระบุชื่อ Process, หมายเลข Port หรือชื่อ Service อย่างน้อย 1 รายการ"}, 400)
                return

            if proc_list:
                ok, count, msg = current_client.add_custom_monitors(
                    hostid, "process", proc_list, software_name=sw_name,
                    create_trigger=create_trig, severity=severity, os_type=os_type)
                total_items += count
                messages.append(msg)
                if not ok: has_error = True

            if port_list:
                ok, count, msg = current_client.add_custom_monitors(
                    hostid, "port", port_list, software_name=sw_name,
                    create_trigger=create_trig, severity=severity, os_type=os_type)
                total_items += count
                messages.append(msg)
                if not ok: has_error = True

            if svc_list:
                ok, count, msg = current_client.add_custom_monitors(
                    hostid, "service", svc_list, software_name=sw_name,
                    create_trigger=create_trig, severity=severity, os_type=os_type)
                total_items += count
                messages.append(msg)
                if not ok: has_error = True

            final_msg = " · ".join(messages)
            self._send_json({"success": not has_error or total_items > 0, "count": total_items, "message": final_msg})
            return

        elif path == "/api/host/inventory/probe":
            data = self._read_json()
            hostid = str(data.get("hostid") or "").strip()
            os_family = data.get("os_family") or "linux"
            if not hostid.isdigit() or os_family not in ms.OS_FAMILIES:
                self._send_json({"error": "hostid and a valid os_family are required"}, 400)
                return
            ok, count, msg = current_client.create_inventory_probes(hostid, os_family)
            self._send_json({"success": ok, "count": count, "message": msg})
            return

        elif path == "/api/settings":
            data = self._read_json()
            try:
                saved = ms.save_settings(data.get("settings") or {})
            except (TypeError, ValueError) as e:
                self._send_json({"error": f"Invalid settings: {e}"}, 400)
                return
            self._send_json({"success": True, "settings": saved})
            return

        elif path == "/api/host/valuemaps/setup-standard":
            data = self._read_json()
            hostid = data.get("hostid")
            if not hostid:
                self._send_json({"error": "hostid is required"}, 400)
                return
            ok, count, msg = current_client.ensure_standard_valuemaps(str(hostid))
            self._send_json({"success": ok, "count": count, "message": msg})
            return

        self.send_error(404, "Endpoint not found")

def get_local_ip():
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

def find_available_port(start_port=5000, max_attempts=30):
    import socket
    for p in range(start_port, start_port + max_attempts):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("", p))
                return p
        except OSError:
            continue
    return start_port

def start_server():
    global PORT, current_client
    current_client = load_saved_session()
    
    # Check if preferred port is occupied
    httpd = None
    try:
        server_address = ("", PORT)
        httpd = ThreadedHTTPServer(server_address, ZabbixRequestHandler)
    except OSError as err:
        old_port = PORT
        PORT = find_available_port(old_port + 1)
        print(f"[!] พอร์ต {old_port} ไม่ว่าง กำลังเปลี่ยนไปใช้พอร์ต {PORT} แทน...")
        server_address = ("", PORT)
        httpd = ThreadedHTTPServer(server_address, ZabbixRequestHandler)

    lan_ip = get_local_ip()
    print("=====================================================")
    print(f"[*] Zabbix Host Manager Web Server is running!")
    print(f"[*] ใช้งานบนเครื่องนี้ (Local):  http://127.0.0.1:{PORT}")
    print(f"[*] ให้เครื่องอื่นในวงแลนเข้า: http://{lan_ip}:{PORT}")
    print("=====================================================")
    print("[*] กด Ctrl + C เพื่อหยุดการทำงานของเซิร์ฟเวอร์")
    print("=====================================================")
    sys.stdout.flush()
    try:
        webbrowser.open(f"http://127.0.0.1:{PORT}")
    except Exception:
        pass
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server...")
        httpd.server_close()

if __name__ == "__main__":
    try:
        start_server()
    except Exception as e:
        import traceback
        err_msg = traceback.format_exc()
        print("\n" + "="*55)
        print("[ERROR] เกิดข้อผิดพลาดในการเริ่มโปรแกรม:")
        print(err_msg)
        print("="*55)
        try:
            exe_dir = os.path.dirname(sys.executable if getattr(sys, "frozen", False) else __file__)
            log_path = os.path.join(exe_dir, "error.log")
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(err_msg + "\n")
            print(f"[*] บันทึกรายละเอียดข้อผิดพลาดลงไฟล์: {log_path}")
        except Exception:
            pass
        input("\n[!] กด Enter เพื่อปิดหน้าต่างนี้...")
