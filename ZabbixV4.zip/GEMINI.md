# Zabbix & Elastic Host Manager - Workspace Guidelines & Project Rules

This document records the architectural standards, patterns, and troubleshooting rules established for the **Zabbix & Elastic Host Manager** application.

---

## 1. Architecture & Runtime Environment

- **Python Runtime:**
  - Embedded Python located at `.\python\python.exe` (no global pip installed; standard library only + pre-bundled packages like `requests`).
  - Web Server: Built on `http.server.ThreadingMixIn` running in [app.py](file:///c:/Project/ZabbixV2/app.py) on port 5000 (`http://127.0.0.1:5000`).
  - Always run/restart the server with `.\python\python.exe app.py` as a daemon background task when Python code changes.
- **Frontend Architecture:**
  - Pure Vanilla Web stack (HTML5, Vanilla CSS, Vanilla JavaScript). **Do not introduce Tailwind CSS or heavy JS frameworks.**
  - Files located in `web/`:
    - [web/index.html](file:///c:/Project/ZabbixV2/web/index.html): Main single-page application structure.
    - [web/app.js](file:///c:/Project/ZabbixV2/web/app.js): Zabbix core logic, dashboard, template mapping, trigger explorer, and settings.
    - [web/styles.css](file:///c:/Project/ZabbixV2/web/styles.css): Complete design system with dual dark/light themes.
    - [web/elastic.js](file:///c:/Project/ZabbixV2/web/elastic.js): Elastic logging module.
  - **Asset Versioning / Cache Busting:** Always bump the version query parameter in `<link>` and `<script>` tags in `index.html` (e.g. `?v=57`) after modifying CSS or JS.

---

## 2. Design & UI Aesthetics Standards

- **Theme Palette:**
  - **Dark Mode (Default):** Deep slate canvas (`--bg: #0b0f19`), elevated cards (`--panel: #121829`), crisp borders (`rgba(255,255,255,.08)`), neon cyan/blue/magenta accents.
  - **Light Mode:** Crisp slate canvas (`--bg: #edf2f7`), pure white cards (`--panel: #ffffff`), slate text (`--text: #0f172a`).
  - Toggled via `document.documentElement.dataset.theme = 'dark' | 'light'`.
- **Navigation & Layout:**
  - Sidebar layout:
    1. Zabbix section (`#dashboard`, `#mapping`, `#reports`)
    2. Elastic section (`#es-overview`, `#es-config`, `#es-indices`, `#es-settings`)
    3. System section: Setting menu (`#settings`) is strictly placed as the last navigation section.
    4. Bottom footer: Logout button (`#logoutLink`) is pinned at the very bottom left.
- **Readability Rules:**
  - Do not use low-contrast or dim gray text for critical data. Use high-contrast font colors with semantic status badges (`tag ok`, `tag warn`, `tag bad`, `tag neutral`, and severity badges `sev-5` to `sev-1`).

---

## 3. Zabbix API & Session Persistence

- **Session File ([`.session.json`](file:///c:/Project/ZabbixV2/.session.json)):**
  - Session metadata is stored as JSON: `{"url": "...", "token": "...", "is_token": bool, "version": "..."}`.
  - **Resilient Token Handling:** Do not clear `.session.json` on temporary network timeouts. Only clear it if Zabbix explicitly returns an unauthorized/expired error (`client.auth_expired == True`) or when the user explicitly clicks logout (`/api/disconnect`).
- **Browser LocalStorage:**
  - Login URL and username are remembered in `localStorage` (`mz_login_url`, `mz_login_user`, `mz_login_method`) to auto-fill inputs.
- **Form Submission Defense:**
  - Every `<form>` element (especially `#loginForm`) must specify `action="javascript:void(0);"` or handle `onsubmit="return false;"` to guarantee the browser never falls back to native `GET /?` navigation.

---

## 4. JavaScript Coding Constraints & Pitfalls

- **Regex Literals:**
  - In JavaScript regex literals (`/.../`), never use double-escaped backslashes (`\\[` or `\\-`). Use single escapes like `/\[([^\]]+)\]/` or `/[\d._-]+$/`.
  - Double backslashes in literals break parser evaluation and cause fatal `SyntaxError: Invalid regular expression`, causing the entire script not to execute and breaking all event listeners.
- **Headless Edge Verification:**
  - To verify JS syntax and console errors on Windows without Node.js, run headless Microsoft Edge with `& "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --headless=new --dump-dom "http://127.0.0.1:5000"` or inspect console outputs.

---

## 5. Key Feature Workflows

- **Template Mapping:**
  - User searches for software/services -> maps to Zabbix Templates -> links to hosts via `/api/host/templates/link`.
- **Trigger & Monitoring Explorer:**
  - Located at the bottom of Template Mapping.
  - Correlates monitored items with active Zabbix triggers, displaying metric item keys, trigger expressions, problem status, and severity levels.

---

## 6. Recent Changelog & UI Enhancements (บันทึกการแก้ไขล่าสุด)

- **Interactive Section Help Buttons (`?`):**
  - Added clean circular `?` help buttons (`.section-help-btn`) placed neatly at the end of section titles across all pages (Dashboard, Template Mapping, Reports, Elastic Overview/Config/Indices, System Settings).
  - Help content opens/closes on click via smooth accordion dropdowns (`.section-help-box`) with close (`✕`) buttons without affecting the main sidebar menu on the left.
- **Compact & Clean Trigger Explorer Redesign:**
  - Redesigned software correlation cards from bulky 3-column blocks into a streamlined layout with a top-ribbon for Template details (Step 1) and a balanced 2-column split (Items vs Triggers).
  - Cards support instant folding/unfolding (`.is-collapsed`) on header click.
- **Full-Width Right Expansion Fix:**
  - Fixed an unclosed `</div>` in `.trig-toolbar` in [app.js](file:///c:/Project/ZabbixV2/web/app.js) that previously forced `#trigResultsContainer` inside a flex container and caused the cards to shrink-wrap horizontally.
  - Updated [styles.css](file:///c:/Project/ZabbixV2/web/styles.css) with `width: 100%` and `grid-template-columns: minmax(260px, 30%) 1fr` so the Triggers & alert conditions column dynamically stretches to fill the entire right edge of the viewport.
  - Increased Expression snippet max-width up to `88%` with smooth hover preview.
- **Asset Cache-Busting Version:**
  - Incremented version parameter in [index.html](file:///c:/Project/ZabbixV2/web/index.html) to `?v=80`.
- **Host Inventory Scanner (`Software`, `Service`, `Process`, `Port`) & Clean UI (`v80 / ZabbixV4`):**
  - Created Zabbix Templates `Custom - Host Inventory Scanner (Windows)` and `Custom - Host Inventory Scanner (Linux)` using built-in Zabbix Agent keys (`registry.get`, `wmi.getall`, `proc.get`, `system.sw.packages.get[.*]`, `vfs.dir.get`, `vfs.file.contents[/proc/net/tcp]`).
  - Upgraded `Installed Software, Service, Process & Port Inventory` (`#software`) with 5 category filter tabs (`ทั้งหมด`, `📦 Software`, `⚙ Service`, `⚡ Process`, `🔌 Port`), `▶ Execute` button, non-overlapping flexbox summary banner (`#inventoryBanner`), and an 8-column table with opaque sticky headers (`z-index: 4`).
- **Real-Time `Server Information` Sync & 2-Line Expandable/Scrollable Fields (`v80 / ZabbixV4`):**
  - Every field in `Server Information` (`#serverInfo`) exceeding 2 lines automatically clamps at 2 lines and shows a `▾ ดูทั้งหมด` / `▴ ย่อเก็บ` toggle button plus mouse-wheel scroll support (`.srv-info-cell`, `enhanceServerInfoCells()`).
  - Added real-time 3-second polling (`pollSelectedHostRealtime()`) and `Cache-Control: no-store` headers so any change on Zabbix (Hostname, IP, Group, Templates, Proxy, Status, and all Host Macros `Macro = Value`) updates live in `Server Information`.
- **Dynamic Brand Logos (`Zabbix` & `Elastic`):**
  - Added [web/logo-zabbix.png](file:///c:/Project/ZabbixV2/web/logo-zabbix.png) and [web/logo-elastic.png](file:///c:/Project/ZabbixV2/web/logo-elastic.png) and updated `#brandIcon` / [`updateBrandTitle()`](file:///c:/Project/ZabbixV2/web/app.js#L1488-L1513) so the top header logo switches dynamically between the Zabbix red `Z` logo and the Elastic cluster logo based on the active menu section.
- **Login Screen & Zabbix 7.0+ Compatibility:**
  - Redesigned `#loginOverlay` to use a clean deep navy background (`#071126`) with a prominent royal-sapphire card (`.login-card`).
  - Upgraded `ZabbixClient` in [zabbix_api.py](file:///c:/Project/ZabbixV2/zabbix_api.py) to support Zabbix 7.0+ (`Authorization: Bearer <token>`, `selectHostGroups`, `proxy.get` + `proxygroup.get`).
- **Dashboard & Server Information Updates:**
  - Filter `#app` searches both `AppID : AppName` and Zabbix `Group`.
  - Added dedicated section `All Server From : <searched App / Group>` (`#allHostsBar`, `#allServersTitleVal`, `#allServersSummaryBar`, `#allServersList`) directly underneath the `Application & Server` section when selecting `"ทั้งหมด"` in `Server Name` to display:
    - Top summary bar showing total servers, `Enable / Active (เชื่อมต่อ Zabbix อยู่)`, and `Disable / ไม่เชื่อมต่อ Zabbix` pulled from Zabbix.
    - Full-width row list showing `#`, `Server Name`, `IP Address`, and unified `Status (สถานะเชื่อมต่อ Zabbix)`.
  - Removed `Technical Name` and added `Zabbix Proxy` right after `OS Template` in `Server Information`.
  - Added Status filter (`#osStatusFilter`) in `OS Monitoring Details` (`ทุกสถานะ`, `Monitored`, `Not Monitored`, `Not Required` with live counts).
- **Standalone HTML & Portable Packaging (`ZabbixV3.zip`):**
  - Added [web/standalone_engine.js](file:///c:/Project/ZabbixV2/web/standalone_engine.js) and [build_standalone.py](file:///c:/Project/ZabbixV2/build_standalone.py) to generate [Zabbix_Monitoring_Standalone.html](file:///c:/Project/ZabbixV2/Zabbix_Monitoring_Standalone.html).
- **Light Theme Default & High-Contrast Readability Fixes:**
  - Changed default startup theme to **Light Theme (`data-theme="light"`)** in [web/index.html](file:///c:/Project/ZabbixV2/web/index.html) and [web/app.js](file:///c:/Project/ZabbixV2/web/app.js).
  - Fixed `.counts b` (`color: #0f172a` in Light Mode instead of `#fff`), `.ring` unfilled donut track (`#e2e8f0` in Light Mode), pagination buttons (`.pg-num`), `.detail`, `.es-sub`, and resource card values (`var(--green)`, `var(--purple)`, `var(--blue)`, `var(--yellow)`) in [web/styles.css](file:///c:/Project/ZabbixV2/web/styles.css) and [web/app.js](file:///c:/Project/ZabbixV2/web/app.js).
