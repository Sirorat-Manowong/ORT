@echo off
setlocal
chcp 65001 >nul 2>&1
title Zabbix Host Manager

echo ========================================================
echo        Zabbix Host Manager (Full Program)
echo ========================================================
echo.
echo [*] Working Directory: %~dp0
cd /d "%~dp0"

set "PYTHON_CMD="

if exist "%~dp0python\python.exe" (
    echo [*] Using bundled official Python runtime...
    set "PYTHON_CMD=%~dp0python\python.exe"
    goto RUN
)

where python >nul 2>&1
if %errorlevel% equ 0 (
    echo [*] Using system Python...
    set "PYTHON_CMD=python"
    goto RUN
)

where py >nul 2>&1
if %errorlevel% equ 0 (
    echo [*] Using py launcher...
    set "PYTHON_CMD=py"
    goto RUN
)

echo.
echo [ERROR] Python not found!
echo Please ensure python folder exists in: %~dp0python\
echo Or install Python on this machine.
echo.
pause
exit /b 1

:RUN
"%PYTHON_CMD%" "%~dp0app.py"

if %errorlevel% neq 0 (
    echo.
    echo ========================================================
    echo [ERROR] Program exited with code: %errorlevel%
    echo If this is an enterprise computer, make sure the folder
    echo is NOT placed inside C:\Temp.
    echo Extract to Desktop or Documents instead.
    echo ========================================================
    echo.
    pause
)
