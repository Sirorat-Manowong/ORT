"""
Elastic / Filebeat management.

  - Local stores: Elastic connection settings, per-host log inputs (path + json/plaintext)
  - filebeat.yml + install script generation (Linux bash / Windows PowerShell)
  - Elasticsearch REST: list / create / delete index, search what a host is shipping
  - Kibana REST: list / create Space, create data view inside a Space
  - Host status: Filebeat installed? version? running? config paths? index / space / logs present?

Server inventory always comes from Zabbix; this module never stores server lists itself.
Secrets (password / API key) are kept only in elastic_settings.json on this machine and are
never returned to the browser or written into generated filebeat.yml (keystore references are used).
"""
import json
import os
import re
import stat
import sys
import threading
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import requests

if getattr(sys, "frozen", False):
    _DATA_DIR = os.path.dirname(sys.executable)
else:
    _DATA_DIR = os.path.dirname(os.path.abspath(__file__))

SETTINGS_FILE = os.path.join(_DATA_DIR, "elastic_settings.json")
LOGCONFIG_FILE = os.path.join(_DATA_DIR, "log_config.json")
_lock = threading.Lock()

LOG_TYPES = ("json", "plaintext")
ENV_CODES = {"production": "prod", "prod": "prod", "non production": "nonprod", "nonprod": "nonprod",
             "non-production": "nonprod", "uat": "nonprod", "development": "nonprod", "dev": "nonprod"}

DEFAULT_SETTINGS = {
    "es_url": "",
    "kibana_url": "",
    "auth_type": "apikey",          # none | basic | apikey
    "username": "",
    "password": "",                 # secret
    "api_key": "",                  # secret (base64 "id:key" as shown by Kibana)
    "verify_tls": True,
    "index_pattern": "applog-{appid}-{appname}-{env}-{type}",
    "space_pattern": "app-{appid}-{appname}",
    "filebeat_version": "8.15.0",
    "linux_config_path": "/etc/filebeat/filebeat.yml",
    "windows_config_path": "C:\\Program Files\\Filebeat\\filebeat.yml",
    "default_env": "prod",
    "number_of_shards": 1,
    "number_of_replicas": 1,
    # Remote check on the real machine (read-only)
    "ssh_user": "",
    "ssh_port": 22,
    "ssh_key_path": "",
    "ssh_password": "",              # secret (optional when a key is used)
    "ssh_sudo": True,                # use `sudo -n cat` when the user cannot read the config
    "win_user": "",
    "win_password": "",              # secret
}
SECRET_KEYS = ("password", "api_key", "ssh_password", "win_password")


# ---------------------------------------------------------------------------
# Stores
# ---------------------------------------------------------------------------
def _read(path: str, default: Any) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def _write(path: str, data: Any, private: bool = False) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    if private:
        try:
            os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)  # 0600: credentials inside
        except OSError:
            pass
    os.replace(tmp, path)


def load_settings() -> Dict[str, Any]:
    data = _read(SETTINGS_FILE, {})
    merged = dict(DEFAULT_SETTINGS)
    if isinstance(data, dict):
        merged.update({k: v for k, v in data.items() if k in DEFAULT_SETTINGS})
    return merged


def public_settings() -> Dict[str, Any]:
    s = load_settings()
    out = {k: v for k, v in s.items() if k not in SECRET_KEYS}
    out["has_password"] = bool(s.get("password"))
    out["has_api_key"] = bool(s.get("api_key"))
    out["has_ssh_password"] = bool(s.get("ssh_password"))
    out["has_win_password"] = bool(s.get("win_password"))
    out["configured"] = bool(s.get("es_url"))
    return out


def _clean_url(u: str) -> str:
    u = (u or "").strip().rstrip("/")
    if u and not re.match(r"^https?://", u, re.I):
        raise ValueError("URL ต้องขึ้นต้นด้วย http:// หรือ https://")
    return u


def save_settings(update: Dict[str, Any]) -> Dict[str, Any]:
    cur = load_settings()
    for k, v in (update or {}).items():
        if k not in DEFAULT_SETTINGS:
            continue
        if k in SECRET_KEYS:
            if v in (None, ""):        # empty = keep the saved secret
                continue
            if v == "__clear__":
                v = ""
            cur[k] = str(v)[:2000]
        elif k in ("es_url", "kibana_url"):
            cur[k] = _clean_url(v)
        elif k == "auth_type":
            cur[k] = v if v in ("none", "basic", "apikey") else "apikey"
        elif k in ("verify_tls", "ssh_sudo"):
            cur[k] = bool(v)
        elif k == "ssh_port":
            cur[k] = max(1, min(65535, int(v)))
        elif k in ("ssh_user", "win_user"):
            v = str(v).strip()
            if v and not re.fullmatch(r"[A-Za-z0-9._\\@-]{1,64}", v):
                raise ValueError(f"{k} มีอักขระไม่ถูกต้อง")
            cur[k] = v
        elif k in ("number_of_shards", "number_of_replicas"):
            cur[k] = max(0 if k == "number_of_replicas" else 1, min(50, int(v)))
        elif k in ("index_pattern", "space_pattern"):
            v = str(v).strip()
            if "{appid}" not in v:
                raise ValueError(f"{k} ต้องมี {{appid}}")
            if k == "index_pattern" and "{type}" not in v:
                raise ValueError("index_pattern ต้องมี {type} เพื่อแยก json / plaintext")
            cur[k] = v[:120]
        elif k == "filebeat_version":
            if not re.fullmatch(r"\d+\.\d+\.\d+", str(v).strip()):
                raise ValueError("filebeat_version ต้องอยู่ในรูป 8.15.0")
            cur[k] = str(v).strip()
        elif k == "default_env":
            cur[k] = env_code(v)
        else:
            cur[k] = str(v).strip()[:300]
    with _lock:
        _write(SETTINGS_FILE, cur, private=True)
    return public_settings()


def load_host_config(hostid: str) -> Dict[str, Any]:
    data = _read(LOGCONFIG_FILE, {})
    return (data.get("hosts", {}) if isinstance(data, dict) else {}).get(str(hostid)) or {}


def all_host_configs() -> Dict[str, Any]:
    data = _read(LOGCONFIG_FILE, {})
    return data.get("hosts", {}) if isinstance(data, dict) else {}


def save_host_config(hostid: str, cfg: Dict[str, Any]) -> Dict[str, Any]:
    inputs = []
    seen = set()
    for raw in (cfg.get("inputs") or [])[:100]:
        path = str(raw.get("path") or "").strip()
        if not path:
            continue
        if len(path) > 400 or any(ch in path for ch in "\n\r\"'`$"):
            raise ValueError(f"Path ไม่ถูกต้อง: {path[:60]}")
        ltype = raw.get("type") if raw.get("type") in LOG_TYPES else "plaintext"
        key = (path.lower(), ltype)
        if key in seen:
            continue
        seen.add(key)
        name = re.sub(r"[^A-Za-z0-9_.-]+", "-", str(raw.get("name") or "").strip())[:60]
        inputs.append({"id": raw.get("id") or uuid.uuid4().hex[:10], "path": path, "type": ltype,
                       "name": name, "multiline": bool(raw.get("multiline"))})
    record = {"inputs": inputs, "env": env_code(cfg.get("env") or load_settings()["default_env"]),
              "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
    with _lock:
        data = _read(LOGCONFIG_FILE, {})
        if not isinstance(data, dict):
            data = {}
        data.setdefault("hosts", {})[str(hostid)] = record
        _write(LOGCONFIG_FILE, data)
    return record


# ---------------------------------------------------------------------------
# Naming
# ---------------------------------------------------------------------------
def env_code(env: Any) -> str:
    return ENV_CODES.get(str(env or "").strip().lower(), "prod")


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-") or "app"


def index_name(appid: str, appname: str, env: str, ltype: str, settings: Optional[Dict[str, Any]] = None) -> str:
    s = settings or load_settings()
    name = s["index_pattern"].format(appid=_slug(appid), appname=_slug(appname), env=env_code(env), type=ltype)
    return re.sub(r"-{2,}", "-", name.lower())


def space_id(appid: str, appname: str, settings: Optional[Dict[str, Any]] = None) -> str:
    s = settings or load_settings()
    sid = s["space_pattern"].replace("{env}", "").format(appid=_slug(appid), appname=_slug(appname))
    return re.sub(r"-{2,}", "-", re.sub(r"[^a-z0-9_-]+", "-", sid.lower())).strip("-")


INDEX_NAME_RX = re.compile(r"^[a-z0-9][a-z0-9._-]{0,254}$")


def validate_index_name(name: str) -> str:
    name = (name or "").strip()
    if not INDEX_NAME_RX.fullmatch(name) or name in (".", "..") or "*" in name or "," in name:
        raise ValueError("ชื่อ index ต้องเป็นตัวพิมพ์เล็ก a-z 0-9 . _ - และห้ามขึ้นต้นด้วย . _ -")
    return name


# ---------------------------------------------------------------------------
# filebeat.yml + install scripts
# ---------------------------------------------------------------------------
def _yq(s: str) -> str:
    """YAML double-quoted scalar."""
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


def build_filebeat_yml(host: Dict[str, Any], app: Dict[str, str], cfg: Dict[str, Any], os_family: str,
                       settings: Optional[Dict[str, Any]] = None) -> str:
    s = settings or load_settings()
    env = cfg.get("env") or s["default_env"]
    inputs = cfg.get("inputs") or []
    types = sorted({i["type"] for i in inputs}) or ["plaintext"]
    lines = [
        f"# filebeat.yml generated by Monitoring Zabbix on {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        f"# Host: {host.get('name')} ({host.get('host')}) · App {app.get('appid')} : {app.get('appname')} · env {env}",
        "# Credentials are read from the Filebeat keystore (see install script), never stored here.",
        "",
        "filebeat.inputs:",
    ]
    if not inputs:
        lines.append("  []  # ยังไม่มี log path — เพิ่มในหน้า Filebeat Config")
    for inp in inputs:
        iid = re.sub(r"[^A-Za-z0-9_-]", "-", f"{_slug(app.get('appid', ''))}-{inp.get('name') or inp['type']}-{inp['id']}")
        lines += [
            "  - type: filestream",
            f"    id: {iid}",
            "    enabled: true",
            "    paths:",
            f"      - {_yq(inp['path'])}",
            "    fields:",
            f"      log_type: {inp['type']}",
            f"      app_id: {_yq(app.get('appid', ''))}",
            f"      app_name: {_yq(app.get('appname', ''))}",
            f"      env: {env}",
        ]
        if inp.get("name"):
            lines.append(f"      log_name: {_yq(inp['name'])}")
        if inp["type"] == "json":
            lines += [
                "    parsers:",
                "      - ndjson:",
                '          target: ""',
                "          overwrite_keys: true",
                "          add_error_key: true",
                "          expand_keys: true",
            ]
        elif inp.get("multiline"):
            lines += [
                "    parsers:",
                "      - multiline:",
                "          type: pattern",
                "          pattern: '^\\d{4}-\\d{2}-\\d{2}|^\\[\\d{4}-\\d{2}-\\d{2}'",
                "          negate: true",
                "          match: after",
            ]
    hosts = s.get("es_url") or "https://elasticsearch.example:9200"
    first_type_index = index_name(app.get("appid", ""), app.get("appname", ""), env, types[0], s)
    lines += [
        "",
        "processors:",
        "  - add_host_metadata:",
        "      when.not.contains.tags: forwarded",
        "",
        "# Custom index names need an explicit template and ILM off",
        "setup.ilm.enabled: false",
        f"setup.template.name: {_yq(index_name(app.get('appid', ''), app.get('appname', ''), env, 'tpl', s))}",
        f"setup.template.pattern: {_yq(index_name(app.get('appid', ''), app.get('appname', ''), env, '*', s))}",
        "setup.template.settings:",
        f"  index.number_of_shards: {s.get('number_of_shards', 1)}",
        f"  index.number_of_replicas: {s.get('number_of_replicas', 1)}",
        "",
        "output.elasticsearch:",
        f"  hosts: [{_yq(hosts)}]",
    ]
    if s.get("auth_type") == "apikey":
        lines.append('  api_key: "${ES_API_KEY}"')
    elif s.get("auth_type") == "basic":
        lines += [f"  username: {_yq(s.get('username') or 'filebeat_writer')}", '  password: "${ES_PASSWORD}"']
    lines.append(f"  index: {_yq(first_type_index)}")
    if len(types) > 1:
        lines.append("  indices:")
        for t in types:
            lines += [f"    - index: {_yq(index_name(app.get('appid', ''), app.get('appname', ''), env, t, s))}",
                      "      when.equals:",
                      f"        fields.log_type: {t}"]
    if not s.get("verify_tls", True):
        lines += ["  ssl.verification_mode: none  # ตั้งค่า certificate_authorities แทนเมื่อใช้งานจริง"]
    lines += ["", "logging.level: info", "logging.to_files: true", ""]
    return "\n".join(lines)


def build_install_script(os_family: str, yml: str, host: Dict[str, Any], settings: Optional[Dict[str, Any]] = None) -> Tuple[str, str]:
    """Return (filename suffix, script text)."""
    s = settings or load_settings()
    ver = s["filebeat_version"]
    secret_name = "ES_API_KEY" if s.get("auth_type") == "apikey" else ("ES_PASSWORD" if s.get("auth_type") == "basic" else "")
    if os_family == "windows":
        cfg_path = s["windows_config_path"]
        install_dir = os.path.dirname(cfg_path.replace("/", "\\")) if "\\" in cfg_path else "C:\\Program Files\\Filebeat"
        # Single-quoted here-string (@' ... '@) is literal: no escaping needed, only '@ at line start would end it
        yml_ps = "\n".join((" " + ln) if ln.startswith("'@") else ln for ln in yml.splitlines())
        keystore = (f"""
$secret = Read-Host -AsSecureString "Enter {secret_name} for Elasticsearch"
$plain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret))
& "$InstallDir\\filebeat.exe" keystore create --force -c "$CfgPath" --path.data "C:\\ProgramData\\filebeat" | Out-Null
$plain | & "$InstallDir\\filebeat.exe" keystore add {secret_name} --stdin --force -c "$CfgPath" --path.data "C:\\ProgramData\\filebeat"
""" if secret_name else "")
        script = f"""# Filebeat {ver} install / configure for {host.get('name')} — generated by Monitoring Zabbix
# Run in an elevated PowerShell:  powershell -ExecutionPolicy Bypass -File .\\filebeat_install.ps1
$ErrorActionPreference = "Stop"
$Version    = "{ver}"
$InstallDir = "{install_dir}"
$CfgPath    = "{cfg_path}"
$Zip        = "$env:TEMP\\filebeat-$Version-windows-x86_64.zip"

if (-not (Test-Path "$InstallDir\\filebeat.exe")) {{
    Write-Host "[*] Downloading Filebeat $Version ..."
    Invoke-WebRequest -UseBasicParsing "https://artifacts.elastic.co/downloads/beats/filebeat/filebeat-$Version-windows-x86_64.zip" -OutFile $Zip
    Expand-Archive -Path $Zip -DestinationPath "$env:TEMP\\filebeat-extract" -Force
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    Copy-Item "$env:TEMP\\filebeat-extract\\filebeat-$Version-windows-x86_64\\*" $InstallDir -Recurse -Force
    & "$InstallDir\\install-service-filebeat.ps1"
}} else {{
    Write-Host "[*] Filebeat already installed: $(& "$InstallDir\\filebeat.exe" version)"
}}

if (Test-Path $CfgPath) {{ Copy-Item $CfgPath "$CfgPath.bak-$(Get-Date -Format yyyyMMddHHmmss)" }}
$Yml = @'
{yml_ps}
'@
Set-Content -Path $CfgPath -Value $Yml -Encoding UTF8
{keystore}
& "$InstallDir\\filebeat.exe" test config -c "$CfgPath" --path.data "C:\\ProgramData\\filebeat"
& "$InstallDir\\filebeat.exe" test output -c "$CfgPath" --path.data "C:\\ProgramData\\filebeat"
Restart-Service filebeat -ErrorAction SilentlyContinue
if (-not $?) {{ Start-Service filebeat }}
Get-Service filebeat
"""
        return "ps1", script
    if os_family == "aix":
        return "txt", (f"Filebeat is not supported on AIX (no official Elastic build).\n"
                       f"Host: {host.get('name')}\n"
                       "Alternative: forward these files with rsyslog (imfile) to Logstash / an rsyslog relay,\n"
                       "then into Elasticsearch using the index names shown in Monitoring Zabbix.\n\n"
                       "Reference config generated for documentation purposes:\n\n" + yml)
    cfg_path = s["linux_config_path"]
    keystore = (f"""
read -r -s -p "Enter {secret_name} for Elasticsearch: " SECRET; echo
filebeat keystore create --force >/dev/null
printf '%s' "$SECRET" | filebeat keystore add {secret_name} --stdin --force
unset SECRET
""" if secret_name else "")
    script = f"""#!/usr/bin/env bash
# Filebeat {ver} install / configure for {host.get('name')} — generated by Monitoring Zabbix
# Run as root:  sudo bash filebeat_install.sh
set -euo pipefail
VERSION="{ver}"
CFG="{cfg_path}"
ARCH=$(uname -m); [ "$ARCH" = "aarch64" ] && PKG_ARCH=arm64 || PKG_ARCH=amd64; [ "$ARCH" = "aarch64" ] && RPM_ARCH=aarch64 || RPM_ARCH=x86_64

if ! command -v filebeat >/dev/null 2>&1; then
  echo "[*] Installing Filebeat $VERSION ..."
  if command -v rpm >/dev/null 2>&1 && ! command -v dpkg >/dev/null 2>&1; then
    curl -fsSLo /tmp/filebeat.rpm "https://artifacts.elastic.co/downloads/beats/filebeat/filebeat-$VERSION-$RPM_ARCH.rpm"
    rpm -Uvh /tmp/filebeat.rpm
  else
    curl -fsSLo /tmp/filebeat.deb "https://artifacts.elastic.co/downloads/beats/filebeat/filebeat-$VERSION-$PKG_ARCH.deb"
    dpkg -i /tmp/filebeat.deb
  fi
else
  echo "[*] Filebeat already installed: $(filebeat version)"
fi

[ -f "$CFG" ] && cp -p "$CFG" "$CFG.bak-$(date +%Y%m%d%H%M%S)"
cat > "$CFG" <<'FILEBEAT_YML'
{yml}
FILEBEAT_YML
chown root:root "$CFG"; chmod 0640 "$CFG"
# allow the Zabbix agent to read the config for Monitoring Zabbix checks (optional)
if getent group zabbix >/dev/null; then chgrp zabbix "$CFG"; fi
{keystore}
filebeat test config -c "$CFG"
filebeat test output -c "$CFG" || echo "[!] output test failed — check URL / credentials / firewall"
systemctl enable filebeat
systemctl restart filebeat
systemctl --no-pager status filebeat | head -n 5
"""
    return "sh", script


# ---------------------------------------------------------------------------
# Parse a filebeat.yml read from the host (no PyYAML in the bundled runtime)
# ---------------------------------------------------------------------------
def parse_filebeat_yml(text: str) -> Dict[str, Any]:
    paths, indices, hosts, types = [], [], [], []
    in_paths = False
    for raw in (text or "").splitlines():
        line = raw.split("#", 1)[0].rstrip() if not raw.strip().startswith("- \"") else raw.rstrip()
        stripped = line.strip()
        if not stripped:
            continue
        if re.match(r"^paths\s*:", stripped):
            in_paths = True
            inline = re.findall(r"[\"']([^\"']+)[\"']", stripped)
            paths += inline
            continue
        if in_paths:
            m = re.match(r"^-\s*[\"']?(.+?)[\"']?\s*$", stripped)
            if m:
                paths.append(m.group(1))
                continue
            in_paths = False
        m = re.match(r"^(?:-\s*)?index\s*:\s*[\"']?([^\"'\s]+)", stripped)
        if m:
            indices.append(m.group(1))
        m = re.match(r"^hosts\s*:\s*\[(.+)\]", stripped)
        if m:
            hosts += [h.strip().strip("\"'") for h in m.group(1).split(",")]
        m = re.match(r"^log_type\s*:\s*(\w+)", stripped)
        if m:
            types.append(m.group(1))
        if re.match(r"^-\s*ndjson\s*:", stripped):
            types.append("json")
    return {"paths": list(dict.fromkeys(paths)), "indices": list(dict.fromkeys(indices)),
            "hosts": list(dict.fromkeys(hosts)), "types": sorted(set(types))}


# ---------------------------------------------------------------------------
# Elasticsearch / Kibana REST
# ---------------------------------------------------------------------------
class ElasticError(RuntimeError):
    pass


class ElasticClient:
    def __init__(self, settings: Optional[Dict[str, Any]] = None, timeout: int = 15):
        self.s = settings or load_settings()
        self.timeout = timeout
        self.session = requests.Session()
        if self.s.get("auth_type") == "apikey" and self.s.get("api_key"):
            self.session.headers["Authorization"] = f"ApiKey {self.s['api_key']}"
        elif self.s.get("auth_type") == "basic" and self.s.get("username"):
            self.session.auth = (self.s["username"], self.s.get("password", ""))
        self.session.verify = bool(self.s.get("verify_tls", True))
        if not self.session.verify:
            try:
                import urllib3
                urllib3.disable_warnings()
            except Exception:  # noqa: BLE001
                pass

    def _req(self, base_key: str, method: str, path: str, body: Any = None, params: Any = None,
             headers: Optional[Dict[str, str]] = None, ok404: bool = False) -> Any:
        base = self.s.get(base_key)
        if not base:
            raise ElasticError("ยังไม่ได้ตั้งค่า " + ("Elasticsearch URL" if base_key == "es_url" else "Kibana URL"))
        try:
            r = self.session.request(method, base + path, json=body, params=params, headers=headers, timeout=self.timeout)
        except requests.exceptions.SSLError as e:
            raise ElasticError(f"TLS error (ลองปิด Verify TLS หรือใส่ CA): {e}") from e
        except requests.exceptions.RequestException as e:
            raise ElasticError(f"เชื่อมต่อไม่ได้: {e}") from e
        if r.status_code == 404 and ok404:
            return None
        if r.status_code >= 400:
            try:
                err = r.json()
                reason = (err.get("error") or {}).get("reason") if isinstance(err.get("error"), dict) else err.get("message") or err.get("error")
            except ValueError:
                reason = r.text[:200]
            raise ElasticError(f"HTTP {r.status_code}: {reason}")
        if not r.content:
            return {}
        try:
            return r.json()
        except ValueError:
            return r.text

    def es(self, method: str, path: str, body: Any = None, params: Any = None, ok404: bool = False) -> Any:
        return self._req("es_url", method, path, body, params, ok404=ok404)

    def kb(self, method: str, path: str, body: Any = None, ok404: bool = False) -> Any:
        return self._req("kibana_url", method, path, body, headers={"kbn-xsrf": "true"}, ok404=ok404)

    # ---- cluster / indices ----
    def info(self) -> Dict[str, Any]:
        out = {"elasticsearch": None, "kibana": None, "errors": []}
        try:
            r = self.es("GET", "/")
            out["elasticsearch"] = {"cluster": r.get("cluster_name"), "version": (r.get("version") or {}).get("number")}
        except ElasticError as e:
            out["errors"].append(f"Elasticsearch: {e}")
        if self.s.get("kibana_url"):
            try:
                r = self.kb("GET", "/api/status")
                out["kibana"] = {"version": ((r or {}).get("version") or {}).get("number"),
                                 "status": (((r or {}).get("status") or {}).get("overall") or {}).get("level")
                                 or (((r or {}).get("status") or {}).get("overall") or {}).get("state")}
            except ElasticError as e:
                out["errors"].append(f"Kibana: {e}")
        return out

    def list_indices(self, pattern: str = "*") -> List[Dict[str, Any]]:
        if not re.fullmatch(r"[a-z0-9*._,-]+", pattern or "*"):
            raise ValueError("pattern ไม่ถูกต้อง")
        rows = self.es("GET", f"/_cat/indices/{pattern}", params={
            "format": "json", "h": "index,health,status,docs.count,store.size,creation.date.string", "s": "index"}, ok404=True) or []
        return [r for r in rows if not str(r.get("index", "")).startswith(".")]

    def index_exists(self, name: str) -> bool:
        return self.es("HEAD", f"/{validate_index_name(name)}", ok404=True) is not None

    def create_index(self, name: str) -> Dict[str, Any]:
        name = validate_index_name(name)
        if self.index_exists(name):
            return {"acknowledged": True, "existed": True}
        return self.es("PUT", f"/{name}", body={"settings": {
            "number_of_shards": int(self.s.get("number_of_shards", 1)),
            "number_of_replicas": int(self.s.get("number_of_replicas", 1))}})

    def delete_index(self, name: str) -> Dict[str, Any]:
        name = validate_index_name(name)  # rejects wildcards, commas, system indices
        return self.es("DELETE", f"/{name}")

    def host_shipping(self, index_patterns: List[str], names: List[str], ips: List[str]) -> Dict[str, Any]:
        """What Elasticsearch has received from this host: last event, Filebeat version, files, indices."""
        pats = ",".join(p for p in index_patterns if re.fullmatch(r"[a-z0-9*._-]+", p)) or "*"
        should = []
        for n in {x for x in names if x}:
            for f in ("host.name", "host.hostname", "agent.hostname", "agent.name"):
                should.append({"term": {f: n.lower()}})
                should.append({"term": {f: n}})
        for ip in {x for x in ips if x}:
            should.append({"term": {"host.ip": ip}})
        body = {
            "size": 0, "track_total_hits": True,
            "query": {"bool": {"should": should, "minimum_should_match": 1}},
            "aggs": {
                "last": {"max": {"field": "@timestamp"}},
                "versions": {"terms": {"field": "agent.version", "size": 5}},
                "files": {"terms": {"field": "log.file.path", "size": 50}},
                "indices": {"terms": {"field": "_index", "size": 20}},
                "types": {"terms": {"field": "fields.log_type", "size": 5}},
            },
        }
        r = self.es("POST", f"/{pats}/_search", body=body, params={"ignore_unavailable": "true", "allow_no_indices": "true"})
        aggs = (r or {}).get("aggregations") or {}
        total = ((r or {}).get("hits") or {}).get("total")
        last = (aggs.get("last") or {}).get("value_as_string") or (aggs.get("last") or {}).get("value")
        buckets = lambda k: [b["key"] for b in (aggs.get(k) or {}).get("buckets", [])]  # noqa: E731
        return {"docs": total.get("value") if isinstance(total, dict) else (total or 0), "last_event": last,
                "versions": buckets("versions"), "files": buckets("files"), "indices": buckets("indices"),
                "types": buckets("types")}

    # ---- Kibana spaces / data views ----
    def list_spaces(self) -> List[Dict[str, Any]]:
        return self.kb("GET", "/api/spaces/space") or []

    def get_space(self, sid: str) -> Optional[Dict[str, Any]]:
        return self.kb("GET", f"/api/spaces/space/{sid}", ok404=True)

    def create_space(self, sid: str, name: str, description: str = "") -> Dict[str, Any]:
        if not re.fullmatch(r"[a-z0-9_-]{1,100}", sid):
            raise ValueError("Space id ต้องเป็น a-z 0-9 _ -")
        existing = self.get_space(sid)
        if existing:
            return {"existed": True, **existing}
        return self.kb("POST", "/api/spaces/space", body={"id": sid, "name": name[:100], "description": description[:300],
                                                            "disabledFeatures": []})

    def list_data_views(self, sid: str) -> List[Dict[str, Any]]:
        r = self.kb("GET", f"/s/{sid}/api/data_views", ok404=True) or {}
        return r.get("data_view") or r.get("data_views") or []

    def create_data_view(self, sid: str, title: str, name: str) -> Dict[str, Any]:
        for dv in self.list_data_views(sid):
            if dv.get("title") == title:
                return {"existed": True, **dv}
        return self.kb("POST", f"/s/{sid}/api/data_views/data_view", body={
            "data_view": {"title": title, "name": name, "timeFieldName": "@timestamp"}})


# ---------------------------------------------------------------------------
# Host status (Filebeat on the host + what exists in Elastic)
# ---------------------------------------------------------------------------
OK, MISSING, NA, UNKNOWN = "OK", "Missing", "Not Required", "Unknown"


def _norm_path(p: str) -> str:
    return (p or "").strip().strip("\"'").replace("\\\\", "\\").rstrip("/\\").lower()


def _glob_match(pattern: str, path: str) -> bool:
    rx = "^" + re.escape(_norm_path(pattern)).replace(r"\*", "[^/\\\\]*").replace(r"\?", ".") + "$"
    return re.match(rx, _norm_path(path)) is not None


def os_family_from_uname(text: str) -> str:
    t = (text or "").lower()
    if t.startswith("aix") or " aix " in f" {t} ":
        return "aix"
    if "windows" in t or "microsoft" in t:
        return "windows"
    return "linux" if t else ""


def evaluate_host(host: Dict[str, Any], app: Dict[str, str], remote: Dict[str, Any],
                  client: Optional["ElasticClient"], settings: Optional[Dict[str, Any]] = None,
                  fb_zbx: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    host/app come from Zabbix (name, IP, appid : appname only).
    fb_zbx = Filebeat process facts read from the host's Zabbix proc.num items.
    remote = remote_check.check_host() result: what is really on the machine.
    """
    s = settings or load_settings()
    cfg = load_host_config(host.get("hostid"))
    inputs = cfg.get("inputs") or []
    env = cfg.get("env") or s["default_env"]
    used_types = sorted({i["type"] for i in inputs})
    expected_indices = {t: index_name(app.get("appid", ""), app.get("appname", ""), env, t, s) for t in used_types}
    expected_space = space_id(app.get("appid", ""), app.get("appname", ""), s)
    notes, errors = [], []

    fb = fb_zbx or {}
    reachable = bool(remote.get("reachable"))
    os_family = os_family_from_uname(remote.get("os", "")) if reachable else ""   # "" = not known yet
    # filebeat.yml: prefer the Zabbix item (vfs.file.contents / "Config filebeat.yml"), fall back to SSH
    cfg_text = fb.get("config_text") or (remote.get("config_text", "") if remote.get("config_readable") else "")
    cfg_from_zabbix = bool(fb.get("config_text"))
    on_host = parse_filebeat_yml(cfg_text) if cfg_text.strip() else None

    shipping, index_state, space_state, dv_state = None, {}, None, None
    if client:
        try:
            for t, idx in expected_indices.items():
                index_state[t] = client.index_exists(idx)
            pats = list(expected_indices.values()) or [index_name(app.get("appid", ""), app.get("appname", ""), env, "*", s)]
            ips = [i.get("ip") for i in host.get("interfaces", [])]
            shipping = client.host_shipping(pats, [host.get("host"), host.get("name")], ips)
        except ElasticError as e:
            errors.append(f"Elasticsearch: {e}")
        if s.get("kibana_url"):
            try:
                space_state = client.get_space(expected_space) is not None
                if space_state:
                    titles = {dv.get("title") for dv in client.list_data_views(expected_space)}
                    want = index_name(app.get("appid", ""), app.get("appname", ""), env, "*", s)
                    dv_state = want in titles or any(i in titles for i in expected_indices.values())
            except ElasticError as e:
                errors.append(f"Kibana: {e}")

    checks: List[Dict[str, Any]] = []

    def add(cid, name, status, detail="", action=None):
        checks.append({"id": cid, "name": name, "status": status, "detail": detail, "action": action})

    supported = os_family != "aix"

    # --- Filebeat status from Zabbix proc.num items (รูปที่ 1 + รูปที่ 2) ---
    zbx_has = fb.get("items_found", 0) > 0
    zbx_data = fb.get("has_data")
    zbx_running = fb.get("running")
    zbx_installed = zbx_running or (fb.get("config_paths") and zbx_data)
    inst_detail_parts = []
    for ins in fb.get("instances", []):
        state = "running" if ins["running"] else ("stopped" if ins["collecting"] else "no data")
        inst_detail_parts.append(f"{ins['name']}={ins['count'] if ins['count'] is not None else '?'} ({state})")
    inst_detail = " · ".join(inst_detail_parts)

    if zbx_has:
        add("installed", "ติดตั้ง Filebeat (จาก Zabbix)",
            OK if zbx_installed else (UNKNOWN if not zbx_data else MISSING),
            (f"พบ process filebeat ใน Zabbix" + (f" · config path: {', '.join(fb['config_paths'])}" if fb.get("config_paths") else ""))
            if zbx_installed else ("Zabbix มี item แต่ยังไม่มีข้อมูล (รอรอบเก็บ)" if not zbx_data else "proc.num = 0 (ไม่พบ process filebeat)"),
            None if zbx_installed or not supported else {"type": "install_script"})
        add("running", "Filebeat ทำงานอยู่ (จาก Zabbix)",
            OK if zbx_running else (UNKNOWN if not zbx_data else MISSING),
            inst_detail or ("ยังไม่มีข้อมูลจาก Zabbix" if not zbx_data else "ไม่มี process filebeat ทำงานอยู่"))
    elif remote.get("reachable"):
        add("installed", "ติดตั้ง Filebeat", OK if remote.get("installed") else MISSING,
            (f"version {remote.get('version') or '?'} · {remote.get('binary', '')}" if remote.get("installed") else "ไม่พบ filebeat บนเครื่อง"),
            None if remote.get("installed") or not supported else {"type": "install_script"})
        add("running", "Filebeat ทำงานอยู่", OK if remote.get("running") else MISSING, f"{remote.get('service_state')}")
    else:
        add("installed", "ติดตั้ง Filebeat", UNKNOWN,
            "ยังไม่มี item ตรวจ filebeat ใน Zabbix (เพิ่ม Template Process filebeat หรือ proc.num[,,,filebeat])")
        add("running", "Filebeat ทำงานอยู่", UNKNOWN, "ยังไม่มีข้อมูลจาก Zabbix")

    if not supported:
        add("supported", "Filebeat รองรับ OS นี้", MISSING, "Elastic ไม่มี Filebeat สำหรับ AIX — ใช้ rsyslog/Logstash แทน")

    add("inputs", "กำหนด log path ในโปรแกรม", OK if inputs else MISSING,
        f"{len(inputs)} path · {', '.join(used_types) or '-'}", None if inputs else {"type": "edit_config"})

    cfg_paths = [i["path"] for i in inputs]
    # filebeat.yml comparison: read from Zabbix item "Config filebeat.yml" (fallback SSH)
    cfg_src_label = "จาก Zabbix" if cfg_from_zabbix else "จากเครื่อง"
    if on_host is None:
        add("config_read", "อ่าน filebeat.yml", UNKNOWN,
            "ยังไม่มี item 'Config filebeat.yml' (vfs.file.contents[...filebeat.yml]) ใน Zabbix สำหรับ host นี้")
    else:
        host_paths = on_host["paths"]
        missing = [p for p in cfg_paths if not any(_norm_path(p) == _norm_path(h) for h in host_paths)]
        extra = [h for h in host_paths if not any(_norm_path(h) == _norm_path(p) for p in cfg_paths)]
        add("config_paths", f"Path ใน filebeat.yml ตรงกับที่กำหนด ({cfg_src_label})",
            (OK if not missing else MISSING) if inputs else NA,
            (("ตรงกัน" if not missing else "ขาด: " + ", ".join(missing)) if inputs else "ยังไม่ได้กำหนด log path ในโปรแกรม")
            + (" · มีในเครื่อง: " + ", ".join(extra) if extra else ""),
            {"type": "install_script"} if inputs and missing else None)
        want_idx = set(expected_indices.values())
        add("config_index", f"ชื่อ index ใน filebeat.yml ตรงมาตรฐาน ({cfg_src_label})",
            (OK if want_idx <= set(on_host["indices"]) else MISSING) if want_idx else NA,
            f"ในไฟล์: {', '.join(on_host['indices']) or '-'} · มาตรฐาน: {', '.join(sorted(want_idx)) or '-'}",
            {"type": "install_script"} if want_idx and not want_idx <= set(on_host["indices"]) else None)
    if reachable and inputs:
        found = remote.get("paths_found") or {}
        absent = [p for p in cfg_paths if not found.get(p)]
        add("paths_exist", "ไฟล์ log มีอยู่จริงบนเครื่อง", OK if not absent else MISSING,
            "ครบทุก path" if not absent else "ไม่พบไฟล์: " + ", ".join(absent))
        if remote.get("running"):
            harvested = remote.get("harvested_files") or []
            idle = [p for p in cfg_paths if not any(_glob_match(p, h) for h in harvested)]
            add("harvesting", "Filebeat กำลังอ่านไฟล์ตาม path", OK if not idle else MISSING,
                f"{len(harvested)} ไฟล์ใน registry" + ("" if not idle else " · ยังไม่อ่าน: " + ", ".join(idle)))

    if not client:
        add("elastic", "เชื่อมต่อ Elasticsearch", UNKNOWN, "ยังไม่ได้ตั้งค่า Elastic Settings", {"type": "settings"})
    else:
        for t in LOG_TYPES:
            if t not in expected_indices:
                continue
            ex = index_state.get(t)
            add(f"index_{t}", f"Index {t}", OK if ex else (UNKNOWN if ex is None else MISSING), expected_indices[t],
                None if ex else {"type": "create_index", "index": expected_indices[t]})
        if s.get("kibana_url"):
            add("space", "Kibana Space", OK if space_state else (UNKNOWN if space_state is None else MISSING), expected_space,
                None if space_state else {"type": "create_space", "space": expected_space})
            if space_state:
                add("data_view", "Data view ใน Space", OK if dv_state else MISSING,
                    index_name(app.get("appid", ""), app.get("appname", ""), env, "*", s),
                    None if dv_state else {"type": "create_space", "space": expected_space})
        if shipping is not None:
            fresh = False
            if shipping.get("last_event"):
                try:
                    ts = datetime.fromisoformat(str(shipping["last_event"]).replace("Z", "+00:00"))
                    fresh = (datetime.now(timezone.utc) - ts).total_seconds() < 86400
                except ValueError:
                    fresh = True
            add("logs", "มี log เข้า Elasticsearch (24 ชม.)", OK if fresh else MISSING,
                f"{shipping.get('docs', 0)} docs · ล่าสุด {shipping.get('last_event') or '-'}")

    counted = [c for c in checks if c["status"] in (OK, MISSING)]
    ok = sum(1 for c in counted if c["status"] == OK)
    return {
        "host": {"hostid": host.get("hostid"), "name": host.get("name"), "host": host.get("host")},
        "app": app, "os_family": os_family, "os_name": remote.get("os", "") if reachable else "",
        "supported": supported, "env": env,
        "filebeat": {
            "installed": zbx_installed if zbx_has else (remote.get("installed") if reachable else None),
            "version": remote.get("version", "") if reachable else "",
            "running": zbx_running if zbx_has else (remote.get("running") if reachable else None),
            "service_state": remote.get("service_state", "") if reachable else "",
            "source": "zabbix" if zbx_has else ("machine" if reachable else "none"),
            "config_paths": fb.get("config_paths", []),
            "instances": fb.get("instances", []),
            "config_on_host": on_host,
            "config_source": "zabbix" if cfg_from_zabbix else ("machine" if on_host else "none"),
            "harvested_files": remote.get("harvested_files", []), "recent_log": remote.get("recent_log", [])},
        "zabbix_filebeat": fb,
        "remote": {k: remote.get(k) for k in ("reachable", "method", "address", "error", "os", "user", "checked_at")},
        "config": cfg, "expected": {"indices": expected_indices, "space": expected_space},
        "elastic": {"configured": client is not None, "shipping": shipping, "indices": index_state,
                    "space": space_state, "data_view": dv_state},
        "checks": checks, "pct": round(ok * 100 / len(counted)) if counted else None, "ok": ok, "total": len(counted),
        "notes": notes, "errors": errors[:10],
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
