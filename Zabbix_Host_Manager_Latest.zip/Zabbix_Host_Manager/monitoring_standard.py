"""
Monitoring Standard engine.

Pure logic (no network calls): given a host, its Zabbix items/templates and an
inventory snapshot (installed software, Windows services, processes), evaluate
how complete the monitoring is against a defined standard and compute
coverage percentages per section.

Sections
  os       - OS-level metrics (CPU, memory, filesystem, network, ...)
  service  - Windows services / Linux & AIX processes (up/down monitoring)
  software - Installed applications that need an application template

Status per check: "Monitored" | "Not Monitored" | "Not Required"
Coverage % = Monitored / (Total - Not Required)
"""
import json
import os
import re
import sys
import threading
import time
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

MONITORED = "Monitored"
NOT_MONITORED = "Not Monitored"
NOT_REQUIRED = "Not Required"

OS_FAMILIES = ("windows", "linux", "aix")

# ---------------------------------------------------------------------------
# 1) OS monitoring standard
#    match   : regexes tested against item key_ (lower-case)
#    required: per OS family
#    add     : item to create when "Add Monitor" is used (None = template only)
# ---------------------------------------------------------------------------
OS_CHECKS: List[Dict[str, Any]] = [
    {
        "id": "agent_availability", "expected": "agent.ping", "name": "Agent availability", "category": "Availability",
        "match": [r"^agent\.ping$", r"^zabbix\[host,agent,available\]$", r"^icmpping(\[|$)"],
        "required": {"windows": True, "linux": True, "aix": True},
        "add": {"*": {"key": "agent.ping", "name": "Zabbix agent ping", "value_type": 3, "delay": "1m"}},
        "trigger": {"expr": "nodata(/{host}/{key},5m)=1", "desc": "Zabbix agent is not available on {HOST.NAME}", "priority": 3},
    },
    {
        "id": "cpu_util", "expected": "system.cpu.util", "name": "CPU utilization", "category": "CPU",
        "match": [r"^system\.cpu\.util", r"^perf_counter(_en)?\[.*processor.*% processor time"],
        "required": {"windows": True, "linux": True, "aix": True},
        "add": {"*": {"key": "system.cpu.util", "name": "CPU utilization", "value_type": 0, "units": "%", "delay": "1m"}},
        "trigger": {"expr": "min(/{host}/{key},5m)>90", "desc": "High CPU utilization on {HOST.NAME} (>90% for 5m)", "priority": 2},
    },
    {
        "id": "cpu_load", "expected": "system.cpu.load[all,avg5]", "name": "CPU load / queue", "category": "CPU",
        "match": [r"^system\.cpu\.load", r"^perf_counter(_en)?\[.*processor queue length"],
        "required": {"windows": False, "linux": True, "aix": True},
        "add": {"*": {"key": "system.cpu.load[all,avg5]", "name": "CPU load average (5m)", "value_type": 0, "delay": "1m"}},
    },
    {
        "id": "memory", "expected": "vm.memory.util / vm.memory.size[pused]", "name": "Memory utilization", "category": "Memory",
        "match": [r"^vm\.memory\.(util|size)", r"^perf_counter(_en)?\[.*\\memory\\"],
        "required": {"windows": True, "linux": True, "aix": True},
        "add": {
            "windows": {"key": "vm.memory.size[pused]", "name": "Memory utilization", "value_type": 0, "units": "%", "delay": "1m"},
            "linux": {"key": "vm.memory.util", "name": "Memory utilization", "value_type": 0, "units": "%", "delay": "1m"},
            "aix": {"key": "vm.memory.size[available]", "name": "Available memory", "value_type": 3, "units": "B", "delay": "1m"},
        },
    },
    {
        "id": "swap", "expected": "system.swap.size[,pfree]", "name": "Swap / paging file", "category": "Memory",
        "match": [r"^system\.swap\.(size|in|out)", r"^perf_counter(_en)?\[.*paging file"],
        "required": {"windows": False, "linux": True, "aix": True},
        "add": {"*": {"key": "system.swap.size[,pfree]", "name": "Free swap space in %", "value_type": 0, "units": "%", "delay": "1m"}},
    },
    {
        "id": "fs_usage", "expected": "vfs.fs.size[<fs>,pused]", "name": "Filesystem space", "category": "Disk",
        "match": [r"^vfs\.fs\.(size|dependent\.size)\[", r"^vfs\.fs\.get$"],
        "required": {"windows": True, "linux": True, "aix": True},
        "add": {
            "windows": {"key": "vfs.fs.size[C:,pused]", "name": "C: Space utilization", "value_type": 0, "units": "%", "delay": "5m"},
            "linux": {"key": "vfs.fs.size[/,pused]", "name": "/: Space utilization", "value_type": 0, "units": "%", "delay": "5m"},
            "aix": {"key": "vfs.fs.size[/,pused]", "name": "/: Space utilization", "value_type": 0, "units": "%", "delay": "5m"},
        },
        "trigger": {"expr": "last(/{host}/{key})>90", "desc": "Disk space is critically low on {HOST.NAME} (>90%)", "priority": 3},
    },
    {
        "id": "fs_inode", "expected": "vfs.fs.inode[<fs>,pfree]", "name": "Filesystem inodes", "category": "Disk",
        "match": [r"^vfs\.fs\.(inode|dependent\.inode)\["],
        "required": {"windows": False, "linux": True, "aix": True},
        "add": {"linux": {"key": "vfs.fs.inode[/,pfree]", "name": "/: Free inodes in %", "value_type": 0, "units": "%", "delay": "5m"},
                "aix": {"key": "vfs.fs.inode[/,pfree]", "name": "/: Free inodes in %", "value_type": 0, "units": "%", "delay": "5m"}},
    },
    {
        "id": "disk_io", "expected": "vfs.dev.read/write[<disk>] (OS template)", "name": "Disk I/O", "category": "Disk",
        "match": [r"^vfs\.dev\.(read|write)", r"^perf_counter(_en)?\[.*physicaldisk"],
        "required": {"windows": True, "linux": True, "aix": True},
        "add": None,  # needs device discovery -> OS template
    },
    {
        "id": "network", "expected": "net.if.in/out[<if>] (OS template)", "name": "Network interface traffic", "category": "Network",
        "match": [r"^net\.if\.(in|out|total)\[", r"^perf_counter(_en)?\[.*network interface"],
        "required": {"windows": True, "linux": True, "aix": True},
        "add": None,  # needs interface discovery -> OS template
    },
    {
        "id": "uptime", "expected": "system.uptime", "name": "System uptime", "category": "System",
        "match": [r"^system\.uptime$"],
        "required": {"windows": True, "linux": True, "aix": True},
        "add": {"*": {"key": "system.uptime", "name": "System uptime", "value_type": 3, "units": "uptime", "delay": "1m"}},
    },
    {
        "id": "process_count", "expected": "proc.num[]", "name": "Number of processes", "category": "System",
        "match": [r"^proc\.num$", r"^proc\.num\[\s*\]$", r"^proc\.num\[,"],
        "required": {"windows": True, "linux": True, "aix": True},
        "add": {"*": {"key": "proc.num[]", "name": "Number of processes", "value_type": 3, "delay": "1m"}},
    },
    {
        "id": "os_info", "expected": "system.uname", "name": "OS identification", "category": "System",
        "match": [r"^system\.uname$", r"^system\.sw\.os"],
        "required": {"windows": True, "linux": True, "aix": True},
        "add": {"*": {"key": "system.uname", "name": "System description", "value_type": 4, "delay": "1h"}},
    },
]

OS_TEMPLATES = {
    "windows": ["Windows by Zabbix agent", "Windows by Zabbix agent active"],
    "linux": ["Linux by Zabbix agent", "Linux by Zabbix agent active"],
    "aix": ["AIX by Zabbix agent"],
}
OS_TEMPLATE_KEYWORDS = {"windows": ["windows"], "linux": ["linux"], "aix": ["aix"]}

# ---------------------------------------------------------------------------
# 2) Baseline services / processes every server should have monitored
#    alternatives: any name in the list satisfies the check
# ---------------------------------------------------------------------------
BASELINE_SERVICES: Dict[str, List[Dict[str, Any]]] = {
    "windows": [
        {"id": "eventlog", "names": ["EventLog"], "display": "Windows Event Log"},
        {"id": "w32time", "names": ["W32Time"], "display": "Windows Time"},
    ],
    "linux": [
        {"id": "sshd", "names": ["sshd"], "display": "OpenSSH server"},
        {"id": "cron", "names": ["crond", "cron"], "display": "Cron scheduler"},
        {"id": "syslog", "names": ["rsyslogd", "syslog-ng", "systemd-journald"], "display": "System logging"},
        {"id": "timesync", "names": ["chronyd", "ntpd", "systemd-timesyncd"], "display": "Time synchronization"},
    ],
    "aix": [
        {"id": "sshd", "names": ["sshd"], "display": "OpenSSH server"},
        {"id": "cron", "names": ["cron"], "display": "Cron scheduler"},
        {"id": "syslog", "names": ["syslogd"], "display": "System logging"},
        {"id": "timesync", "names": ["xntpd", "chronyd", "ntpd"], "display": "Time synchronization"},
    ],
}

# ---------------------------------------------------------------------------
# 3) Software catalog -> expected Zabbix template
#    include/exclude : regex on installed software name (lower-case)
#    services        : regex on Windows service name (lower-case)
#    processes       : process names (Linux/AIX/Windows, ".exe" optional)
#    templates       : candidate standard templates (first one that exists in Zabbix wins)
#    template_keywords: linked template names containing these count as monitored
#    item_patterns   : item keys proving application-level monitoring
# ---------------------------------------------------------------------------
SOFTWARE_CATALOG: List[Dict[str, Any]] = [
    {"id": "mssql", "name": "Microsoft SQL Server", "kind": "Database", "required": True,
     "include": [r"^microsoft sql server \d{4}", r"^sql server \d{4} database engine services"],
     "exclude": [r"setup", r"management studio", r"native client", r"odbc", r"browser", r"vss", r"writer", r"tools",
                 r"shared", r"localdb", r"compact", r"report", r"polic", r"t-sql", r"language", r"dac", r"redist", r"clr types",
                 r"command line", r"common files", r"batch parser", r"connection info", r"sql server agent", r"rsfx", r"driver", r"dmf", r"xevent", r"sql writer"],
     "services": [r"^mssqlserver$", r"^mssql\$"], "processes": ["sqlservr"],
     "templates": ["MSSQL by Zabbix agent 2", "MSSQL by ODBC"], "template_keywords": ["mssql", "sql server"],
     "item_patterns": [r"^mssql\.", r"perf_counter(_en)?\[.*(mssql|sqlserver)"]},
    {"id": "oracle", "name": "Oracle Database", "kind": "Database", "required": True,
     "include": [r"^oracle database", r"^oracle \d+c", r"^oracle.*database server"],
     "exclude": [r"client", r"instant", r"odbc", r"java"],
     "services": [r"^oracleservice"], "processes": ["ora_pmon", "tnslsnr"],
     "templates": ["Oracle by Zabbix Agent 2", "Oracle by ODBC"], "template_keywords": ["oracle"],
     "item_patterns": [r"^oracle\."]},
    {"id": "mysql", "name": "MySQL / MariaDB", "kind": "Database", "required": True,
     "include": [r"^mysql server", r"^mysql(-community)?-server", r"^mariadb(-server)?($|[\s-]\d)", r"^mariadb server"],
     "exclude": [r"connector", r"workbench", r"client", r"libs?$", r"common"],
     "services": [r"^mysql\d*$", r"^mariadb"], "processes": ["mysqld", "mariadbd"],
     "templates": ["MySQL by Zabbix agent 2", "MySQL by Zabbix agent", "MySQL by ODBC"], "template_keywords": ["mysql", "mariadb"],
     "item_patterns": [r"^mysql\."]},
    {"id": "postgresql", "name": "PostgreSQL", "kind": "Database", "required": True,
     "include": [r"^postgresql\d*(-server)?$", r"^postgresql \d+", r"^postgresql\d*-server"],
     "exclude": [r"libs?$", r"jdbc", r"odbc", r"contrib", r"client"],
     "services": [r"^postgresql"], "processes": ["postgres", "postmaster"],
     "templates": ["PostgreSQL by Zabbix agent 2", "PostgreSQL by Zabbix agent"], "template_keywords": ["postgres", "pgsql"],
     "item_patterns": [r"^pgsql\.", r"^postgresql\."]},
    {"id": "db2", "name": "IBM Db2", "kind": "Database", "required": True,
     "include": [r"^db2", r"^ibm db2"], "exclude": [r"client", r"driver"],
     "services": [r"^db2"], "processes": ["db2sysc"],
     "templates": [], "template_keywords": ["db2"], "item_patterns": [r"db2"]},
    {"id": "iis", "name": "Microsoft IIS", "kind": "Web server", "required": True,
     "include": [r"internet information services"], "exclude": [r"express", r"url rewrite", r"arr"],
     "services": [r"^w3svc$"], "processes": ["w3wp"],
     "templates": ["IIS by Zabbix agent", "IIS by Zabbix agent active"], "template_keywords": ["iis"],
     "item_patterns": [r"perf_counter(_en)?\[.*web service", r"^iis\."]},
    {"id": "apache", "name": "Apache HTTP Server", "kind": "Web server", "required": True,
     "include": [r"^httpd$", r"^httpd-\d", r"^apache2$", r"^apache http server"],
     "exclude": [r"tomcat", r"tools", r"filesystem", r"utils", r"devel", r"doc"],
     "services": [r"^apache\d*$"], "processes": ["httpd", "apache2"],
     "templates": ["Apache by Zabbix agent", "Apache by HTTP"], "template_keywords": ["apache"],
     "item_patterns": [r"^apache\.", r"^web\.page\.get\[.*server-status"]},
    {"id": "nginx", "name": "Nginx", "kind": "Web server", "required": True,
     "include": [r"^nginx($|[\s-]\d|-core|-full)"], "exclude": [r"filesystem", r"mod-", r"module"],
     "services": [r"^nginx"], "processes": ["nginx"],
     "templates": ["Nginx by Zabbix agent", "Nginx by HTTP"], "template_keywords": ["nginx"],
     "item_patterns": [r"^nginx\.", r"^web\.page\.get\[.*(basic_status|stub_status)"]},
    {"id": "tomcat", "name": "Apache Tomcat", "kind": "Middleware", "required": True,
     "include": [r"tomcat"], "exclude": [r"native", r"docs", r"lib"],
     "services": [r"^tomcat\d*$"], "processes": [],
     "templates": ["Apache Tomcat by JMX"], "template_keywords": ["tomcat"],
     "item_patterns": [r"^jmx\[.*catalina"]},
    {"id": "weblogic", "name": "Oracle WebLogic / IBM WebSphere", "kind": "Middleware", "required": True,
     "include": [r"weblogic", r"websphere"], "exclude": [],
     "services": [r"weblogic", r"^ibmwas"], "processes": [],
     "templates": ["Generic Java JMX"], "template_keywords": ["weblogic", "websphere", "jmx"],
     "item_patterns": [r"^jmx\["]},
    {"id": "docker", "name": "Docker Engine", "kind": "Container", "required": True,
     "include": [r"^docker(-ce|-engine|\.io)?$", r"^docker engine", r"^docker desktop", r"^moby-engine"],
     "exclude": [r"cli$", r"compose", r"buildx"],
     "services": [r"^docker$", r"^com\.docker\.service$"], "processes": ["dockerd"],
     "templates": ["Docker by Zabbix agent 2"], "template_keywords": ["docker"],
     "item_patterns": [r"^docker\."]},
    {"id": "redis", "name": "Redis", "kind": "Database", "required": True,
     "include": [r"^redis(-server)?($|[\s-]\d)"], "exclude": [r"tools", r"client"],
     "services": [r"^redis"], "processes": ["redis-server"],
     "templates": ["Redis by Zabbix agent 2"], "template_keywords": ["redis"], "item_patterns": [r"^redis\."]},
    {"id": "mongodb", "name": "MongoDB", "kind": "Database", "required": True,
     "include": [r"^mongodb(-org)?(-server)?($|[\s-]\d)", r"^mongodb \d"], "exclude": [r"compass", r"shell", r"tools", r"mongosh"],
     "services": [r"^mongodb"], "processes": ["mongod"],
     "templates": ["MongoDB node by Zabbix agent 2"], "template_keywords": ["mongo"], "item_patterns": [r"^mongodb\."]},
    {"id": "rabbitmq", "name": "RabbitMQ", "kind": "Middleware", "required": True,
     "include": [r"rabbitmq(-server)?"], "exclude": [],
     "services": [r"^rabbitmq"], "processes": [],
     "templates": ["RabbitMQ node by Zabbix agent", "RabbitMQ node by HTTP"], "template_keywords": ["rabbitmq"],
     "item_patterns": [r"^rabbitmq\."]},
    {"id": "elasticsearch", "name": "Elasticsearch", "kind": "Database", "required": True,
     "include": [r"^elasticsearch"], "exclude": [r"curator"],
     "services": [r"^elasticsearch"], "processes": [],
     "templates": ["Elasticsearch Cluster by HTTP"], "template_keywords": ["elasticsearch"], "item_patterns": [r"^es\."]},
    {"id": "exchange", "name": "Microsoft Exchange Server", "kind": "Application", "required": True,
     "include": [r"^microsoft exchange server"], "exclude": [r"language", r"update", r"pack"],
     "services": [r"^msexchange"], "processes": [],
     "templates": ["Microsoft Exchange Server 2016 by Zabbix agent", "Microsoft Exchange Server 2016 by Zabbix agent active"],
     "template_keywords": ["exchange"], "item_patterns": [r"perf_counter(_en)?\[.*msexchange"]},
    {"id": "ad_ds", "name": "Active Directory Domain Services", "kind": "Application", "required": True,
     "include": [], "exclude": [],
     "services": [r"^ntds$"], "processes": [],
     "templates": ["Active Directory DS by Zabbix agent", "Active Directory DS by Zabbix agent active"],
     "template_keywords": ["active directory"], "item_patterns": [r"perf_counter(_en)?\[.*ntds"]},
    {"id": "hyperv", "name": "Microsoft Hyper-V", "kind": "Virtualization", "required": True,
     "include": [], "exclude": [],
     "services": [r"^vmms$"], "processes": [],
     "templates": ["Hyper-V by Zabbix agent", "Hyper-V by Zabbix agent active"], "template_keywords": ["hyper-v"],
     "item_patterns": [r"perf_counter(_en)?\[.*hyper-v"]},
    {"id": "sap", "name": "SAP / SAP Business One", "kind": "Application", "required": True,
     "include": [r"^sap ", r"sap business one"], "exclude": [r"gui", r"crystal", r"client"],
     "services": [r"^sbo", r"^sap"], "processes": [],
     "templates": [], "template_keywords": ["sap"], "item_patterns": []},
    # --- informational: detected but monitoring not required by standard ---
    {"id": "zabbix_agent", "name": "Zabbix Agent", "kind": "Monitoring", "required": False,
     "include": [r"^zabbix agent", r"^zabbix-agent"], "exclude": [],
     "services": [r"^zabbix agent"], "processes": ["zabbix_agentd", "zabbix_agent2"],
     "templates": [], "template_keywords": [], "item_patterns": []},
    {"id": "vmware_tools", "name": "VMware Tools", "kind": "Virtualization", "required": False,
     "include": [r"^vmware tools", r"^open-vm-tools"], "exclude": [],
     "services": [r"^vmtools$"], "processes": ["vmtoolsd"],
     "templates": [], "template_keywords": [], "item_patterns": []},
    {"id": "java", "name": "Java Runtime", "kind": "Runtime", "required": False,
     "include": [r"^java(\(tm\))? (se )?(\d+ )?(runtime|development|update)", r"^jdk", r"openjdk", r"^java-\d+-openjdk", r"^temurin"],
     "exclude": [], "services": [], "processes": [],
     "templates": ["Generic Java JMX"], "template_keywords": ["jmx"], "item_patterns": [r"^jmx\["]},
]

# ---------------------------------------------------------------------------
# Local stores: settings + waivers (Not Required exceptions)
# ---------------------------------------------------------------------------
if getattr(sys, "frozen", False):
    _DATA_DIR = os.path.dirname(sys.executable)
else:
    _DATA_DIR = os.path.dirname(os.path.abspath(__file__))

SETTINGS_FILE = os.path.join(_DATA_DIR, "monitoring_settings.json")
WAIVERS_FILE = os.path.join(_DATA_DIR, "standard_waivers.json")
_store_lock = threading.Lock()

DEFAULT_SETTINGS = {
    "pass_threshold": 100,   # % coverage needed for PASS
    "warn_threshold": 80,    # % coverage needed for PARTIAL
    "direct_agent": True,    # query the Zabbix agent directly for inventory
    "agent_port": 10050,
    "organization": "",
}


def _read_json(path: str, default: Any) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def _write_json(path: str, data: Any) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def load_settings() -> Dict[str, Any]:
    data = _read_json(SETTINGS_FILE, {})
    merged = dict(DEFAULT_SETTINGS)
    if isinstance(data, dict):
        merged.update({k: v for k, v in data.items() if k in DEFAULT_SETTINGS})
    return merged


def save_settings(update: Dict[str, Any]) -> Dict[str, Any]:
    current = load_settings()
    for key, value in (update or {}).items():
        if key not in DEFAULT_SETTINGS:
            continue
        if key in ("pass_threshold", "warn_threshold"):
            value = max(0, min(100, int(value)))
        elif key == "agent_port":
            value = max(1, min(65535, int(value)))
        elif key == "direct_agent":
            value = bool(value)
        else:
            value = str(value)[:200]
        current[key] = value
    if current["warn_threshold"] > current["pass_threshold"]:
        current["warn_threshold"] = current["pass_threshold"]
    with _store_lock:
        _write_json(SETTINGS_FILE, current)
    return current


def load_waivers(hostid: str) -> Dict[str, Dict[str, str]]:
    data = _read_json(WAIVERS_FILE, {})
    return (data.get("hosts", {}) or {}).get(str(hostid), {}) if isinstance(data, dict) else {}


def set_waiver(hostid: str, check_key: str, reason: str, remove: bool = False) -> Dict[str, Dict[str, str]]:
    with _store_lock:
        data = _read_json(WAIVERS_FILE, {})
        if not isinstance(data, dict):
            data = {}
        hosts = data.setdefault("hosts", {})
        host_waivers = hosts.setdefault(str(hostid), {})
        if remove:
            host_waivers.pop(check_key, None)
        else:
            host_waivers[check_key] = {"reason": (reason or "").strip()[:300] or "Not required",
                                       "at": datetime.now().strftime("%Y-%m-%d %H:%M")}
        if not host_waivers:
            hosts.pop(str(hostid), None)
        _write_json(WAIVERS_FILE, data)
        return host_waivers


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _rx(patterns: List[str]) -> List["re.Pattern"]:
    return [re.compile(p, re.IGNORECASE) for p in patterns]


for _c in OS_CHECKS:
    _c["_rx"] = _rx(_c["match"])
for _s in SOFTWARE_CATALOG:
    _s["_inc"] = _rx(_s["include"])
    _s["_exc"] = _rx(_s["exclude"])
    _s["_svc"] = _rx(_s["services"])
    _s["_items"] = _rx(_s["item_patterns"])


def detect_os_family(templates: List[Dict[str, Any]], items: List[Dict[str, Any]],
                     uname: str = "", hint: str = "") -> str:
    """Decide windows / linux / aix from uname, templates, items and host name hints."""
    text = (uname or "").lower()
    if text:
        if text.startswith("aix") or " aix " in f" {text} ":
            return "aix"
        if "windows" in text:
            return "windows"
        if "linux" in text:
            return "linux"
    for t in templates or []:
        name = (t.get("name") or "").lower()
        if "aix" in name:
            return "aix"
        if "windows" in name:
            return "windows"
        if "linux" in name:
            return "linux"
    for it in items or []:
        key = (it.get("key_") or "").lower()
        if key.startswith(("perf_counter", "service.info", "wmi.", "registry.", "eventlog")):
            return "windows"
        if key == "system.uname" and it.get("lastvalue"):
            return detect_os_family([], [], it.get("lastvalue"), hint)
    h = (hint or "").lower()
    if "aix" in h:
        return "aix"
    if "win" in h:
        return "windows"
    return "linux" if h else "windows"


def parse_key_params(key: str) -> Tuple[str, List[str]]:
    """Split 'proc.num[a,"b,c",,d]' into ('proc.num', ['a', 'b,c', '', 'd'])."""
    if "[" not in key or not key.endswith("]"):
        return key, []
    name, raw = key[: key.index("[")], key[key.index("[") + 1: -1]
    params, cur, quoted, i = [], "", False, 0
    while i < len(raw):
        ch = raw[i]
        if quoted:
            if ch == "\\" and i + 1 < len(raw) and raw[i + 1] == '"':
                cur += '"'
                i += 1
            elif ch == '"':
                quoted = False
            else:
                cur += ch
        elif ch == '"' and not cur.strip():
            quoted = True
            cur = ""
        elif ch == ",":
            params.append(cur.strip())
            cur = ""
        else:
            cur += ch
        i += 1
    params.append(cur.strip())
    return name, params


def _norm_proc(name: str) -> str:
    n = (name or "").strip().lower()
    return n[:-4] if n.endswith(".exe") else n


def _parse_delay(delay: str) -> int:
    m = re.match(r"^\s*(\d+)\s*([smhdw]?)\s*$", str(delay or ""))
    if not m:
        return 3600
    mult = {"": 1, "s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}[m.group(2)]
    return int(m.group(1)) * mult


def item_health(item: Dict[str, Any], now: Optional[float] = None) -> Optional[str]:
    """Return None when the item is collecting normally, else an issue code."""
    now = now or time.time()
    if str(item.get("status", "0")) != "0":
        return "disabled"
    if str(item.get("state", "0")) == "1":
        return "unsupported"
    try:
        lastclock = int(item.get("lastclock") or 0)
    except (TypeError, ValueError):
        lastclock = 0
    if lastclock <= 0:
        return "no_data"
    if now - lastclock > max(3 * _parse_delay(item.get("delay")), 3600):
        return "stale"
    return None


ISSUE_TEXT = {
    "disabled": "Item ถูกปิดใช้งาน (Disabled)",
    "unsupported": "Item ไม่รองรับ (Unsupported)",
    "no_data": "ยังไม่มีข้อมูลเข้ามา",
    "stale": "ข้อมูลไม่อัปเดต (Stale)",
}


def _pick_best(cands: List[Dict[str, Any]], now: float) -> Optional[Dict[str, Any]]:
    if not cands:
        return None
    order = {None: 0, "no_data": 1, "stale": 2, "unsupported": 3, "disabled": 4}
    return sorted(cands, key=lambda it: order.get(item_health(it, now), 9))[0]


def _status_from_item(item: Optional[Dict[str, Any]], now: float) -> Tuple[str, Optional[str]]:
    if not item:
        return NOT_MONITORED, None
    issue = item_health(item, now)
    if issue in ("disabled", "unsupported"):
        return NOT_MONITORED, issue
    return MONITORED, issue


def _fmt_clock(ts: Any) -> str:
    try:
        ts = int(ts or 0)
    except (TypeError, ValueError):
        return ""
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S") if ts > 0 else ""


def _summarize(checks: List[Dict[str, Any]]) -> Dict[str, Any]:
    total = len(checks)
    mon = sum(1 for c in checks if c["status"] == MONITORED)
    nr = sum(1 for c in checks if c["status"] == NOT_REQUIRED)
    nm = total - mon - nr
    denom = total - nr
    pct = round(mon * 100 / denom) if denom > 0 else None
    configured = [c for c in checks if c["status"] == MONITORED]
    healthy = sum(1 for c in configured if not c.get("issue"))
    health_pct = round(healthy * 100 / len(configured)) if configured else None
    return {"total": total, "monitored": mon, "not_monitored": nm, "not_required": nr,
            "pct": pct, "healthy": healthy, "health_pct": health_pct, "checks": checks}


def _apply_waiver(check: Dict[str, Any], waivers: Dict[str, Dict[str, str]]) -> None:
    w = waivers.get(check["check_key"])
    if w and check["status"] != MONITORED:
        check["status"] = NOT_REQUIRED
        check["waived"] = True
        check["reason"] = f"Waiver: {w.get('reason', '')} ({w.get('at', '')})"


def resolve_template(names: List[str], keywords: List[str], all_templates: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Find the first standard template that exists on this Zabbix server."""
    by_name = {(t.get("name") or "").lower(): t for t in all_templates or []}
    for n in names:
        t = by_name.get(n.lower())
        if t:
            return t
    for kw in keywords:
        for t in all_templates or []:
            if kw.lower() in (t.get("name") or "").lower():
                return t
    return None


# ---------------------------------------------------------------------------
# Main evaluator
# ---------------------------------------------------------------------------
def evaluate(host: Dict[str, Any], items: List[Dict[str, Any]], templates: List[Dict[str, Any]],
             inventory: Dict[str, Any], all_templates: List[Dict[str, Any]],
             settings: Optional[Dict[str, Any]] = None, waivers: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    settings = settings or load_settings()
    waivers = waivers or {}
    now = time.time()
    family = inventory.get("os_family") or "linux"
    linked_names = [(t.get("name") or "") for t in templates or []]
    linked_lower = [n.lower() for n in linked_names]
    items = items or []

    # ---------------- OS ----------------
    os_checks = []
    for spec in OS_CHECKS:
        cands = [it for it in items if any(rx.search(it.get("key_") or "") for rx in spec["_rx"])]
        best = _pick_best(cands, now)
        status, issue = _status_from_item(best, now)
        required = spec["required"].get(family, True)
        reason = ""
        if status != MONITORED and not required:
            status, reason = NOT_REQUIRED, "ไม่บังคับสำหรับ OS นี้ตามมาตรฐาน"
        elif status == NOT_MONITORED:
            reason = ISSUE_TEXT.get(issue, "ไม่มี item ตามมาตรฐาน")
        elif issue:
            reason = ISSUE_TEXT[issue]
        add_spec = None
        if spec.get("add"):
            add_spec = spec["add"].get(family) or spec["add"].get("*")
        os_tpl = resolve_template(OS_TEMPLATES.get(family, []), [], all_templates)
        if add_spec:
            action = {"type": "add_item", "check_id": spec["id"], "label": f"เพิ่ม {add_spec['key']}"}
        elif os_tpl:
            action = {"type": "link_template", "templateid": os_tpl["templateid"], "name": os_tpl["name"],
                      "label": f"ผูก {os_tpl['name']}"}
        else:
            action = {"type": "none", "label": "ต้องใช้ OS template"}
        check = {
            "check_key": f"os:{spec['id']}", "section": "os", "id": spec["id"], "kind": "os",
            "name": spec["name"], "category": spec["category"], "status": status, "issue": issue,
            "reason": reason, "expected": add_spec["key"] if add_spec else spec.get("expected", ""),
            "actual": best.get("key_") if best else "", "item_name": best.get("name") if best else "",
            "itemid": best.get("itemid") if best else None,
            "lastvalue": (best.get("lastvalue") if best else "") or "",
            "units": (best.get("units") if best else "") or "",
            "lastclock": _fmt_clock(best.get("lastclock")) if best else "",
            "error": (best.get("error") if best else "") or "",
            "action": action if status == NOT_MONITORED else None, "waivable": status == NOT_MONITORED,
        }
        _apply_waiver(check, waivers)
        os_checks.append(check)

    # Index service / process items on the host
    svc_items: Dict[str, List[Dict[str, Any]]] = {}
    proc_items: Dict[str, List[Dict[str, Any]]] = {}
    for it in items:
        kname, params = parse_key_params(it.get("key_") or "")
        kname = kname.lower()
        if kname in ("service.info", "service_state") and params and params[0]:
            svc_items.setdefault(params[0].lower(), []).append(it)
        elif kname in ("proc.num", "proc_info", "proc.mem", "proc.cpu.util") and params:
            if params[0]:
                proc_items.setdefault(_norm_proc(params[0]), []).append(it)
            if len(params) > 3 and params[3]:
                proc_items.setdefault(_norm_proc(params[3]), []).append(it)

    inv_services = inventory.get("services") or []
    inv_processes = inventory.get("processes") or []
    inv_software = inventory.get("software") or []
    has_services = bool(inventory.get("source", {}).get("services"))
    has_processes = bool(inventory.get("source", {}).get("processes"))
    has_software = bool(inventory.get("source", {}).get("software"))
    svc_index = {(s.get("name") or "").lower(): s for s in inv_services}
    proc_index = {_norm_proc(p.get("name")): p for p in inv_processes}
    is_win = family == "windows"

    used_itemids = set()

    def service_item_for(names: List[str], kind: str) -> Optional[Dict[str, Any]]:
        pool = svc_items if kind == "service" else proc_items
        cands = []
        for n in names:
            cands += pool.get(n.lower() if kind == "service" else _norm_proc(n), [])
        used_itemids.update(it.get("itemid") for it in cands)
        return _pick_best(cands, now)

    service_checks: List[Dict[str, Any]] = []
    seen_service_keys = set()

    def add_service_check(cid: str, names: List[str], display: str, kind: str, origin: str, required: bool = True):
        # service.info accepts the service name or its display name, so match both
        if kind == "service" and display and display not in names:
            names = names + [display]
        if kind == "service":
            for s in inv_services:  # resolve a display name to the real service name
                if (s.get("display_name") or "").lower() in {n.lower() for n in names}:
                    names = [s["name"]] + names
                    break
        present_name, present_obj = None, None
        for n in names:
            obj = svc_index.get(n.lower()) if kind == "service" else proc_index.get(_norm_proc(n))
            if obj:
                present_name, present_obj = (obj.get("name") or n), obj
                break
        target = present_name or names[0]
        dedup = f"{kind}:{target.lower() if kind == 'service' else _norm_proc(target)}"
        if dedup in seen_service_keys:
            return
        seen_service_keys.add(dedup)
        best = service_item_for(names, kind)
        status, issue = _status_from_item(best, now)
        inventory_known = has_services if kind == "service" else has_processes
        reason = ""
        state = ""
        if present_obj is not None:
            state = present_obj.get("state", "") if kind == "service" else f"{present_obj.get('count', 1)} process"
        if status != MONITORED:
            if not required:
                status, reason = NOT_REQUIRED, "ไม่บังคับตามมาตรฐาน"
            elif inventory_known and present_obj is None:
                status, reason = NOT_REQUIRED, "ไม่พบบนเครื่อง"
            elif kind == "service" and present_obj is not None and present_obj.get("startup") == "disabled":
                status, reason = NOT_REQUIRED, "Service ถูกตั้งเป็น Disabled"
            else:
                reason = ISSUE_TEXT.get(issue, "ยังไม่ได้ Monitor")
                if not inventory_known:
                    reason += " (ยังไม่ยืนยันว่ามีบนเครื่อง)"
        elif issue:
            reason = ISSUE_TEXT[issue]
        key = f"service.info[{target},state]" if kind == "service" else f"proc.num[{_norm_proc(target) if not is_win else target}]"
        if kind == "process" and is_win and not target.lower().endswith(".exe"):
            key = f"proc.num[{target}.exe]"
        if best and best.get("key_"):
            key = best["key_"]  # re-enable the existing (disabled) item instead of creating a duplicate
        check = {
            "check_key": f"service:{dedup}", "section": "service", "id": cid, "kind": kind,
            "name": display, "category": origin, "status": status, "issue": issue, "reason": reason,
            "expected": key, "actual": best.get("key_") if best else "", "itemid": best.get("itemid") if best else None,
            "lastvalue": (best.get("lastvalue") if best else "") or "", "units": "",
            "lastclock": _fmt_clock(best.get("lastclock")) if best else "",
            "error": (best.get("error") if best else "") or "", "state": state,
            "action": {"type": "add_service", "name": target, "display_name": display, "kind": kind, "key": key,
                       "label": "Add Monitor"} if status == NOT_MONITORED else None,
            "waivable": status == NOT_MONITORED,
        }
        _apply_waiver(check, waivers)
        service_checks.append(check)

    base_kind = "service" if is_win else "process"
    for b in BASELINE_SERVICES.get(family, []):
        add_service_check(b["id"], b["names"], b["display"], base_kind, "Baseline")

    # ---------------- Software ----------------
    software_checks: List[Dict[str, Any]] = []
    matched_software_names = set()
    for cat in SOFTWARE_CATALOG:
        hits = []
        for sw in inv_software:
            nm = (sw.get("name") or "").strip()
            low = nm.lower()
            if any(rx.search(low) for rx in cat["_inc"]) and not any(rx.search(low) for rx in cat["_exc"]):
                hits.append(sw)
        svc_hits = [s for s in inv_services if any(rx.search((s.get("name") or "").lower()) for rx in cat["_svc"])]
        proc_hits = [p for p in inv_processes if _norm_proc(p.get("name")) in {_norm_proc(x) for x in cat["processes"]}]
        # also treat existing service/process items as evidence the software exists
        item_svc_hits = [n for n in svc_items if any(rx.search(n) for rx in cat["_svc"])]
        item_proc_hits = [n for n in proc_items if n in {_norm_proc(x) for x in cat["processes"]}]
        if not (hits or svc_hits or proc_hits or item_svc_hits or item_proc_hits):
            continue
        for h in hits:
            matched_software_names.add((h.get("name") or "").lower())

        evidence = []
        if hits:
            evidence.append("installed: " + ", ".join(sorted({h.get("name", "") for h in hits})[:3]))
        if svc_hits or item_svc_hits:
            evidence.append("service: " + ", ".join(sorted({s.get("name", "") for s in svc_hits} | set(item_svc_hits))[:3]))
        if proc_hits or item_proc_hits:
            evidence.append("process: " + ", ".join(sorted({p.get("name", "") for p in proc_hits} | set(item_proc_hits))[:3]))
        version = next((h.get("version") for h in hits if h.get("version")), "")

        linked_tpl = next((linked_names[i] for i, ln in enumerate(linked_lower)
                           if ln in [t.lower() for t in cat["templates"]]
                           or any(kw in ln for kw in cat["template_keywords"])), "")
        app_items = [it for it in items if any(rx.search(it.get("key_") or "") for rx in cat["_items"])]
        best_app_item = _pick_best(app_items, now)
        expected_tpl = resolve_template(cat["templates"], cat["template_keywords"], all_templates)

        issue = None
        if linked_tpl:
            status, actual, reason = MONITORED, linked_tpl, "ผูก Template แล้ว"
        elif best_app_item and item_health(best_app_item, now) not in ("disabled", "unsupported"):
            status, actual = MONITORED, best_app_item.get("key_")
            issue = item_health(best_app_item, now)
            reason = "มี application items" + (f" ({ISSUE_TEXT[issue]})" if issue else "")
        elif not cat["required"]:
            status, actual, reason = NOT_REQUIRED, "", "ไม่บังคับตามมาตรฐาน"
        else:
            status, actual = NOT_MONITORED, ""
            reason = "ยังไม่ผูก Template ของ software นี้"
            if not expected_tpl and not cat["templates"]:
                reason = "ไม่มี Template มาตรฐาน ให้ Monitor ผ่าน service/process"

        action = None
        if status == NOT_MONITORED:
            if expected_tpl:
                action = {"type": "link_template", "templateid": expected_tpl["templateid"], "name": expected_tpl["name"],
                          "label": f"ผูก {expected_tpl['name']}"}
            elif cat["templates"]:
                action = {"type": "none", "label": f"ไม่พบ Template '{cat['templates'][0]}' บน Zabbix (import ก่อน)"}
        check = {
            "check_key": f"software:{cat['id']}", "section": "software", "id": cat["id"], "kind": "software",
            "name": cat["name"], "category": cat["kind"], "status": status, "issue": issue, "reason": reason,
            "version": version, "evidence": "; ".join(evidence),
            "expected": expected_tpl["name"] if expected_tpl else (cat["templates"][0] if cat["templates"] else "service/process"),
            "actual": actual, "lastvalue": "", "units": "", "lastclock": "", "error": "",
            "action": action, "waivable": status == NOT_MONITORED,
        }
        _apply_waiver(check, waivers)
        software_checks.append(check)

        # The software's own services/processes must also be up/down monitored
        if cat["required"]:
            if is_win:
                for s in (svc_hits[:3] or [{"name": n} for n in item_svc_hits[:3]]):
                    add_service_check(f"{cat['id']}:{s['name']}", [s["name"]], s.get("display_name") or s["name"],
                                      "service", cat["name"])
                for p in proc_hits[:2]:
                    if not svc_hits:
                        add_service_check(f"{cat['id']}:{p['name']}", [p["name"]], p["name"], "process", cat["name"])
            else:
                procs = [p["name"] for p in proc_hits] or item_proc_hits or cat["processes"][:1]
                for pn in procs[:2]:
                    add_service_check(f"{cat['id']}:{pn}", [pn], pn, "process", cat["name"])

    # Any other service/process already monitored on the host counts as expected.
    # service.info only exists on Windows; on other OSes those items are a template mismatch
    # and are reported under Data health instead.
    if is_win:
        for name, its in svc_items.items():
            if all(it.get("itemid") in used_itemids for it in its):
                continue
            raw = parse_key_params(its[0].get("key_"))[1][0]
            label = re.sub(r"^(state of service|status of service)\s+", "", its[0].get("name") or raw, flags=re.I)
            add_service_check(f"existing:{name}", [raw], label, "service", "Existing item")
    for name, its in proc_items.items():
        if name and not all(it.get("itemid") in used_itemids for it in its):
            add_service_check(f"existing:{name}", [name], its[0].get("name") or name, "process", "Existing item")

    # Running services/processes not covered by the standard (candidates for Add Monitor)
    covered = {c["check_key"] for c in service_checks}
    others = []
    for s in inv_services:
        key = f"service:service:{(s.get('name') or '').lower()}"
        if key not in covered and s.get("state") == "running":
            others.append({"name": s.get("name"), "display_name": s.get("display_name") or s.get("name"),
                           "kind": "service", "state": s.get("state"), "startup": s.get("startup", "")})
    for p in inv_processes:
        key = f"service:process:{_norm_proc(p.get('name'))}"
        if key not in covered:
            others.append({"name": p.get("name"), "display_name": p.get("name"), "kind": "process",
                           "state": f"{p.get('count', 1)} process", "startup": ""})

    os_sum = _summarize(os_checks)
    svc_sum = _summarize(service_checks)
    svc_sum["others"] = others[:500]
    sw_sum = _summarize(software_checks)
    sw_sum["other_installed"] = max(0, len(inv_software) - len(matched_software_names))

    all_checks = os_checks + service_checks + software_checks
    overall = _summarize(all_checks)
    overall.pop("checks", None)

    pct = overall["pct"]
    if pct is None:
        verdict = {"status": "N/A", "label": "ไม่มีรายการให้ประเมิน"}
    elif pct >= settings["pass_threshold"]:
        verdict = {"status": "PASS", "label": "พร้อมตามมาตรฐาน"}
    elif pct >= settings["warn_threshold"]:
        verdict = {"status": "PARTIAL", "label": "พร้อมบางส่วน"}
    else:
        verdict = {"status": "FAIL", "label": "ยังไม่พร้อมตามมาตรฐาน"}

    # Data health: every enabled item that is not collecting properly
    health_issues = []
    for it in items:
        issue = item_health(it, now)
        if issue and issue != "disabled":
            health_issues.append({"itemid": it.get("itemid"), "name": it.get("name"), "key": it.get("key_"),
                                  "issue": issue, "issue_text": ISSUE_TEXT[issue], "error": it.get("error") or "",
                                  "lastclock": _fmt_clock(it.get("lastclock"))})

    os_tpl_linked = [n for n in linked_names if any(kw in n.lower() for kw in OS_TEMPLATE_KEYWORDS.get(family, []))]
    rec_os_tpl = resolve_template(OS_TEMPLATES.get(family, []), [], all_templates)
    mismatched = [n for n in linked_names
                  if any(kw in n.lower() for fam, kws in OS_TEMPLATE_KEYWORDS.items() if fam != family for kw in kws)]
    notes = list(inventory.get("notes", []))
    for n in mismatched:
        notes.insert(0, f"Template '{n}' เป็นของ OS อื่น แต่เครื่องนี้เป็น {family.upper()} — items จะ Unsupported")

    src = inventory.get("source", {})
    verified = sum(1 for k in ("software", "services" if is_win else "processes") if src.get(k))
    confidence = "verified" if verified == 2 else ("partial" if verified == 1 else "estimated")
    if family == "windows" and not src.get("services"):
        confidence = "partial" if src.get("software") else "estimated"

    return {
        "host": host,
        "os_family": family,
        "os_name": inventory.get("os_name") or "",
        "templates": [{"templateid": t.get("templateid"), "name": t.get("name")} for t in templates or []],
        "os_template": {"linked": os_tpl_linked,
                        "recommended": rec_os_tpl["name"] if rec_os_tpl else (OS_TEMPLATES.get(family) or [""])[0],
                        "recommended_id": rec_os_tpl["templateid"] if rec_os_tpl else None},
        "inventory": {
            "source": src, "confidence": confidence, "errors": inventory.get("errors", [])[:20],
            "software_count": len(inv_software), "services_count": len(inv_services),
            "processes_count": len(inv_processes), "collected_at": inventory.get("collected_at", ""),
            "notes": notes, "agent_address": inventory.get("agent_address", ""),
        },
        "template_mismatch": mismatched,
        "sections": {"os": os_sum, "service": svc_sum, "software": sw_sum},
        "overall": overall,
        "verdict": verdict,
        "health": {"count": len(health_issues), "issues": health_issues[:300]},
        "items_total": len(items),
        "settings": {"pass_threshold": settings["pass_threshold"], "warn_threshold": settings["warn_threshold"]},
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }


def software_inventory_rows(inventory: Dict[str, Any], items: List[Dict[str, Any]], linked_templates: List[Dict[str, Any]],
                            linked_lower: List[str], all_templates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    One row per software / service / process found ON THE MACHINE, mapped to Zabbix.
      template  = template that holds the matching item (or linked app template), "Host" if created on the host
      item      = name + key of the Zabbix item that monitors it
      status    = Monitored when such an item / template exists, else Not Monitored
    """
    inv_software = inventory.get("software") or []
    inv_services = inventory.get("services") or []
    inv_processes = inventory.get("processes") or []
    probe_keys = {p["key"] for fam in ("windows", "linux", "aix") for p in __import__("zabbix_api").ZabbixClient.INVENTORY_PROBES[fam]}

    def origin(it):
        return it.get("_template") or "Host (สร้างบน host)"

    mon_services, mon_procs, mon_ports = {}, {}, {}
    for it in items:
        if (it.get("key_") or "") in probe_keys:
            continue
        kname, params = parse_key_params(it.get("key_") or "")
        kl = kname.lower()
        if kl in ("service.info", "service_state") and params and params[0]:
            mon_services.setdefault(params[0].lower(), it)
        elif kl.startswith("proc.num") or kl in ("proc.mem", "proc.cpu.util", "proc_info"):
            if params and params[0]:
                mon_procs.setdefault(_norm_proc(params[0]), it)
            if len(params) > 3 and params[3]:
                mon_procs.setdefault(_norm_proc(params[3]), it)
        elif kl in ("net.tcp.port", "net.tcp.listen", "net.tcp.service"):
            p = ""
            if kl == "net.tcp.port" and len(params) > 1 and params[1]:
                p = params[1]
            elif kl == "net.tcp.service" and len(params) > 2 and params[2]:
                p = params[2]
            elif params and params[0]:
                p = params[0]
            if p:
                mon_ports.setdefault(str(p).strip(), it)

    def catalog_for(name, svc_name="", proc_name=""):
        low = (name or "").lower()
        for cat in SOFTWARE_CATALOG:
            if low and any(rx.search(low) for rx in cat["_inc"]) and not any(rx.search(low) for rx in cat["_exc"]):
                return cat
            if svc_name and any(rx.search(svc_name.lower()) for rx in cat["_svc"]):
                return cat
            if proc_name and _norm_proc(proc_name) in {_norm_proc(x) for x in cat["processes"]}:
                return cat
        return None

    def expected_for(cat, kind, svc_name, proc_name):
        if cat:
            tpl = resolve_template(cat["templates"], cat["template_keywords"], all_templates)
            if tpl:
                return tpl["name"], tpl
            if cat["templates"]:
                return cat["templates"][0] + " (ไม่มีบน Zabbix)", None
        if kind == "Service":
            return f"service.info[{svc_name},state]", None
        if kind == "Process":
            return f"proc.num[{proc_name}]", None
        return "", None

    rows, seen = [], set()

    def add_row(kind, name, version, svc_name="", proc_name="", state="", startup=""):
        if not name:
            return
        key = (kind, (svc_name or proc_name or name).lower())
        if key in seen:
            return
        seen.add(key)
        cat = catalog_for(name if kind == "Software" else "", svc_name, proc_name)
        expected, exp_tpl = expected_for(cat, kind, svc_name, proc_name)
        status, template, item_name, item_key, lastclock = NOT_MONITORED, "", "", "", 0
        # 1) a service / process item on the host (own or inherited from a template)
        # service.info key may use the service Name OR its DisplayName, so try both
        it = None
        if kind == "Service":
            it = mon_services.get((svc_name or "").lower()) or (mon_services.get(name.lower()) if name else None)
        if it is None and kind == "Process":
            it = mon_procs.get(_norm_proc(proc_name))
        if it is not None:
            enabled = str(it.get("status", "0")) == "0" and str(it.get("state", "0")) == "0"
            status = MONITORED if enabled else NOT_MONITORED
            template, item_name, item_key = origin(it), it.get("name") or "", it.get("key_") or ""
            lastclock = int(it.get("lastclock") or 0)
            if not enabled:
                item_name += " (disabled)" if str(it.get("status", "0")) != "0" else " (unsupported)"
        # 2) application template linked on the host / application items
        if status != MONITORED and cat:
            for idx, ln in enumerate(linked_lower):
                if ln in [t.lower() for t in cat["templates"]] or any(kw in ln for kw in cat["template_keywords"]):
                    status, template = MONITORED, linked_templates[idx].get("name", "")
                    item_name = item_name or "(items ทั้งหมดของ template)"
                    break
            if status != MONITORED:
                app_items = [x for x in items if any(rx.search(x.get("key_") or "") for rx in cat["_items"])]
                if app_items:
                    status, template = MONITORED, origin(app_items[0])
                    item_name, item_key = app_items[0].get("name") or "", app_items[0].get("key_") or ""
                    lastclock = max((int(x.get("lastclock") or 0) for x in app_items), default=0)
        action = None
        if status != MONITORED:
            if exp_tpl:
                action = {"type": "link_template", "templateid": exp_tpl["templateid"], "name": exp_tpl["name"]}
            elif kind == "Service" and svc_name:
                action = {"type": "add_service", "name": svc_name, "display_name": name, "key": f"service.info[{svc_name},state]"}
            elif kind == "Process" and proc_name:
                action = {"type": "add_service", "name": proc_name, "display_name": proc_name, "key": f"proc.num[{proc_name}]"}
            elif kind == "Software" and name:
                clean_name = re.sub(r"[^\w\.\-]", "", name.split()[0].lower())
                if clean_name:
                    action = {"type": "add_service", "name": clean_name, "display_name": name, "key": f"proc.num[{clean_name}]"}
        last_checked = datetime.fromtimestamp(lastclock).strftime("%Y-%m-%d %H:%M:%S") if lastclock > 0 else ""
        rows.append({"name": name, "kind": kind, "version": version or "", "state": state or "", "startup": startup or "",
                     "service_name": svc_name, "expected": expected or "-", "template": template, "item": item_name,
                     "item_key": item_key, "status": status, "action": action, "last_checked": last_checked,
                     "category": cat["kind"] if cat else ""})

    for sw in inv_software:
        add_row("Software", sw.get("name"), sw.get("version"))
    for sv in inv_services:
        add_row("Service", sv.get("display_name") or sv.get("name"), "", svc_name=sv.get("name"),
                state=sv.get("state"), startup=sv.get("startup"))
    # processes: only meaningful ones (already monitored or a known application) to avoid kernel/system noise
    for pr in inv_processes:
        pn = pr.get("name") or ""
        if _norm_proc(pn) in mon_procs or catalog_for("", proc_name=pn):
            add_row("Process", pn, "", proc_name=pn, state=f"{pr.get('count', 1)} process")
    # monitored items whose service/process was NOT in the machine inventory.
    # Zabbix service.info keys use the service Name or its DisplayName, so match both.
    inv_svc_names = set()
    for sv in inv_services:
        inv_svc_names.add((sv.get("name") or "").lower())
        inv_svc_names.add((sv.get("display_name") or "").lower())
    inv_proc_names = {_norm_proc(p.get("name")) for p in inv_processes}
    for sname, it in mon_services.items():
        raw = parse_key_params(it.get("key_"))[1][0]
        if raw.lower() in inv_svc_names or sname in inv_svc_names:
            continue
        disp = re.sub(r"^(state|status) of service\s+", "", it.get("name") or sname, flags=re.I)
        add_row("Service", disp, "", svc_name=raw, state="")
    for pname, it in mon_procs.items():
        if _norm_proc(pname) in inv_proc_names:
            continue
        add_row("Process", pname, "", proc_name=pname)
    for port, it in mon_ports.items():
        enabled = str(it.get("status", "0")) == "0" and str(it.get("state", "0")) == "0"
        status = MONITORED if enabled else NOT_MONITORED
        tmpl = origin(it)
        iname = it.get("name") or f"TCP Port {port} state"
        ikey = it.get("key_") or f"net.tcp.port[,{port}]"
        lastclock = int(it.get("lastclock") or 0)
        last_checked = datetime.fromtimestamp(lastclock).strftime("%Y-%m-%d %H:%M:%S") if lastclock > 0 else ""
        rows.append({"name": f"TCP Port {port}", "kind": "Port", "version": "", "state": "Listening",
                     "startup": "", "service_name": str(port), "expected": f"net.tcp.port[,{port}]",
                     "template": tmpl, "item": iname, "item_key": ikey, "status": status,
                     "action": (None if status == MONITORED else {"type": "add_port", "port": str(port), "name": f"TCP Port {port}", "key": f"net.tcp.port[,{port}]"}),
                     "last_checked": last_checked, "category": "port"})

    order = {MONITORED: 0, NOT_MONITORED: 1}
    kind_order = {"Software": 0, "Service": 1, "Process": 2, "Port": 3}
    rows.sort(key=lambda r: (order.get(r["status"], 2), kind_order.get(r["kind"], 4), r["name"].lower()))
    return rows


def os_add_spec(check_id: str, family: str) -> Optional[Dict[str, Any]]:
    """Item spec used by the 'Add Monitor' fix for an OS check."""
    for spec in OS_CHECKS:
        if spec["id"] == check_id and spec.get("add"):
            add = spec["add"].get(family) or spec["add"].get("*")
            if add:
                return {**add, "trigger": spec.get("trigger")}
    return None
