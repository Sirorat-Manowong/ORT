# Zabbix & Elastic Host Manager - Workspace Guidelines & Project Rules

This document records the architectural standards, patterns, and troubleshooting rules established for the **Zabbix & Elastic Host Manager** application.

---

## 1. Architecture & Runtime Environment

- **Python Runtime:**
  - Embedded Python located at `.\python\python.exe` (no global pip installed; standard library only + pre-bundled packages like `requests`).
  - Web Server: Built on `http.server.ThreadingMixIn` running in [app.py](file:///c:/Project/Zabbix/app.py) on port 5000 (`http://127.0.0.1:5000`).
  - Always run/restart the server with `.\python\python.exe app.py` as a daemon background task when Python code changes.
- **Frontend Architecture:**
  - Pure Vanilla Web stack (HTML5, Vanilla CSS, Vanilla JavaScript). **Do not introduce Tailwind CSS or heavy JS frameworks.**
  - Files located in `web/`:
    - [web/index.html](file:///c:/Project/Zabbix/web/index.html): Main single-page application structure.
    - [web/app.js](file:///c:/Project/Zabbix/web/app.js): Zabbix core logic, dashboard, template mapping, trigger explorer, and settings.
    - [web/styles.css](file:///c:/Project/Zabbix/web/styles.css): Complete design system with dual dark/light themes.
    - [web/elastic.js](file:///c:/Project/Zabbix/web/elastic.js): Elastic logging module.
  - **Asset Versioning / Cache Busting:** Always bump the version query parameter in `<link>` and `<script>` tags in `index.html` (e.g. `?v=43`) after modifying CSS or JS.

---

## 2. Design & UI Aesthetics Standards

- **Theme Palette:**
  - **Dark Mode (Default):** Deep slate canvas (`--bg: #0b0f19`), elevated cards (`--panel: #121829`), crisp borders (`rgba(255,255,255,.08)`), neon cyan/blue/magenta accents.
  - **Light Mode:** Crisp slate canvas (`--bg: #edf2f7`), pure white cards (`--panel: #ffffff`), slate text (`--text: #0f172a`).
  - Toggled via `document.documentElement.dataset.theme = 'dark' | 'light'`.
- **Navigation & Layout:**
  - Sidebar layout:
    1. Zabbix section (`#dashboard`, `#mapping`, `#reports`)
    2. Elastic section (`#es-overview`, `#es-config`, `#es-indices`, `#es-settings`)
    3. System section: Setting menu (`#settings`) is strictly placed as the last navigation section.
    4. Bottom footer: Logout button (`#logoutLink`) is pinned at the very bottom left.
- **Readability Rules:**
  - Do not use low-contrast or dim gray text for critical data. Use high-contrast font colors with semantic status badges (`tag ok`, `tag warn`, `tag bad`, `tag neutral`, and severity badges `sev-5` to `sev-1`).

---

## 3. Zabbix API & Session Persistence

- **Session File ([`.session.json`](file:///c:/Project/Zabbix/.session.json)):**
  - Session metadata is stored as JSON: `{"url": "...", "token": "...", "is_token": bool, "version": "..."}`.
  - **Resilient Token Handling:** Do not clear `.session.json` on temporary network timeouts. Only clear it if Zabbix explicitly returns an unauthorized/expired error (`client.auth_expired == True`) or when the user explicitly clicks logout (`/api/disconnect`).
- **Browser LocalStorage:**
  - Login URL and username are remembered in `localStorage` (`mz_login_url`, `mz_login_user`, `mz_login_method`) to auto-fill inputs.
- **Form Submission Defense:**
  - Every `<form>` element (especially `#loginForm`) must specify `action="javascript:void(0);"` or handle `onsubmit="return false;"` to guarantee the browser never falls back to native `GET /?` navigation.

---

## 4. JavaScript Coding Constraints & Pitfalls

- **Regex Literals:**
  - In JavaScript regex literals (`/.../`), never use double-escaped backslashes (`\\[` or `\\-`). Use single escapes like `/\[([^\]]+)\]/` or `/[\d._-]+$/`.
  - Double backslashes in literals break parser evaluation and cause fatal `SyntaxError: Invalid regular expression`, causing the entire script not to execute and breaking all event listeners.
- **Headless Edge Verification:**
  - To verify JS syntax and console errors on Windows without Node.js, run headless Microsoft Edge with `--headless=new --enable-logging=stderr --v=1` or inspect console outputs.

---

## 5. Key Feature Workflows

- **Template Mapping:**
  - User searches for software/services -> maps to Zabbix Templates -> links to hosts via `/api/host/templates/link`.
- **Trigger & Monitoring Explorer:**
  - Located at the bottom of Template Mapping.
  - Correlates monitored items with active Zabbix triggers, displaying metric item keys, trigger expressions, problem status, and severity levels.
