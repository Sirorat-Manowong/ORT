# -*- coding: utf-8 -*-
"""
Generate a flow diagram (PNG) describing how the program collects
software & services from a host and shows them. Pure stdlib (no PIL).
A tiny software rasterizer: filled/stroked rounded rects, lines,
arrows and a built-in 5x7 bitmap font scaled up.
"""
import struct, zlib, math

W, H = 1600, 1860
BG = (247, 249, 252)
canvas = [[BG[0], BG[1], BG[2]] for _ in range(W * H)]

def put(x, y, c):
    if 0 <= x < W and 0 <= y < H:
        p = (y * W + x) * 3
        # with alpha blend optional; here opaque
        canvas[y * W + x] = [c[0], c[1], c[2]]

def blend(x, y, c, a):
    if 0 <= x < W and 0 <= y < H:
        idx = y * W + x
        bg = canvas[idx]
        canvas[idx] = [int(c[i] * a + bg[i] * (1 - a)) for i in range(3)]

def hline(x0, x1, y, c, t=1):
    if x1 < x0: x0, x1 = x1, x0
    for yy in range(y - t // 2, y - t // 2 + t):
        for x in range(x0, x1 + 1):
            put(x, yy, c)

def vline(x, y0, y1, c, t=1):
    if y1 < y0: y0, y1 = y1, y0
    for xx in range(x - t // 2, x - t // 2 + t):
        for y in range(y0, y1 + 1):
            put(xx, y, c)

def line(x0, y0, x1, y1, c, t=2):
    dx = abs(x1 - x0); dy = abs(y1 - y0)
    sx = 1 if x0 < x1 else -1
    sy = 1 if y0 < y1 else -1
    err = dx - dy
    while True:
        for ox in range(-(t // 2), t // 2 + 1):
            for oy in range(-(t // 2), t // 2 + 1):
                put(x0 + ox, y0 + oy, c)
        if x0 == x1 and y0 == y1:
            break
        e2 = 2 * err
        if e2 > -dy:
            err -= dy; x0 += sx
        if e2 < dx:
            err += dx; y0 += sy

def fill_rect(x0, y0, x1, y1, c):
    for y in range(y0, y1):
        for x in range(x0, x1):
            put(x, y, c)

def round_rect(x0, y0, x1, y1, r, fillc=None, strokec=None, t=2):
    if fillc:
        for y in range(y0, y1):
            for x in range(x0, x1):
                # corner rounding
                inx = x - x0 if x - x0 < r else (x1 - 1 - x if x1 - 1 - x < r else r)
                iny = y - y0 if y - y0 < r else (y1 - 1 - y if y1 - 1 - y < r else r)
                if inx < r and iny < r:
                    dx = r - inx; dy = r - iny
                    if dx * dx + dy * dy > r * r:
                        continue
                put(x, y, fillc)
    if strokec:
        # straight edges
        hline(x0 + r, x1 - r, y0, strokec, t)
        hline(x0 + r, x1 - r, y1 - 1, strokec, t)
        vline(x0, y0 + r, y1 - r, strokec, t)
        vline(x1 - 1, y0 + r, y1 - r, strokec, t)
        # corners
        for ang in range(0, 91):
            a = math.radians(ang)
            # top-left
            cx, cy = x0 + r, y0 + r
            px = int(cx - r * math.cos(a)); py = int(cy - r * math.sin(a))
            for ox in range(t): put(px + ox, py, strokec); put(px, py + ox, strokec)
            # top-right
            cx, cy = x1 - 1 - r, y0 + r
            px = int(cx + r * math.cos(a)); py = int(cy - r * math.sin(a))
            for ox in range(t): put(px - ox, py, strokec); put(px, py + ox, strokec)
            # bottom-left
            cx, cy = x0 + r, y1 - 1 - r
            px = int(cx - r * math.cos(a)); py = int(cy + r * math.sin(a))
            for ox in range(t): put(px + ox, py, strokec); put(px, py - ox, strokec)
            # bottom-right
            cx, cy = x1 - 1 - r, y1 - 1 - r
            px = int(cx + r * math.cos(a)); py = int(cy + r * math.sin(a))
            for ox in range(t): put(px - ox, py, strokec); put(px, py - ox, strokec)

def arrow(x0, y0, x1, y1, c, t=3):
    line(x0, y0, x1, y1, c, t)
    ang = math.atan2(y1 - y0, x1 - x0)
    ah = 14
    for da in (math.radians(150), math.radians(-150)):
        ax = int(x1 + ah * math.cos(ang + da))
        ay = int(y1 + ah * math.sin(ang + da))
        line(x1, y1, ax, ay, c, t)

# ---- 5x7 font ----
FONT = {
 'A':["01110","10001","10001","11111","10001","10001","10001"],
 'B':["11110","10001","10001","11110","10001","10001","11110"],
 'C':["01110","10001","10000","10000","10000","10001","01110"],
 'D':["11100","10010","10001","10001","10001","10010","11100"],
 'E':["11111","10000","10000","11110","10000","10000","11111"],
 'F':["11111","10000","10000","11110","10000","10000","10000"],
 'G':["01110","10001","10000","10111","10001","10001","01111"],
 'H':["10001","10001","10001","11111","10001","10001","10001"],
 'I':["01110","00100","00100","00100","00100","00100","01110"],
 'J':["00111","00010","00010","00010","00010","10010","01100"],
 'K':["10001","10010","10100","11000","10100","10010","10001"],
 'L':["10000","10000","10000","10000","10000","10000","11111"],
 'M':["10001","11011","10101","10101","10001","10001","10001"],
 'N':["10001","11001","10101","10011","10001","10001","10001"],
 'O':["01110","10001","10001","10001","10001","10001","01110"],
 'P':["11110","10001","10001","11110","10000","10000","10000"],
 'Q':["01110","10001","10001","10001","10101","10010","01101"],
 'R':["11110","10001","10001","11110","10100","10010","10001"],
 'S':["01111","10000","10000","01110","00001","00001","11110"],
 'T':["11111","00100","00100","00100","00100","00100","00100"],
 'U':["10001","10001","10001","10001","10001","10001","01110"],
 'V':["10001","10001","10001","10001","10001","01010","00100"],
 'W':["10001","10001","10001","10101","10101","11011","10001"],
 'X':["10001","10001","01010","00100","01010","10001","10001"],
 'Y':["10001","10001","01010","00100","00100","00100","00100"],
 'Z':["11111","00001","00010","00100","01000","10000","11111"],
 '0':["01110","10001","10011","10101","11001","10001","01110"],
 '1':["00100","01100","00100","00100","00100","00100","01110"],
 '2':["01110","10001","00001","00010","00100","01000","11111"],
 '3':["11110","00001","00001","01110","00001","00001","11110"],
 '4':["00010","00110","01010","10010","11111","00010","00010"],
 '5':["11111","10000","11110","00001","00001","10001","01110"],
 '6':["00110","01000","10000","11110","10001","10001","01110"],
 '7':["11111","00001","00010","00100","01000","01000","01000"],
 '8':["01110","10001","10001","01110","10001","10001","01110"],
 '9':["01110","10001","10001","01111","00001","00010","01100"],
 '.':["00000","00000","00000","00000","00000","00110","00110"],
 ',':["00000","00000","00000","00000","00110","00110","01100"],
 ':':["00000","00110","00110","00000","00110","00110","00000"],
 '/':["00001","00010","00010","00100","01000","01000","10000"],
 '-':["00000","00000","00000","11111","00000","00000","00000"],
 '+':["00000","00100","00100","11111","00100","00100","00000"],
 '(':["00010","00100","01000","01000","01000","00100","00010"],
 ')':["01000","00100","00010","00010","00010","00100","01000"],
 '[':["01110","01000","01000","01000","01000","01000","01110"],
 ']':["01110","00010","00010","00010","00010","00010","01110"],
 '&':["01100","10010","10100","01000","10101","10010","01101"],
 '?':["01110","10001","00001","00010","00100","00000","00100"],
 '%':["11001","11010","00100","01000","10011","10011","00000"],
 '>':["10000","01000","00100","00010","00100","01000","10000"],
 '<':["00001","00010","00100","01000","00100","00010","00001"],
 '=':["00000","00000","11111","00000","11111","00000","00000"],
 ' ':["00000","00000","00000","00000","00000","00000","00000"],
 "'":["00100","00100","00100","00000","00000","00000","00000"],
 '#':["01010","01010","11111","01010","11111","01010","01010"],
 '!':["00100","00100","00100","00100","00100","00000","00100"],
}

def text(x, y, s, c, scale=2, spacing=1):
    cx = x
    for ch in s.upper():
        g = FONT.get(ch, FONT['?'] if ch not in FONT else FONT[ch])
        g = FONT.get(ch, FONT.get(' '))
        for ry, row in enumerate(g):
            for rx, bit in enumerate(row):
                if bit == '1':
                    for sx in range(scale):
                        for sy in range(scale):
                            put(cx + rx * scale + sx, y + ry * scale + sy, c)
        cx += (5 + spacing) * scale
    return cx

def text_w(s, scale=2, spacing=1):
    return len(s) * (5 + spacing) * scale

def ctext(cx, y, s, c, scale=2):
    w = text_w(s, scale)
    text(cx - w // 2, y, s, c, scale)

# ---------- colors ----------
INK = (33, 43, 54)
MUTED = (99, 110, 123)
BLUE = (47, 111, 237); BLUE_BG = (224, 235, 255)
GREEN = (22, 163, 127); GREEN_BG = (219, 245, 238)
PURP = (124, 77, 219); PURP_BG = (238, 230, 252)
ORANGE = (214, 128, 20); ORANGE_BG = (252, 240, 220)
GREY = (120, 130, 142); GREY_BG = (233, 237, 242)
RED = (210, 70, 70); RED_BG = (252, 228, 228)
WHITE = (255, 255, 255)

def box(x, y, w, h, title, lines, fillc, strokec, tcol=INK, tscale=3, lscale=2):
    round_rect(x, y, x + w, y + h, 16, fillc, strokec, 3)
    ctext(x + w // 2, y + 18, title, strokec, tscale)
    ly = y + 18 + tscale * 7 + 14
    for ln in lines:
        ctext(x + w // 2, ly, ln, tcol, lscale)
        ly += lscale * 7 + 8
    return (x, y, w, h)

# ---------- title ----------
ctext(W // 2, 30, "HOW THE PROGRAM COLLECTS SOFTWARE & SERVICES", INK, 4)
ctext(W // 2, 78, "ZABBIX HOST MANAGER - INVENTORY FLOW", MUTED, 2)

# ---------- 1. Browser ----------
box(600, 120, 400, 110, "1) WEB DASHBOARD (BROWSER)",
    ["USER OPENS A HOST, TAB 'SOFTWARE'",
     "GET /API/HOST/SOFTWARE-INVENTORY?HOSTID=.."],
    BLUE_BG, BLUE)
arrow(800, 230, 800, 285, BLUE, 3)

# ---------- 2. app.py ----------
box(540, 290, 520, 120, "2) APP.PY  (HTTP SERVER)",
    ["BUILD_SOFTWARE_INVENTORY(HOSTID)",
     "GET HOST + ITEMS, THEN CALL",
     "CLIENT.COLLECT_INVENTORY(...)"],
    GREEN_BG, GREEN)
arrow(800, 410, 800, 465, GREEN, 3)

# ---------- 3. collect_inventory ----------
box(500, 470, 600, 110, "3) COLLECT_INVENTORY (ZABBIX_API.PY)",
    ["DECIDE OS FAMILY (WINDOWS/LINUX/AIX)",
     "TRY 2 SOURCES IN ORDER  ->"],
    PURP_BG, PURP)
# split to two sources
arrow(640, 580, 430, 650, PURP, 3)
arrow(960, 580, 1180, 650, PURP, 3)
ctext(500, 612, "SOURCE A (FIRST)", MUTED, 2)
ctext(1120, 612, "SOURCE B (FALLBACK)", MUTED, 2)

# ---------- Source A: Zabbix stored values ----------
box(120, 660, 620, 230, "A) VALUES ALREADY IN ZABBIX",
    ["READ ITEM 'LASTVALUE' FROM HOST ITEMS",
     "MATCH PROBE KEYS BY OS:",
     "WIN:  REGISTRY.GET[..UNINSTALL..]  (SOFTWARE)",
     "      WMI.GETALL[.. WIN32_SERVICE] (SERVICES)",
     "LINUX: SYSTEM.SW.PACKAGES , PROC.GET[]",
     "AIX:  SYSTEM.RUN[LSLPP] , SYSTEM.RUN[PS]",
     "THE ZABBIX AGENT ON THE HOST COLLECTED",
     "THESE EARLIER AND STORED THEM ON SERVER"],
    ORANGE_BG, ORANGE, lscale=2, tscale=2)

# ---------- Source B: direct agent ----------
box(860, 660, 620, 230, "B) DIRECT PASSIVE AGENT QUERY",
    ["ONLY IF ENABLED + KEY MISSING IN ZABBIX",
     "OPEN TCP TO AGENT IP:10050 DIRECTLY",
     "ASK SAME KEYS LIVE (THREADPOOL, 6S)",
     "QUERY_AGENT(ADDR, KEY, PORT)",
     "IS_SAFE_ADDRESS() GUARDS THE TARGET",
     "RESULT MERGED INTO THE SAME LISTS",
     "SOURCE TAGGED AS 'AGENT'"],
    BLUE_BG, BLUE, lscale=2, tscale=2)

arrow(430, 890, 640, 955, ORANGE, 3)
arrow(1180, 890, 960, 955, BLUE, 3)

# ---------- 4. parse ----------
box(500, 960, 600, 150, "4) PARSE RAW AGENT OUTPUT",
    ["_PARSE_SOFTWARE(RAW) -> NAME + VERSION",
     "_PARSE_SERVICES(RAW) -> SERVICE NAME/STATE",
     "_PARSE_PROCESSES(RAW) -> RUNNING PROCS",
     "DE-DUPLICATE BY NAME (CASE-INSENSITIVE)"],
    GREEN_BG, GREEN, lscale=2, tscale=2)
arrow(800, 1110, 800, 1165, GREEN, 3)

# ---------- 5. snapshot ----------
box(480, 1170, 640, 140, "5) INVENTORY SNAPSHOT",
    ["{ OS_FAMILY, SOFTWARE[], SERVICES[],",
     "  PROCESSES[], SOURCE, COLLECTED_AT }",
     "CACHED (INVENTORY_CACHE_SECONDS)",
     "SO REPEATED OPENS ARE FAST"],
    PURP_BG, PURP, lscale=2, tscale=2)
arrow(800, 1310, 800, 1365, PURP, 3)

# ---------- 6. evaluate / map ----------
box(440, 1370, 720, 150, "6) MAP TO STANDARD  (MONITORING_STANDARD.PY)",
    ["COMPARE EACH SOFTWARE/SERVICE TO CATALOG",
     "SOFTWARE_INVENTORY_ROWS(): EXPECTED TEMPLATE,",
     "REAL LINKED TEMPLATE/ITEM, MONITORED Y/N",
     "COMPUTE COVERAGE % PER SECTION"],
    GREEN_BG, GREEN, lscale=2, tscale=2)
arrow(800, 1520, 800, 1575, GREEN, 3)

# ---------- 7. back to browser ----------
box(560, 1580, 480, 120, "7) JSON BACK TO BROWSER",
    ["ROWS RENDERED AS A TABLE:",
     "SOFTWARE / SERVICE | VERSION |",
     "EXPECTED TEMPLATE | MONITORED?"],
    BLUE_BG, BLUE, lscale=2, tscale=2)

# ---------- legend ----------
lx, ly = 90, 1760
def chip(x, y, c, label):
    round_rect(x, y, x + 26, y + 26, 6, c, c, 1)
    text(x + 36, y + 6, label, MUTED, 2)
chip(lx, ly, ORANGE, "DATA FROM ZABBIX STORE")
chip(lx, ly + 40, BLUE, "LIVE AGENT / BROWSER")
chip(lx, ly + 80, PURP, "CORE LOGIC")
chip(lx + 520, ly, GREEN, "SERVER PROCESSING")

# ---------- encode PNG ----------
def write_png(path, width, height, pix):
    raw = bytearray()
    for y in range(height):
        raw.append(0)
        row = pix[y * width:(y + 1) * width]
        for px in row:
            raw += bytes(px)
    comp = zlib.compress(bytes(raw), 9)
    def chunk(typ, data):
        c = struct.pack(">I", len(data)) + typ + data
        c += struct.pack(">I", zlib.crc32(typ + data) & 0xffffffff)
        return c
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    with open(path, "wb") as f:
        f.write(sig)
        f.write(chunk(b"IHDR", ihdr))
        f.write(chunk(b"IDAT", comp))
        f.write(chunk(b"IEND", b""))

write_png(r"c:\Project\Zabbix\inventory_flow.png", W, H, canvas)
print("written inventory_flow.png", W, H)
