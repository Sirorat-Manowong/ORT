"""
Zabbix Bulk Host Importer (CLI Tool)
Can be run from command prompt or terminal.
Example:
    python bulk_import.py
    python bulk_import.py --csv hosts_sample.csv --url http://192.168.1.50/zabbix --user Admin --password zabbix
"""
import argparse
import csv
import os
import sys
import getpass
from zabbix_api import ZabbixClient

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

def run_import():
    parser = argparse.ArgumentParser(description="Bulk add hosts to Zabbix Server from a CSV file.")
    parser.add_argument("--url", help="Zabbix Server URL (e.g. http://192.168.1.100/zabbix or http://192.168.1.100)")
    parser.add_argument("--user", help="Zabbix Username (e.g. Admin)")
    parser.add_argument("--password", help="Zabbix Password")
    parser.add_argument("--token", help="Zabbix API Token (optional, alternative to user/pass)")
    parser.add_argument("--csv", help="Path to CSV file with host definitions")

    args = parser.parse_args()

    print("==================================================")
    print("      ZABBIX BULK HOST IMPORTER (CLI)")
    print("==================================================")

    url = args.url
    if not url:
        url = input("Enter Zabbix URL (e.g. http://192.168.1.100): ").strip()

    token = args.token
    user = args.user
    pwd = args.password

    if not token and not user:
        choice = input("Authenticate with [1] Username/Password or [2] API Token? (1/2): ").strip()
        if choice == "2":
            token = input("Enter API Token: ").strip()
        else:
            user = input("Enter Username [Admin]: ").strip() or "Admin"
            pwd = getpass.getpass("Enter Password: ")

    csv_path = args.csv
    if not csv_path:
        csv_path = input("Enter CSV file path [hosts_sample.csv]: ").strip() or "hosts_sample.csv"

    if not os.path.exists(csv_path):
        print(f"[!] Error: CSV file '{csv_path}' not found!")
        sys.exit(1)

    print(f"\n[*] Connecting to Zabbix at {url}...")
    client = ZabbixClient(url)
    ok, msg = client.login(username=user, password=pwd, api_token=token)
    if not ok:
        print(f"[-] Connection failed: {msg}")
        sys.exit(1)

    print(f"[+] Logged in successfully! (Zabbix version: {client.api_version})")

    # Read CSV
    hosts_to_import = []
    with open(csv_path, mode="r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for r in reader:
            clean_r = {k.strip().lower(): v.strip() for k, v in r.items() if k}
            host = clean_r.get("host") or clean_r.get("hostname")
            ip = clean_r.get("ip") or clean_r.get("ip_address")
            if host and ip:
                hosts_to_import.append({
                    "host": host,
                    "name": clean_r.get("name") or host,
                    "ip": ip,
                    "port": clean_r.get("port") or "10050",
                    "group_name": clean_r.get("group_name") or clean_r.get("group"),
                    "template_name": clean_r.get("template_name") or clean_r.get("template"),
                    "description": clean_r.get("description", "")
                })

    print(f"\n[*] Found {len(hosts_to_import)} hosts to import from '{csv_path}'.")
    if not hosts_to_import:
        print("No valid host rows found.")
        sys.exit(0)

    confirm = input("Proceed with host creation? (y/N): ").strip().lower()
    if confirm != "y":
        print("Cancelled by user.")
        sys.exit(0)

    print("\n---------------- Starting Import ----------------")
    success_count = 0
    fail_count = 0

    for idx, item in enumerate(hosts_to_import, 1):
        h_name = item["host"]
        h_ip = item["ip"]
        h_port = item["port"]
        g_name = item["group_name"]
        t_name = item["template_name"]

        ok, res_msg, hid = client.create_host(
            host=h_name,
            ip=h_ip,
            port=h_port,
            name=item["name"],
            group_names=[g_name] if g_name else None,
            template_names=[t_name] if t_name else None,
            description=item["description"]
        )

        if ok:
            print(f"[{idx}/{len(hosts_to_import)}] [+] SUCCESS: {h_name} ({h_ip}) -> Host ID: {hid}")
            success_count += 1
        else:
            print(f"[{idx}/{len(hosts_to_import)}] [-] FAILED: {h_name} ({h_ip}) -> {res_msg}")
            fail_count += 1

    print("-------------------------------------------------")
    print(f"[*] Import Completed! Total: {len(hosts_to_import)} | Success: {success_count} | Failed: {fail_count}")

if __name__ == "__main__":
    run_import()
