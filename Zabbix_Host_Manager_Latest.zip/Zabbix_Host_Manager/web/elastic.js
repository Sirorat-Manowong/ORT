/**
 * Monitoring Zabbix — Elastic / Filebeat section
 * Pages: Log Overview · Filebeat Config · Index & Space · Elastic Settings
 * Server list, Application (appid : appname) and OS always come from Zabbix (hosts / currentHost in app.js).
 */

let esStatusCache = {};      // hostid -> /api/elastic/host-status result
let esConfigDraft = null;    // { hostid, env, inputs[] } being edited

const ES_STATUS_TAG = {
  "OK": '<span class="tag ok">● OK</span>',
  "Missing": '<span class="tag bad">✕ Missing</span>',
  "Unknown": '<span class="tag warn">? Unknown</span>',
  "Not Required": '<span class="tag neutral">— N/A</span>',
};

function esTag(status) { return ES_STATUS_TAG[status] || escapeHtml(status); }

function esNeedHost(title) {
  return `<section class="panel"><div class="paneltitle">${title}</div>
    <p class="muted">เลือก Application และ Server ด้านบนก่อน (รายชื่อเครื่องดึงจาก Zabbix)</p></section>`;
}

async function esApi(path, method = "GET", body = null) {
  const opts = { method, headers: { "Content-Type": "application/json" } };
  if (body) opts.body = JSON.stringify(body);
  const resp = await fetch(`${API_BASE}${path}`, opts);
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok || data.success === false) throw new Error(data.error || data.message || `HTTP ${resp.status}`);
  return data;
}

function esHostsOfApp(appId) {
  return appId ? hosts.filter((h) => h.appId === appId) : [];
}

function renderElasticPage(page) {
  if (page === "es-overview") return renderEsOverview();
  if (page === "es-config") return renderEsConfig();
  if (page === "es-indices") return renderEsIndices();
  if (page === "es-settings") return renderEsSettings();
}

// =========================================================
// 1) Log Overview
//    Fleet table (auto-checked) -> selected host: 3 steps (Filebeat -> Config -> Elasticsearch)
//    -> one log-path table. Each fact is shown once.
// =========================================================
const ES_GROUPS = [
  { id: "filebeat", title: "① Filebeat บนเครื่อง", hint: "จาก Zabbix item proc.num",
    checks: ["access", "supported", "installed", "running"] },
  { id: "config", title: "② Config filebeat.yml", hint: "จาก Zabbix item Config filebeat.yml",
    checks: ["inputs", "config_read", "config_paths", "config_index", "paths_exist", "harvesting"] },
  { id: "elastic", title: "③ Elasticsearch / Kibana", hint: "จาก Elastic Settings",
    checks: ["elastic", "index_json", "index_plaintext", "space", "data_view", "logs"] },
];

const ES_ACTION_LABEL = {
  install_script: "⇩ Install script", edit_config: "✎ กำหนด log path", settings: "⚙ ตั้งค่า Elastic",
  create_index: "＋ สร้าง index", create_space: "＋ สร้าง Space",
};

function esActionBtn(a, primary = false) {
  if (!a || !ES_ACTION_LABEL[a.type]) return "";
  const cls = primary ? "" : (a.type.startsWith("create_") ? "mini-btn add" : "mini-btn");
  return `<button class="${cls}" data-es-act='${escapeHtml(JSON.stringify(a))}'>${ES_ACTION_LABEL[a.type]}</button>`;
}

// Overall state of one host from its checks
function esOverall(r) {
  if (!r) return { cls: "neutral", label: "ยังไม่ตรวจ" };
  const counted = r.checks.filter((c) => c.status === "OK" || c.status === "Missing");
  if (!counted.length) return { cls: "neutral", label: "ไม่มีข้อมูล" };
  const missing = counted.filter((c) => c.status === "Missing").length;
  if (!missing) return { cls: "ok", label: "พร้อม" };
  return { cls: "bad", label: `ยังไม่พร้อม · ขาด ${missing}` };
}

function esGroupState(r, group) {
  const list = r.checks.filter((c) => group.checks.includes(c.id));
  if (!list.length) return "Not Required";
  if (list.some((c) => c.status === "Missing")) return "Missing";
  if (list.every((c) => c.status === "Not Required")) return "Not Required";
  if (list.some((c) => c.status === "Unknown")) return list.some((c) => c.status === "OK") ? "Partial" : "Unknown";
  return "OK";
}

const ES_GROUP_TAG = {
  OK: '<span class="tag ok">● OK</span>', Missing: '<span class="tag bad">✕ ไม่ผ่าน</span>',
  Partial: '<span class="tag warn">▲ บางส่วน</span>', Unknown: '<span class="tag neutral">? ไม่มีข้อมูล</span>',
  "Not Required": '<span class="tag neutral">— ไม่ต้องใช้</span>',
};

async function renderEsOverview() {
  const appHostsList = currentHost ? esHostsOfApp(currentHost.appId) : [];
  extra.innerHTML = `
    <section class="panel">
      <div class="paneltitle">◉ Log Monitoring Overview
        <span class="row-actions">${appHostsList.length ? '<button class="secondary" id="esCheckAll">⟳ ตรวจใหม่ทั้งหมด</button>' : ""}</span></div>
      ${currentHost ? `<p class="muted">Application <b>${escapeHtml(appLabelFor(currentHost) || "-")}</b> · ${appHostsList.length} เครื่อง · คลิกแถวเพื่อดูรายละเอียด</p>
      <div class="tablewrap"><table class="data es-fleet"><thead><tr>
        <th>Host</th><th>Install filebeat</th><th>Running</th><th>filebeat.yml</th><th>Elasticsearch</th><th>สถานะ</th></tr></thead>
        <tbody id="esFleet">${esFleetRows(appHostsList)}</tbody></table></div>`
      : '<p class="muted">เลือก Application และ Server ด้านบน (รายชื่อเครื่องดึงจาก Zabbix)</p>'}
    </section>
    ${currentHost ? '<section class="panel" id="esHostPanel"><p class="muted">กำลังตรวจสอบ...</p></section>' : ""}`;
  $("#esCheckAll")?.addEventListener("click", (e) => esCheckHosts(appHostsList, e.currentTarget, true));
  $("#esFleet")?.addEventListener("click", (e) => {
    const tr = e.target.closest("[data-es-host]");
    if (!tr || (currentHost && tr.dataset.esHost === currentHost.id)) return;
    selectHost(tr.dataset.esHost).then(() => renderEsOverview());
  });
  if (!currentHost) return;
  await esLoadHostPanel();
  // Fill the rest of the fleet automatically (only hosts not checked yet)
  const pending = appHostsList.filter((h) => !esStatusCache[h.hostid]);
  if (pending.length && pending.length <= 30) esCheckHosts(pending, null, false);
}

function esFleetRows(list) {
  if (!list.length) return '<tr><td colspan="6" class="empty-cell">ไม่มีเครื่อง</td></tr>';
  return list.map((h) => {
    const r = esStatusCache[h.hostid];
    const dash = '<span class="muted">…</span>';
    const pill = (v, yes, no) => (v === true ? `<span class="tag ok">● ${yes}</span>` : v === false ? `<span class="tag bad">✕ ${no}</span>` : '<span class="tag neutral">? ไม่มีข้อมูล</span>');
    const cfg = !r ? dash : r.filebeat.config_source === "none" ? '<span class="tag neutral">? ไม่มี item</span>'
      : ES_GROUP_TAG[esGroupState(r, ES_GROUPS[1])];
    const ov = esOverall(r);
    return `<tr data-es-host="${h.id}" class="es-row ${currentHost && currentHost.id === h.id ? "row-selected" : ""}">
      <td><b>${escapeHtml(h.name)}</b></td>
      <td>${r ? pill(r.filebeat.installed, "Install", "Not Install") : dash}</td>
      <td>${r ? pill(r.filebeat.running, "Running", "Not running") : dash}</td>
      <td>${cfg}</td>
      <td>${r ? ES_GROUP_TAG[esGroupState(r, ES_GROUPS[2])] : dash}</td>
      <td>${r ? `<span class="tag ${ov.cls}">${escapeHtml(ov.label)}</span>${r.pct != null ? ` <span class="muted">${r.pct}%</span>` : ""}` : dash}</td></tr>`;
  }).join("");
}

async function esCheckHosts(list, btn, refresh) {
  if (!list.length) return;
  if (btn) btn.disabled = true;
  for (const [i, h] of list.entries()) {
    if (btn) btn.textContent = `ตรวจ ${i + 1}/${list.length}...`;
    try { esStatusCache[h.hostid] = await esApi(`/api/elastic/host-status?hostid=${h.hostid}${refresh ? "&refresh=1" : ""}`); } catch (err) { /* next host */ }
    const tb = $("#esFleet");
    if (!tb) return;  // user left the page
    tb.innerHTML = esFleetRows(esHostsOfApp(currentHost ? currentHost.appId : h.appId));
  }
  if (btn) { btn.disabled = false; btn.textContent = "⟳ ตรวจใหม่ทั้งหมด"; }
  if (refresh && currentHost && esStatusCache[currentHost.hostid] && $("#esHostPanel")) {
    $("#esHostPanel").innerHTML = esHostPanelHTML(esStatusCache[currentHost.hostid]);
  }
}

async function esLoadHostPanel(refresh = false) {
  const panel = $("#esHostPanel");
  if (!panel || !currentHost) return;
  try {
    const r = await esApi(`/api/elastic/host-status?hostid=${currentHost.hostid}${refresh ? "&refresh=1" : ""}`);
    esStatusCache[currentHost.hostid] = r;
    const tb = $("#esFleet");
    if (tb) tb.innerHTML = esFleetRows(esHostsOfApp(currentHost.appId));
    panel.innerHTML = esHostPanelHTML(r);
  } catch (err) {
    panel.innerHTML = `<p class="bad">ตรวจสอบไม่สำเร็จ: ${escapeHtml(err.message)}</p>`;
  }
}

// glob (* ?) match for log paths, case-insensitive, separator-agnostic
function esGlob(pattern, path) {
  const norm = (x) => String(x || "").trim().replace(/\\/g, "/").replace(/\/+$/, "").toLowerCase();
  const rx = new RegExp("^" + norm(pattern).replace(/[.+^${}()|[\]]/g, "\\$&").replace(/\*/g, "[^/]*").replace(/\?/g, ".") + "$");
  return rx.test(norm(path));
}

function esPathRows(r) {
  const on = r.filebeat.config_on_host;
  const ship = r.elastic.shipping;
  const ymlPaths = on ? on.paths : [];
  const shipped = ship ? ship.files : null;
  const yes = '<span class="tag ok">✓</span>', no = '<span class="tag bad">✕</span>', na = '<span class="muted">—</span>';
  const same = (a, b) => esGlob(a, b) || esGlob(b, a);
  const rows = [];
  for (const i of r.config.inputs || []) {
    const inYml = on ? ymlPaths.some((p) => same(i.path, p)) : null;
    const inEs = shipped ? shipped.some((f) => esGlob(i.path, f)) : null;
    rows.push(`<tr><td class="mono">${escapeHtml(i.path)}</td><td><span class="tag neutral">${escapeHtml(i.type)}</span></td>
      <td>${yes}</td><td>${inYml === null ? na : inYml ? yes : no}</td><td>${inEs === null ? na : inEs ? yes : no}</td></tr>`);
  }
  for (const p of ymlPaths) {
    if ((r.config.inputs || []).some((i) => same(i.path, p))) continue;
    const inEs = shipped ? shipped.some((f) => esGlob(p, f)) : null;
    rows.push(`<tr class="es-extra"><td class="mono">${escapeHtml(p)}</td><td><span class="muted">-</span></td>
      <td>${no}<span class="cell-note">มีใน filebeat.yml แต่ยังไม่ได้กำหนดในโปรแกรม</span></td><td>${yes}</td><td>${inEs === null ? na : inEs ? yes : no}</td></tr>`);
  }
  return rows.join("") || '<tr><td colspan="5" class="empty-cell">ยังไม่มี log path ทั้งในโปรแกรมและใน filebeat.yml</td></tr>';
}

function esHostPanelHTML(r) {
  const ov = esOverall(r);
  const next = r.checks.find((c) => c.status === "Missing" && c.action) || r.checks.find((c) => c.status === "Missing");
  const cfgText = (r.zabbix_filebeat && r.zabbix_filebeat.config_text) || "";
  const groups = ES_GROUPS.map((g) => {
    const list = r.checks.filter((c) => g.checks.includes(c.id));
    if (!list.length || list.every((c) => c.status === "Not Required")) return "";
    return `<div class="es-step es-step-${esGroupState(r, g).toLowerCase().replace(/\s+/g, "-")}">
      <div class="es-step-head"><b>${g.title}</b>${ES_GROUP_TAG[esGroupState(r, g)]}</div>
      <div class="cell-note">${g.hint}</div>
      ${list.filter((c) => c.status !== "Not Required").map((c) => `<div class="es-check">
          <div class="es-check-line">${esTag(c.status)} <span>${escapeHtml(c.name.replace(/\s*\((จาก Zabbix|จากเครื่อง)\)/, ""))}</span></div>
          ${c.detail ? `<div class="cell-note">${escapeHtml(c.detail)}</div>` : ""}
          ${c.status !== "OK" && c.action && c !== next ? `<div>${esActionBtn(c.action)}</div>` : ""}
        </div>`).join("")}
    </div>`;
  }).join("");
  return `
    <div class="paneltitle">${escapeHtml(r.host.name)}
      <span class="row-actions"><span class="tag ${ov.cls} es-big">${escapeHtml(ov.label)}</span>
      ${r.pct != null ? `<b class="es-pct">${r.pct}%</b>` : ""}
      <button class="secondary" id="esRecheck">⟳ ตรวจใหม่</button></span></div>
    ${next ? `<div class="es-next"><span>ขั้นต่อไป:</span> <b>${escapeHtml(next.name.replace(/\s*\((จาก Zabbix|จากเครื่อง)\)/, ""))}</b>
      <span class="muted">${escapeHtml(next.detail || "")}</span> ${esActionBtn(next.action, true)}</div>` : ""}
    ${r.supported ? "" : '<div class="inv-banner"><span class="bad">AIX ไม่รองรับ Filebeat</span> — ใช้ rsyslog (imfile) → Logstash แทน</div>'}
    <div class="es-steps">${groups}</div>
    <h4 class="es-sub">Log path</h4>
    <div class="tablewrap"><table class="data"><thead><tr><th>Path</th><th>ประเภท</th><th>กำหนดในโปรแกรม</th><th>ใน filebeat.yml</th><th>ส่งเข้า Elasticsearch</th></tr></thead>
      <tbody>${esPathRows(r)}</tbody></table></div>
    ${cfgText ? `<details class="others"><summary>ดู filebeat.yml (จาก Zabbix · ${cfgText.split("\n").length} บรรทัด)</summary><pre class="es-log">${escapeHtml(cfgText)}</pre></details>` : ""}
    ${r.errors.length ? `<details class="others"><summary>ข้อผิดพลาดการเชื่อมต่อ (${r.errors.length})</summary><ul class="inv-notes">${r.errors.map((e) => `<li>${escapeHtml(e)}</li>`).join("")}</ul></details>` : ""}
    <p class="muted small">ตรวจเมื่อ ${escapeHtml(r.generated_at)}</p>`;
}

// Shared action buttons (overview + config pages)
document.addEventListener("click", async (e) => {
  const b = e.target.closest("[data-es-act]");
  if (!b || !currentHost) return;
  e.preventDefault();
  const a = JSON.parse(b.dataset.esAct);
  const r = esStatusCache[currentHost.hostid];
  try {
    if (a.type === "noop") {
    } else if (a.type === "install_script") {
      window.open(`${API_BASE}/api/elastic/file?hostid=${currentHost.hostid}&kind=script&os=${(r && r.os_family) || "linux"}`, "_blank", "noopener");
    } else if (a.type === "edit_config") {
      navTo("es-config");
    } else if (a.type === "settings") {
      navTo("es-settings");
    } else if (a.type === "create_index") {
      if (!confirm(`สร้าง index ${a.index} บน Elasticsearch?`)) return;
      b.disabled = true;
      const res = await esApi("/api/elastic/index", "POST", { action: "create", name: a.index });
      showToast(res.message);
      esLoadHostPanel();
    } else if (a.type === "create_space") {
      if (!confirm(`สร้าง Kibana Space ${a.space} พร้อม data view สำหรับ ${appLabelFor(currentHost)}?`)) return;
      b.disabled = true;
      const res = await esApi("/api/elastic/space", "POST", { appid: currentHost.appId, appname: currentHost.appName, env: r ? r.env : "" });
      showToast(res.message);
      esLoadHostPanel();
    }
  } catch (err) {
    showToast(err.message, true);
    b.disabled = false;
  }
});

document.addEventListener("click", (e) => {
  if (e.target.closest("#esRecheck")) esLoadHostPanel(true);
});

// =========================================================
// 2) Filebeat Config (paths, log type, index names, generate files)
// =========================================================
async function renderEsConfig() {
  if (!currentHost) {
    extra.innerHTML = esNeedHost("✎ Filebeat Config");
    return;
  }
  let data;
  try { data = await esApi(`/api/elastic/host-config?hostid=${currentHost.hostid}`); } catch (err) { showToast(err.message, true); return; }
  const prevOs = esConfigDraft && esConfigDraft.hostid === currentHost.hostid ? esConfigDraft.os : "";
  esConfigDraft = { hostid: currentHost.hostid, env: data.env, os: prevOs, inputs: (data.config.inputs || []).map((i) => ({ ...i })), names: data.index_names };
  const known = esStatusCache[currentHost.hostid];
  const fam = (known && known.os_family) || esConfigDraft.os || "linux";
  esConfigDraft.os = fam;
  extra.innerHTML = `
    <section class="panel">
      <div class="paneltitle">✎ Filebeat Config — ${escapeHtml(currentHost.name)}
        <span class="muted">App ${escapeHtml(data.app.appid ? data.app.appid + " : " + data.app.appname : "ไม่พบ group appid : appname")}</span></div>
      ${fam === "aix" ? '<div class="inv-banner"><span class="bad">AIX ไม่รองรับ Filebeat</span> — ไฟล์ที่สร้างจะเป็นเอกสารอ้างอิงสำหรับ rsyslog/Logstash</div>' : ""}
      ${!data.app.appid ? '<div class="inv-banner"><span class="warn">เครื่องนี้ไม่มี Host group รูปแบบ "appid : appname" ใน Zabbix — ชื่อ index จะไม่ถูกต้อง</span></div>' : ""}
      <div class="rep-row">
        <label class="rep-label">Environment
          <select class="form-ctl" id="esEnv"><option value="prod">Production (prod)</option><option value="nonprod">Non Production (nonprod)</option></select></label>
        <label class="rep-label">OS ของเครื่อง (สำหรับ install script)
          <select class="form-ctl" id="esOs"><option value="linux">Linux</option><option value="windows">Windows</option><option value="aix">AIX</option></select>
          <span class="cell-note">${known && known.os_family ? "ตรวจจากเครื่องจริง: " + escapeHtml(known.os_name || known.os_family) : "ยังไม่ได้ตรวจเครื่อง — เลือกเอง หรือกดตรวจที่ Log Overview"}</span></label>
        <div class="es-names" id="esNames"></div>
      </div>
      <div class="tablewrap"><table class="data"><thead><tr><th>#</th><th>Log path</th><th>ประเภท log</th><th>ชื่อ (log_name)</th><th>Multiline</th><th>ส่งเข้า index</th><th></th></tr></thead>
        <tbody id="esInputs"></tbody></table></div>
      <div class="rep-row">
        <button class="secondary" id="esAddInput">＋ เพิ่ม Path</button>
        <span class="muted small">รองรับ wildcard เช่น /var/log/app/*.log หรือ C:\\Logs\\App\\*.json · JSON = 1 บรรทัด 1 JSON (ndjson)</span>
      </div>
      <div class="row-actions" style="margin-top:12px">
        <button id="esSaveCfg">💾 บันทึก</button>
        <button class="secondary" id="esCopyApp">⧉ ใช้ config นี้กับทุกเครื่องใน App</button>
        <button class="secondary" id="esViewYml">👁 ดู filebeat.yml</button>
        <button class="secondary" id="esDlYml">⇩ filebeat.yml</button>
        <button class="secondary" id="esDlScript"></button>
      </div>
      <p class="muted small">Install script: ติดตั้ง Filebeat ${"(ถ้ายังไม่มี)"}, สำรอง config เดิม, เขียน config ใหม่, เก็บ API key ใน Filebeat keystore (ไม่เขียนลงไฟล์), ทดสอบ config/output และ restart service — ให้แอดมินรันบนเครื่องเอง</p>
    </section>`;
  $("#esEnv").value = esConfigDraft.env;
  $("#esOs").value = fam;
  $("#esOs").addEventListener("change", (e) => { esConfigDraft.os = e.target.value; esUpdateScriptLabel(); });
  $("#esEnv").addEventListener("change", (e) => { esConfigDraft.env = e.target.value; esRenderInputs(); });
  $("#esAddInput").addEventListener("click", () => {
    esConfigDraft.inputs.push({ id: "", path: "", type: "plaintext", name: "", multiline: false });
    esRenderInputs();
    const rows = document.querySelectorAll("#esInputs [data-f=path]");
    rows[rows.length - 1].focus();
  });
  $("#esInputs").addEventListener("input", esReadInputs);
  $("#esInputs").addEventListener("change", (e) => { esReadInputs(); if (e.target.dataset.f === "type") esRenderInputs(); });
  $("#esInputs").addEventListener("click", (e) => {
    const del = e.target.closest("[data-del]");
    if (!del) return;
    esConfigDraft.inputs.splice(parseInt(del.dataset.del, 10), 1);
    esRenderInputs();
  });
  $("#esSaveCfg").addEventListener("click", () => esSaveConfig(currentHost.hostid, true));
  $("#esCopyApp").addEventListener("click", esCopyToApp);
  $("#esViewYml").addEventListener("click", async () => {
    if (await esSaveConfig(currentHost.hostid, false)) window.open(`${API_BASE}/api/elastic/file?hostid=${currentHost.hostid}&kind=yml&inline=1&os=${esConfigDraft.os}`, "_blank", "noopener");
  });
  $("#esDlYml").addEventListener("click", async () => {
    if (await esSaveConfig(currentHost.hostid, false)) location.href = `${API_BASE}/api/elastic/file?hostid=${currentHost.hostid}&kind=yml&os=${esConfigDraft.os}`;
  });
  $("#esDlScript").addEventListener("click", async () => {
    if (await esSaveConfig(currentHost.hostid, false)) location.href = `${API_BASE}/api/elastic/file?hostid=${currentHost.hostid}&kind=script&os=${esConfigDraft.os}`;
  });
  esUpdateScriptLabel();
  esRenderInputs();
}

function esUpdateScriptLabel() {
  const b = $("#esDlScript");
  if (b) b.textContent = `⇩ Install script (${esConfigDraft.os === "windows" ? "PowerShell" : esConfigDraft.os === "aix" ? "AIX: เอกสาร" : "bash"})`;
}

function esIndexFor(type) {
  // names come from the server pattern; swap env locally for preview
  const n = (esConfigDraft.names || {})[type] || "";
  return n.replace(/-(prod|nonprod)-/, `-${esConfigDraft.env}-`);
}

function esRenderInputs() {
  const tb = $("#esInputs");
  if (!tb) return;
  tb.innerHTML = esConfigDraft.inputs.map((i, n) => `<tr>
      <td>${n + 1}</td>
      <td><input class="form-ctl wide" data-i="${n}" data-f="path" value="${escapeHtml(i.path)}" placeholder="/var/log/app/*.log"></td>
      <td><select class="form-ctl" data-i="${n}" data-f="type"><option value="plaintext" ${i.type === "plaintext" ? "selected" : ""}>Plaintext</option>
        <option value="json" ${i.type === "json" ? "selected" : ""}>JSON</option></select></td>
      <td><input class="form-ctl" data-i="${n}" data-f="name" value="${escapeHtml(i.name || "")}" placeholder="app, access, error"></td>
      <td>${i.type === "plaintext" ? `<label class="chk-inline"><input type="checkbox" data-i="${n}" data-f="multiline" ${i.multiline ? "checked" : ""}> รวมบรรทัด (stack trace)</label>` : '<span class="muted">-</span>'}</td>
      <td class="mono">${escapeHtml(esIndexFor(i.type))}</td>
      <td><button class="mini-btn del" data-del="${n}">🗑</button></td></tr>`).join("")
    || '<tr><td colspan="7" class="empty-cell">ยังไม่มี log path — กด "＋ เพิ่ม Path"</td></tr>';
  const used = [...new Set(esConfigDraft.inputs.map((i) => i.type))];
  $("#esNames").innerHTML = used.length
    ? used.map((t) => `<div><span class="muted">${t}</span> <b class="mono">${escapeHtml(esIndexFor(t))}</b></div>`).join("")
    : '<span class="muted">ชื่อ index จะแสดงเมื่อเพิ่ม path</span>';
}

function esReadInputs() {
  document.querySelectorAll("#esInputs [data-i]").forEach((el) => {
    const row = esConfigDraft.inputs[parseInt(el.dataset.i, 10)];
    if (!row) return;
    row[el.dataset.f] = el.type === "checkbox" ? el.checked : el.value;
  });
}

async function esSaveConfig(hostid, notify) {
  esReadInputs();
  const empty = esConfigDraft.inputs.filter((i) => !i.path.trim()).length;
  try {
    const res = await esApi("/api/elastic/host-config", "POST", { hostid, env: esConfigDraft.env, inputs: esConfigDraft.inputs });
    esConfigDraft.inputs = res.config.inputs.map((i) => ({ ...i }));
    if (notify) showToast(res.message + (empty ? ` (ข้าม ${empty} แถวที่ไม่มี path)` : ""));
    esRenderInputs();
    delete esStatusCache[hostid];
    return true;
  } catch (err) {
    showToast(`บันทึกไม่สำเร็จ: ${err.message}`, true);
    return false;
  }
}

async function esCopyToApp() {
  const targets = esHostsOfApp(currentHost.appId).filter((h) => h.hostid !== currentHost.hostid);
  if (!targets.length) { showToast("ไม่มีเครื่องอื่นใน Application นี้", true); return; }
  if (!confirm(`ใช้ log path ชุดนี้ (${esConfigDraft.inputs.length} path) กับอีก ${targets.length} เครื่องใน ${appLabelFor(currentHost)}?\nconfig เดิมของเครื่องเหล่านั้นจะถูกแทนที่`)) return;
  if (!(await esSaveConfig(currentHost.hostid, false))) return;
  let ok = 0;
  for (const h of targets) {
    try {
      await esApi("/api/elastic/host-config", "POST", { hostid: h.hostid, env: esConfigDraft.env,
        inputs: esConfigDraft.inputs.map(({ path, type, name, multiline }) => ({ path, type, name, multiline })) });
      ok++;
      delete esStatusCache[h.hostid];
    } catch (err) { /* continue */ }
  }
  showToast(`คัดลอก config ไป ${ok}/${targets.length} เครื่องแล้ว`, ok < targets.length);
}

// =========================================================
// 3) Index & Space (Elasticsearch + Kibana)
// =========================================================
async function renderEsIndices() {
  const app = currentHost && currentHost.appId ? currentHost : null;
  const defPattern = app ? `*-${app.appId}-*` : "*";
  extra.innerHTML = `
    <section class="panel">
      <div class="paneltitle">⛁ Elasticsearch Indices <span class="source" id="esConn">กำลังเชื่อมต่อ...</span></div>
      <div class="rep-row">
        <input class="form-ctl" id="esPattern" value="${escapeHtml(defPattern)}" placeholder="pattern เช่น applog-1234-*" style="min-width:260px">
        <button class="secondary" id="esLoadIdx">⌕ ค้นหา</button>
        <div class="ac" data-ac="esNewIdx" style="min-width:320px"><input class="form-ctl" id="esNewIdx" placeholder="ชื่อ index ใหม่" autocomplete="off" style="width:100%"><div class="ac-menu" hidden></div></div>
        <button id="esCreateIdx">＋ Create Index</button>
      </div>
      <div class="tablewrap"><table class="data"><thead><tr><th>Index</th><th>Health</th><th>Status</th><th>Docs</th><th>Size</th><th>Created</th><th>ตรงกับ config</th><th></th></tr></thead>
        <tbody id="esIdxRows"><tr><td colspan="8" class="empty-cell">...</td></tr></tbody></table></div>
    </section>
    <section class="panel">
      <div class="paneltitle">◫ Kibana Spaces
        <span class="row-actions">${app ? `<button id="esCreateSpace">＋ Create Space สำหรับ ${escapeHtml(appLabelFor(app))}</button>` : ""}</span></div>
      <div class="tablewrap"><table class="data"><thead><tr><th>Space id</th><th>Name</th><th>Description</th></tr></thead>
        <tbody id="esSpaceRows"><tr><td colspan="3" class="empty-cell">...</td></tr></tbody></table></div>
      ${app ? "" : '<p class="muted small">เลือก Application ด้านบนเพื่อสร้าง Space</p>'}
    </section>`;

  // Standard index names of this App (from every host's saved config) for suggestions + "matches config"
  const expected = new Set();
  if (app) {
    for (const h of esHostsOfApp(app.appId)) {
      try {
        const d = await esApi(`/api/elastic/host-config?hostid=${h.hostid}`);
        const types = new Set((d.config.inputs || []).map((i) => i.type));
        (types.size ? [...types] : ["json", "plaintext"]).forEach((t) => expected.add(d.index_names[t]));
      } catch (err) { /* ignore */ }
    }
  }
  setupAutocomplete('[data-ac="esNewIdx"]', {
    getItems: (q) => [...expected].filter((n) => !q || n.includes(q.toLowerCase())).map((n) => ({ value: n, sub: "มาตรฐาน" })),
  });

  try {
    const t = await esApi("/api/elastic/test", "POST");
    $("#esConn").textContent = t.elasticsearch ? `ES ${t.elasticsearch.version} · ${t.elasticsearch.cluster}${t.kibana ? " · Kibana " + t.kibana.version : ""}` : "เชื่อมต่อไม่ได้";
    if (t.errors.length) showToast(t.errors[0], true);
  } catch (err) {
    $("#esConn").textContent = "ยังไม่ได้ตั้งค่า";
  }

  const loadIdx = async () => {
    const tb = $("#esIdxRows");
    try {
      const d = await esApi(`/api/elastic/indices?pattern=${encodeURIComponent($("#esPattern").value.trim() || "*")}`);
      const names = new Set(d.indices.map((i) => i.index));
      const missing = [...expected].filter((n) => !names.has(n));
      tb.innerHTML = d.indices.map((i) => `<tr><td class="mono">${escapeHtml(i.index)}</td>
          <td><span class="tag ${i.health === "green" ? "ok" : i.health === "yellow" ? "warn" : "bad"}">${escapeHtml(i.health)}</span></td>
          <td>${escapeHtml(i.status)}</td><td>${escapeHtml(i["docs.count"] || "0")}</td><td>${escapeHtml(i["store.size"] || "")}</td>
          <td>${escapeHtml((i["creation.date.string"] || "").replace("T", " ").slice(0, 19))}</td>
          <td>${expected.has(i.index) ? esTag("OK") : '<span class="muted">-</span>'}</td>
          <td><button class="mini-btn del" data-del-idx="${escapeHtml(i.index)}">🗑 Delete</button></td></tr>`).join("")
        + missing.map((n) => `<tr><td class="mono">${escapeHtml(n)}</td><td colspan="5" class="muted">ยังไม่มีบน Elasticsearch (กำหนดไว้ใน config)</td>
          <td>${esTag("Missing")}</td><td><button class="mini-btn add" data-mk-idx="${escapeHtml(n)}">＋ Create</button></td></tr>`).join("")
        || '<tr><td colspan="8" class="empty-cell">ไม่พบ index</td></tr>';
    } catch (err) {
      tb.innerHTML = `<tr><td colspan="8" class="empty-cell bad">${escapeHtml(err.message)}</td></tr>`;
    }
  };
  const loadSpaces = async () => {
    const tb = $("#esSpaceRows");
    try {
      const d = await esApi("/api/elastic/spaces");
      tb.innerHTML = d.spaces.map((s) => `<tr><td class="mono">${escapeHtml(s.id)}</td><td>${escapeHtml(s.name || "")}</td><td>${escapeHtml(s.description || "")}</td></tr>`).join("")
        || '<tr><td colspan="3" class="empty-cell">ไม่มี Space</td></tr>';
    } catch (err) {
      tb.innerHTML = `<tr><td colspan="3" class="empty-cell bad">${escapeHtml(err.message)}</td></tr>`;
    }
  };
  $("#esLoadIdx").addEventListener("click", loadIdx);
  const createIdx = async (name) => {
    if (!name) { showToast("กรุณาใส่ชื่อ index", true); return; }
    if (!confirm(`สร้าง index ${name}?`)) return;
    try { showToast((await esApi("/api/elastic/index", "POST", { action: "create", name })).message); loadIdx(); } catch (err) { showToast(err.message, true); }
  };
  $("#esCreateIdx").addEventListener("click", () => createIdx($("#esNewIdx").value.trim()));
  $("#esIdxRows").addEventListener("click", async (e) => {
    const mk = e.target.closest("[data-mk-idx]");
    if (mk) return createIdx(mk.dataset.mkIdx);
    const del = e.target.closest("[data-del-idx]");
    if (!del) return;
    const name = del.dataset.delIdx;
    const typed = prompt(`ลบ index "${name}" และข้อมูล log ทั้งหมดใน index นี้ถาวร (ย้อนกลับไม่ได้)\n\nพิมพ์ชื่อ index เพื่อยืนยัน:`);
    if (typed === null) return;
    if (typed.trim() !== name) { showToast("ชื่อไม่ตรง — ยกเลิกการลบ", true); return; }
    try { showToast((await esApi("/api/elastic/index", "POST", { action: "delete", name, confirm: typed.trim() })).message); loadIdx(); } catch (err) { showToast(err.message, true); }
  });
  $("#esCreateSpace")?.addEventListener("click", async (e) => {
    if (!confirm(`สร้าง Kibana Space + data view สำหรับ ${appLabelFor(app)}?`)) return;
    e.currentTarget.disabled = true;
    try { showToast((await esApi("/api/elastic/space", "POST", { appid: app.appId, appname: app.appName })).message); loadSpaces(); } catch (err) { showToast(err.message, true); }
    e.currentTarget.disabled = false;
  });
  loadIdx();
  loadSpaces();
}

// =========================================================
// 4) Elastic Settings
// =========================================================
async function renderEsSettings() {
  let s = {};
  try { s = (await esApi("/api/elastic/settings")).settings; } catch (err) { showToast(err.message, true); }
  const f = (id, label, val, attrs = "") => `<label>${label}<input class="form-ctl" id="${id}" value="${escapeHtml(val == null ? "" : String(val))}" ${attrs}></label>`;
  extra.innerHTML = `
    <section class="panel">
      <div class="paneltitle">⚙ Elastic Settings <span class="source">${s.configured ? "ตั้งค่าแล้ว" : "ยังไม่ได้ตั้งค่า"}</span></div>
      <div class="settings-grid">
        ${f("esUrl", "Elasticsearch URL", s.es_url, 'placeholder="https://es.example.local:9200"')}
        ${f("kbUrl", "Kibana URL (สำหรับ Space / data view)", s.kibana_url, 'placeholder="https://kibana.example.local:5601"')}
        <label>วิธียืนยันตัวตน<select class="form-ctl" id="esAuth">
          <option value="apikey">API key</option><option value="basic">Username / Password</option><option value="none">ไม่มี</option></select></label>
        ${f("esUser", "Username (basic)", s.username)}
        <label>Password (basic)<input class="form-ctl" type="password" id="esPass" placeholder="${s.has_password ? "บันทึกไว้แล้ว — เว้นว่าง = คงเดิม" : ""}" autocomplete="new-password"></label>
        <label>API key (base64 id:key)<input class="form-ctl" type="password" id="esKey" placeholder="${s.has_api_key ? "บันทึกไว้แล้ว — เว้นว่าง = คงเดิม" : ""}" autocomplete="off"></label>
        ${f("esIdxPat", "รูปแบบชื่อ index ({appid} {appname} {env} {type})", s.index_pattern)}
        ${f("esSpacePat", "รูปแบบ Kibana Space id ({appid} {appname})", s.space_pattern)}
        ${f("esFbVer", "Filebeat version สำหรับ install script", s.filebeat_version)}
        <label>Default environment<select class="form-ctl" id="esDefEnv"><option value="prod">prod</option><option value="nonprod">nonprod</option></select></label>
        ${f("esLinuxCfg", "Path config บน Linux", s.linux_config_path)}
        ${f("esWinCfg", "Path config บน Windows", s.windows_config_path)}
        ${f("esShards", "Shards ต่อ index", s.number_of_shards, 'type="number" min="1" max="50"')}
        ${f("esReplicas", "Replicas ต่อ index", s.number_of_replicas, 'type="number" min="0" max="50"')}
        <div class="settings-sub">การเข้าเครื่องจริงเพื่อตรวจ Filebeat (อ่านอย่างเดียว)</div>
        ${f("sshUser", "SSH user (Linux / AIX)", s.ssh_user, 'placeholder="เช่น monitor หรือ root"')}
        ${f("sshPort", "SSH port", s.ssh_port, 'type="number" min="1" max="65535"')}
        ${f("sshKey", "SSH private key (path บนเครื่องนี้)", s.ssh_key_path, 'placeholder="~/.ssh/id_rsa"')}
        <label>SSH password (ถ้าไม่ใช้ key)<input class="form-ctl" type="password" id="sshPass" placeholder="${s.has_ssh_password ? "บันทึกไว้แล้ว — เว้นว่าง = คงเดิม" : ""}" autocomplete="new-password"></label>
        ${f("winUser", "Windows user (WinRM) เช่น DOMAIN\\monitor", s.win_user)}
        <label>Windows password<input class="form-ctl" type="password" id="winPass" placeholder="${s.has_win_password ? "บันทึกไว้แล้ว — เว้นว่าง = คงเดิม" : ""}" autocomplete="new-password"></label>
        <label class="chk"><input type="checkbox" id="sshSudo" ${s.ssh_sudo !== false ? "checked" : ""}> ใช้ <span class="mono">sudo -n</span> อ่าน filebeat.yml / registry เมื่อ user ไม่มีสิทธิ์ (ต้องตั้ง NOPASSWD เฉพาะคำสั่ง cat/tail)</label>
        <label class="chk"><input type="checkbox" id="esVerify" ${s.verify_tls !== false ? "checked" : ""}> ตรวจสอบ TLS certificate (ปิดเฉพาะกรณี self-signed ในเครือข่ายทดสอบ)</label>
      </div>
      <p class="muted small">รหัสผ่าน / API key / SSH password เก็บเฉพาะในไฟล์ elastic_settings.json บนเครื่องนี้ (สิทธิ์ 0600) ไม่ส่งกลับมาที่หน้าเว็บ และไม่ถูกเขียนลง filebeat.yml</p>
      <div class="row-actions"><button id="esSaveSet">💾 บันทึก</button><button class="secondary" id="esTest">⚡ ทดสอบการเชื่อมต่อ</button>
        ${s.has_api_key || s.has_password || s.has_ssh_password || s.has_win_password ? '<button class="secondary" id="esClearSecret">ลบรหัสที่บันทึกไว้</button>' : ""}</div>
      <div id="esTestResult" class="detail"></div>
    </section>`;
  $("#esAuth").value = s.auth_type || "apikey";
  $("#esDefEnv").value = s.default_env || "prod";
  const collect = () => ({
    es_url: $("#esUrl").value, kibana_url: $("#kbUrl").value, auth_type: $("#esAuth").value, username: $("#esUser").value,
    password: $("#esPass").value, api_key: $("#esKey").value, index_pattern: $("#esIdxPat").value, space_pattern: $("#esSpacePat").value,
    filebeat_version: $("#esFbVer").value, default_env: $("#esDefEnv").value, linux_config_path: $("#esLinuxCfg").value,
    windows_config_path: $("#esWinCfg").value, number_of_shards: parseInt($("#esShards").value, 10),
    number_of_replicas: parseInt($("#esReplicas").value, 10), verify_tls: $("#esVerify").checked,
    ssh_user: $("#sshUser").value, ssh_port: parseInt($("#sshPort").value, 10) || 22, ssh_key_path: $("#sshKey").value,
    ssh_password: $("#sshPass").value, win_user: $("#winUser").value, win_password: $("#winPass").value, ssh_sudo: $("#sshSudo").checked,
  });
  const save = async () => {
    try { await esApi("/api/elastic/settings", "POST", { settings: collect() }); esStatusCache = {}; return true; } catch (err) { showToast(`บันทึกไม่สำเร็จ: ${err.message}`, true); return false; }
  };
  $("#esSaveSet").addEventListener("click", async () => { if (await save()) { showToast("บันทึก Elastic Settings แล้ว"); renderEsSettings(); } });
  $("#esTest").addEventListener("click", async () => {
    if (!(await save())) return;
    const box = $("#esTestResult");
    box.className = "detail show";
    box.textContent = "กำลังทดสอบ...";
    try {
      const t = await esApi("/api/elastic/test", "POST");
      box.innerHTML = `Elasticsearch: ${t.elasticsearch ? `<span class="ok">● ${escapeHtml(t.elasticsearch.cluster)} v${escapeHtml(t.elasticsearch.version)}</span>` : '<span class="bad">✕</span>'}<br>
        Kibana: ${t.kibana ? `<span class="ok">● v${escapeHtml(t.kibana.version || "?")} ${escapeHtml(t.kibana.status || "")}</span>` : '<span class="muted">ไม่ได้ตั้งค่า / เชื่อมต่อไม่ได้</span>'}
        ${t.errors.map((e) => `<div class="bad">${escapeHtml(e)}</div>`).join("")}`;
    } catch (err) {
      box.innerHTML = `<span class="bad">${escapeHtml(err.message)}</span>`;
    }
  });
  $("#esClearSecret")?.addEventListener("click", async () => {
    if (!confirm("ลบ password / API key ที่บันทึกไว้?")) return;
    try { await esApi("/api/elastic/settings", "POST", { settings: { password: "__clear__", api_key: "__clear__", ssh_password: "__clear__", win_password: "__clear__" } }); showToast("ลบแล้ว"); renderEsSettings(); } catch (err) { showToast(err.message, true); }
  });
}
