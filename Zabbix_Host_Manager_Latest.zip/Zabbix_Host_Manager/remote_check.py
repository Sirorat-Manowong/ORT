"""
Read-only Filebeat checks executed on the real machine.

  Linux / AIX : OpenSSH client already on the OS (ssh / ssh.exe) — key or password (SSH_ASKPASS)
  Windows     : PowerShell Remoting (WinRM) — needs this program to run on Windows

Only inspection commands are sent (filebeat version, systemctl is-active, cat config,
read registry, ls of configured paths, last log lines). Nothing is changed on the host.
"""
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
from typing import Any, Dict, List, Optional, Tuple

if getattr(sys, "frozen", False):
    _DATA_DIR = os.path.dirname(sys.executable)
else:
    _DATA_DIR = os.path.dirname(os.path.abspath(__file__))
KNOWN_HOSTS = os.path.join(_DATA_DIR, "ssh_known_hosts")

_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}
CACHE_SECONDS = 120

ADDR_RX = re.compile(r"^[A-Za-z0-9.:\-]{1,253}$")
USER_RX = re.compile(r"^[A-Za-z0-9._\\@-]{1,64}$")


def _sh_quote(s: str) -> str:
    return "'" + str(s).replace("'", "'\"'\"'") + "'"


def _sh_glob(path: str) -> str:
    """Quote a path for sh but keep * and ? as live glob characters."""
    parts = re.split(r"([*?])", path)
    return "".join(p if p in ("*", "?") else (_sh_quote(p) if p else "") for p in parts)


def _ps_quote(s: str) -> str:
    return "'" + str(s).replace("'", "''") + "'"


# ---------------------------------------------------------------------------
# Scripts (POSIX sh for Linux/AIX, PowerShell for Windows)
# ---------------------------------------------------------------------------
def linux_script(cfg_path: str, paths: List[str], use_sudo: bool) -> str:
    sudo = "sudo -n " if use_sudo else ""
    cfg = _sh_quote(cfg_path)
    cfg_dir = _sh_quote(os.path.dirname(cfg_path) or "/etc/filebeat")
    lines = [
        "export LC_ALL=C PATH=$PATH:/usr/share/filebeat/bin:/usr/local/bin:/usr/sbin:/sbin",
        "echo '@@OS'; uname -a",
        "echo '@@USER'; id -un",
        "echo '@@FB_BIN'; command -v filebeat 2>/dev/null || ls /usr/share/filebeat/bin/filebeat 2>/dev/null",
        "echo '@@FB_VERSION'; (filebeat version || /usr/share/filebeat/bin/filebeat version) 2>/dev/null | head -n 1",
        "echo '@@FB_PKG'; (dpkg-query -W -f='${Version}' filebeat || rpm -q --qf '%{VERSION}' filebeat) 2>/dev/null",
        "echo '@@FB_ACTIVE'; systemctl is-active filebeat 2>/dev/null || (service filebeat status >/dev/null 2>&1 && echo active)",
        "echo '@@FB_ENABLED'; systemctl is-enabled filebeat 2>/dev/null",
        "echo '@@FB_PID'; (pgrep -x filebeat || ps -e -o pid= -o comm= | awk '$2==\"filebeat\"{print $1}') 2>/dev/null | head -n 1",
        "echo '@@FB_SINCE'; systemctl show filebeat -p ActiveEnterTimestamp --value 2>/dev/null",
        f"echo '@@FB_CONFIG'; cat {cfg} 2>/dev/null || {sudo}cat {cfg} 2>/dev/null || echo '@@NOACCESS'",
        f"echo '@@FB_INPUTS_D'; for f in {cfg_dir}/inputs.d/*.yml; do [ -e \"$f\" ] && {{ echo \"# file: $f\"; cat \"$f\" 2>/dev/null || {sudo}cat \"$f\" 2>/dev/null; }}; done",
        # Files Filebeat is actually harvesting (registry), newest state last
        "echo '@@FB_REGISTRY'; R=/var/lib/filebeat/registry/filebeat/log.json; "
        f"(tail -n 4000 $R 2>/dev/null || {sudo}tail -n 4000 $R 2>/dev/null) | grep -o '\"source\":\"[^\"]*\"' | sort -u | cut -d'\"' -f4 | head -n 200",
        f"echo '@@FB_LOG'; ({sudo}journalctl -u filebeat -n 15 --no-pager -o cat 2>/dev/null || tail -n 15 /var/log/filebeat/filebeat* 2>/dev/null) | cut -c1-400",
    ]
    for i, p in enumerate(paths[:50]):
        lines.append(f"echo '@@PATH {i}'; ls -1d {_sh_glob(p)} 2>/dev/null | head -n 5")
    lines.append("echo '@@END'")
    return "\n".join(lines) + "\n"


def windows_script(cfg_path: str, paths: List[str]) -> str:
    plist = ",".join(_ps_quote(p) for p in paths[:50]) or "@()"
    return f"""
$ErrorActionPreference = 'SilentlyContinue'
'@@OS'; (Get-CimInstance Win32_OperatingSystem).Caption + ' ' + (Get-CimInstance Win32_OperatingSystem).Version
'@@USER'; whoami
$svc = Get-CimInstance Win32_Service -Filter "Name='filebeat'"
$exe = $null
if ($svc) {{ $exe = ($svc.PathName -replace '^"([^"]+)".*$', '$1') -replace '^(\\S+\\.exe).*$', '$1' }}
if (-not $exe -or -not (Test-Path $exe)) {{ $exe = 'C:\\Program Files\\Filebeat\\filebeat.exe' }}
'@@FB_BIN'; if (Test-Path $exe) {{ $exe }}
'@@FB_VERSION'; if (Test-Path $exe) {{ (& $exe version) | Select-Object -First 1 }}
'@@FB_PKG';
'@@FB_ACTIVE'; if ($svc) {{ if ($svc.State -eq 'Running') {{ 'active' }} else {{ $svc.State.ToLower() }} }}
'@@FB_ENABLED'; if ($svc) {{ $svc.StartMode.ToLower() }}
'@@FB_PID'; if ($svc -and $svc.ProcessId) {{ $svc.ProcessId }}
'@@FB_SINCE';
$cfg = {_ps_quote(cfg_path)}
if ($svc -and $svc.PathName -match '-c\\s+"?([^"]+filebeat\\.yml)') {{ $cfg = $Matches[1] }}
'@@FB_CONFIG'; if (Test-Path $cfg) {{ Get-Content -Raw $cfg }} else {{ '@@NOACCESS' }}
'@@FB_INPUTS_D'; Get-ChildItem (Join-Path (Split-Path $cfg) 'inputs.d') -Filter *.yml | ForEach-Object {{ "# file: $($_.FullName)"; Get-Content -Raw $_.FullName }}
'@@FB_REGISTRY'; $reg = 'C:\\ProgramData\\filebeat\\registry\\filebeat\\log.json'
if (Test-Path $reg) {{ Get-Content $reg -Tail 4000 | Select-String -Pattern '"source":"([^"]*)"' -AllMatches | ForEach-Object {{ $_.Matches }} | ForEach-Object {{ $_.Groups[1].Value -replace '\\\\\\\\','\\' }} | Sort-Object -Unique | Select-Object -First 200 }}
'@@FB_LOG'; Get-ChildItem 'C:\\ProgramData\\filebeat\\logs' -Filter 'filebeat*' | Sort-Object LastWriteTime | Select-Object -Last 1 | ForEach-Object {{ Get-Content $_.FullName -Tail 15 }}
$i = 0
foreach ($p in @({plist})) {{ "@@PATH $i"; Get-ChildItem -Path $p | Select-Object -First 5 | ForEach-Object {{ $_.FullName }}; $i++ }}
'@@END'
"""


def port_open(addr: str, port: int, timeout: float = 1.5) -> bool:
    import socket
    if not ADDR_RX.fullmatch(addr or ""):
        return False
    try:
        with socket.create_connection((addr, int(port)), timeout=timeout):
            return True
    except OSError:
        return False


def parse_sections(out: str) -> Dict[str, str]:
    sec: Dict[str, List[str]] = {}
    cur = None
    for line in (out or "").splitlines():
        if line.startswith("@@") and not line.startswith("@@NOACCESS"):
            cur = line[2:].strip()
            sec.setdefault(cur, [])
            continue
        if cur:
            sec[cur].append(line.rstrip("\r"))
    return {k: "\n".join(v).strip() for k, v in sec.items()}


# ---------------------------------------------------------------------------
# Transports
# ---------------------------------------------------------------------------
def find_ssh() -> Optional[str]:
    p = shutil.which("ssh")
    if p:
        return p
    win = os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "System32", "OpenSSH", "ssh.exe")
    return win if os.path.exists(win) else None


def ssh_run(addr: str, settings: Dict[str, Any], script: str, timeout: int = 25) -> Tuple[int, str, str]:
    ssh = find_ssh()
    if not ssh:
        raise RuntimeError("ไม่พบคำสั่ง ssh บนเครื่องที่รันโปรแกรม")
    user = (settings.get("ssh_user") or "").strip()
    if not ADDR_RX.fullmatch(addr) or not USER_RX.fullmatch(user or "x"):
        raise ValueError("address / ssh user ไม่ถูกต้อง")
    if not user:
        raise RuntimeError("ยังไม่ได้ตั้งค่า SSH user ใน Elastic Settings")
    port = str(int(settings.get("ssh_port") or 22))
    cmd = [ssh, "-p", port, "-o", "ConnectTimeout=8", "-o", "ServerAliveInterval=5",
           "-o", "StrictHostKeyChecking=accept-new", "-o", f"UserKnownHostsFile={KNOWN_HOSTS}",
           "-o", "LogLevel=ERROR"]
    key = (settings.get("ssh_key_path") or "").strip()
    if key:
        key = os.path.expanduser(key)
        if not os.path.exists(key):
            raise RuntimeError(f"ไม่พบ SSH key: {key}")
        cmd += ["-i", key, "-o", "IdentitiesOnly=yes"]
    env = dict(os.environ)
    askpass_dir = None
    if settings.get("ssh_password"):
        # Password auth without sshpass: OpenSSH asks SSH_ASKPASS, which echoes an env var (never on the command line)
        askpass_dir = tempfile.mkdtemp(prefix="mz_ask_")
        if os.name == "nt":
            helper = os.path.join(askpass_dir, "ask.cmd")
            with open(helper, "w") as f:
                f.write("@echo off\r\necho %MZ_SSH_PASS%\r\n")
        else:
            helper = os.path.join(askpass_dir, "ask.sh")
            with open(helper, "w") as f:
                f.write('#!/bin/sh\nprintf "%s\\n" "$MZ_SSH_PASS"\n')
            os.chmod(helper, stat.S_IRWXU)
        env.update({"SSH_ASKPASS": helper, "SSH_ASKPASS_REQUIRE": "force", "DISPLAY": env.get("DISPLAY", ":0"),
                    "MZ_SSH_PASS": settings["ssh_password"]})
        cmd += ["-o", "PreferredAuthentications=publickey,password,keyboard-interactive", "-o", "NumberOfPasswordPrompts=1"]
    else:
        cmd += ["-o", "BatchMode=yes"]
    cmd += [f"{user}@{addr}", "sh -s"]
    try:
        p = subprocess.run(cmd, input=script, capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=timeout, env=env)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"SSH timeout ({timeout}s)")
    finally:
        if askpass_dir:
            shutil.rmtree(askpass_dir, ignore_errors=True)


def winrm_run(addr: str, settings: Dict[str, Any], script: str, timeout: int = 40) -> Tuple[int, str, str]:
    user = (settings.get("win_user") or "").strip()
    if not ADDR_RX.fullmatch(addr):
        raise ValueError("address ไม่ถูกต้อง")
    if not user:
        raise RuntimeError("ยังไม่ได้ตั้งค่า Windows (WinRM) user ใน Elastic Settings")
    if not USER_RX.fullmatch(user):
        raise ValueError("Windows user ไม่ถูกต้อง")
    if os.name == "nt":
        ps = shutil.which("powershell") or "powershell"
        wrapper = (
            "$p = ConvertTo-SecureString $env:MZ_WIN_PASS -AsPlainText -Force;"
            f"$c = New-Object System.Management.Automation.PSCredential({_ps_quote(user)}, $p);"
            "$sb = [scriptblock]::Create([Console]::In.ReadToEnd());"
            f"Invoke-Command -ComputerName {_ps_quote(addr)} -Credential $c -ScriptBlock $sb -ErrorAction Stop"
        )
        env = dict(os.environ, MZ_WIN_PASS=settings.get("win_password") or "")
        try:
            p = subprocess.run([ps, "-NoProfile", "-NonInteractive", "-Command", wrapper], input=script,
                               capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout, env=env)
            return p.returncode, p.stdout, p.stderr
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"WinRM timeout ({timeout}s)")
    try:
        import winrm  # optional: pip install pywinrm
    except ImportError:
        raise RuntimeError("ตรวจเครื่อง Windows ต้องรันโปรแกรมนี้บน Windows (PowerShell Remoting) "
                           "หรือติดตั้ง pywinrm บนเครื่องที่รันโปรแกรม")
    sess = winrm.Session(f"http://{addr}:5985/wsman", auth=(user, settings.get("win_password") or ""), transport="ntlm")
    r = sess.run_ps(script)
    return r.status_code, r.std_out.decode("utf-8", "replace"), r.std_err.decode("utf-8", "replace")


# ---------------------------------------------------------------------------
# Main entry
# ---------------------------------------------------------------------------
def check_host(hostid: str, addr: str, os_hint: str, settings: Dict[str, Any], paths: List[str],
               refresh: bool = False) -> Dict[str, Any]:
    key = f"{hostid}|{addr}|{os_hint}|{'|'.join(paths)}"
    hit = _cache.get(key)
    if hit and not refresh and time.time() - hit[0] < CACHE_SECONDS:
        return hit[1]
    res: Dict[str, Any] = {"reachable": False, "method": "", "address": addr, "error": "", "checked_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    is_win = os_hint == "windows"
    res["method"] = "winrm" if is_win else "ssh"
    try:
        if is_win:
            rc, out, err = winrm_run(addr, settings, windows_script(settings.get("windows_config_path"), paths))
        else:
            rc, out, err = ssh_run(addr, settings, linux_script(settings.get("linux_config_path"), paths,
                                                               bool(settings.get("ssh_sudo", True))))
    except (RuntimeError, ValueError, OSError) as e:
        res["error"] = str(e)
        _cache[key] = (time.time(), res)
        return res
    sec = parse_sections(out)
    if "OS" not in sec:
        msg = (err or out or "").strip().splitlines()
        res["error"] = (msg[-1] if msg else f"exit {rc}")[:300]
        if "Permission denied" in (err or ""):
            res["error"] = f"เข้าเครื่องไม่ได้ (Permission denied) — ตรวจ user / key / password · {res['error']}"
        _cache[key] = (time.time(), res)
        return res

    cfg_text = sec.get("FB_CONFIG", "")
    no_access = cfg_text.strip() in ("", "@@NOACCESS") or cfg_text.strip().endswith("@@NOACCESS")
    ver_line = sec.get("FB_VERSION", "")
    m = re.search(r"version\s+(\d+\.\d+\.\d+)", ver_line)
    version = m.group(1) if m else (sec.get("FB_PKG", "").split("-")[0].split("+")[0] or "")
    active = (sec.get("FB_ACTIVE", "").splitlines() or [""])[0].strip().lower()
    pid = (sec.get("FB_PID", "").splitlines() or [""])[0].strip()
    paths_found = {}
    for i, p in enumerate(paths[:50]):
        files = [x for x in sec.get(f"PATH {i}", "").splitlines() if x.strip()]
        paths_found[p] = files
    res.update({
        "reachable": True,
        "os": sec.get("OS", "")[:200],
        "user": sec.get("USER", ""),
        "binary": sec.get("FB_BIN", "").splitlines()[0] if sec.get("FB_BIN") else "",
        "installed": bool(sec.get("FB_BIN") or version or sec.get("FB_PKG") or pid),
        "version": version,
        "version_line": ver_line[:200],
        "running": active == "active" or bool(pid),
        "service_state": active or ("running" if pid else "not found"),
        "enabled": (sec.get("FB_ENABLED", "").splitlines() or [""])[0].strip(),
        "since": sec.get("FB_SINCE", ""),
        "config_readable": not no_access and bool(cfg_text.strip()),
        "config_text": "" if no_access else (cfg_text + ("\n" + sec.get("FB_INPUTS_D", "") if sec.get("FB_INPUTS_D") else ""))[:200000],
        "harvested_files": [x for x in sec.get("FB_REGISTRY", "").splitlines() if x.strip()][:200],
        "paths_found": paths_found,
        "recent_log": sec.get("FB_LOG", "").splitlines()[-15:],
        "stderr": (err or "").strip()[-300:],
    })
    _cache[key] = (time.time(), res)
    return res
