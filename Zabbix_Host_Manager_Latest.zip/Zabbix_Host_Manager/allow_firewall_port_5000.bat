@echo off
chcp 65001 >nul
title Open Port 5000 Firewall

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] ขอสิทธิ์ Administrator เพื่อเปิดพอร์ต Firewall...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo ========================================================
echo    🚀 กำลังเปิดพอร์ต 5000 บน Windows Defender Firewall...
echo ========================================================
echo.

netsh advfirewall firewall delete rule name="Zabbix Host Manager (Port 5000)" >nul 2>&1
netsh advfirewall firewall add rule name="Zabbix Host Manager (Port 5000)" dir=in action=allow protocol=TCP localport=5000

if %errorlevel% equ 0 (
    echo.
    echo ========================================================
    echo    ✅ สำเร็จ! เปิดพอร์ต 5000 บน Windows Firewall เรียบร้อยแล้ว
    echo ========================================================
    echo.
    for /f "tokens=*" %%a in ('powershell -NoProfile -Command "(Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -notmatch 'Loopback|vEthernet' -and $_.IPAddress -notlike '169.254*' } | Select-Object -First 1).IPAddress"') do set CURRENT_IP=%%a
    if "%CURRENT_IP%"=="" set CURRENT_IP=IP_เครื่องนี้
    echo เครื่องอื่นในวงแลนสามารถเข้าใช้งานผ่านลิงก์นี้ได้ทันที:
    echo    http://%CURRENT_IP%:5000
    echo    (หรือบนเครื่องนี้เอง: http://127.0.0.1:5000)
    echo.
) else (
    echo [ERROR] เกิดข้อผิดพลาดในการเปิดพอร์ต
)

echo.
pause
