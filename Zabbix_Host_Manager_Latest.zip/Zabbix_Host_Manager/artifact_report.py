"""
Monitoring Readiness artifacts.

Builds evidence documents from monitoring_standard.evaluate() results:
  html  - self-contained, print-ready report (A4)
  pdf   - rendered by headless Microsoft Edge / Google Chrome (no Python deps)
  png   - full report image rendered by the same browser
  csv   - every check as one row (Excel friendly, UTF-8 BOM)
  json  - the raw evaluation
"""
import csv
import html
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime
from typing import Any, Dict, List, Optional

E = html.escape

STATUS_CLASS = {"Monitored": "ok", "Not Monitored": "bad", "Not Required": "na"}
VERDICT_CLASS = {"PASS": "ok", "PARTIAL": "warn", "FAIL": "bad", "N/A": "na"}
SECTION_TITLES = {
    "os": "OS Monitoring",
    "service": "Service / Process Monitoring",
    "software": "Software Monitoring",
}


def safe_filename(text: str, fallback: str = "report") -> str:
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", text or "").strip("._")
    return (name or fallback)[:80]


def _pct_text(p: Optional[int]) -> str:
    return "—" if p is None else f"{p}%"


def _ring(pct: Optional[int], color: str, label: str, counts: str) -> str:
    p = pct or 0
    return f"""
    <div class="kpi">
      <div class="ring" style="background:conic-gradient({color} {p * 3.6}deg,#e6eaf2 0)"><span>{E(_pct_text(pct))}</span></div>
      <div class="kpi-label">{E(label)}</div>
      <div class="kpi-counts">{counts}</div>
    </div>"""


def _counts(s: Dict[str, Any], with_nr: bool = True) -> str:
    out = f"Total <b>{s['total']}</b> · Monitored <b>{s['monitored']}</b><br>Not Monitored <b>{s['not_monitored']}</b>"
    if with_nr:
        out += f" · Not Required <b>{s['not_required']}</b>"
    return out


def _check_rows(checks: List[Dict[str, Any]], section: str) -> str:
    if not checks:
        return '<tr><td colspan="7" class="muted center">ไม่มีรายการ</td></tr>'
    rows = []
    for i, c in enumerate(checks, 1):
        cls = STATUS_CLASS.get(c["status"], "na")
        note = c.get("reason") or ""
        if c.get("error"):
            note += f" — {c['error']}"
        if section == "os":
            value = (str(c.get("lastvalue") or "") + (" " + c["units"] if c.get("units") and c.get("lastvalue") else "")).strip()
            cols = [c["category"], c["name"], c.get("expected") or "", c.get("actual") or "-", value or "-", c.get("lastclock") or "-"]
        elif section == "service":
            cols = [c.get("kind", "").title(), c["name"], c.get("category") or "", c.get("actual") or c.get("expected") or "",
                    c.get("state") or "-", c.get("lastclock") or "-"]
        else:
            cols = [c.get("category") or "", c["name"], c.get("version") or "-", c.get("expected") or "-",
                    c.get("actual") or "-", c.get("evidence") or "-"]
        tds = "".join(f"<td>{E(str(v))}</td>" for v in cols)
        rows.append(f'<tr><td class="num">{i}</td>{tds}<td><span class="tag {cls}">{E(c["status"])}</span>'
                    f'{"<div class=note>" + E(note) + "</div>" if note else ""}</td></tr>')
    return "".join(rows)


def _section_table(key: str, sec: Dict[str, Any]) -> str:
    heads = {
        "os": ["Category", "Metric", "Standard item", "Zabbix item", "Last value", "Last check"],
        "service": ["Type", "Service / Process", "Source", "Zabbix item", "State", "Last check"],
        "software": ["Type", "Software", "Version", "Expected template", "Monitored by", "Evidence"],
    }[key]
    th = "".join(f"<th>{E(h)}</th>" for h in ["#"] + heads + ["Status"])
    extra = ""
    if key == "software" and sec.get("other_installed"):
        extra = f'<p class="muted small">ซอฟต์แวร์อื่นที่ติดตั้งแต่ไม่อยู่ในมาตรฐาน: {sec["other_installed"]} รายการ (ไม่นับในเปอร์เซ็นต์)</p>'
    return f"""
    <h3>{E(SECTION_TITLES[key])} <span class="pill">{E(_pct_text(sec['pct']))}</span>
      <span class="muted small">Monitored {sec['monitored']} / Required {sec['total'] - sec['not_required']}</span></h3>
    <table class="grid"><thead><tr>{th}</tr></thead><tbody>{_check_rows(sec['checks'], key)}</tbody></table>{extra}"""


def combine(a: Dict[str, Any], b: Dict[str, Any]) -> Dict[str, Any]:
    """Software Monitoring = installed software + Windows services / processes."""
    out = {k: a[k] + b[k] for k in ("total", "monitored", "not_monitored", "not_required")}
    denom = out["total"] - out["not_required"]
    out["pct"] = round(out["monitored"] * 100 / denom) if denom > 0 else None
    return out


def _host_block(r: Dict[str, Any], index: int, total: int) -> str:
    h = r["host"]
    s = r["sections"]
    sw_all = combine(s["service"], s["software"])
    v = r["verdict"]
    inv = r["inventory"]
    groups = ", ".join(g.get("name", "") for g in h.get("groups", []))
    iface = next((i for i in h.get("interfaces", []) if str(i.get("type")) == "1"), (h.get("interfaces") or [{}])[0])
    tpl = ", ".join(t["name"] for t in r["templates"]) or "—"
    src = inv.get("source", {})
    src_text = ", ".join(f"{k}: {v_ or 'ไม่มีข้อมูล'}" for k, v_ in src.items())
    conf = {"verified": "Verified (ข้อมูลจริงจากเครื่อง)", "partial": "Partial (ข้อมูลจริงบางส่วน)",
            "estimated": "Estimated (ประเมินจาก Zabbix items เท่านั้น)"}.get(inv.get("confidence"), inv.get("confidence"))
    health_rows = "".join(
        f"<tr><td>{E(x['name'] or '')}</td><td class='mono'>{E(x['key'] or '')}</td><td>{E(x['issue_text'])}</td>"
        f"<td>{E(x.get('error') or '')}</td><td>{E(x.get('lastclock') or '-')}</td></tr>"
        for x in r["health"]["issues"][:100]
    ) or '<tr><td colspan="5" class="muted center">ไม่พบปัญหาการเก็บข้อมูล</td></tr>'
    waived = [c for sec in s.values() for c in sec["checks"] if c.get("waived")]
    waiver_rows = "".join(f"<tr><td>{E(c['name'])}</td><td>{E(SECTION_TITLES[c['section']])}</td><td>{E(c['reason'])}</td></tr>"
                          for c in waived)
    notes = "".join(f"<li>{E(n)}</li>" for n in inv.get("notes", []) + inv.get("errors", [])[:5])
    page_break = ' style="page-break-before:always"' if index > 0 else ""
    return f"""
  <section class="host"{page_break}>
    <div class="host-head">
      <div>
        <div class="eyebrow">HOST {index + 1} / {total}</div>
        <h2>{E(h.get('name') or h.get('host') or '')}</h2>
        <div class="muted">{E(h.get('host', ''))} · Zabbix ID {E(str(h.get('hostid', '')))}</div>
      </div>
      <div class="verdict {VERDICT_CLASS.get(v['status'], 'na')}">
        <div class="v-status">{E(v['status'])}</div><div class="v-label">{E(v['label'])}</div>
        <div class="v-pct">{E(_pct_text(r['overall']['pct']))}</div>
      </div>
    </div>
    <table class="meta">
      <tr><th>IP / Interface</th><td>{E(str(iface.get('ip') or iface.get('dns') or '-'))}:{E(str(iface.get('port') or ''))}</td>
          <th>OS family</th><td>{E(r['os_family'].upper())} {E(r.get('os_name') or '')}</td></tr>
      <tr><th>Host groups</th><td>{E(groups or '-')}</td><th>Linked templates</th><td>{E(tpl)}</td></tr>
      <tr><th>Recommended OS template</th><td>{E(r['os_template']['recommended'] or '-')}
          {'✓ linked' if r['os_template']['linked'] else '— not linked'}</td>
          <th>Inventory</th><td>{E(conf)}<br><span class="small muted">{E(src_text)} · {E(inv.get('collected_at', ''))}</span></td></tr>
      <tr><th>Items on host</th><td>{r['items_total']}</td>
          <th>Data health</th><td>{r['health']['count']} item(s) มีปัญหา{' · healthy ' + _pct_text(r['overall'].get('health_pct')) if r['overall'].get('health_pct') is not None else ''}</td></tr>
    </table>
    <div class="kpis">
      {_ring(r['overall']['pct'], '#16a37f', 'Overall Coverage', _counts(r['overall']))}
      {_ring(s['os']['pct'], '#2f6fed', 'OS Monitoring', _counts(s['os'], with_nr=False))}
      {_ring(sw_all['pct'], '#7c4ddb', 'Software Monitoring', _counts(sw_all) + '<br><span class="small">(software + service/process)</span>')}
    </div>
    {_section_table('os', s['os'])}
    {_section_table('service', s['service'])}
    {_section_table('software', s['software'])}
    <h3>Data health (items ที่เก็บข้อมูลไม่ได้)</h3>
    <table class="grid"><thead><tr><th>Item</th><th>Key</th><th>Issue</th><th>Error</th><th>Last check</th></tr></thead>
      <tbody>{health_rows}</tbody></table>
    {'<h3>Waivers (Not Required ที่อนุมัติ)</h3><table class="grid"><thead><tr><th>Check</th><th>Section</th><th>Reason</th></tr></thead><tbody>' + waiver_rows + '</tbody></table>' if waived else ''}
    {'<h3>Notes</h3><ul class="notes">' + notes + '</ul>' if notes else ''}
  </section>"""


def build_html(reports: List[Dict[str, Any]], meta: Dict[str, Any]) -> str:
    total = len(reports)
    generated = meta.get("generated_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    title = meta.get("title") or "Monitoring Readiness Report"
    thresholds = reports[0]["settings"] if reports else {"pass_threshold": 100, "warn_threshold": 80}

    summary = ""
    if total > 1:
        rows = "".join(
            f"<tr><td>{i}</td><td>{E(r['host'].get('name') or '')}</td><td>{E(r['os_family'].upper())}</td>"
            f"<td>{E(_pct_text(r['sections']['os']['pct']))}</td>"
            f"<td>{E(_pct_text(combine(r['sections']['service'], r['sections']['software'])['pct']))}</td>"
            f"<td><b>{E(_pct_text(r['overall']['pct']))}</b></td>"
            f"<td><span class='tag {VERDICT_CLASS.get(r['verdict']['status'], 'na')}'>{E(r['verdict']['status'])}</span></td></tr>"
            for i, r in enumerate(reports, 1))
        passed = sum(1 for r in reports if r["verdict"]["status"] == "PASS")
        summary = f"""
  <section class="summary">
    <h2>Summary — {total} hosts · PASS {passed} / {total}</h2>
    <table class="grid"><thead><tr><th>#</th><th>Host</th><th>OS</th><th>OS Monitoring</th><th>Software Monitoring</th>
      <th>Overall</th><th>Verdict</th></tr></thead><tbody>{rows}</tbody></table>
  </section>"""

    body = "".join(_host_block(r, i, total) for i, r in enumerate(reports))
    org = E(meta.get("organization") or "")
    return f"""<!DOCTYPE html>
<html lang="th"><head><meta charset="utf-8">
<title>{E(title)}</title>
<style>
  @page {{ size: A4; margin: 12mm 10mm; }}
  * {{ box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }}
  body {{ margin: 0; font: 11px/1.45 "Segoe UI", "Noto Sans Thai", "Tahoma", Arial, sans-serif; color: #1c2434; background: #fff; }}
  .wrap {{ max-width: 1180px; margin: 0 auto; padding: 22px 26px; }}
  header.doc {{ display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 3px solid #2f6fed; padding-bottom: 12px; margin-bottom: 14px; }}
  header.doc h1 {{ margin: 0; font-size: 22px; }}
  .eyebrow {{ font-size: 9.5px; letter-spacing: .12em; color: #6b7690; font-weight: 700; }}
  .muted {{ color: #6b7690; }} .small {{ font-size: 9.5px; }} .center {{ text-align: center; }} .mono {{ font-family: Consolas, Menlo, monospace; font-size: 9.5px; }}
  .doc-meta {{ text-align: right; font-size: 10px; color: #4b5670; }}
  h2 {{ font-size: 17px; margin: 4px 0; }}
  h3 {{ font-size: 13px; margin: 18px 0 6px; padding-bottom: 4px; border-bottom: 1px solid #e3e8f0; }}
  .host-head {{ display: flex; justify-content: space-between; align-items: center; gap: 16px; margin: 6px 0 10px; }}
  .verdict {{ min-width: 190px; text-align: center; border-radius: 12px; padding: 10px 14px; color: #fff; }}
  .verdict.ok {{ background: #16a37f; }} .verdict.warn {{ background: #d97706; }} .verdict.bad {{ background: #dc3545; }} .verdict.na {{ background: #8a94a8; }}
  .v-status {{ font-size: 18px; font-weight: 800; letter-spacing: .06em; }} .v-label {{ font-size: 11px; }} .v-pct {{ font-size: 24px; font-weight: 800; }}
  table {{ border-collapse: collapse; width: 100%; }}
  table.meta th {{ text-align: left; width: 16%; background: #f4f6fb; color: #4b5670; font-weight: 600; }}
  table.meta td, table.meta th {{ border: 1px solid #e3e8f0; padding: 6px 8px; vertical-align: top; }}
  .kpis {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin: 14px 0 4px; }}
  .kpi {{ border: 1px solid #e3e8f0; border-radius: 12px; padding: 10px; text-align: center; page-break-inside: avoid; }}
  .ring {{ width: 84px; height: 84px; border-radius: 50%; margin: 0 auto 6px; display: grid; place-items: center; position: relative; }}
  .ring::before {{ content: ""; position: absolute; inset: 10px; background: #fff; border-radius: 50%; }}
  .ring span {{ position: relative; font-size: 18px; font-weight: 800; }}
  .kpi-label {{ font-weight: 700; }} .kpi-counts {{ font-size: 9.5px; color: #4b5670; margin-top: 3px; }}
  table.grid th {{ background: #2f3b56; color: #fff; text-align: left; font-weight: 600; padding: 6px 7px; font-size: 10px; }}
  table.grid td {{ border-bottom: 1px solid #e8ecf3; padding: 5px 7px; vertical-align: top; word-break: break-word; }}
  table.grid tr:nth-child(even) td {{ background: #fafbfd; }}
  table.grid tr {{ page-break-inside: avoid; }}
  td.num {{ color: #8a94a8; width: 26px; }}
  .tag {{ display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 9.5px; font-weight: 700; white-space: nowrap; }}
  .tag.ok {{ background: #dff5ec; color: #0f7a5c; }} .tag.bad {{ background: #fde3e6; color: #b42335; }}
  .tag.warn {{ background: #fff1d6; color: #9a5a00; }} .tag.na {{ background: #eceff4; color: #5b657a; }}
  .note {{ font-size: 9px; color: #6b7690; margin-top: 2px; }}
  .pill {{ display: inline-block; background: #2f6fed; color: #fff; border-radius: 10px; padding: 1px 8px; font-size: 11px; margin-left: 6px; }}
  .notes {{ margin: 4px 0; padding-left: 18px; color: #4b5670; }}
  .standard {{ margin: 16px 0; padding: 10px 12px; background: #f4f6fb; border-radius: 10px; font-size: 10px; color: #4b5670; }}
  .sign {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-top: 34px; page-break-inside: avoid; }}
  .sign div {{ border-top: 1px solid #8a94a8; padding-top: 6px; text-align: center; color: #4b5670; }}
  footer {{ margin-top: 18px; font-size: 9px; color: #8a94a8; text-align: center; }}
</style></head>
<body><div class="wrap">
  <header class="doc">
    <div>
      <div class="eyebrow">{org or 'MONITORING ZABBIX'} · EVIDENCE</div>
      <h1>{E(title)}</h1>
      <div class="muted">{E(meta.get('subtitle') or '')}</div>
    </div>
    <div class="doc-meta">
      Generated: <b>{E(generated)}</b><br>
      Zabbix: {E(meta.get('zabbix_url') or '-')} (v{E(str(meta.get('zabbix_version') or '-'))})<br>
      Prepared by: {E(meta.get('prepared_by') or '-')}
    </div>
  </header>
  <div class="standard">
    <b>เกณฑ์ประเมิน:</b> Coverage = Monitored ÷ (Total − Not Required). PASS ≥ {thresholds['pass_threshold']}% ·
    PARTIAL ≥ {thresholds['warn_threshold']}% · ต่ำกว่านั้น = FAIL.
    "Monitored" = มี item/template ตามมาตรฐานที่เปิดใช้งานและไม่ Unsupported. Items ที่ยังไม่มีข้อมูลหรือข้อมูลไม่อัปเดตแสดงใน Data health.
  </div>
  {summary}
  {body}
  <div class="sign"><div>ผู้จัดทำ / Prepared by</div><div>ผู้ตรวจสอบ / Reviewed by</div><div>ผู้อนุมัติ / Approved by</div></div>
  <footer>Monitoring Zabbix · Readiness report generated from live Zabbix API data · {E(generated)}</footer>
</div></body></html>"""


def build_csv(reports: List[Dict[str, Any]]) -> bytes:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["Host", "Zabbix ID", "OS", "Section", "Category", "Check", "Status", "Reason", "Expected",
                "Zabbix item / template", "Last value", "Last check", "Host overall %", "Verdict"])

    def clean(v: Any) -> str:
        s = "" if v is None else str(v)
        return "'" + s if s[:1] in ("=", "+", "@", "-") and not re.match(r"^-?\d+(\.\d+)?$", s) else s

    for r in reports:
        h = r["host"]
        for key, sec in r["sections"].items():
            for c in sec["checks"]:
                w.writerow([clean(x) for x in (
                    h.get("name"), h.get("hostid"), r["os_family"], SECTION_TITLES[key], c.get("category"), c["name"],
                    c["status"], c.get("reason"), c.get("expected"), c.get("actual"), c.get("lastvalue"),
                    c.get("lastclock"), r["overall"]["pct"], r["verdict"]["status"])])
    return ("\ufeff" + buf.getvalue()).encode("utf-8")


def build_json(reports: List[Dict[str, Any]], meta: Dict[str, Any]) -> bytes:
    return json.dumps({"meta": meta, "reports": reports}, ensure_ascii=False, indent=2).encode("utf-8")


# ---------------------------------------------------------------------------
# Headless browser rendering (Edge / Chrome / Chromium already on the machine)
# ---------------------------------------------------------------------------
def find_browser() -> Optional[str]:
    env = os.environ.get("MONITORING_BROWSER")
    if env and os.path.exists(env):
        return env
    candidates: List[str] = []
    if sys.platform.startswith("win"):
        for base in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"), os.environ.get("LOCALAPPDATA")):
            if base:
                candidates += [os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                               os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")]
    elif sys.platform == "darwin":
        candidates += ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                       "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                       "/Applications/Chromium.app/Contents/MacOS/Chromium"]
    for c in candidates:
        if os.path.exists(c):
            return c
    for name in ("msedge", "google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge"):
        p = shutil.which(name)
        if p:
            return p
    return None


def estimate_height(reports: List[Dict[str, Any]]) -> int:
    rows = 0
    for r in reports:
        rows += sum(len(s["checks"]) for s in r["sections"].values()) + min(len(r["health"]["issues"]), 100)
    return min(30000, 700 + len(reports) * 750 + rows * 30)


def render_with_browser(html_text: str, fmt: str, height: int = 2400) -> bytes:
    browser = find_browser()
    if not browser:
        raise RuntimeError("ไม่พบ Microsoft Edge / Google Chrome บนเครื่องนี้ (ใช้ไฟล์ HTML แล้วสั่ง Print → Save as PDF แทนได้)")
    with tempfile.TemporaryDirectory(prefix="mzbx_") as tmp:
        src = os.path.join(tmp, "report.html")
        out = os.path.join(tmp, "report." + fmt)
        with open(src, "w", encoding="utf-8") as f:
            f.write(html_text)
        url = "file:///" + src.replace("\\", "/").lstrip("/")
        common = [browser, "--disable-gpu", "--no-first-run", "--no-default-browser-check", "--hide-scrollbars",
                  f"--user-data-dir={os.path.join(tmp, 'profile')}", "--allow-file-access-from-files"]
        if fmt == "pdf":
            target = ["--no-pdf-header-footer", "--print-to-pdf-no-header", f"--print-to-pdf={out}"]
        else:
            target = [f"--screenshot={out}", f"--window-size=1240,{int(height)}", "--force-device-scale-factor=1"]
        last_err = ""
        for headless in ("--headless=new", "--headless"):
            try:
                proc = subprocess.run(common + [headless] + target + [url], capture_output=True, timeout=90)
                last_err = proc.stderr.decode("utf-8", "replace")[-400:]
            except subprocess.TimeoutExpired:
                last_err = "browser timed out"
                continue
            if os.path.exists(out) and os.path.getsize(out) > 0:
                with open(out, "rb") as f:
                    return f.read()
        raise RuntimeError(f"สร้างไฟล์ {fmt.upper()} ไม่สำเร็จ: {last_err.strip() or 'unknown error'}")
