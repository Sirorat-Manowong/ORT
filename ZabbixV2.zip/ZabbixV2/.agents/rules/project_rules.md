# Project Rules & Established Standards

Refer to [GEMINI.md](file:///c:/Project/Zabbix/GEMINI.md) at the workspace root for the complete rules and architectural guidelines.

## Quick Highlights:
1. **Server Execution:** Use `.\python\python.exe app.py`. Restart server whenever `app.py` or `zabbix_api.py` changes.
2. **Frontend:** Pure Vanilla HTML/CSS/JS in `web/`. Always bump asset versions (e.g. `?v=43`).
3. **Session:** Saved in `.session.json` and `localStorage`. Do not clear session on network timeout unless token is explicitly expired.
4. **Regex Syntax:** Never double-escape backslashes inside regex literals in `app.js`.
5. **UI Layout:** Settings menu is last in sidebar; Logout button is pinned at bottom left; High contrast dual dark/light themes.
