/**
 * Monitoring Zabbix - Front-end logic
 * UI = Monitoring Zabbix layout. Data = existing Zabbix REST backend (unchanged).
 * Endpoints used: /api/status, /api/connect, /api/disconnect, /api/hosts, /api/host/items
 */

const API_BASE = window.location.protocol === "file:" ? "http://127.0.0.1:5000" : "";

// ---- State ----
let hosts = [];              // normalized host list from /api/hosts
let currentHost = null;      // selected host object
let currentItems = [];       // items of selected host from /api/host/items
let currentParentTemplates = [];
let currentServices = [];    // discovered services (expected) from /api/host/discover-services
let cachedTemplates = [];    // all Zabbix templates from /api/templates (for auto-match)
let currentCompliance = null; // /api/host/compliance result for currentHost
let currentPage = "dashboard"; // active sidebar page
let loginMethod = "user";

// ---- DOM ----
const $ = (s) => document.querySelector(s);
const loginOverlay = $("#loginOverlay");
const portal = $("#portal");
const toastRegion = $("#toast");

// =========================================================
// Utilities
// =========================================================
function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

function showToast(message, isError = false) {
  if (!toastRegion) return;
  const el = document.createElement("div");
  el.className = "toast" + (isError ? " error" : "");
  el.textContent = (isError ? "✕ " : "✓ ") + message;
  toastRegion.appendChild(el);
  setTimeout(() => el.remove(), 4000);
}

async function apiRequest(endpoint, method = "GET", body = null) {
  const options = { method, headers: { "Content-Type": "application/json" } };
  if (body) options.body = JSON.stringify(body);
  const response = await fetch(`${API_BASE}${endpoint}`, options);
  const data = await response.json();
  if (!response.ok && !data.success) {
    throw new Error(data.error || data.message || `HTTP ${response.status}`);
  }
  return data;
}

// =========================================================
// Reusable Autocomplete (searchable dropdown)
// Attaches a filtered suggestion menu to an <input>.
//   opts.getItems(query) -> [{ value, label?, sub? }]  (string items also OK)
//   opts.onSelect(item)  -> called when a suggestion is chosen
//   opts.minChars        -> 0 shows all on focus (default 0)
// =========================================================
function highlight(text, query) {
  if (!query) return escapeHtml(text);
  const i = text.toLowerCase().indexOf(query.toLowerCase());
  if (i < 0) return escapeHtml(text);
  return escapeHtml(text.slice(0, i)) + "<mark>" + escapeHtml(text.slice(i, i + query.length)) + "</mark>" + escapeHtml(text.slice(i + query.length));
}

function setupAutocomplete(wrapSelector, opts) {
  const wrap = typeof wrapSelector === "string" ? $(wrapSelector) : wrapSelector;
  if (!wrap) return;
  const input = wrap.querySelector("input");
  const menu = wrap.querySelector(".ac-menu");
  if (!input || !menu) return;

  let items = [];
  let activeIdx = -1;

  const norm = (it) => (typeof it === "string" ? { value: it } : it);

  function render() {
    const q = input.value.trim();
    items = (opts.getItems(q) || []).map(norm);
    if (!items.length) {
      menu.innerHTML = `<div class="ac-empty">${q ? "ไม่พบรายการที่ตรงกับ \"" + escapeHtml(q) + "\"" : "ไม่มีตัวเลือก"}</div>`;
      menu.hidden = false;
      return;
    }
    menu.innerHTML = items
      .map((it, i) => {
        const label = it.label || it.value;
        const sub = it.sub ? `<span class="ac-sub">${escapeHtml(it.sub)}</span>` : "";
        const allCls = it.isAll ? " ac-all" : "";
        const icon = it.isAll ? `<span class="ac-all-icon" style="display:inline-flex;align-items:center;margin-right:6px"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"/><rect x="2" y="14" width="20" height="8" rx="2" ry="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg></span>` : "";
        return `<div class="ac-item${i === activeIdx ? " active" : ""}${allCls}" data-idx="${i}">${icon}${highlight(label, q)}${sub}</div>`;
      })
      .join("");
    menu.hidden = false;
  }

  function close() { menu.hidden = true; activeIdx = -1; }

  function choose(i) {
    const it = items[i];
    if (!it) return;
    input.value = it.value;
    close();
    if (opts.onSelect) opts.onSelect(it);
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  input.addEventListener("focus", () => {
    try { input.select(); } catch (_) {}
    render();
  });
  input.addEventListener("click", () => { if (menu.hidden) render(); });
  input.addEventListener("input", () => { activeIdx = -1; render(); });
  input.addEventListener("keydown", (e) => {
    if (menu.hidden) return;
    if (e.key === "ArrowDown") { e.preventDefault(); activeIdx = Math.min(activeIdx + 1, items.length - 1); render(); scrollActive(); }
    else if (e.key === "ArrowUp") { e.preventDefault(); activeIdx = Math.max(activeIdx - 1, 0); render(); scrollActive(); }
    else if (e.key === "Enter") { if (activeIdx >= 0) { e.preventDefault(); choose(activeIdx); } }
    else if (e.key === "Escape") { close(); }
  });
  function scrollActive() {
    const el = menu.querySelector(".ac-item.active");
    if (el) el.scrollIntoView({ block: "nearest" });
  }

  menu.addEventListener("mousedown", (e) => {
    const item = e.target.closest(".ac-item");
    if (!item) return;
    e.preventDefault();
    choose(parseInt(item.dataset.idx, 10));
  });

  document.addEventListener("click", (e) => {
    if (!wrap.contains(e.target)) close();
  });

  // expose a refresh hook (used after data loads)
  wrap._acRefresh = () => { if (document.activeElement === input) render(); };
}

function sparkPoints(seed) {
  // Deterministic pseudo sparkline around a baseline value (0-100)
  const base = Math.max(5, Math.min(90, seed || 20));
  const pts = [];
  let v = base;
  for (let i = 0; i <= 13; i++) {
    const noise = ((seed * (i + 3) * 7) % 17) - 8;
    v = Math.max(2, Math.min(95, base + noise));
    const x = Math.round((i / 13) * 150);
    const y = Math.round(25 - (v / 100) * 23);
    pts.push(`${x},${y}`);
  }
  return pts.join(" ");
}

// =========================================================
// Authentication
// =========================================================
async function checkAuthStatus() {
  try {
    const res = await apiRequest("/api/status");
    if (res && res.connected) {
      onLoggedIn(res);
      return true;
    }
  } catch (err) {
    console.warn("Backend not reachable or no session:", err);
  }
  showLogin();
  return false;
}

function showLogin() {
  loginOverlay.hidden = false;
  portal.hidden = true;
}

// Environment (UAT / Production) is derived from the Zabbix Server URL used at login.
// A URL that looks like UAT/non-production (uat, nonprod, dev, sit, test, staging, qa)
// is treated as UAT; anything else defaults to Production.
let currentEnv = "Production";

function detectEnvFromUrl(url) {
  const u = (url || "").toLowerCase();
  const uatHints = ["uat", "nonprod", "non-prod", "dev", "develop", "sit", "test", "staging", "stage", "qa"];
  return uatHints.some((h) => u.includes(h)) ? "UAT" : "Production";
}

function applyEnvironment(url) {
  currentEnv = detectEnvFromUrl(url);
  const badge = $("#envBadge");
  if (badge) {
    badge.textContent = currentEnv;
    badge.classList.toggle("prod", currentEnv === "Production");
    badge.classList.toggle("uat", currentEnv === "UAT");
    badge.hidden = false;
    badge.title = `ประเมินจาก URL ที่ใช้ login: ${url || "-"}`;
  }
  if (currentHost) renderServerInfo(currentHost);
}

function onLoggedIn(statusRes) {
  loginOverlay.hidden = true;
  portal.hidden = false;
  applyEnvironment(statusRes.url);
  updateBrandTitle(currentPage || "dashboard");
  initSidebarCollapse();
  const label = $("#userLabel");
  if (label) {
    label.dataset.suffix = statusRes.version ? `Zabbix v${statusRes.version}` : "";
    applyProfileName(loadProfile().name);
  }
  const foot = $("#globalFoot");
  if (foot) foot.textContent = `เชื่อมต่อ Zabbix สำเร็จ${statusRes.version ? " (v" + statusRes.version + ")" : ""} · ข้อมูลดึงจาก Zabbix API`;
  loadHosts();
  loadTemplates();
}

// Load all Zabbix templates once for Template Mapping auto-match
async function loadTemplates() {
  try {
    const res = await apiRequest("/api/templates");
    if (res && res.success && Array.isArray(res.templates)) {
      cachedTemplates = res.templates;
    }
  } catch (err) {
    console.warn("loadTemplates failed:", err);
  }
}

// Fuzzy-match a typed software name to Zabbix templates.
// Returns templates sorted by relevance (best first).
function matchTemplates(query) {
  const q = (query || "").toLowerCase().trim();
  if (!q) return [];
  const words = q.split(/[\s_\-:]+/).filter(Boolean);
  return cachedTemplates
    .map((t) => {
      const name = (t.name || "").toLowerCase();
      let score = 0;
      if (name === q) score = 100;
      else if (name.includes(q)) score = 80;
      else {
        const hit = words.filter((w) => name.includes(w)).length;
        if (hit) score = 40 + hit * 10;
      }
      return { ...t, score };
    })
    .filter((t) => t.score > 0)
    .sort((a, b) => b.score - a.score);
}

// Restore remembered login inputs
try {
  localStorage.removeItem("mz_login_url");
  const savedUser = localStorage.getItem("mz_login_user");
  const savedMethod = localStorage.getItem("mz_login_method");
  const savedVerifySsl = localStorage.getItem("mz_verify_ssl");
  if (savedUser && $("#loginUser")) $("#loginUser").value = savedUser;
  if (savedVerifySsl === "false") $("#loginVerifySsl").checked = false;
  if (savedMethod === "token") {
    loginMethod = "token";
    document.querySelectorAll(".login-tab").forEach((t) => t.classList.toggle("active", t.dataset.method === "token"));
    if ($("#userFields")) $("#userFields").hidden = true;
    if ($("#tokenFields")) $("#tokenFields").hidden = false;
  }
} catch (e) {}

// Login tab switch
document.querySelectorAll(".login-tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    loginMethod = tab.dataset.method;
    document.querySelectorAll(".login-tab").forEach((t) => t.classList.toggle("active", t === tab));
    $("#userFields").hidden = loginMethod !== "user";
    $("#tokenFields").hidden = loginMethod !== "token";
  });
});

$("#loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const url = $("#loginUrl").value.trim();
  const username = $("#loginUser").value.trim();
  const password = $("#loginPass").value;
  const token = $("#loginToken").value.trim();
  const err = $("#loginError");
  err.hidden = true;

  if (!url) { err.textContent = "กรุณากรอก Zabbix Server URL"; err.hidden = false; return; }
  if (loginMethod === "user" && (!username || !password)) {
    err.textContent = "กรุณากรอก Username และ Password"; err.hidden = false; return;
  }
  if (loginMethod === "token" && !token) {
    err.textContent = "กรุณากรอก API Token"; err.hidden = false; return;
  }

  const btn = $("#loginSubmit");
  btn.disabled = true;
  btn.textContent = "กำลังเชื่อมต่อ...";
  try {
    const payload = {
      url,
      username: loginMethod === "user" ? username : "",
      password: loginMethod === "user" ? password : "",
      api_token: loginMethod === "user" ? "" : token,
      verify_ssl: $("#loginVerifySsl").checked
    };
    const res = await apiRequest("/api/connect", "POST", payload);
    if (res && res.success) {
      showToast("เชื่อมต่อ Zabbix Server สำเร็จ!");
      try {
        if (loginMethod === "user") localStorage.setItem("mz_login_user", username);
        localStorage.setItem("mz_login_method", loginMethod);
        localStorage.setItem("mz_verify_ssl", String($("#loginVerifySsl").checked));
      } catch (e) {}
      onLoggedIn({ connected: true, version: res.version, url: res.url });
    } else {
      throw new Error(res.message || "เชื่อมต่อไม่สำเร็จ");
    }
  } catch (e2) {
    err.textContent = `เชื่อมต่อไม่สำเร็จ: ${e2.message}`;
    err.hidden = false;
  } finally {
    btn.disabled = false;
    btn.textContent = "เข้าสู่ระบบ →";
  }
});

$("#logoutLink").addEventListener("click", async (e) => {
  e.preventDefault();
  try { await apiRequest("/api/disconnect", "POST"); } catch (err) {}
  showToast("ออกจากระบบแล้ว");
  showLogin();
});

// =========================================================
// Load hosts (from /api/hosts) and build filter dropdowns
// =========================================================
async function loadHosts() {
  try {
    const data = await apiRequest("/api/hosts");
    if (!data || !data.success || !Array.isArray(data.hosts)) return;

    hosts = data.hosts.map((h) => {
      const iface = (h.interfaces && h.interfaces[0]) || {};
      const manageIp = iface.ip || "127.0.0.1";
      const port = iface.port || "10050";
      const groupName = (h.groups && h.groups[0] && h.groups[0].name) || "Zabbix servers";
      const templates = h.parentTemplates || [];
      const isWindows =
        templates.some((t) => (t.name || "").toLowerCase().includes("windows")) ||
        (h.host || "").toLowerCase().includes("win");
      const macros = h.macros || [];
      const getMacro = (m) => {
        const found = macros.find((x) => x.macro === m);
        return found && found.value ? found.value : "";
      };
      return {
        id: String(h.hostid),
        hostid: String(h.hostid),
        name: h.name || h.host,
        techName: h.host,
        ip: manageIp,
        manageIp: `${manageIp}:${port}`,
        serviceIp: getMacro("{$HOST.IP2}"),
        actionHost: getMacro("{$ACTION_HOST}") || (h.name || h.host),
        oracleSid: getMacro("{$ORACLE_SID}"),
        groups: (h.groups || []).map((g) => g.name),
        group: groupName,
        os: isWindows ? "Windows Server (Zabbix Agent)" : "Linux (Zabbix Agent)",
        type: isWindows ? "Windows" : "Linux",
        status: h.status === "0" ? "online" : "pending",
        templates: templates,
        raw: h
      };
    });

    // Parse Application group pattern "123 : appname" from Zabbix groups
    // appId = numeric left part, appName = right part. Keep full "123 : app" label too.
    hosts.forEach((h) => {
      const appGroup = (h.groups || []).find((g) => /^\s*\d+\s*:\s*\S+/.test(g));
      if (appGroup) {
        const m = appGroup.match(/^\s*(\d+)\s*:\s*(.+?)\s*$/);
        h.appId = m ? m[1] : appGroup;
        h.appName = m ? m[2] : appGroup;
        h.appLabel = appGroup.replace(/\s+/g, " ").trim();
      } else {
        h.appId = "";
        h.appName = "";
        h.appLabel = "";
      }
    });

    buildFilters();
    // Start empty: let the user pick Application / Environment / Server first.
    if (!hosts.length) {
      $("#serverInfo").innerHTML = '<tr><td colspan="2" style="text-align:center;color:#8ea0b4;padding:16px">ยังไม่มีเครื่องใน Zabbix</td></tr>';
    }
  } catch (err) {
    console.error("loadHosts failed:", err);
    showToast(`โหลดรายการ Server ไม่สำเร็จ: ${err.message}`, true);
  }
}

// Distinct Application groups (only hosts that belong to a "123 : app" group)
function appHosts() {
  return hosts.filter((h) => h.appId);
}

// Combined "appid : appname" label used in the Application filter
function appLabelFor(h) {
  return h.appLabel || (h.appId ? `${h.appId} : ${h.appName}` : "");
}

// Extract appId from a typed "appid : appname" string (or bare appid)
function appIdFromInput(val) {
  if (!val) return "";
  const m = String(val).match(/^\s*(\d+)/);
  return m ? m[1] : val.trim();
}

// Distinct "appid : appname" labels, de-duplicated
function appOptionLabels() {
  const seen = new Map();
  appHosts().forEach((h) => { if (!seen.has(h.appId)) seen.set(h.appId, appLabelFor(h)); });
  return [...seen.values()];
}

function buildFilters() {
  // Autocomplete data sources are read live via getItems, so nothing to pre-fill.
  refreshHostOptions();
}

let isAllHostsSelected = false;

// Kept for compatibility: sets the Server Name value when a host is chosen.
function refreshHostOptions(preferredName) {
  if (preferredName) {
    if (isAllHostsSelected && preferredName !== "ทั้งหมด") {
      $("#host").value = "ทั้งหมด";
    } else {
      $("#host").value = preferredName;
    }
  }
}

// Hosts available for the currently typed Application (or all if none typed)
function hostOptionsForApp() {
  const appId = appIdFromInput($("#app").value);
  const members = appId ? hosts.filter((h) => h.appId === appId) : hosts;
  return members.length ? members : hosts;
}

// Resolve the host object from the typed Server Name
function hostFromInput(val) {
  if (!val) return null;
  const q = val.trim().toLowerCase();
  if (q === "ทั้งหมด" || q === "all") return null;
  return hosts.find((h) => h.name.toLowerCase() === q)
    || hosts.find((h) => h.name.toLowerCase().includes(q))
    || null;
}

function selectAllHostsForCurrentApp() {
  const appHosts = hostOptionsForApp();
  if (!appHosts.length) {
    showToast("ไม่พบเครื่องในระบบ", true);
    return;
  }
  isAllHostsSelected = true;
  $("#host").value = "ทั้งหมด";

  // Select all target hosts for Template Mapping
  selectedMapTargetHostIds.clear();
  appHosts.forEach((h) => selectedMapTargetHostIds.add(h.hostid));

  // If reports page, also select all
  if (typeof selectedReportHostIds !== "undefined") {
    selectedReportHostIds.clear();
    appHosts.forEach((h) => selectedReportHostIds.add(h.hostid));
  }

  // Use currently selected host if it is in appHosts, else first host
  const baselineHost = (currentHost && appHosts.some((h) => h.hostid === currentHost.hostid))
    ? currentHost
    : appHosts[0];

  selectHost(baselineHost.id).then(() => {
    $("#host").value = "ทั้งหมด";
    if (currentPage && !["dashboard", "os", "software"].includes(currentPage)) {
      renderCurrentPage();
    } else {
      const foot = $("#globalFoot");
      if (foot) {
        foot.textContent = `เลือก: ทั้งหมด (${appHosts.length} เครื่องใน Application) · กำลังตรวจสอบผ่าน ${baselineHost.name}`;
      }
    }
  });

  showToast(`เลือกทั้งหมด ${appHosts.length} เครื่องใน Application เรียบร้อย`);
}

// ---- Wire up the three filter autocompletes ----
setupAutocomplete('[data-ac="app"]', {
  getItems: (q) => {
    const ql = q.toLowerCase();
    return appOptionLabels().filter((l) => !ql || l.toLowerCase().includes(ql));
  },
  onSelect: (it) => {
    const appId = appIdFromInput(it.value);
    const members = hosts.filter((h) => h.appId === appId);
    if (currentHost && currentHost.appId !== appId) {
      if (members.length) {
        $("#host").value = members[0].name;
        selectHost(members[0].id);
        if (currentPage && !["dashboard", "os", "software"].includes(currentPage)) {
          renderCurrentPage();
        }
      } else {
        $("#host").value = "";
      }
    } else if (!currentHost && members.length) {
      $("#host").value = members[0].name;
      selectHost(members[0].id);
      if (currentPage && !["dashboard", "os", "software"].includes(currentPage)) {
        renderCurrentPage();
      }
    }
  }
});
setupAutocomplete('[data-ac="host"]', {
  getItems: (q) => {
    let ql = (q || "").toLowerCase().trim();
    const isAllText = (ql === "ทั้งหมด" || ql === "all");
    const appHosts = hostOptionsForApp();
    if (!appHosts.length) return [];

    // If query equals current host name (e.g. user clicked/focused the input while
    // a host was already selected like "ZBAPP"), or is "ทั้งหมด" / "all", or is empty:
    // show ALL hosts in this app so the user can easily choose any host or "ทั้งหมด"!
    const isCurrentHostName = currentHost && ql === currentHost.name.toLowerCase();
    const isShowingAll = !ql || isAllText || isCurrentHostName;

    const filterQ = isShowingAll ? "" : ql;

    const filtered = appHosts
      .filter((h) => !filterQ || h.name.toLowerCase().includes(filterQ) || (h.ip || "").toLowerCase().includes(filterQ))
      .map((h) => ({ value: h.name, sub: h.ip || h.type }));

    // If search text doesn't match any host and isn't "ทั้งหมด" / "all", return empty
    const queryMatchesAllKeyword = "ทั้งหมด".includes(ql) || "all".includes(ql);
    if (!isShowingAll && !queryMatchesAllKeyword && filtered.length === 0) {
      return [];
    }

    // "ทั้งหมด" option is always shown at the top when hosts are available!
    const list = [{
      value: "ทั้งหมด",
      label: "ทั้งหมด",
      sub: `ทุกเครื่อง (${appHosts.length} เครื่อง)`,
      isAll: true
    }];

    return list.concat(filtered);
  },
  onSelect: (it) => {
    if (it.isAll || it.value === "ทั้งหมด") {
      selectAllHostsForCurrentApp();
    } else {
      isAllHostsSelected = false;
      const host = hostFromInput(it.value);
      if (host) {
        selectHost(host.id);
        if (currentPage && !["dashboard", "os", "software"].includes(currentPage)) {
          renderCurrentPage();
        }
      }
    }
  }
});

$("#btnSearch").addEventListener("click", () => {
  const val = ($("#host").value || "").trim();
  if (val === "ทั้งหมด" || val.toLowerCase() === "all") {
    selectAllHostsForCurrentApp();
    return;
  }
  const host = hostFromInput(val);
  if (host) {
    isAllHostsSelected = false;
    selectHost(host.id);
    if (currentPage && !["dashboard", "os", "software"].includes(currentPage)) {
      renderCurrentPage();
    }
  } else {
    // No exact server typed: fall back to first host of the typed application
    const appId = appIdFromInput($("#app").value);
    const first = (appId ? hosts.filter((h) => h.appId === appId) : hosts)[0];
    if (first) {
      isAllHostsSelected = false;
      selectHost(first.id);
      if (currentPage && !["dashboard", "os", "software"].includes(currentPage)) {
        renderCurrentPage();
      }
    } else {
      showToast("ไม่พบ Server ที่ตรงกับการค้นหา", true);
    }
  }
});

$("#btnReset").addEventListener("click", () => {
  isAllHostsSelected = false;
  // Clear all filters back to empty state
  $("#app").value = "";
  $("#host").value = "";
  refreshHostOptions();           // repopulate full server list
  currentHost = null;
  currentCompliance = null;
  $("#softwareSearch").value = "";
  softwareAllRows = [];
  $("#softwarePager").hidden = true;
  $("#softwareRows").innerHTML = '<tr><td colspan="9" style="text-align:center;color:#8ea0b4;padding:14px">เลือกเครื่องเพื่อดู software / service</td></tr>';
  // Reset the dashboard panels to the initial empty prompt
  $("#serverInfo").innerHTML = '<tr><td colspan="2" style="text-align:center;color:#8ea0b4;padding:16px">เลือกเครื่องเพื่อดูข้อมูล</td></tr>';
  if (currentPage && !["dashboard", "os", "software"].includes(currentPage)) {
    renderCurrentPage();
  }
});

// =========================================================
// Select host -> load items (/api/host/items) and render
// =========================================================
async function selectHost(hostid, opts) {
  const host = hosts.find((h) => h.id === hostid);
  if (!host) return;
  if (currentHost !== host) currentCompliance = null;
  currentHost = host;

  // sync filter inputs to the selected host
  if (host.appId) $("#app").value = appLabelFor(host);
  refreshHostOptions(host.name);

  renderServerInfo(host);

  // placeholders while loading
  $("#metricRows").innerHTML = '<tr><td colspan="7" style="text-align:center;color:#8ea0b4;padding:14px">กำลังโหลด items...</td></tr>';
  $("#softwareRows").innerHTML = '<tr><td colspan="7" style="text-align:center;color:#8ea0b4;padding:14px">กำลังโหลด...</td></tr>';

  try {
    // Items feed the live resource cards; the compliance engine (server side) does the
    // standard check: inventory vs Zabbix items/templates -> % per section.
    const [itemsRes, comp] = await Promise.all([
      apiRequest(`/api/host/items?hostid=${host.hostid}`),
      apiRequest(`/api/host/compliance?hostid=${host.hostid}${opts && opts.refresh ? "&refresh=1" : ""}`)
    ]);
    if (currentHost !== host) return;  // user switched host while loading

    currentItems = (itemsRes && itemsRes.items) || [];
    currentParentTemplates = (itemsRes && itemsRes.parent_templates) || host.templates || [];
    currentCompliance = comp;

    renderResources(currentItems);
    renderServerInfo(host);
    renderComplianceDashboard(comp);
    $("#globalFoot").textContent = `แสดงผลสำหรับ ${host.name} · ${currentItems.length} items · ` +
      `Inventory: ${comp.inventory.confidence} · ประเมินเมื่อ ${comp.generated_at}`;
    if (currentPage && !["dashboard", "os", "software"].includes(currentPage)) {
      renderCurrentPage();
    }
  } catch (err) {
    console.error("items load failed:", err);
    showToast(`โหลด items ไม่สำเร็จ: ${err.message}`, true);
    $("#metricRows").innerHTML = `<tr><td colspan="7" style="text-align:center;color:#ff8f99;padding:14px">${escapeHtml(err.message)}</td></tr>`;
  }
}

// Selecting a Server Name from the datalist loads that host immediately
$("#host").addEventListener("change", (e) => {
  const host = hostFromInput(e.target.value);
  if (host) {
    selectHost(host.id);
    if (currentPage && !["dashboard", "os", "software"].includes(currentPage)) {
      renderCurrentPage();
    }
  }
});

// =========================================================
// Renderers
// =========================================================
function renderServerInfo(host) {
  const c = currentCompliance && currentCompliance.host && String(currentCompliance.host.hostid) === host.hostid ? currentCompliance : null;
  $("#serverInfo").innerHTML = `
    <tr><td>Hostname</td><td>${escapeHtml(host.name)}</td></tr>
    <tr><td>Technical Name</td><td>${escapeHtml(host.techName)}</td></tr>
    <tr><td>IP Address (Manage)</td><td>${escapeHtml(host.manageIp)}</td></tr>
    <tr><td>IP Service ({$HOST.IP2})</td><td>${host.serviceIp ? escapeHtml(host.serviceIp) : "-"}</td></tr>
    <tr><td>Application ID</td><td>${host.appId ? escapeHtml(host.appId) : "-"}</td></tr>
    <tr><td>Application Name</td><td>${host.appName ? escapeHtml(host.appName) : "-"}</td></tr>
    <tr><td>Group</td><td>${escapeHtml(host.group)}</td></tr>
    <tr><td>Environment</td><td><span class="tag" style="background:#113e78;color:#c4e0ff">${escapeHtml(currentEnv || "-")}</span></td></tr>
    <tr><td>Zabbix Host ID</td><td>${escapeHtml(host.hostid)}</td></tr>
    <tr><td>OS</td><td>${c ? `<b>${escapeHtml(c.os_family.toUpperCase())}</b> ${escapeHtml(c.os_name || "")}` : escapeHtml(host.os)}</td></tr>
    <tr><td>OS Template</td><td>${c ? (c.os_template.linked.length ? escapeHtml(c.os_template.linked.join(", "))
      : `<span class="warn">ยังไม่ผูก</span> <span class="muted">(แนะนำ ${escapeHtml(c.os_template.recommended)})</span>`) : "-"}</td></tr>
    <tr><td>Inventory</td><td>${c ? confidenceTag(c.inventory.confidence) : "-"}</td></tr>
    <tr><td>Readiness</td><td>${c ? verdictTag(c.verdict, c.overall.pct) : '<span class="muted">กำลังประเมิน...</span>'}</td></tr>
    <tr><td>Action Host ({$ACTION_HOST})</td><td>${escapeHtml(host.actionHost)}</td></tr>
    ${host.oracleSid ? `<tr><td>Oracle SID</td><td>${escapeHtml(host.oracleSid)}</td></tr>` : ""}
    <tr><td>Server Status</td><td><span class="tag ${host.status === "online" ? "ok" : "warn"}">${host.status === "online" ? "Active" : "Pending"}</span></td></tr>
    <tr><td>Last Updated</td><td>${new Date().toLocaleString("th-TH")}</td></tr>
  `;
}

// Pull a numeric 0-100 value from items by matching key/name patterns
function findMetric(items, matchers) {
  for (const it of items) {
    const k = (it.key_ || "").toLowerCase();
    const n = (it.name || "").toLowerCase();
    const last = parseFloat(it.lastvalue);
    if (isNaN(last) || last < 0 || last > 100) continue;
    for (const m of matchers) {
      if (k.includes(m) || n.includes(m)) return Math.round(last);
    }
  }
  return null;
}

function renderResources(items) {
  const cpu = findMetric(items, ["system.cpu.util", "cpu utilization", "processor time", "cpu percentage"]);
  const mem = findMetric(items, ["vm.memory", "memory used", "memory utilization"]);
  const disk = findMetric(items, ["vfs.fs.size", "disk percentage", "disk utilization"]);

  const setRes = (sel, val, unit, strokeSeed, color) => {
    const card = $(`[data-res="${sel}"]`);
    if (!card) return;
    card.textContent = val === null ? "—" : (unit === "%" ? `${val}%` : `${val}`);
    if (color) card.style.color = color;
    const poly = card.closest(".resource").querySelector("polyline");
    if (poly) poly.setAttribute("points", sparkPoints(val === null ? 20 : val));
  };

  setRes("cpu", cpu, "%", cpu, cpu !== null && cpu > 80 ? "#ff626d" : "#25d9a0");
  setRes("mem", mem, "%", mem, mem !== null && mem > 85 ? "#ff626d" : "#a66bff");
  setRes("disk", disk, "%", disk, disk !== null && disk > 85 ? "#ff626d" : "#42a5ff");

  // Network: find bits/bytes rate item, show as text
  const netItem = items.find((it) => (it.key_ || "").toLowerCase().startsWith("net.if."));
  const netCard = $('[data-res="net"]');
  if (netCard) {
    if (netItem && netItem.lastvalue) {
      const v = parseFloat(netItem.lastvalue);
      const mbps = isNaN(v) ? netItem.lastvalue : (v / 1e6).toFixed(1) + " Mbps";
      netCard.textContent = mbps;
      netCard.style.color = "#ffc44d";
    } else {
      netCard.textContent = "—";
      netCard.style.color = "#ffc44d";
    }
    const poly = netCard.closest(".resource").querySelector("polyline");
    if (poly) poly.setAttribute("points", sparkPoints(35));
  }
}

// =========================================================
// Compliance (Monitoring Standard) rendering
// =========================================================
function statusTag(status, issue) {
  if (status === "Monitored") {
    return issue ? `<span class="tag warn" title="${escapeHtml(issue)}">▲ Monitored</span>` : '<span class="tag ok">● Monitored</span>';
  }
  if (status === "Not Required") return '<span class="tag neutral">— Not Required</span>';
  return '<span class="tag bad">✕ Not Monitored</span>';
}

function verdictTag(v, pct) {
  const cls = { PASS: "ok", PARTIAL: "warn", FAIL: "bad" }[v.status] || "neutral";
  return `<span class="tag ${cls}">${escapeHtml(v.status)}</span> ${pct == null ? "" : pct + "%"} <span class="muted">${escapeHtml(v.label)}</span>`;
}

function confidenceTag(conf) {
  const map = {
    verified: ['ok', 'Verified', 'ข้อมูลจริงจากเครื่อง'],
    partial: ['warn', 'Partial', 'ข้อมูลจริงบางส่วน'],
    estimated: ['bad', 'Estimated', 'ประเมินจาก Zabbix items เท่านั้น'],
  }[conf] || ['neutral', conf, ''];
  return `<span class="tag ${map[0]}">${map[1]}</span> <span class="muted">${map[2]}</span>`;
}

function pctOrDash(p) { return p == null ? "—" : p; }

// Software ring = Windows services / processes + installed software (the user's "Software Monitoring")
function combineSummary(a, b) {
  const s = {
    total: a.total + b.total, monitored: a.monitored + b.monitored,
    not_monitored: a.not_monitored + b.not_monitored, not_required: a.not_required + b.not_required,
  };
  const denom = s.total - s.not_required;
  s.pct = denom > 0 ? Math.round(s.monitored * 100 / denom) : null;
  return s;
}

function renderComplianceDashboard(c) {
  const os = c.sections.os, svc = c.sections.service, sw = c.sections.software;
  const swAll = combineSummary(svc, sw);
  const ov = c.overall;
  setRing("#overallRing", pctOrDash(ov.pct), "#overallCounts",
    `Total <b>${ov.total}</b>　Monitored <b>${ov.monitored}</b><br>Not Monitored <b>${ov.not_monitored}</b>　Not Required <b>${ov.not_required}</b>`);
  setRing("#osRing", pctOrDash(os.pct), "#osCounts",
    `Total <b>${os.total - os.not_required}</b>　Monitored <b>${os.monitored}</b><br>Not Monitored <b>${os.not_monitored}</b>`);
  setRing("#swRing", pctOrDash(swAll.pct), "#swCounts",
    `Total <b>${swAll.total}</b>　Monitored <b>${swAll.monitored}</b><br>Not Monitored <b>${swAll.not_monitored}</b>　Not Required <b>${swAll.not_required}</b>`);

  const agent = os.checks.find((x) => x.id === "agent_availability");
  setHealth("#hbHost", "● Registered", "ok");
  if (agent && agent.status === "Monitored" && !agent.issue) setHealth("#hbAgent", "● Connected", "ok");
  else if (agent && agent.status === "Monitored") setHealth("#hbAgent", "▲ " + (agent.issue || "check"), "warn");
  else setHealth("#hbAgent", "✕ No agent check", "bad");
  setHealth("#hbTemplate", c.os_template.linked.length ? "● Assigned" : (c.templates.length ? "▲ No OS template" : "✕ None"),
    c.os_template.linked.length ? "ok" : (c.templates.length ? "warn" : "bad"));
  const lvl = (p) => (p == null ? ["— N/A", "neutral"] : p >= 100 ? ["● Full", "ok"] : p > 0 ? [`▲ ${p}%`, "warn"] : ["✕ None", "bad"]);
  setHealth("#hbOs", ...lvl(os.pct));
  setHealth("#hbSw", ...lvl(swAll.pct));

  renderOsChecks(os.checks);
  setSoftwareRows(c);
  renderInventoryBanner(c);
}

function renderOsChecks(checks) {
  $("#metricRows").innerHTML = checks.map((ck, i) => {
    const val = ck.lastvalue === "" || ck.lastvalue == null ? "-" : `${ck.lastvalue}${ck.units ? " " + ck.units : ""}`;
    return `<tr data-check="${escapeHtml(ck.check_key)}">
      <td>${i + 1}</td><td>${escapeHtml(ck.name)} <span class="muted">· ${escapeHtml(ck.category)}</span></td>
      <td class="mono">${escapeHtml(ck.expected || "-")}</td><td class="mono">${escapeHtml(ck.actual || "-")}</td>
      <td>${statusTag(ck.status, ck.issue)}${ck.reason ? `<div class="cell-note">${escapeHtml(ck.reason)}</div>` : ""}</td>
      <td>${escapeHtml(String(val).slice(0, 40))}</td><td>${escapeHtml(ck.lastclock || "-")}</td></tr>`;
  }).join("") || '<tr><td colspan="7" class="empty-cell">ไม่มีรายการ</td></tr>';
}

function findCheck(checkKey) {
  if (!currentCompliance) return null;
  for (const sec of Object.values(currentCompliance.sections)) {
    const hit = sec.checks.find((x) => x.check_key === checkKey);
    if (hit) return hit;
  }
  return null;
}

// Detail box with the recommended fix + waiver controls
function showCheckDetail(boxSel, ck) {
  const el = $(boxSel);
  el.className = "detail show";
  const act = ck.action;
  const fixBtn = act && act.type !== "none"
    ? `<button class="mini-btn add" data-fix="${escapeHtml(ck.check_key)}">＋ ${escapeHtml(act.label)}</button>` : "";
  const waiveBtn = ck.waived
    ? `<button class="mini-btn" data-unwaive="${escapeHtml(ck.check_key)}">↺ ยกเลิก Not Required</button>`
    : ck.waivable ? `<button class="mini-btn" data-waive="${escapeHtml(ck.check_key)}">— ตั้งเป็น Not Required</button>` : "";
  el.innerHTML = `<b>${escapeHtml(ck.name)}</b> ${statusTag(ck.status, ck.issue)}
    <div class="detail-grid">
      <span>Standard</span><span class="mono">${escapeHtml(ck.expected || "-")}</span>
      <span>Zabbix</span><span class="mono">${escapeHtml(ck.actual || "-")}</span>
      ${ck.evidence ? `<span>Evidence</span><span>${escapeHtml(ck.evidence)}</span>` : ""}
      ${ck.reason ? `<span>Reason</span><span>${escapeHtml(ck.reason)}</span>` : ""}
      ${ck.error ? `<span>Error</span><span class="bad">${escapeHtml(ck.error)}</span>` : ""}
      ${ck.lastclock ? `<span>Last check</span><span>${escapeHtml(ck.lastclock)} · ${escapeHtml(String(ck.lastvalue).slice(0, 120))}</span>` : ""}
    </div>
    ${act && act.type === "none" ? `<div class="cell-note">${escapeHtml(act.label)}</div>` : ""}
    <div class="row-actions" style="margin-top:8px">${fixBtn}${waiveBtn}</div>`;
}

// Apply one recommended fix / waiver via the backend, then re-evaluate
async function runCheckAction(kind, checkKey, btn) {
  const ck = findCheck(checkKey);
  if (!ck || !currentHost) return;
  let action;
  if (kind === "fix") {
    action = { ...ck.action, os_family: currentCompliance.os_family };
    const what = action.type === "link_template" ? `ผูก Template "${action.name}"` : action.label;
    if (!confirm(`${what}\nบนเครื่อง ${currentHost.name} (Zabbix)?`)) return;
  } else if (kind === "waive") {
    const reason = prompt(`เหตุผลที่ "${ck.name}" ไม่ต้อง Monitor (จะแสดงใน Report):`, "");
    if (reason === null) return;
    action = { type: "waive", check_key: checkKey, reason };
  } else {
    action = { type: "unwaive", check_key: checkKey };
  }
  if (btn) { btn.disabled = true; btn.textContent = "กำลังดำเนินการ..."; }
  try {
    const res = await apiRequest("/api/host/compliance/fix", "POST", { hostid: currentHost.hostid, action });
    showToast(res.message || (res.success ? "สำเร็จ" : "ไม่สำเร็จ"), !res.success);
    await refreshCurrentHost();
  } catch (err) {
    showToast(`ไม่สำเร็จ: ${err.message}`, true);
    if (btn) btn.disabled = false;
  }
}

async function refreshCurrentHost(refreshInventory = false) {
  if (!currentHost) return;
  await selectHost(currentHost.id, { refresh: refreshInventory });
  if (currentPage === "mapping") renderMapping();
}

// One delegated handler for all fix / waiver buttons on every page
document.addEventListener("click", (e) => {
  const b = e.target.closest("[data-fix],[data-waive],[data-unwaive]");
  if (!b) return;
  e.preventDefault();
  if (b.dataset.fix) runCheckAction("fix", b.dataset.fix, b);
  else if (b.dataset.waive) runCheckAction("waive", b.dataset.waive, b);
  else runCheckAction("unwaive", b.dataset.unwaive, b);
});

$("#metricRows").addEventListener("click", (e) => {
  const tr = e.target.closest("tr[data-check]");
  if (!tr || e.target.closest("button")) return;
  const ck = findCheck(tr.dataset.check);
  if (ck) showCheckDetail("#metricDetail", ck);
});

$("#btnAllItems").addEventListener("click", () => {
  const el = $("#metricDetail");
  el.className = "detail show";
  if (!currentItems.length) { el.innerHTML = "ยังไม่มี items"; return; }
  const list = currentItems.slice(0, 80).map((it) => `${escapeHtml(it.name || it.key_)} <span class="muted">(${escapeHtml(it.key_)})</span>`).join(" • ");
  el.innerHTML = `<b>Items ทั้งหมดบนเครื่องนี้ (${currentItems.length})</b><br>${list}`;
});

function renderInventoryBanner(c) {
  const box = $("#inventoryBanner");
  if (!box) return;
  const inv = c.inventory;
  const src = Object.entries(inv.source).map(([k, v]) => `${k}: <b>${v ? escapeHtml(v) : "—"}</b>`).join(" · ");
  const notes = [...(c.template_mismatch || []).map((t) => `Template "${t}" ไม่ตรงกับ OS ${c.os_family.toUpperCase()}`), ...inv.notes]
    .slice(0, 4).map((n) => `<li>${escapeHtml(n)}</li>`).join("");
  box.innerHTML = `<div>${confidenceTag(inv.confidence)} <span class="muted">· software ${inv.software_count} · services ${inv.services_count} · processes ${inv.processes_count} · ${src}</span></div>
    ${notes ? `<ul class="inv-notes">${notes}</ul>` : ""}`;
  box.hidden = false;
}

// Collect real inventory through Zabbix (creates [Inventory] probe items on the host)
$("#btnInventory")?.addEventListener("click", async (e) => {
  if (!currentHost || !currentCompliance) { showToast("กรุณาเลือกเครื่องก่อน", true); return; }
  const fam = currentCompliance.os_family;
  if (!confirm(`สร้าง inventory probe items บน ${currentHost.name} (${fam.toUpperCase()}) ใน Zabbix?\n` +
    "ใช้อ่านรายการ software / service / process จริงจากเครื่อง (เก็บ 7 วัน, รอบ 1 ชั่วโมง)")) return;
  const btn = e.currentTarget;
  btn.disabled = true;
  try {
    const res = await apiRequest("/api/host/inventory/probe", "POST", { hostid: currentHost.hostid, os_family: fam });
    showToast(res.message, !res.success);
    setTimeout(() => refreshCurrentHost(true), 15000);
  } catch (err) {
    showToast(`ไม่สำเร็จ: ${err.message}`, true);
  } finally {
    btn.disabled = false;
  }
});

$("#btnReEvaluate")?.addEventListener("click", () => {
  if (!currentHost) { showToast("กรุณาเลือกเครื่องก่อน", true); return; }
  showToast("กำลังประเมินใหม่ (อ่าน inventory ใหม่)...");
  refreshCurrentHost(true);
});

// Rows for the "Installed Software & Monitoring Status" table
function setSoftwareRows(c) {
  // Load the full machine inventory (software + service + process) mapped to Zabbix, async.
  loadSoftwareInventory(false);
}

// Every software / service / process found on the machine, mapped to Zabbix
async function loadSoftwareInventory(refresh) {
  if (!currentHost) return;
  const tbody = $("#softwareRows");
  const forHost = currentHost.hostid;
  if (tbody) tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;color:#8ea0b4;padding:14px">กำลังอ่าน software / service จากเครื่อง...</td></tr>`;
  try {
    const res = await apiRequest(`/api/host/software-inventory?hostid=${forHost}${refresh ? "&refresh=1" : ""}`);
    if (currentHost.hostid !== forHost) return;  // user switched host while loading
    softwareInv = res;
    softwareAllRows = res.rows || [];
    swPage = 1;
    renderInventoryBannerSw(res.inventory);
    renderSoftwarePage();
  } catch (err) {
    softwareAllRows = [];
    if (tbody) tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;color:#ff8f99;padding:14px">อ่าน inventory ไม่สำเร็จ: ${escapeHtml(err.message)}</td></tr>`;
  }
}

function renderInventoryBannerSw(inv) {
  const box = $("#inventoryBanner");
  if (!box || !inv) return;
  const conf = { verified: ["ok", "ข้อมูลจริงจากเครื่อง"], partial: ["warn", "ข้อมูลบางส่วน"], estimated: ["bad", "ประเมินจาก Zabbix items"] }[inv.confidence] || ["neutral", inv.confidence || "-"];
  const rows = softwareAllRows || [];
  const mon = rows.filter((r) => r.status === "Monitored").length;
  const got = inv.software_count + inv.services_count > 0;
  box.innerHTML = got
    ? `<b>จากเครื่องจริง:</b> software ${inv.software_count} · service ${inv.services_count}
       <span class="muted">· อ่านเมื่อ ${escapeHtml(inv.collected_at || "-")}</span>
       <span class="sw-sum"><span class="tag ok">Monitored ${mon}</span> <span class="tag bad">Not Monitored ${rows.length - mon}</span></span>`
    : `<b class="warn">ยังไม่มีรายการ software / service จากเครื่องนี้</b> — กด <b>⤓ ดึงจากเครื่อง</b>
       <span class="muted">(Zabbix จะสร้าง item [Inventory] แบบอ่านอย่างเดียวบน host แล้วอ่านรายการทั้งหมดจากเครื่อง)</span>
       ${rows.length ? `<div class="cell-note">ตอนนี้แสดงเฉพาะ ${rows.length} รายการที่มี item ใน Zabbix อยู่แล้ว</div>` : ""}`;
  box.hidden = false;
}



// ---- Software table pagination ----
let softwareAllRows = [];   // full inventory rows for current host
let softwareInv = null;     // full /software-inventory response
let swPage = 1;             // current page (1-based)
let swPageSize = 25;        // rows per page ("all" => Infinity)

function softwareFilteredRows() {
  const q = ($("#softwareSearch").value || "").toLowerCase().trim();
  const kind = ($("#swKindFilter") && $("#swKindFilter").value) || "all";
  const st = ($("#swStatusFilter") && $("#swStatusFilter").value) || "all";
  return softwareAllRows.filter((r) =>
    (kind === "all" || r.kind === kind) &&
    (st === "all" || r.status === st) &&
    (!q || [r.name, r.kind, r.version, r.state, r.service_name, r.expected, r.template, r.item, r.item_key, r.status].some((v) => (v || "").toLowerCase().includes(q)))
  );
}

function renderSoftwarePage() {
  const tbody = $("#softwareRows");
  const pager = $("#softwarePager");
  const data = softwareFilteredRows();

  if (!data.length) {
    tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;color:#8ea0b4;padding:14px">${
      softwareAllRows.length ? "ไม่พบรายการที่ตรงกับตัวกรอง" : 'ยังไม่มีรายการจากเครื่อง — กด <b>⤓ ดึงจากเครื่อง</b> ด้านบน'
    }</td></tr>`;
    if (pager) pager.hidden = true;
    return;
  }

  const size = swPageSize === Infinity ? data.length : swPageSize;
  const totalPages = Math.max(1, Math.ceil(data.length / size));
  if (swPage > totalPages) swPage = totalPages;
  const start = (swPage - 1) * size;
  const pageRows = data.slice(start, start + size);

  tbody.innerHTML = pageRows.map((r, idx) => {
    const kindTag = `<span class="tag neutral">${escapeHtml(r.kind)}</span>`;
    const ver = r.kind === "Software" ? (r.version || "-")
      : [r.state, r.startup].filter(Boolean).join(" · ") || "-";
    return `
    <tr>
      <td>${start + idx + 1}</td>
      <td>${escapeHtml(r.name)} ${kindTag}${r.service_name && r.service_name !== r.name ? `<div class="cell-note mono">${escapeHtml(r.service_name)}</div>` : ""}</td>
      <td>${escapeHtml(ver)}</td>
      <td class="mono">${escapeHtml(r.expected || "-")}</td>
      <td>${r.template ? escapeHtml(r.template) : '<span class="muted">-</span>'}</td>
      <td>${r.item ? `${escapeHtml(r.item)}${r.item_key ? `<div class="cell-note mono">${escapeHtml(r.item_key)}</div>` : ""}` : '<span class="muted">-</span>'}</td>
      <td>${r.status === "Monitored" ? '<span class="tag ok">● Monitored</span>' : '<span class="tag bad">✕ Not Monitored</span>'}</td>
      <td>${r.last_checked ? escapeHtml(r.last_checked) : '<span class="muted">-</span>'}</td>
      <td><button class="secondary mini-btn" data-swview='${escapeHtml(JSON.stringify({ name: r.name, kind: r.kind, version: r.version, state: r.state, expected: r.expected, template: r.template, item: r.item, item_key: r.item_key, status: r.status, last_checked: r.last_checked }))}'>View</button></td>
    </tr>`;
  }).join("");

  // Show pager info whenever there is data; page buttons only matter with >1 page
  if (pager) {
    pager.hidden = false;
    const from = start + 1;
    const to = Math.min(start + size, data.length);
    $("#swPgInfo").textContent = `แสดง ${from}–${to} จาก ${data.length} รายการ`;
    $("#swPrev").disabled = swPage <= 1;
    $("#swNext").disabled = swPage >= totalPages;
    $("#swPages").innerHTML = buildPageNumbers(swPage, totalPages);
  }
}

// Compact page-number list with ellipsis (…) for many pages
function buildPageNumbers(current, total) {
  if (total <= 1) return `<button class="pg-num active" data-pg="1">1</button>`;
  const nums = new Set([1, total, current, current - 1, current + 1]);
  const sorted = [...nums].filter((n) => n >= 1 && n <= total).sort((a, b) => a - b);
  let html = "";
  let prev = 0;
  sorted.forEach((n) => {
    if (n - prev > 1) html += `<span class="pg-ellipsis">…</span>`;
    html += `<button class="pg-num ${n === current ? "active" : ""}" data-pg="${n}">${n}</button>`;
    prev = n;
  });
  return html;
}

$("#swPrev").addEventListener("click", () => { if (swPage > 1) { swPage--; renderSoftwarePage(); } });
$("#swNext").addEventListener("click", () => { swPage++; renderSoftwarePage(); });
$("#swPages").addEventListener("click", (e) => {
  const btn = e.target.closest("[data-pg]");
  if (!btn) return;
  swPage = parseInt(btn.dataset.pg, 10);
  renderSoftwarePage();
});
$("#swPageSize").addEventListener("change", (e) => {
  swPageSize = e.target.value === "all" ? Infinity : parseInt(e.target.value, 10);
  swPage = 1;
  renderSoftwarePage();
});

$("#softwareRows").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-sw]");
  // View details
  const view = e.target.closest("button[data-swview]");
  if (view) {
    const d = JSON.parse(view.dataset.swview);
    const el = $("#softwareDetail");
    el.className = "detail show";
    el.innerHTML = `<b>${escapeHtml(d.name)}</b> <span class="tag neutral">${escapeHtml(d.kind)}</span>
      <div class="detail-grid">
        <span>Version / State</span><span>${escapeHtml(d.version || d.state || "-")}</span>
        <span>Expected Template</span><span class="mono">${escapeHtml(d.expected || "-")}</span>
        <span>Zabbix Template</span><span>${escapeHtml(d.template || "-")}</span>
        <span>Zabbix Item</span><span class="mono">${escapeHtml(d.item || "-")}${d.item_key ? " · " + escapeHtml(d.item_key) : ""}</span>
        <span>สถานะ</span><span>${d.status === "Monitored" ? '<span class="tag ok">● Monitored</span>' : '<span class="tag bad">✕ Not Monitored</span>'}</span>
      </div>`;
  }
});

// Search / filter re-run pagination
function filterSoftware() {
  swPage = 1;
  renderSoftwarePage();
}
$("#softwareSearch").addEventListener("input", filterSoftware);
$("#swKindFilter")?.addEventListener("change", filterSoftware);
$("#swStatusFilter")?.addEventListener("change", filterSoftware);
$("#btnSwCollect")?.addEventListener("click", (e) => collectFromMachine(e.currentTarget));

// Ask Zabbix to read the machine (read-only [Inventory] items + Check now), then poll until data arrives
async function collectFromMachine(btn) {
  if (!currentHost) { showToast("กรุณาเลือกเครื่องก่อน", true); return; }
  const fam = (softwareInv && softwareInv.os_family) || "windows";
  const forHost = currentHost.hostid;
  btn.disabled = true;
  btn.textContent = "กำลังสั่ง Zabbix...";
  try {
    const res = await apiRequest("/api/host/inventory/probe", "POST", { hostid: forHost, os_family: fam });
    if (!res.success) throw new Error(res.message || "ไม่สำเร็จ");
    for (let i = 1; i <= 12; i++) {           // up to ~2 minutes
      btn.textContent = `รอข้อมูลจากเครื่อง ${i * 10}s...`;
      await new Promise((r) => setTimeout(r, 10000));
      if (!currentHost || currentHost.hostid !== forHost) return;
      const inv = await apiRequest(`/api/host/software-inventory?hostid=${forHost}&refresh=1`);
      const n = inv.inventory.software_count + inv.inventory.services_count;
      if (n > 0) {
        softwareInv = inv; softwareAllRows = inv.rows || []; renderInventoryBannerSw(inv.inventory); swPage = 1; renderSoftwarePage();
        showToast(`ดึงจากเครื่องแล้ว: software ${inv.inventory.software_count} · service ${inv.inventory.services_count}`);
        return;
      }
    }
    showToast("ยังไม่มีข้อมูลจากเครื่อง — agent อาจเป็น active mode (รอบเก็บ 1 ชม.) หรือ key ไม่รองรับ", true);
  } catch (err) {
    showToast(`ดึงจากเครื่องไม่สำเร็จ: ${err.message}`, true);
  } finally {
    btn.disabled = false;
    btn.textContent = "⤓ ดึงจากเครื่อง";
  }
}

setupAutocomplete('[data-ac="software"]', {
  getItems: (q) => {
    const ql = q.toLowerCase();
    const seen = new Set();
    const out = [];
    softwareAllRows.forEach((r) => {
      if ((!ql || (r.name || "").toLowerCase().includes(ql)) && !seen.has(r.name)) {
        seen.add(r.name);
        out.push({ value: r.name, sub: r.kind });
      }
    });
    return out.slice(0, 50);
  },
  onSelect: () => filterSoftware()
});

$("#btnExport").addEventListener("click", () => {
  const data = softwareFilteredRows();
  const esc = (v) => `"${String(v == null ? "" : v).replace(/"/g, '""')}"`;
  const safe = (v) => { const s = String(v == null ? "" : v); return /^[=+@-]/.test(s) && !/^-?\d/.test(s) ? "'" + s : s; };
  const lines = data.map((r, i) => [i + 1, r.kind, r.name, r.service_name, r.version || r.state, r.expected, r.template, r.item, r.item_key, r.status].map((v) => esc(safe(v))).join(","));
  const csv = "No,Type,Name,Service name,Version/State,Expected Template,Zabbix Template,Zabbix Item,Item key,Monitoring Status\n" + lines.join("\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" }));
  a.download = `software-inventory-${currentHost ? currentHost.techName : "export"}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
});

function setRing(spanSel, pct, countsSel, countsHtml) {
  const span = $(spanSel);
  if (span) {
    span.textContent = pct + "%";
    const ring = span.closest(".ring");
    if (ring) ring.style.setProperty("--pct", pct);
  }
  if (countsSel) {
    const c = $(countsSel);
    if (c) c.innerHTML = countsHtml;
  }
}

function setHealth(sel, text, cls) {
  const el = $(sel);
  if (!el) return;
  el.textContent = text;
  el.className = "state " + cls;
}

// =========================================================
// Top / side navigation (Reports, Mapping, Settings)
// =========================================================
const extra = $("#extraPage");

function updateBrandTitle(target) {
  const titleEl = $("#brandTitle");
  const iconEl = $("#brandIcon");
  if (!titleEl) return;

  const t = String(target || "dashboard");
  if (t.startsWith("es-")) {
    titleEl.textContent = "ELASTIC · Logging";
    if (iconEl) {
      iconEl.textContent = "◉";
      iconEl.className = "brandicon brandicon-elastic";
    }
  } else if (t === "settings") {
    titleEl.textContent = "SYSTEM · Setting";
    if (iconEl) {
      iconEl.textContent = "⚙";
      iconEl.className = "brandicon brandicon-system";
    }
  } else {
    titleEl.textContent = "ZABBIX · Monitoring";
    if (iconEl) {
      iconEl.textContent = "⌁";
      iconEl.className = "brandicon brandicon-zabbix";
    }
  }
}

function navTo(target, linkEl) {
  updateBrandTitle(target);
  document.querySelectorAll("aside a, .topnav a").forEach((a) => {
    a.classList.toggle("active", a.dataset.nav === target);
  });

  const mainFilters = $("#mainFilters");
  const dashboardContent = $("#dashboardContent");
  const dashboardSections = ["dashboard", "os", "software"];
  const pagesWithFilter = ["dashboard", "os", "software", "mapping", "reports", "es-overview", "es-config", "es-indices"];

  if (mainFilters) {
    mainFilters.hidden = !pagesWithFilter.includes(target);
  }

  if (dashboardSections.includes(target)) {
    // Show the dashboard, hide the standalone (extra) page entirely
    currentPage = target;
    if (dashboardContent) dashboardContent.hidden = false;
    extra.hidden = true;
    if (target === "dashboard") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      const dest = $("#" + target);
      if (dest) {
        dest.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }
    return;
  }

  // Standalone page: hide the whole dashboard, show only the extra page
  if (dashboardContent) dashboardContent.hidden = true;
  extra.hidden = false;
  currentPage = target;
  renderCurrentPage();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function renderCurrentPage() {
  if (currentPage === "reports") renderReports();
  else if (currentPage === "mapping") renderMapping();
  else if (currentPage === "settings") renderSettings();
  else if (currentPage.startsWith("es-") && typeof renderElasticPage === "function") renderElasticPage(currentPage);
}

document.querySelectorAll("[data-nav]").forEach((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    navTo(link.dataset.nav, link);
  });
});

// =========================================================
// Template Mapping page (driven by the compliance result)
// =========================================================
let mapSelectedTemplate = null;   // { templateid, name } chosen in Add Mapping
let selectedMapKeys = new Set();
let selectedMapHostId = null;
let selectedMapTargetHostIds = new Set(); // target host IDs to apply monitoring to (Multi-Server)

function getAppServersForMapping() {
  const appId = (currentHost && currentHost.appId) || appIdFromInput($("#app")?.value || "");
  if (appId) {
    const list = hosts.filter((h) => h.appId === appId);
    if (list.length) return list;
  }
  return currentHost ? [currentHost] : [];
}

function getTargetHostsForMapping() {
  const ids = Array.from(selectedMapTargetHostIds);
  if (!ids.length && currentHost) ids.push(currentHost.hostid);
  return ids.map((hid) => hosts.find((h) => h.hostid === hid) || { hostid: hid, name: `Host ${hid}` });
}

function updateMapMultiServerUI() {
  const count = selectedMapTargetHostIds.size;
  const badge = $("#mapServerBadge");
  const countSpan = $("#mapServerCount");
  const chkAll = $("#mapServerSelectAll");

  if (countSpan) countSpan.textContent = count;
  if (badge) {
    badge.classList.toggle("active", count > 1);
    badge.innerHTML = `✓ กำลังเลือกเป้าหมาย <b>${count}</b> เครื่อง`;
  }

  if (chkAll) {
    const visibleChks = document.querySelectorAll("#mapServerRows .map-server-chk");
    if (!visibleChks.length) {
      chkAll.checked = false;
      chkAll.indeterminate = false;
    } else {
      const checkedVisible = Array.from(visibleChks).filter((c) => c.checked).length;
      chkAll.checked = checkedVisible > 0 && checkedVisible === visibleChks.length;
      chkAll.indeterminate = checkedVisible > 0 && checkedVisible < visibleChks.length;
    }
  }

  updateMapActionButtonsLabel();
}

function updateMapActionButtonsLabel() {
  const count = selectedMapTargetHostIds.size;
  const multiText = count > 1 ? ` ไปยัง ${count} เครื่อง` : "";

  // 1. Template Add Button
  const mapAddBtn = $("#mapAddBtn");
  if (mapAddBtn && !mapAddBtn.disabled) {
    mapAddBtn.textContent = `＋ Add Mapping${multiText}`;
  }

  // 2. Custom Monitor Single Button
  const cmAddBtn = $("#cmAddBtn");
  if (cmAddBtn && !cmAddBtn.disabled) {
    cmAddBtn.textContent = `＋ เพิ่ม Monitor${multiText}`;
  }

  // 3. Custom Monitor Multi Button
  const cmAddMultiBtn = $("#cmAddMultiBtn");
  if (cmAddMultiBtn && !cmAddMultiBtn.disabled) {
    cmAddMultiBtn.textContent = `＋ เพิ่มทั้งหมด${multiText}`;
  }

  // 4. Batch Add Button
  const batchBtn = $("#mapBatchAddBtn");
  const batchCount = $("#mapBatchBtnCount");
  if (batchBtn && !batchBtn.disabled && batchCount) {
    batchBtn.innerHTML = `➕ Add Monitoring รายการที่เลือกไว้ (<span id="mapBatchBtnCount">${selectedMapKeys.size}</span>)${multiText}`;
  }
}

function getRowKey(r) {
  return `${r.kind || ""}::${r.name || ""}::${r.service_name || ""}::${r.item_key || ""}`;
}

function getRowAction(r) {
  if (r.action && r.action.type && r.action.type !== "none") {
    return r.action;
  }
  const osf = ((mapInvMeta && mapInvMeta.os_family) || (currentCompliance && currentCompliance.os_family) || "linux").toLowerCase();
  const isWin = osf.includes("win");
  if (r.kind === "Service") {
    const sname = r.service_name || r.name;
    return {
      type: "add_service",
      name: sname,
      display_name: r.name,
      key: isWin ? `service.info[${sname},state]` : `proc.num[${sname}]`
    };
  }
  if (r.kind === "Process") {
    return {
      type: "add_service",
      name: r.name,
      display_name: r.name,
      key: `proc.num[${r.name}]`
    };
  }
  if (r.kind === "Port") {
    const p = (r.service_name || r.name || "").replace(/\D/g, "");
    return {
      type: "add_port",
      port: p,
      name: `TCP Port ${p}`,
      key: `net.tcp.port[,${p}]`
    };
  }
  if (r.kind === "Software") {
    if (r.expected && r.expected !== "-") {
      const match = cachedTemplates.find((t) => t.name.toLowerCase() === r.expected.toLowerCase());
      if (match) {
        return { type: "link_template", templateid: match.templateid, name: match.name };
      }
    }
    const procName = (r.name || "").split(/[\s\-_]/)[0].toLowerCase();
    if (procName) {
      return {
        type: "add_service",
        name: procName,
        display_name: r.name,
        key: `proc.num[${procName}]`
      };
    }
  }
  return null;
}

function updateMapBatchBar() {
  const count = selectedMapKeys.size;
  const badge = $("#mapSelBadge");
  const bar = $("#mapBatchBar");
  const btn = $("#mapBatchAddBtn");
  const btnCount = $("#mapBatchBtnCount");
  const chkAll = $("#mapSelectAll");

  if (badge) {
    badge.textContent = `✓ เลือกไว้ ${count} รายการ`;
    badge.classList.toggle("active", count > 0);
  }
  if (bar) {
    bar.classList.toggle("has-selection", count > 0);
  }
  if (btn) {
    btn.disabled = count === 0;
  }
  if (btnCount) {
    btnCount.textContent = count;
  }

  if (chkAll) {
    const visibleChks = document.querySelectorAll("#mapRows .map-row-chk");
    if (!visibleChks.length) {
      chkAll.checked = false;
      chkAll.indeterminate = false;
    } else {
      const checkedVisible = Array.from(visibleChks).filter((c) => c.checked).length;
      chkAll.checked = checkedVisible > 0 && checkedVisible === visibleChks.length;
      chkAll.indeterminate = checkedVisible > 0 && checkedVisible < visibleChks.length;
    }
  }

  updateMapActionButtonsLabel();
}

async function renderMapping() {
  if (!currentHost || !currentCompliance) {
    const appId = appIdFromInput($("#app")?.value || "");
    const appMembers = appId ? hosts.filter((h) => h.appId === appId) : [];
    if (appMembers.length > 0) {
      selectHost(appMembers[0].id);
      return;
    }
    extra.innerHTML = `
      <section class="panel"><div class="paneltitle">Template Mapping <span class="source">Monitoring Standard</span></div>
      <p class="muted">${currentHost ? "กำลังประเมินเครื่อง..." : "เลือก Application และ Server ด้านบน เพื่อตรวจสอบและจัดการ Template Mapping"}</p></section>`;
    return;
  }
  if (selectedMapHostId !== currentHost.hostid) {
    selectedMapKeys.clear();
    selectedMapHostId = currentHost.hostid;
  }

  const appServers = getAppServersForMapping();
  const appLabel = (currentHost && appLabelFor(currentHost)) || $("#app")?.value || "";
  const hasMultipleServers = appServers.length > 1;

  if (!selectedMapTargetHostIds.size || !appServers.some((h) => selectedMapTargetHostIds.has(h.hostid))) {
    selectedMapTargetHostIds.clear();
    if (currentHost) selectedMapTargetHostIds.add(currentHost.hostid);
  }

  if (!cachedTemplates.length) await loadTemplates();
  const c = currentCompliance;

  extra.innerHTML = `
    <section class="panel">
    <div class="paneltitle">Template Mapping — ${escapeHtml(currentHost.name)}
      <span>${verdictTag(c.verdict, c.overall.pct)}</span></div>
    <p class="muted">OS: <b>${escapeHtml(c.os_family.toUpperCase())}</b> · Linked templates:
      ${c.templates.length ? c.templates.map((t) => `<span class="tag neutral">${escapeHtml(t.name)}</span>`).join(" ") : '<span class="bad">ไม่มี</span>'}</p>

    <!-- Multi-Server Target Card (1 Appname/AppID มีมากกว่า 1 เครื่อง) -->
    <div class="map-servers-card" id="mapServersCard">
      <div class="map-servers-head">
        <div class="map-servers-title">
          <span class="icon">🖥️</span>
          <div>
            <div class="title-text">
              เครื่องใน Application: <b>${escapeHtml(appLabel || (currentHost && currentHost.appName) || (currentHost && currentHost.appId) || "Application เดียวกัน")}</b>
              <span class="tag ${hasMultipleServers ? 'ok' : 'neutral'}">${appServers.length} เครื่อง</span>
            </div>
            <div class="title-sub">
              ${hasMultipleServers
                ? 'ติ๊ก Checkbox ด้านหน้า Server เพื่อเลือกเครื่องที่ต้องการ Add Monitoring (Template, Custom Process / Port, หรือเลือกจากตาราง) พร้อมกันหลายเครื่อง'
                : 'Application นี้มี 1 เครื่องในระบบ (หากใน Application มีมากกว่า 1 เครื่อง จะมี Checkbox ด้านหน้าให้เลือก Add Monitoring พร้อมกัน)'}
            </div>
          </div>
        </div>
        <div class="map-servers-summary">
          <span class="map-server-badge ${selectedMapTargetHostIds.size > 1 ? 'active' : ''}" id="mapServerBadge">
            ✓ กำลังเลือกเป้าหมาย <b id="mapServerCount">${selectedMapTargetHostIds.size}</b> เครื่อง
          </span>
          ${hasMultipleServers ? `
          <div class="map-servers-actions">
            <button type="button" class="mini-btn secondary" id="mapBtnSelectAllServers">☑ เลือกทุกเครื่องใน App</button>
            <button type="button" class="mini-btn secondary" id="mapBtnSelectCurrentServerOnly">เฉพาะเครื่องนี้เครื่องเดียว</button>
          </div>` : ''}
        </div>
      </div>
      ${hasMultipleServers ? `
      <div class="map-servers-tablewrap">
        <table class="data map-servers-table">
          <thead>
            <tr>
              <th style="width:36px;text-align:center">
                <input type="checkbox" id="mapServerSelectAll" title="เลือก/ยกเลิกทุกเครื่อง">
              </th>
              <th>Server Name</th>
              <th>IP Address</th>
              <th>OS / Platform</th>
              <th>Templates ปัจจุบัน</th>
              <th>สถานะ Agent</th>
              <th style="text-align:center">สลับตรวจสอบ</th>
            </tr>
          </thead>
          <tbody id="mapServerRows">
            ${appServers.map((h) => {
              const isChecked = selectedMapTargetHostIds.has(h.hostid);
              const isCurrent = h.hostid === currentHost.hostid;
              const tmplCount = (h.templates || []).length;
              return `<tr class="${isChecked ? 'map-row-selected' : ''}" data-host-row="${h.hostid}">
                <td style="text-align:center">
                  <input type="checkbox" class="map-server-chk" data-hostid="${h.hostid}" ${isChecked ? 'checked' : ''} title="ติ๊กเพื่อเลือกเพิ่ม Monitoring บนเครื่องนี้">
                </td>
                <td>
                  <b>${escapeHtml(h.name)}</b>
                  ${isCurrent ? '<span class="tag ok" style="margin-left:6px">● เครื่องปัจจุบัน</span>' : ''}
                  ${h.techName && h.techName !== h.name ? `<div class="cell-note mono">${escapeHtml(h.techName)}</div>` : ''}
                </td>
                <td class="mono">${escapeHtml(h.ip || "-")}</td>
                <td><span class="tag neutral">${escapeHtml(h.type || h.os || "Linux")}</span></td>
                <td>${tmplCount ? `${tmplCount} templates` : '<span class="muted">-</span>'}</td>
                <td>${h.status === "online" ? '<span class="tag ok">● Online</span>' : '<span class="tag warn">Pending</span>'}</td>
                <td style="text-align:center">
                  ${!isCurrent ? `<button type="button" class="mini-btn secondary" data-switch-map-host="${h.hostid}" title="เปลี่ยนมาดู software/services ของเครื่องนี้">🔍 ตรวจเครื่องนี้</button>` : '<span class="muted" style="font-size:11px">กำลังดูเครื่องนี้</span>'}
                </td>
              </tr>`;
            }).join("")}
          </tbody>
        </table>
      </div>` : ''}
    </div>

    <!-- Box 1: Official Template Mapping -->
    <div class="mapping-add">
      <div class="mapping-add-head">
        <span class="mapping-badge tpl">Zabbix Template</span>
        <span>Add Template Mapping — พิมพ์ชื่อ software แล้วระบบจับคู่ Template จาก Zabbix ให้อัตโนมัติ</span>
      </div>
      <div class="mapping-add-row">
        <div class="ac" data-ac="maptmpl"><input class="form-ctl" id="mapAddInput" placeholder="พิมพ์ software เช่น windows, aix, mysql, oracle, iis..." style="width:100%"><div class="ac-menu" hidden></div></div>
        <input class="form-ctl" id="mapAddSelected" placeholder="Template ที่เลือก" readonly>
        <button id="mapAddBtn">＋ Add Mapping</button>
      </div>
      <div class="mapping-add-hint" id="mapAddHint">${cachedTemplates.length} templates บน Zabbix ·
        แนะนำ OS template: <b>${escapeHtml(c.os_template.recommended || "-")}</b>${c.os_template.linked.length ? " (ผูกแล้ว)" : ""}</div>
    </div>

    <!-- Box 2: Custom Monitor (Process, Port, Service) -->
    <div class="mapping-add custom-mon-box">
      <div class="mapping-add-head" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <div style="display:flex;align-items:center;gap:8px">
          <span class="mapping-badge custom">Custom Monitor</span>
          <span>Add Custom Monitor — สำหรับ Software, Process, Service หรือ Port ที่ยังไม่มี Template</span>
        </div>
        <div class="custom-mon-tabs">
          <button type="button" class="mini-btn active" id="cmBtnTabSingle">แบบเลือกประเภท (Process / Port / Service)</button>
          <button type="button" class="mini-btn secondary" id="cmBtnTabMulti">📦 1 Software + หลาย Process &amp; Port</button>
        </div>
      </div>

      <!-- Mode 1: Single/Group by Type -->
      <div id="cmSecSingle">
        <div style="display:grid;grid-template-columns:180px minmax(180px,1fr) minmax(220px,1.4fr) auto;gap:10px;align-items:end;margin-top:10px">
          <div>
            <label class="cm-label">ประเภท Monitor</label>
            <select class="form-ctl" id="cmType" style="width:100%">
              <option value="process">⚙ Process (proc.num)</option>
              <option value="port">🔌 TCP Port (net.tcp.port)</option>
              <option value="service">🛠 Windows Service (service.info)</option>
            </select>
          </div>
          <div>
            <label class="cm-label">ชื่อ Software / ระบบ (ไม่บังคับ)</label>
            <input class="form-ctl" id="cmSoftware" placeholder="เช่น Payment Gateway, CoreApp" style="width:100%">
          </div>
          <div>
            <label class="cm-label" id="cmItemsLabel">ชื่อ Process (คั่นด้วยจุลภาค , เพื่อเพิ่มหลายตัว)</label>
            <input class="form-ctl" id="cmItems" placeholder="เช่น process1, process2, process3" style="width:100%">
          </div>
          <div>
            <button id="cmAddBtn" style="white-space:nowrap;padding:10px 18px">＋ เพิ่ม Monitor</button>
          </div>
        </div>
      </div>

      <!-- Mode 2: Multi-Type for 1 Software -->
      <div id="cmSecMulti" hidden style="margin-top:10px">
        <div style="display:grid;grid-template-columns:minmax(180px,1fr) minmax(200px,1.2fr) minmax(180px,1fr) auto;gap:10px;align-items:end">
          <div>
            <label class="cm-label">ชื่อ Software / ระบบ <span class="bad">*</span></label>
            <input class="form-ctl" id="cmMultiSoftware" placeholder="เช่น Payment API, Auth Gateway" style="width:100%">
          </div>
          <div>
            <label class="cm-label">Process ที่ต้อง Monitor (คั่นด้วย ,)</label>
            <input class="form-ctl" id="cmMultiProcesses" placeholder="เช่น pay_worker, queue_listener, nginx" style="width:100%">
          </div>
          <div>
            <label class="cm-label">Port ที่ต้อง Monitor (คั่นด้วย ,)</label>
            <input class="form-ctl" id="cmMultiPorts" placeholder="เช่น 8080, 8443, 9000 หรือ 1, 2, 3, 4" style="width:100%">
          </div>
          <div>
            <button id="cmAddMultiBtn" style="white-space:nowrap;padding:10px 18px">＋ เพิ่มทั้งหมด</button>
          </div>
        </div>
      </div>

      <!-- Trigger alert options -->
      <div style="display:flex;align-items:center;gap:14px;margin-top:10px;padding-top:8px;border-top:1px dashed var(--line);font-size:11.5px;flex-wrap:wrap">
        <label class="chk-inline" style="cursor:pointer">
          <input type="checkbox" id="cmTrigger" checked>
          <span>สร้าง <b>Trigger แจ้งเตือน</b> อัตโนมัติเมื่อหยุดทำงาน / Port ปิด</span>
        </label>
        <span style="color:var(--muted)">|</span>
        <label style="display:flex;align-items:center;gap:6px;color:var(--muted)">
          ระดับเตือน:
          <select class="form-ctl" id="cmSeverity" style="padding:2px 8px;font-size:11px;width:auto;font-weight:600">
            <option value="2" style="color:#f87171">🔴 Serv2 (Critical สีแดง)</option>
            <option value="3" style="color:#facc15" selected>🟡 Serv3 (Warning สีเหลือง)</option>
          </select>
        </label>
        <span class="muted small" style="margin-left:auto" id="cmHint">💡 สามารถพิมพ์หลาย Process เช่น "process1, process2, process3" หรือหลาย Port เช่น "1, 2, 3, 4"</span>
      </div>
    </div>

    <!-- Inventory list toolbar -->
    <div class="mapping-toolbar">
      <div class="ac" data-ac="mapsearch" style="flex:1;min-width:220px"><input class="searchbox" id="mapSearch" placeholder="ค้นหา software / service / template / item / port..." style="width:100%"><div class="ac-menu" hidden></div></div>
      <select id="mapKind" class="mapping-select">
        <option value="all">ทุกประเภท</option><option value="Software">Software</option>
        <option value="Service">Service</option><option value="Process">Process</option>
        <option value="Port">Port</option>
      </select>
      <select id="mapFilter" class="mapping-select">
        <option value="all">ทุกสถานะ</option><option value="Not Monitored">Not Monitored</option>
        <option value="Monitored">Monitored</option>
      </select>
      <button class="secondary" id="btnMapRefresh" title="อ่านรายการ software / service จากเครื่องใหม่">⟳ ดึงจากเครื่อง</button>
    </div>
    <div class="inv-banner" id="mapInvBanner" hidden></div>

    <!-- Batch Action Toolbar -->
    <div class="map-batch-bar" id="mapBatchBar">
      <div class="map-batch-info">
        <span class="map-sel-badge" id="mapSelBadge">✓ เลือกไว้ 0 รายการ</span>
        <span class="muted small" id="mapSelHint">ติ๊ก Checkbox หน้ารายชื่อ Software / Service เพื่อเพิ่ม Monitoring พร้อมกันหลายรายการ</span>
      </div>
      <div class="map-batch-actions">
        <button type="button" class="mini-btn secondary" id="mapBtnSelectUnmon">☑ เลือกทั้งหมดที่ยังไม่มี Monitor</button>
        <button type="button" class="mini-btn secondary" id="mapBtnClearSel">ยกเลิกการเลือก</button>
        <button type="button" class="map-batch-btn" id="mapBatchAddBtn" disabled>➕ Add Monitoring รายการที่เลือกไว้ (<span id="mapBatchBtnCount">0</span>)</button>
      </div>
    </div>

    <div class="tablewrap"><table class="data">
      <thead><tr>
        <th style="width:36px;text-align:center"><input type="checkbox" id="mapSelectAll" title="เลือก/ยกเลิกทั้งหมด ในหน้านี้"></th>
        <th>No.</th>
        <th>Software / Service Name</th>
        <th>Version / State</th>
        <th>Expected Template (Zabbix)</th>
        <th>Zabbix Template</th>
        <th>Zabbix Item</th>
        <th>Monitoring Status</th>
        <th>Last Checked</th>
        <th>จัดการ</th>
      </tr></thead>
      <tbody id="mapRows"><tr><td colspan="10" class="empty-cell">กำลังอ่าน software / service จากเครื่อง...</td></tr></tbody>
    </table></div>

    <!-- ===== Section: Zabbix Triggers & Monitoring Intelligence Explorer (เมนูด้านล่างสุด) ===== -->
    <div class="trig-explorer" id="mapTrigExplorer">
      <div class="trig-header">
        <div class="trig-title">
          <div class="trig-title-top">
            <span class="mapping-badge tpl" style="font-size:12px;padding:4px 10px">🔔 Trigger Explorer</span>
            <span>Zabbix Triggers &amp; Monitoring Intelligence</span>
          </div>
          <div class="trig-title-sub">
            ดึงข้อมูล Trigger เฝ้าระวังจริงจาก Zabbix บนเครื่อง <b>${escapeHtml(currentHost?.name || "-")}</b> ตรวจสอบความสัมพันธ์ Software ➔ Template ➔ Item ➔ Trigger Condition
          </div>
        </div>
        <div class="trig-kpi-bar" id="trigKpis">
          <span class="trig-kpi-pill">กำลังโหลดข้อมูล Triggers...</span>
        </div>
      </div>

      <!-- Trigger Search & Toolbar -->
      <div class="trig-toolbar">
        <div class="trig-search">
          <span class="trig-search-icon">🔍</span>
          <input class="form-ctl" id="trigSearchInput" placeholder="พิมพ์ชื่อ Software หรือ Service เช่น apache, mysql, nginx, ssh, spooler เพื่อดู Template, Item และ Trigger..." style="width:100%">
        </div>
        <select class="mapping-select" id="trigSevFilter">
          <option value="all">ทุกระดับความรุนแรง</option>
          <option value="2">🔴 Serv2 (Critical สีแดง)</option>
          <option value="3">🟡 Serv3 (Warning สีเหลือง)</option>
        </select>
        <select class="mapping-select" id="trigStatusFilter">
          <option value="all">ทุกสถานะ Trigger</option>
          <option value="has_trigger">เฉพาะที่มี Trigger เซ็ตไว้</option>
          <option value="no_trigger">เฉพาะที่ยังไม่มี Trigger</option>
          <option value="problem">⚠️ กำลังเกิดปัญหา (Problem)</option>
          <option value="ok">● ปกติ (OK)</option>
        </select>
        <div class="trig-modes">
          <button type="button" class="active" id="trigModeCorrelate" title="แสดงความสัมพันธ์ Software/Service ➔ Template ➔ Item ➔ Trigger">🔍 ตรวจสอบตาม Software &amp; Service</button>
          <button type="button" class="secondary" id="trigModeAll" title="แสดงรายการ Trigger ทั้งหมดบนเครื่องนี้">📋 รายการ Trigger ทั้งหมด (<span id="trigAllCount">0</span>)</button>
        <button type="button" class="mini-btn secondary" id="btnTrigRefresh" title="ดึงข้อมูล Triggers ล่าสุดจาก Zabbix">⟳ รีเฟรช Trigger</button>
        <button type="button" class="mini-btn add" id="btnTrigAddModal" style="padding:7px 14px;font-size:12px;font-weight:700;display:inline-flex;align-items:center;gap:6px" title="สร้าง Trigger เฝ้าระวังใหม่บนเครื่องนี้">
          <span>＋</span> <span>เพิ่ม Trigger</span>
        </button>
      </div>

      <!-- Results Container -->
      <div id="trigResultsContainer">
        <div style="text-align:center;padding:24px;color:var(--muted)">กำลังโหลดข้อมูล Triggers จาก Zabbix...</div>
      </div>
    </div>
    </section>`;

  bindMappingEvents();
  loadMappingInventory(false);
}

let mapInvRows = [];      // software-inventory rows for the mapping page
let mapInvMeta = null;

async function loadMappingInventory(refresh) {
  if (!currentHost) return;
  const forHost = currentHost.hostid;
  const tbody = $("#mapRows");
  if (tbody) tbody.innerHTML = `<tr><td colspan="10" class="empty-cell">กำลังอ่าน software / service จากเครื่อง...</td></tr>`;
  try {
    const res = await apiRequest(`/api/host/software-inventory?hostid=${forHost}${refresh ? "&refresh=1" : ""}`);
    if (!currentHost || currentHost.hostid !== forHost) return;
    mapInvRows = res.rows || [];
    mapInvMeta = res.inventory;
    const box = $("#mapInvBanner");
    if (box && mapInvMeta) {
      const got = mapInvMeta.software_count + mapInvMeta.services_count > 0;
      const mon = mapInvRows.filter((r) => r.status === "Monitored").length;
      box.hidden = false;
      box.innerHTML = got
        ? `<b>จากเครื่องจริง:</b> software ${mapInvMeta.software_count} · service ${mapInvMeta.services_count}
           <span class="sw-sum"><span class="tag ok">Monitored ${mon}</span> <span class="tag bad">Not Monitored ${mapInvRows.length - mon}</span></span>`
        : `<b class="warn">ยังไม่มีรายการจากเครื่องนี้</b> — กด <b>⟳ ดึงจากเครื่อง</b>`;
    }
    buildMappingRows();
    loadHostTriggers(forHost, refresh);
  } catch (err) {
    mapInvRows = [];
    if (tbody) tbody.innerHTML = `<tr><td colspan="10" class="empty-cell bad">อ่าน inventory ไม่สำเร็จ: ${escapeHtml(err.message)}</td></tr>`;
  }
}

function buildMappingRows() {
  const tbody = $("#mapRows");
  if (!tbody) return;
  const q = ($("#mapSearch")?.value || "").toLowerCase().trim();
  const kind = $("#mapKind")?.value || "all";
  const st = $("#mapFilter")?.value || "all";
  const data = mapInvRows.filter((r) =>
    (kind === "all" || r.kind === kind) && (st === "all" || r.status === st) &&
    (!q || [r.name, r.service_name, r.version, r.state, r.expected, r.template, r.item, r.item_key].some((v) => (v || "").toLowerCase().includes(q))));
  if (!data.length) {
    tbody.innerHTML = `<tr><td colspan="10" class="empty-cell">${mapInvRows.length ? "ไม่พบรายการที่ตรงกับเงื่อนไข" : 'ยังไม่มีรายการ — กด ⟳ ดึงจากเครื่อง'}</td></tr>`;
    updateMapBatchBar();
    return;
  }
  tbody.innerHTML = data.map((r, i) => {
    const kindTag = `<span class="tag neutral">${escapeHtml(r.kind)}</span>`;
    const ver = r.kind === "Software" ? (r.version || "-") : [r.state, r.startup].filter(Boolean).join(" · ") || "-";
    const act = r.status !== "Monitored" && r.action
      ? `<button class="mini-btn add" data-mapfix='${escapeHtml(JSON.stringify(r.action))}'>＋ Add Monitor</button>` : "";
    const rKey = getRowKey(r);
    const isChecked = selectedMapKeys.has(rKey);
    const isMon = r.status === "Monitored";
    return `<tr class="${isChecked ? "map-row-selected" : ""}">
      <td style="text-align:center">
        <input type="checkbox" class="map-row-chk" data-row-key="${escapeHtml(rKey)}" ${isChecked ? "checked" : ""} title="${isMon ? 'มอนิเตอร์แล้ว (ติ๊กเพื่อผูกซ้ำ/อัปเดต)' : 'ติ๊กเพื่อเลือกเพิ่ม Monitoring'}">
      </td>
      <td>${i + 1}</td>
      <td>${escapeHtml(r.name)} ${kindTag}${r.service_name && r.service_name !== r.name ? `<div class="cell-note mono">${escapeHtml(r.service_name)}</div>` : ""}</td>
      <td>${escapeHtml(ver)}</td>
      <td class="mono">${escapeHtml(r.expected || "-")}</td>
      <td>${r.template ? escapeHtml(r.template) : '<span class="muted">-</span>'}</td>
      <td>${r.item ? `${escapeHtml(r.item)}${r.item_key ? `<div class="cell-note mono">${escapeHtml(r.item_key)}</div>` : ""}` : '<span class="muted">-</span>'}</td>
      <td>${isMon ? '<span class="tag ok">● Monitored</span>' : '<span class="tag bad">✕ Not Monitored</span>'}</td>
      <td>${r.last_checked ? escapeHtml(r.last_checked) : '<span class="muted">-</span>'}</td>
      <td><div class="row-actions">${act || ''} <button type="button" class="mini-btn secondary" data-trig-search="${escapeHtml(r.name)}" title="ตรวจสอบ Trigger ของ ${escapeHtml(r.name)}">🔔 Trigger</button></div></td></tr>`;
  }).join("");
  updateMapBatchBar();
}

function bindMappingEvents() {
  mapSelectedTemplate = null;
  setupAutocomplete('[data-ac="mapsearch"]', {
    getItems: (q) => {
      const ql = q.toLowerCase();
      const seen = new Set();
      const out = [];
      mapInvRows.forEach((r) => {
        if (r.name && (!ql || r.name.toLowerCase().includes(ql)) && !seen.has(r.name)) { seen.add(r.name); out.push({ value: r.name, sub: r.kind }); }
      });
      return out.slice(0, 50);
    },
    onSelect: buildMappingRows
  });
  $("#mapSearch")?.addEventListener("input", buildMappingRows);
  $("#mapFilter")?.addEventListener("change", buildMappingRows);
  $("#mapKind")?.addEventListener("change", buildMappingRows);
  $("#btnMapRefresh")?.addEventListener("click", () => loadMappingInventory(true));

  // Multi-server target selection handlers
  $("#mapServerRows")?.addEventListener("change", (e) => {
    const chk = e.target.closest(".map-server-chk");
    if (!chk) return;
    const hid = chk.dataset.hostid;
    if (chk.checked) selectedMapTargetHostIds.add(hid);
    else selectedMapTargetHostIds.delete(hid);
    const tr = chk.closest("tr");
    if (tr) tr.classList.toggle("map-row-selected", chk.checked);
    updateMapMultiServerUI();
  });

  $("#mapServerSelectAll")?.addEventListener("change", (e) => {
    const checked = e.target.checked;
    const appServers = getAppServersForMapping();
    if (checked) {
      appServers.forEach((h) => selectedMapTargetHostIds.add(h.hostid));
    } else {
      selectedMapTargetHostIds.clear();
      if (currentHost) selectedMapTargetHostIds.add(currentHost.hostid);
    }
    document.querySelectorAll("#mapServerRows .map-server-chk").forEach((c) => {
      c.checked = selectedMapTargetHostIds.has(c.dataset.hostid);
      const tr = c.closest("tr");
      if (tr) tr.classList.toggle("map-row-selected", c.checked);
    });
    updateMapMultiServerUI();
  });

  $("#mapBtnSelectAllServers")?.addEventListener("click", () => {
    const appServers = getAppServersForMapping();
    appServers.forEach((h) => selectedMapTargetHostIds.add(h.hostid));
    document.querySelectorAll("#mapServerRows .map-server-chk").forEach((c) => {
      c.checked = true;
      const tr = c.closest("tr");
      if (tr) tr.classList.add("map-row-selected");
    });
    updateMapMultiServerUI();
    showToast(`เลือกทุกเครื่องใน Application (${appServers.length} เครื่อง) แล้ว`);
  });

  $("#mapBtnSelectCurrentServerOnly")?.addEventListener("click", () => {
    selectedMapTargetHostIds.clear();
    if (currentHost) selectedMapTargetHostIds.add(currentHost.hostid);
    document.querySelectorAll("#mapServerRows .map-server-chk").forEach((c) => {
      c.checked = c.dataset.hostid === currentHost?.hostid;
      const tr = c.closest("tr");
      if (tr) tr.classList.toggle("map-row-selected", c.checked);
    });
    updateMapMultiServerUI();
    showToast(`เลือกเฉพาะเครื่องปัจจุบัน (${currentHost?.name || "-"}) แล้ว`);
  });

  $("#mapServerRows")?.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-switch-map-host]");
    if (!btn) return;
    const hid = btn.dataset.switchMapHost;
    const target = hosts.find((h) => h.hostid === hid);
    if (target) {
      selectHost(target.id, { refresh: true });
    }
  });

  // Batch Selection Handlers
  $("#mapRows")?.addEventListener("change", (e) => {
    const chk = e.target.closest(".map-row-chk");
    if (!chk) return;
    const key = chk.dataset.rowKey;
    if (chk.checked) selectedMapKeys.add(key);
    else selectedMapKeys.delete(key);
    const tr = chk.closest("tr");
    if (tr) tr.classList.toggle("map-row-selected", chk.checked);
    updateMapBatchBar();
  });

  $("#mapSelectAll")?.addEventListener("change", (e) => {
    const checked = e.target.checked;
    const q = ($("#mapSearch")?.value || "").toLowerCase().trim();
    const kind = $("#mapKind")?.value || "all";
    const st = $("#mapFilter")?.value || "all";
    const visibleData = mapInvRows.filter((r) =>
      (kind === "all" || r.kind === kind) && (st === "all" || r.status === st) &&
      (!q || [r.name, r.service_name, r.version, r.state, r.expected, r.template, r.item, r.item_key].some((v) => (v || "").toLowerCase().includes(q))));

    visibleData.forEach((r) => {
      const k = getRowKey(r);
      if (checked) selectedMapKeys.add(k);
      else selectedMapKeys.delete(k);
    });
    buildMappingRows();
  });

  $("#mapBtnSelectUnmon")?.addEventListener("click", () => {
    const q = ($("#mapSearch")?.value || "").toLowerCase().trim();
    const kind = $("#mapKind")?.value || "all";
    const st = $("#mapFilter")?.value || "all";
    const visibleData = mapInvRows.filter((r) =>
      (kind === "all" || r.kind === kind) && (st === "all" || r.status === st) &&
      (!q || [r.name, r.service_name, r.version, r.state, r.expected, r.template, r.item, r.item_key].some((v) => (v || "").toLowerCase().includes(q))));

    let addedCount = 0;
    visibleData.forEach((r) => {
      if (r.status !== "Monitored") {
        selectedMapKeys.add(getRowKey(r));
        addedCount++;
      }
    });
    buildMappingRows();
    showToast(`เลือก ${addedCount} รายการที่ยังไม่มี Monitor เรียบร้อย`);
  });

  $("#mapBtnClearSel")?.addEventListener("click", () => {
    selectedMapKeys.clear();
    buildMappingRows();
  });

  $("#mapBatchAddBtn")?.addEventListener("click", async () => {
    if (!currentHost) { showToast("กรุณาเลือกเครื่องก่อน", true); return; }
    if (!selectedMapKeys.size) {
      showToast("กรุณาติ๊กเลือกรายการ Software หรือ Service ที่ต้องการก่อน", true);
      return;
    }
    const toAdd = [];
    mapInvRows.forEach((r) => {
      if (selectedMapKeys.has(getRowKey(r))) {
        const act = getRowAction(r);
        if (act) toAdd.push(act);
      }
    });
    if (!toAdd.length) {
      showToast("ไม่พบรายการที่สามารถเพิ่ม Monitoring ได้", true);
      return;
    }

    const targetHosts = getTargetHostsForMapping();
    const count = targetHosts.length;
    const hostMsg = count > 1 ? `ทั้ง ${count} เครื่อง (${targetHosts.map((h) => h.name).join(", ")})` : `เครื่อง "${currentHost.name}"`;

    if (!confirm(`ต้องการเพิ่ม Zabbix Monitoring สำหรับ ${toAdd.length} รายการที่เลือกไว้บน ${hostMsg} หรือไม่?`)) return;

    const btn = $("#mapBatchAddBtn");
    btn.disabled = true;
    const oldHtml = btn.innerHTML;

    let successCount = 0;
    const errors = [];

    for (let i = 0; i < count; i++) {
      const h = targetHosts[i];
      btn.innerHTML = `กำลังเพิ่มบน ${h.name} (${i + 1}/${count})...`;
      const isWin = (h.type || h.os || "").toLowerCase().includes("win");
      try {
        const res = await apiRequest("/api/host/compliance/fix-batch", "POST", {
          hostid: h.hostid,
          actions: toAdd,
          os_family: isWin ? "windows" : "linux"
        });
        if (res && res.success !== false) successCount++;
        else errors.push(`${h.name}: ${res.message || "ล้มเหลว"}`);
      } catch (err) {
        errors.push(`${h.name}: ${err.message}`);
      }
    }

    btn.disabled = false;
    btn.innerHTML = oldHtml;
    updateMapActionButtonsLabel();

    if (successCount > 0) {
      showToast(`เพิ่ม Monitoring ${toAdd.length} รายการสำเร็จบน ${successCount}/${count} เครื่อง${errors.length ? ` (ผิดพลาด ${errors.length} เครื่อง)` : ""}`, errors.length > 0);
      selectedMapKeys.clear();
      cachedTemplates = [];
      currentCompliance = null;
      await loadMappingInventory(true);
      if (currentHost) selectHost(currentHost.id, { refresh: true });
    } else {
      showToast(`เพิ่มไม่สำเร็จ: ${errors.join("; ")}`, true);
    }
  });

  setupAutocomplete('[data-ac="maptmpl"]', {
    getItems: (q) => {
      const src = q.trim() ? matchTemplates(q) : cachedTemplates;
      const linked = new Set((currentCompliance.templates || []).map((t) => t.name));
      return src.slice(0, 30).map((t) => ({ value: t.name, sub: linked.has(t.name) ? "ผูกแล้ว" : "template", _id: t.templateid }));
    },
    onSelect: (it) => {
      mapSelectedTemplate = { templateid: it._id, name: it.value };
      $("#mapAddSelected").value = it.value;
      const count = selectedMapTargetHostIds.size;
      const multiText = count > 1 ? ` (${count} เครื่องเป้าหมาย)` : "";
      $("#mapAddHint").textContent = `พร้อมผูก Template "${it.value}" เข้ากับเครื่อง${multiText} — กด ＋ Add Mapping`;
    }
  });
  $("#mapAddBtn")?.addEventListener("click", addMappingTemplate);

  // Custom Monitor tabs
  $("#cmBtnTabSingle")?.addEventListener("click", () => {
    $("#cmSecSingle").hidden = false;
    $("#cmSecMulti").hidden = true;
    $("#cmBtnTabSingle").className = "mini-btn active";
    $("#cmBtnTabMulti").className = "mini-btn secondary";
  });
  $("#cmBtnTabMulti")?.addEventListener("click", () => {
    $("#cmSecSingle").hidden = true;
    $("#cmSecMulti").hidden = false;
    $("#cmBtnTabMulti").className = "mini-btn active";
    $("#cmBtnTabSingle").className = "mini-btn secondary";
  });

  // Type change in single mode
  $("#cmType")?.addEventListener("change", (e) => {
    const val = e.target.value;
    const lbl = $("#cmItemsLabel");
    const inp = $("#cmItems");
    const hnt = $("#cmHint");
    if (val === "process") {
      if (lbl) lbl.textContent = "ชื่อ Process (คั่นด้วยจุลภาค , เพื่อเพิ่มหลายตัว)";
      if (inp) inp.placeholder = "เช่น process1, process2, process3 หรือ worker, nginx";
      if (hnt) hnt.innerHTML = '💡 ตัวอย่าง: เพิ่มหลาย Process เช่น <b>process1, process2, process3</b>';
    } else if (val === "port") {
      if (lbl) lbl.textContent = "หมายเลข Port (คั่นด้วยจุลภาค , เพื่อเพิ่มหลายตัว)";
      if (inp) inp.placeholder = "เช่น 8080, 8443, 9000, 3000 หรือ 1, 2, 3, 4";
      if (hnt) hnt.innerHTML = '💡 ตัวอย่าง: เพิ่มหลาย Port เช่น <b>8080, 8443, 9000</b> หรือ <b>1, 2, 3, 4</b>';
    } else {
      if (lbl) lbl.textContent = "ชื่อ Windows Service (คั่นด้วยจุลภาค , เพื่อเพิ่มหลายตัว)";
      if (inp) inp.placeholder = "เช่น Spooler, W3SVC, AppServer";
      if (hnt) hnt.innerHTML = '💡 ตัวอย่าง: เพิ่มหลาย Service เช่น <b>W3SVC, MSSQLSERVER</b>';
    }
  });

  // Single mode submit
  $("#cmAddBtn")?.addEventListener("click", async () => {
    if (!currentHost) { showToast("กรุณาเลือกเครื่องก่อน", true); return; }
    const mtype = $("#cmType").value;
    const swName = ($("#cmSoftware").value || "").trim();
    const rawItems = ($("#cmItems").value || "").trim();
    if (!rawItems) {
      showToast(`กรุณาระบุ ${mtype === "port" ? "หมายเลข Port" : "ชื่อ " + mtype} อย่างน้อย 1 รายการ`, true);
      return;
    }

    const targetHosts = getTargetHostsForMapping();
    const count = targetHosts.length;
    const hostMsg = count > 1 ? `ทั้ง ${count} เครื่อง (${targetHosts.map((h) => h.name).join(", ")})` : `เครื่อง "${currentHost.name}"`;

    if (count > 1) {
      if (!confirm(`ต้องการเพิ่ม Custom Monitor นี้ไปยัง ${hostMsg} หรือไม่?`)) return;
    }

    const btn = $("#cmAddBtn");
    btn.disabled = true;
    btn.textContent = `กำลังเพิ่ม (${count} เครื่อง)...`;

    let successCount = 0;
    const errors = [];

    for (let i = 0; i < count; i++) {
      const h = targetHosts[i];
      btn.textContent = `กำลังเพิ่ม (${i + 1}/${count}: ${h.name})...`;
      const isWin = (h.type || h.os || "").toLowerCase().includes("win");
      try {
        const res = await apiRequest("/api/host/custom-monitor/add", "POST", {
          hostid: h.hostid,
          monitor_type: mtype,
          items: rawItems,
          software_name: swName,
          create_trigger: $("#cmTrigger") ? $("#cmTrigger").checked : true,
          severity: parseInt($("#cmSeverity") ? $("#cmSeverity").value : "3", 10) || 3,
          os_type: isWin ? "windows" : "linux"
        });
        if (res && res.success !== false) successCount++;
        else errors.push(`${h.name}: ${res.message || "ล้มเหลว"}`);
      } catch (err) {
        errors.push(`${h.name}: ${err.message}`);
      }
    }

    btn.disabled = false;
    updateMapActionButtonsLabel();
    $("#cmItems").value = "";

    if (successCount > 0) {
      showToast(`เพิ่ม Monitor สำเร็จ ${successCount}/${count} เครื่อง${errors.length ? ` (ผิดพลาด ${errors.length} เครื่อง)` : ""}`, errors.length > 0);
      await loadMappingInventory(true);
      selectHost(currentHost.id, { refresh: true });
    } else {
      showToast(`เพิ่มไม่สำเร็จ: ${errors.join("; ")}`, true);
    }
  });

  // Multi mode submit (Software + multiple Processes & Ports)
  $("#cmAddMultiBtn")?.addEventListener("click", async () => {
    if (!currentHost) { showToast("กรุณาเลือกเครื่องก่อน", true); return; }
    const swName = ($("#cmMultiSoftware").value || "").trim();
    const rawProcs = ($("#cmMultiProcesses").value || "").trim();
    const rawPorts = ($("#cmMultiPorts").value || "").trim();
    if (!rawProcs && !rawPorts) {
      showToast("กรุณาระบุ Process หรือ Port อย่างน้อย 1 รายการ", true);
      return;
    }

    const targetHosts = getTargetHostsForMapping();
    const count = targetHosts.length;
    const hostMsg = count > 1 ? `ทั้ง ${count} เครื่อง (${targetHosts.map((h) => h.name).join(", ")})` : `เครื่อง "${currentHost.name}"`;

    if (count > 1) {
      if (!confirm(`ต้องการเพิ่ม Custom Monitor ทั้งหมดนี้ไปยัง ${hostMsg} หรือไม่?`)) return;
    }

    const btn = $("#cmAddMultiBtn");
    btn.disabled = true;
    btn.textContent = `กำลังเพิ่ม (${count} เครื่อง)...`;

    let successCount = 0;
    const errors = [];

    for (let i = 0; i < count; i++) {
      const h = targetHosts[i];
      btn.textContent = `กำลังเพิ่ม (${i + 1}/${count}: ${h.name})...`;
      const isWin = (h.type || h.os || "").toLowerCase().includes("win");
      try {
        const res = await apiRequest("/api/host/custom-monitor/add", "POST", {
          hostid: h.hostid,
          software_name: swName,
          processes: rawProcs,
          ports: rawPorts,
          create_trigger: $("#cmTrigger") ? $("#cmTrigger").checked : true,
          severity: parseInt($("#cmSeverity") ? $("#cmSeverity").value : "3", 10) || 3,
          os_type: isWin ? "windows" : "linux"
        });
        if (res && res.success !== false) successCount++;
        else errors.push(`${h.name}: ${res.message || "ล้มเหลว"}`);
      } catch (err) {
        errors.push(`${h.name}: ${err.message}`);
      }
    }

    btn.disabled = false;
    updateMapActionButtonsLabel();
    $("#cmMultiProcesses").value = "";
    $("#cmMultiPorts").value = "";

    if (successCount > 0) {
      showToast(`เพิ่ม Monitor สำเร็จ ${successCount}/${count} เครื่อง${errors.length ? ` (ผิดพลาด ${errors.length} เครื่อง)` : ""}`, errors.length > 0);
      await loadMappingInventory(true);
      selectHost(currentHost.id, { refresh: true });
    } else {
      showToast(`เพิ่มไม่สำเร็จ: ${errors.join("; ")}`, true);
    }
  });

  // Add Monitor on an inventory row (service.info / proc.num item)
  $("#mapRows")?.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-mapfix]");
    if (!b) return;
    const action = JSON.parse(b.dataset.mapfix);
    const targetHosts = getTargetHostsForMapping();
    const count = targetHosts.length;
    const hostMsg = count > 1 ? `ทั้ง ${count} เครื่อง (${targetHosts.map((h) => h.name).join(", ")})` : `เครื่อง ${currentHost.name}`;

    if (!confirm(`เพิ่ม Monitor "${action.display_name || action.name}" (${action.key || action.name}) บน ${hostMsg}?`)) return;
    b.disabled = true;
    b.textContent = "...";

    let successCount = 0;
    const errors = [];

    for (let i = 0; i < count; i++) {
      const h = targetHosts[i];
      const isWin = (h.type || h.os || "").toLowerCase().includes("win");
      const osf = isWin ? "windows" : "linux";
      try {
        const res = await apiRequest("/api/host/compliance/fix", "POST", { hostid: h.hostid, action: { ...action, os_family: osf } });
        if (res && res.success !== false) successCount++;
        else errors.push(`${h.name}: ${res.message || "ล้มเหลว"}`);
      } catch (err) {
        errors.push(`${h.name}: ${err.message}`);
      }
    }

    if (successCount > 0) {
      showToast(`เพิ่ม Monitor สำเร็จ ${successCount}/${count} เครื่อง`, errors.length > 0);
      cachedTemplates = [];
      currentCompliance = null;
      await loadMappingInventory(false);
      selectHost(currentHost.id, { refresh: true });
    } else {
      showToast(`เพิ่มไม่สำเร็จ: ${errors.join("; ")}`, true);
      b.disabled = false;
      b.textContent = "＋ Add Monitor";
    }
  });

  updateMapMultiServerUI();

  // Trigger Explorer Events
  $("#trigSearchInput")?.addEventListener("input", renderTriggerSection);
  $("#trigSevFilter")?.addEventListener("change", renderTriggerSection);
  $("#trigStatusFilter")?.addEventListener("change", renderTriggerSection);
  $("#btnTrigRefresh")?.addEventListener("click", () => {
    if (currentHost) loadHostTriggers(currentHost.hostid, true);
  });
  $("#trigModeCorrelate")?.addEventListener("click", () => {
    trigExplorerMode = "correlate";
    $("#trigModeCorrelate").className = "active";
    $("#trigModeAll").className = "secondary";
    renderTriggerSection();
  });
  $("#trigModeAll")?.addEventListener("click", () => {
    trigExplorerMode = "all";
    $("#trigModeAll").className = "active";
    $("#trigModeCorrelate").className = "secondary";
    renderTriggerSection();
  });
  $("#btnTrigAddModal")?.addEventListener("click", () => openAddTriggerModal());
  $("#trigResultsContainer")?.addEventListener("click", (e) => {
    const delBtn = e.target.closest("[data-trig-delete]");
    if (delBtn) {
      deleteTrigger(delBtn.dataset.trigDelete, delBtn.dataset.trigName, delBtn.dataset.isTemplate);
      return;
    }
    const togBtn = e.target.closest("[data-trig-toggle]");
    if (togBtn) {
      toggleTrigger(togBtn.dataset.trigToggle, togBtn.dataset.currentStatus);
      return;
    }
    const addSwBtn = e.target.closest("[data-trig-add-sw]");
    if (addSwBtn) {
      openAddTriggerModal(`Service down: ${addSwBtn.dataset.trigAddSw}`, addSwBtn.dataset.trigAddKey);
      return;
    }
  });
  initTriggerModalEvents();
  $("#mapRows")?.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-trig-search]");
    if (!btn) return;
    const term = btn.dataset.trigSearch;
    const inp = $("#trigSearchInput");
    if (inp) {
      inp.value = term;
      trigExplorerMode = "correlate";
      $("#trigModeCorrelate")?.classList.add("active");
      $("#trigModeCorrelate")?.classList.remove("secondary");
      $("#trigModeAll")?.classList.remove("active");
      $("#trigModeAll")?.classList.add("secondary");
      renderTriggerSection();
      $("#mapTrigExplorer")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  });
}

async function addMappingTemplate() {
  if (!currentHost) { showToast("กรุณาเลือกเครื่องก่อน", true); return; }
  if (!mapSelectedTemplate) { showToast("กรุณาพิมพ์ชื่อ software แล้วเลือก Template จากรายการ", true); return; }

  const targetHosts = getTargetHostsForMapping();
  const count = targetHosts.length;
  const hostMsg = count > 1 ? `ทั้ง ${count} เครื่อง (${targetHosts.map((h) => h.name).join(", ")})` : `เครื่อง "${currentHost.name}"`;

  if (count > 1) {
    if (!confirm(`ต้องการผูก Template "${mapSelectedTemplate.name}" เข้ากับ ${hostMsg} หรือไม่?`)) return;
  }

  const btn = $("#mapAddBtn");
  btn.disabled = true;
  btn.textContent = `กำลังผูก (${count} เครื่อง)...`;

  let successCount = 0;
  const errors = [];

  for (let i = 0; i < count; i++) {
    const h = targetHosts[i];
    btn.textContent = `กำลังผูก (${i + 1}/${count}: ${h.name})...`;
    try {
      const res = await apiRequest("/api/host/templates/link", "POST", {
        hostid: h.hostid,
        template_ids: [mapSelectedTemplate.templateid]
      });
      if (res && res.success !== false) successCount++;
      else errors.push(`${h.name}: ${res.message || "ล้มเหลว"}`);
    } catch (err) {
      errors.push(`${h.name}: ${err.message}`);
    }
  }

  btn.disabled = false;
  updateMapActionButtonsLabel();

  if (successCount > 0) {
    showToast(`ผูก Template "${mapSelectedTemplate.name}" สำเร็จ ${successCount}/${count} เครื่อง${errors.length ? ` (ผิดพลาด ${errors.length} เครื่อง)` : ""}`, errors.length > 0);
    cachedTemplates = [];
    currentCompliance = null;
    mapSelectedTemplate = null;
    $("#mapAddSelected").value = "";
    $("#mapAddInput").value = "";
    await loadMappingInventory(false);
    selectHost(currentHost.id, { refresh: true });
  } else {
    showToast(`เพิ่ม Mapping ไม่สำเร็จ: ${errors.join("; ")}`, true);
  }
}

// =========================================================
// Trigger & Monitoring Intelligence Explorer
// =========================================================
let hostTriggersData = null;
let hostTriggersLoading = false;
let trigExplorerMode = "correlate"; // 'correlate' or 'all'

function getSeverityBadge(priority) {
  const p = String(priority || "0");
  if (p === "2" || p === "4" || p === "5") {
    return `<span class="sev-badge sev-2">🔴 Serv2 (Critical)</span>`;
  }
  return `<span class="sev-badge sev-3">🟡 Serv3 (Warning)</span>`;
}

function getKindIcon(kind) {
  if (kind === "Service") return "🛠";
  if (kind === "Process") return "⚙";
  if (kind === "Port") return "🔌";
  return "📦";
}

async function loadHostTriggers(hostid, force = false) {
  if (!hostid) return;
  const container = $("#trigResultsContainer");
  if (container) {
    container.innerHTML = `<div style="text-align:center;padding:24px;color:var(--muted)">กำลังโหลดข้อมูล Triggers จาก Zabbix...</div>`;
  }
  hostTriggersLoading = true;
  try {
    const res = await apiRequest(`/api/host/triggers?hostid=${hostid}${force ? "&_nocache=" + Date.now() : ""}`);
    if (res && res.success) {
      hostTriggersData = res;
      renderTriggerKPIs(res.summary);
      renderTriggerSection();
    } else {
      if (container) container.innerHTML = `<div class="empty-cell bad">ไม่สามารถโหลด Triggers ได้: ${escapeHtml(res?.message || "Unknown error")}</div>`;
    }
  } catch (err) {
    if (container) container.innerHTML = `<div class="empty-cell bad">โหลด Triggers ผิดพลาด: ${escapeHtml(err.message)}</div>`;
  } finally {
    hostTriggersLoading = false;
  }
}

function renderTriggerKPIs(summary) {
  const kpis = $("#trigKpis");
  if (!kpis) return;
  if (!summary) {
    kpis.innerHTML = `<span class="trig-kpi-pill">0 Triggers</span>`;
    return;
  }
  const sev = summary.by_severity || {};
  const sev2Count = (parseInt(sev["2"] || 0, 10)) + (parseInt(sev["4"] || 0, 10)) + (parseInt(sev["5"] || 0, 10));
  const sev3Count = (parseInt(sev["3"] || 0, 10)) + (parseInt(sev["1"] || 0, 10)) + (parseInt(sev["0"] || 0, 10));
  kpis.innerHTML = `
    <span class="trig-kpi-pill" title="จำนวน Trigger ทั้งหมดบนเครื่องนี้"><b>${summary.total || 0}</b> Triggers</span>
    ${summary.problems > 0 
      ? `<span class="trig-kpi-pill" style="background:rgba(239,68,68,.18);border-color:rgba(239,68,68,.4);color:#f87171" title="กำลังมีปัญหาในขณะนี้">⚠️ <b>${summary.problems}</b> Problems</span>` 
      : `<span class="trig-kpi-pill" style="color:var(--green)">● ปัญหา: 0 (OK)</span>`}
    ${sev2Count > 0 ? `<span class="sev-badge sev-2" title="Serv2 (Critical)">🔴 Serv2 (Critical): ${sev2Count}</span>` : ""}
    ${sev3Count > 0 ? `<span class="sev-badge sev-3" title="Serv3 (Warning)">🟡 Serv3 (Warning): ${sev3Count}</span>` : ""}
  `;
  const cnt = $("#trigAllCount");
  if (cnt) cnt.textContent = summary.total || 0;
}

function matchTriggerWithSoftware(trigger, sw) {
  const sName = (sw.name || "").toLowerCase().trim();
  const sKey = (sw.item_key || "").toLowerCase().trim();
  const sSvc = (sw.service_name || "").toLowerCase().trim();
  const baseName = sName.replace(/[\d._-]+$/, "").trim();

  const items = trigger.items || [];
  for (const it of items) {
    const k = (it.key_ || "").toLowerCase();
    const iname = (it.name || "").toLowerCase();
    if (sKey && k.includes(sKey)) return true;
    if (sName && (k.includes(sName) || iname.includes(sName))) return true;
    if (sSvc && (k.includes(sSvc) || iname.includes(sSvc))) return true;
    if (baseName.length >= 3 && (k.includes(baseName) || iname.includes(baseName))) return true;
  }

  const desc = (trigger.description || "").toLowerCase();
  if (sName && desc.includes(sName)) return true;
  if (sSvc && desc.includes(sSvc)) return true;
  if (baseName.length >= 3 && desc.includes(baseName)) return true;

  const expr = (trigger.expression || "").toLowerCase();
  if (sKey && expr.includes(sKey)) return true;
  if (sName && expr.includes(sName)) return true;
  if (sSvc && expr.includes(sSvc)) return true;
  if (baseName.length >= 3 && expr.includes(baseName)) return true;

  return false;
}

// =========================================================
// Trigger Explorer CRUD: Add, Delete & Toggle Triggers
// =========================================================
function openAddTriggerModal(prefillDesc = "", prefillKey = "") {
  if (!currentHost) { showToast("กรุณาเลือกเครื่องก่อน", true); return; }
  const hostTech = currentHost.host || currentHost.name;
  $("#trigModalHostName").value = `${currentHost.name} (${hostTech})`;
  $("#trigModalName").value = prefillDesc || "";
  $("#trigModalSev").value = "4"; // default High/Critical (Serv2)

  // Populate item dropdown from hostTriggersData & compliance items
  const itemSelect = $("#trigModalItem");
  itemSelect.innerHTML = `<option value="">-- เลือก Item บนเครื่องนี้ (หรือพิมพ์เองด้านล่าง) --</option>`;
  const seenKeys = new Set();
  const availableItems = [];

  if (hostTriggersData && hostTriggersData.triggers) {
    hostTriggersData.triggers.forEach(t => {
      (t.items || []).forEach(it => {
        if (it.key_ && !seenKeys.has(it.key_)) {
          seenKeys.add(it.key_);
          availableItems.push(it);
        }
      });
    });
  }
  if (currentCompliance && currentCompliance.direct_items) {
    currentCompliance.direct_items.forEach(it => {
      if (it.key_ && !seenKeys.has(it.key_)) {
        seenKeys.add(it.key_);
        availableItems.push(it);
      }
    });
  }

  availableItems.sort((a, b) => a.key_.localeCompare(b.key_)).forEach(it => {
    const opt = document.createElement("option");
    opt.value = it.key_;
    opt.textContent = `${it.key_} - ${it.name}`;
    if (prefillKey && it.key_ === prefillKey) opt.selected = true;
    itemSelect.appendChild(opt);
  });

  const activeKey = prefillKey || (availableItems[0]?.key_ || "");
  if (activeKey) {
    $("#trigModalExpr").value = `last(/${hostTech}/${activeKey})=0`;
  } else {
    $("#trigModalExpr").value = "";
  }

  document.querySelectorAll(".preset-chip").forEach(c => c.classList.remove("active"));
  const defChip = document.querySelector('.preset-chip[data-preset="service_down"]');
  if (defChip) defChip.classList.add("active");

  $("#modalAddTrigger")?.classList.remove("hidden");
  setTimeout(() => $("#trigModalName")?.focus(), 50);
}

function closeAddTriggerModal() {
  $("#modalAddTrigger")?.classList.add("hidden");
  const btn = $("#modalAddTrigSubmit");
  if (btn) btn.disabled = false;
  $("#trigAddSpinner")?.classList.add("hidden");
}

function applyTriggerPreset(presetName) {
  if (!currentHost) return;
  const hostTech = currentHost.host || currentHost.name;
  const itemKey = ($("#trigModalItem")?.value || "").trim() || "net.tcp.service[http,,80]";
  let expr = "";
  if (presetName === "service_down") expr = `last(/${hostTech}/${itemKey})=0`;
  else if (presetName === "service_error") expr = `last(/${hostTech}/${itemKey})<>0`;
  else if (presetName === "no_data") expr = `nodata(/${hostTech}/${itemKey},3m)=1`;
  else if (presetName === "high_val") expr = `last(/${hostTech}/${itemKey})>90`;
  else if (presetName === "avg_val") expr = `avg(/${hostTech}/${itemKey},5m)>90`;
  if (expr) $("#trigModalExpr").value = expr;
}

function initTriggerModalEvents() {
  const modal = $("#modalAddTrigger");
  if (!modal || modal.dataset.bound === "1") return;
  modal.dataset.bound = "1";

  $("#modalAddTrigClose")?.addEventListener("click", closeAddTriggerModal);
  $("#modalAddTrigCancel")?.addEventListener("click", closeAddTriggerModal);
  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeAddTriggerModal();
  });

  $("#formAddTrigger")?.addEventListener("submit", (e) => {
    e.preventDefault();
    submitAddTrigger();
  });

  $("#trigModalItem")?.addEventListener("change", () => {
    const activeChip = document.querySelector(".preset-chip.active");
    const preset = activeChip ? activeChip.dataset.preset : "service_down";
    applyTriggerPreset(preset);
  });

  document.querySelectorAll(".preset-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      document.querySelectorAll(".preset-chip").forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      applyTriggerPreset(chip.dataset.preset);
    });
  });
}

async function submitAddTrigger() {
  if (!currentHost) { showToast("กรุณาเลือกเครื่องก่อน", true); return; }
  const hostid = currentHost.hostid;
  const description = ($("#trigModalName")?.value || "").trim();
  const expression = ($("#trigModalExpr")?.value || "").trim();
  const priority = parseInt($("#trigModalSev")?.value || "3", 10);

  if (!description) { showToast("กรุณาระบุชื่อ Trigger", true); $("#trigModalName")?.focus(); return; }
  if (!expression) { showToast("กรุณาระบุเงื่อนไขการแจ้งเตือน (Expression)", true); $("#trigModalExpr")?.focus(); return; }

  const submitBtn = $("#modalAddTrigSubmit");
  const spinner = $("#trigAddSpinner");
  if (submitBtn) submitBtn.disabled = true;
  if (spinner) spinner.classList.remove("hidden");

  try {
    const res = await apiRequest("/api/host/triggers/create", "POST", {
      hostid,
      description,
      expression,
      priority
    });
    if (res.success) {
      showToast(res.message || `สร้าง Trigger '${description}' สำเร็จ!`);
      closeAddTriggerModal();
      await loadHostTriggers(hostid, true);
    } else {
      showToast(res.error || res.message || "Zabbix ปฏิเสธการสร้าง Trigger", true);
    }
  } catch (err) {
    showToast(`เกิดข้อผิดพลาดในการสร้าง Trigger: ${err.message}`, true);
  } finally {
    if (submitBtn) submitBtn.disabled = false;
    if (spinner) spinner.classList.add("hidden");
  }
}

async function deleteTrigger(triggerid, triggerName, isTemplate) {
  if (!currentHost) return;
  if (isTemplate === "1" || isTemplate === true) {
    alert(`Trigger "${triggerName}" ผูกติดมาจาก Zabbix Template จึงไม่สามารถลบเฉพาะเครื่องนี้ได้โดยตรง\n\nคำแนะนำ: หากไม่ต้องการรับการแจ้งเตือน สามารถกดปุ่ม "ปิดใช้งาน (Disable)" เพื่อหยุดการแจ้งเตือนบนเครื่องนี้ได้`);
    return;
  }
  if (!confirm(`คุณต้องการลบ Trigger "${triggerName}" ออกจาก Zabbix หรือไม่?`)) return;

  try {
    const res = await apiRequest("/api/host/triggers/delete", "POST", {
      hostid: currentHost.hostid,
      triggerids: [triggerid]
    });
    if (res.success) {
      showToast(res.message || "ลบ Trigger สำเร็จ!");
      await loadHostTriggers(currentHost.hostid, true);
    } else {
      showToast(res.message || res.error || "ไม่สามารถลบ Trigger ได้", true);
    }
  } catch (err) {
    showToast(`เกิดข้อผิดพลาดในการลบ Trigger: ${err.message}`, true);
  }
}

async function toggleTrigger(triggerid, currentStatus) {
  if (!currentHost) return;
  const newStatus = parseInt(currentStatus, 10) === 0 ? 1 : 0;
  try {
    const res = await apiRequest("/api/host/triggers/toggle", "POST", {
      updates: [{ triggerid: String(triggerid), status: newStatus }]
    });
    if (res.success) {
      showToast(newStatus === 0 ? "เปิดใช้งาน Trigger แล้ว (Enabled) ●" : "ปิดใช้งาน Trigger แล้ว (Disabled)");
      await loadHostTriggers(currentHost.hostid, true);
    } else {
      showToast(res.message || "ไม่สามารถเปลี่ยนสถานะ Trigger ได้", true);
    }
  } catch (err) {
    showToast(`เกิดข้อผิดพลาด: ${err.message}`, true);
  }
}

function renderTriggerSection() {
  const container = $("#trigResultsContainer");
  if (!container) return;
  if (!hostTriggersData || !hostTriggersData.triggers) {
    container.innerHTML = `<div style="text-align:center;padding:24px;color:var(--muted)">ไม่มีข้อมูล Trigger บนเครื่องนี้</div>`;
    return;
  }

  const allTriggers = hostTriggersData.triggers || [];
  const templates = hostTriggersData.templates || [];
  const q = ($("#trigSearchInput")?.value || "").toLowerCase().trim();
  const sevFilter = $("#trigSevFilter")?.value || "all";
  const stFilter = $("#trigStatusFilter")?.value || "all";

  const filterTrigger = (t) => {
    if (sevFilter === "2") {
      const p = String(t.priority);
      if (p !== "2" && p !== "4" && p !== "5") return false;
    } else if (sevFilter === "3") {
      const p = String(t.priority);
      if (p !== "3" && p !== "1" && p !== "0") return false;
    }
    if (stFilter === "problem" && String(t.value) !== "1") return false;
    if (stFilter === "ok" && String(t.value) !== "0") return false;
    if (stFilter === "enabled" && String(t.status) !== "0") return false;
    if (stFilter === "disabled" && String(t.status) !== "1") return false;
    return true;
  };

  if (trigExplorerMode === "all") {
    const filteredTriggers = allTriggers.filter((t) => {
      if (!filterTrigger(t)) return false;
      if (!q) return true;
      const desc = (t.description || "").toLowerCase();
      const expr = (t.expression || "").toLowerCase();
      const itemsStr = (t.items || []).map((it) => (it.name + " " + it.key_).toLowerCase()).join(" ");
      return desc.includes(q) || expr.includes(q) || itemsStr.includes(q);
    });

    if (!filteredTriggers.length) {
      container.innerHTML = `<div class="empty-cell" style="padding:28px">${allTriggers.length ? "ไม่พบ Trigger ที่ตรงกับเงื่อนไขการค้นหา" : "ไม่มี Trigger ใดๆ บนเครื่องนี้"}</div>`;
      return;
    }

    container.innerHTML = `
      <div class="tablewrap"><table class="data">
        <thead><tr>
          <th style="width:45px">No.</th>
          <th style="width:130px">ความรุนแรง (Severity)</th>
          <th>ชื่อ Trigger (Description)</th>
          <th>Item ที่เกี่ยวข้อง (Items &amp; Keys)</th>
          <th>เงื่อนไขการแจ้งเตือน / Expression (เซ็ตว่าอะไร)</th>
          <th style="width:110px">สถานะปัญหา</th>
          <th style="width:110px">การเปิดใช้งาน</th>
          <th style="width:100px;text-align:center">จัดการ</th>
        </tr></thead>
        <tbody>
          ${filteredTriggers.map((t, idx) => {
            const isProb = t.value === "1";
            const isEnabled = t.status === "0";
            const isTemplated = t.templateid && String(t.templateid) !== "0";
            const itemsHtml = (t.items || []).length
              ? t.items.map(it => `<div><span class="mono" style="color:var(--cyan)">${escapeHtml(it.key_)}</span> <span class="muted small">${escapeHtml(it.name)}</span></div>`).join("")
              : '<span class="muted">-</span>';
            return `<tr>
              <td>${idx + 1}</td>
              <td>${getSeverityBadge(t.priority)}</td>
              <td>
                <div style="font-weight:700">${escapeHtml(t.description)}</div>
                ${isTemplated ? '<span class="trig-template-badge" title="สืบทอดมาจาก Zabbix Template">📦 Template</span>' : '<span class="tag neutral small" style="font-size:9.5px;padding:1px 5px">Host Trigger</span>'}
              </td>
              <td>${itemsHtml}</td>
              <td><div class="mono" style="max-width:380px;white-space:normal;color:var(--cyan);background:rgba(0,0,0,.2);padding:4px 8px;border-radius:6px;border:1px solid var(--line)">${escapeHtml(t.expression)}</div></td>
              <td>${isProb ? '<span class="tag bad">⚠️ PROBLEM</span>' : '<span class="tag ok">● OK</span>'}</td>
              <td>
                <button type="button" class="mini-btn ${isEnabled ? 'secondary' : 'ok'}" data-trig-toggle="${t.triggerid}" data-current-status="${t.status}" title="${isEnabled ? 'คลิกเพื่อปิดใช้งาน (Disable)' : 'คลิกเพื่อเปิดใช้งาน (Enable)'}">
                  ${isEnabled ? '✓ Enabled' : '✕ Disabled'}
                </button>
              </td>
              <td>
                <div class="row-actions" style="justify-content:center">
                  <button type="button" class="mini-btn del" data-trig-delete="${t.triggerid}" data-trig-name="${escapeHtml(t.description)}" data-is-template="${isTemplated ? '1' : '0'}" title="${isTemplated ? 'Trigger จาก Template (ไม่สามารถลบเฉพาะเครื่องได้ แนะนำให้กดปิดใช้งาน)' : 'ลบ Trigger นี้ออกจาก Zabbix'}">
                    🗑️ ลบ
                  </button>
                </div>
              </td>
            </tr>`;
          }).join("")}
        </tbody>
      </table></div>
    `;
    return;
  }

  let rowsToCorrelate = mapInvRows.slice();

  if (!rowsToCorrelate.length && allTriggers.length) {
    const seen = new Set();
    allTriggers.forEach(t => {
      (t.items || []).forEach(it => {
        const k = it.key_ || "";
        const m = k.match(/\[([^\]]+)\]/);
        const name = m ? m[1].split(",")[0] : it.name;
        if (name && !seen.has(name)) {
          seen.add(name);
          rowsToCorrelate.push({ name: name, kind: "Item", item: it.name, item_key: it.key_, status: "Monitored", template: "-" });
        }
      });
    });
  }

  const matchedList = [];
  const matchedTriggerIds = new Set();

  rowsToCorrelate.forEach((sw) => {
    const matchedTrigs = allTriggers.filter((t) => matchTriggerWithSoftware(t, sw));
    matchedTrigs.forEach(t => matchedTriggerIds.add(t.triggerid));
    const activeTrigs = matchedTrigs.filter(filterTrigger);

    if (stFilter === "has_trigger" && !matchedTrigs.length) return;
    if (stFilter === "no_trigger" && matchedTrigs.length > 0) return;
    if ((stFilter === "problem" || stFilter === "ok" || sevFilter !== "all") && !activeTrigs.length) return;

    if (q) {
      const swStr = [sw.name, sw.service_name, sw.kind, sw.template, sw.expected, sw.item, sw.item_key].filter(Boolean).join(" ").toLowerCase();
      const trigStr = matchedTrigs.map(t => (t.description + " " + t.expression + " " + (t.items || []).map(i => i.key_).join(" "))).join(" ").toLowerCase();
      if (!swStr.includes(q) && !trigStr.includes(q)) return;
    }

    matchedList.push({
      sw,
      triggers: activeTrigs.length ? activeTrigs : matchedTrigs
    });
  });

  const orphanTriggers = allTriggers.filter(t => !matchedTriggerIds.has(t.triggerid) && filterTrigger(t));
  if (orphanTriggers.length && (!q || orphanTriggers.some(t => (t.description + " " + t.expression).toLowerCase().includes(q)))) {
    matchedList.push({
      sw: {
        name: "System & Host Alert Rules",
        kind: "System / Host",
        service_name: "Host Level Items",
        template: templates.length ? templates.map(t => t.name).join(", ") : "Host Items",
        item: "Host Items & Triggers",
        item_key: "agent.ping, system.cpu.*, etc.",
        status: "Monitored"
      },
      triggers: orphanTriggers
    });
  }

  if (!matchedList.length) {
    container.innerHTML = `
      <div class="empty-cell" style="padding:32px">
        <div style="font-size:15px;font-weight:700;margin-bottom:6px">ไม่พบข้อมูลที่ตรงกับคำค้นหา "${escapeHtml(q)}"</div>
        <div class="muted small">ลองพิมพ์ชื่อ software หรือ service เช่น <b>apache</b>, <b>mysql</b>, <b>nginx</b> หรือล้างคำค้นหา</div>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    <div class="trig-correlate-list">
      ${matchedList.map(({ sw, triggers }) => {
        const hasTrig = triggers.length > 0;
        const tmpl = sw.template && sw.template !== "-" ? sw.template : (templates.length ? templates[0].name : "");
        const matchedItems = [];
        triggers.forEach(t => {
          (t.items || []).forEach(it => {
            if (!matchedItems.some(x => x.key_ === it.key_)) matchedItems.push(it);
          });
        });

        return `
          <div class="trig-correlate-card">
            <div class="trig-card-head">
              <div class="trig-card-name">
                <span style="font-size:16px">${getKindIcon(sw.kind)}</span>
                <span>${escapeHtml(sw.name)}</span>
                <span class="tag neutral">${escapeHtml(sw.kind)}</span>
                ${sw.service_name && sw.service_name !== sw.name ? `<span class="cell-note mono">(${escapeHtml(sw.service_name)})</span>` : ""}
              </div>
              <div class="trig-card-badges">
                ${sw.status === "Monitored" ? '<span class="tag ok">● Monitored</span>' : '<span class="tag bad">✕ Not Monitored</span>'}
                ${hasTrig 
                  ? `<span class="tag ok" style="font-weight:700">✓ มี ${triggers.length} Triggers เฝ้าระวัง</span>`
                  : `<span class="tag warn" style="font-weight:700">⚠️ ยังไม่มี Trigger</span>`}
              </div>
            </div>

            <div class="trig-card-grid">
              <!-- Col 1: Template -->
              <div class="trig-grid-col">
                <div class="trig-col-label">1. Template ที่ใช้ Monitor</div>
                <div class="trig-col-val">
                  ${tmpl ? `<div class="tmpl-name">📦 ${escapeHtml(tmpl)}</div>` : '<span class="muted">— ตรวจวัดผ่าน Item บน Host โดยตรง (ไม่มี Template)</span>'}
                  ${sw.expected && sw.expected !== "-" && sw.expected !== tmpl ? `<div class="cell-note" style="color:var(--yellow);margin-top:4px">แนะนำ OS template: <b>${escapeHtml(sw.expected)}</b></div>` : ""}
                </div>
              </div>

              <!-- Col 2: Item -->
              <div class="trig-grid-col">
                <div class="trig-col-label">2. Item ที่ใช้ตรวจวัด (Metrics)</div>
                <div class="trig-col-val">
                  ${matchedItems.length 
                    ? matchedItems.map(it => `<div><span class="item-chip">${escapeHtml(it.key_)}</span> <span style="font-size:11px;color:var(--muted)">${escapeHtml(it.name)}</span></div>`).join("") 
                    : (sw.item ? `<div><span class="item-chip">${escapeHtml(sw.item_key || sw.item)}</span> <span style="font-size:11px;color:var(--muted)">${escapeHtml(sw.item)}</span></div>` : '<span class="muted">— ยังไม่มี Item</span>')}
                </div>
              </div>

              <!-- Col 3: Trigger & Expression -->
              <div class="trig-grid-col">
                <div class="trig-col-label">3. Trigger &amp; เงื่อนไขการแจ้งเตือน (เซ็ตว่าอะไร)</div>
                <div class="trig-col-val">
                  ${hasTrig ? `
                    <div class="trig-rules-box">
                      ${triggers.map(tr => {
                        const isProb = tr.value === "1";
                        const isEnabled = tr.status === "0";
                        const isTemplated = tr.templateid && String(tr.templateid) !== "0";
                        return `
                          <div class="trig-rule-item">
                            <div class="trig-rule-head">
                              <span class="trig-rule-name">${escapeHtml(tr.description)}</span>
                              ${getSeverityBadge(tr.priority)}
                              ${isTemplated ? '<span class="trig-template-badge" title="สืบทอดมาจาก Zabbix Template">📦 Template</span>' : ''}
                              <div class="trig-rule-actions">
                                <button type="button" class="mini-btn ${isEnabled ? 'secondary' : 'ok'}" data-trig-toggle="${tr.triggerid}" data-current-status="${tr.status}" title="${isEnabled ? 'คลิกเพื่อปิดใช้งาน (Disable)' : 'คลิกเพื่อเปิดใช้งาน (Enable)'}">
                                  ${isEnabled ? 'ปิดใช้งาน' : 'เปิดใช้งาน'}
                                </button>
                                <button type="button" class="mini-btn del" data-trig-delete="${tr.triggerid}" data-trig-name="${escapeHtml(tr.description)}" data-is-template="${isTemplated ? '1' : '0'}" title="${isTemplated ? 'Trigger จาก Template (ไม่สามารถลบเฉพาะเครื่องได้)' : 'ลบ Trigger นี้ออกจาก Zabbix'}">
                                  🗑️ ลบ
                                </button>
                              </div>
                            </div>
                            <div class="trig-rule-expr" title="Trigger Expression">${escapeHtml(tr.expression)}</div>
                            <div class="trig-rule-state">
                              ${isProb ? '<span style="color:var(--red);font-weight:700">⚠️ กำลังเกิดปัญหา (PROBLEM)</span>' : '<span style="color:var(--green)">● สถานะปกติ (OK)</span>'}
                              <span style="color:var(--muted)">·</span>
                              <span style="color:var(--muted)">${isEnabled ? 'เปิดใช้งาน (Enabled)' : 'ปิดใช้งาน (Disabled)'}</span>
                            </div>
                          </div>
                        `;
                      }).join("")}
                    </div>
                    <div style="margin-top:8px;display:flex;justify-content:flex-end">
                      <button type="button" class="mini-btn add" data-trig-add-sw="${escapeHtml(sw.name)}" data-trig-add-key="${escapeHtml(sw.item_key || '')}" title="เพิ่ม Trigger เงื่อนไขใหม่สำหรับ ${escapeHtml(sw.name)}">＋ เพิ่ม Trigger สำหรับ ${escapeHtml(sw.name)}</button>
                    </div>
                  ` : `
                    <div class="trig-empty-alert">
                      <span>⚠️ ซอฟต์แวร์นี้ยังไม่มี Trigger แจ้งเตือนใน Zabbix</span>
                      <div style="display:flex;gap:6px;margin-left:auto">
                        <button type="button" class="mini-btn add" data-trig-add-sw="${escapeHtml(sw.name)}" data-trig-add-key="${escapeHtml(sw.item_key || '')}" title="เพิ่ม Trigger เฝ้าระวังใหม่">＋ เพิ่ม Trigger</button>
                        ${sw.action ? `<button type="button" class="mini-btn secondary" data-mapfix='${escapeHtml(JSON.stringify(sw.action))}'>＋ เพิ่ม Auto-Trigger</button>` : ""}
                      </div>
                    </div>
                  `}
                </div>
              </div>
            </div>
          </div>
        `;
      }).join("")}
    </div>
  `;
}

// =========================================================
// Reports page: readiness artifacts (HTML / PDF / PNG / CSV / JSON)
// =========================================================
let reportAppHosts = [];
let reportScores = {};   // hostid -> compliance summary (fleet table)
let selectedReportHostIds = new Set();

function reportUrl(hostids, fmt, extraParams = {}) {
  const p = new URLSearchParams({ format: fmt, ...extraParams });
  p.set(hostids.length > 1 ? "hostids" : "hostid", hostids.join(","));
  const by = ($("#repPreparedBy")?.value || "").trim();
  if (by) p.set("prepared_by", by);
  try { localStorage.setItem("mz_prepared_by", by); } catch (e) {}
  return `${API_BASE}/api/artifact/report?${p.toString()}`;
}

async function downloadReport(hostids, fmt, btn, title) {
  if (!hostids.length) { showToast("กรุณาเลือกเครื่องก่อน", true); return; }
  const params = title ? { title } : {};
  if (fmt === "html") {  // preview in a new tab (print -> Save as PDF also works there)
    window.open(reportUrl(hostids, "html", { ...params, inline: "1" }), "_blank", "noopener");
    return;
  }
  const label = btn ? btn.textContent : "";
  if (btn) { btn.disabled = true; btn.textContent = "กำลังสร้าง..."; }
  try {
    const resp = await fetch(reportUrl(hostids, fmt, params));
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      throw new Error(err.error || `HTTP ${resp.status}`);
    }
    const blob = await resp.blob();
    const cd = resp.headers.get("Content-Disposition") || "";
    const m = cd.match(/filename="([^"]+)"/);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = m ? m[1] : `readiness.${fmt}`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    showToast(`ดาวน์โหลด ${fmt.toUpperCase()} แล้ว`);
  } catch (err) {
    showToast(`สร้าง ${fmt.toUpperCase()} ไม่สำเร็จ: ${err.message}`, true);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = label; }
  }
}

function formatButtons(scope) {
  return ["html", "pdf", "png", "csv", "json"].map((f) =>
    `<button class="${f === "pdf" ? "" : "secondary"} rep-btn" data-rep="${scope}" data-fmt="${f}">${
      { html: "👁 Preview / Print", pdf: "⇩ PDF", png: "⇩ PNG", csv: "⇩ CSV (Excel)", json: "⇩ JSON" }[f]}</button>`).join("");
}

function updateReportSelectionUI() {
  const total = reportAppHosts.length;
  const sel = selectedReportHostIds.size;
  const allChk = $("#repSelectAll");
  if (allChk) {
    allChk.checked = total > 0 && sel === total;
    allChk.indeterminate = sel > 0 && sel < total;
  }
  const badge = $("#repSelBadge");
  if (badge) {
    badge.textContent = `เลือก ${sel}/${total} เครื่อง`;
  }
  const evalBtn = $("#repEvaluate");
  if (evalBtn) {
    evalBtn.textContent = (sel === total || sel === 0) ? "⟳ ประเมินทุกเครื่อง" : `⟳ ประเมินที่เลือก (${sel})`;
  }
}

function renderReports() {
  let preparedBy = "";
  try { preparedBy = localStorage.getItem("mz_prepared_by") || ""; } catch (e) {}
  const appLabels = appOptionLabels();
  const c = currentCompliance;
  extra.innerHTML = `
    <section class="panel">
      <div class="paneltitle">📄 Readiness Artifact — เครื่องเดียว <span class="source">หลักฐานความพร้อมการ Monitor</span></div>
      ${currentHost && c ? `<p>เครื่อง <b>${escapeHtml(currentHost.name)}</b> · ${escapeHtml(c.os_family.toUpperCase())} · ${verdictTag(c.verdict, c.overall.pct)}
          · OS ${pctOrDash(c.sections.os.pct)}% · Software ${pctOrDash(combineSummary(c.sections.service, c.sections.software).pct)}%</p>`
        : `<p class="muted">เลือก Application / Server ด้านบนก่อน</p>`}
      <div class="rep-row">
        <label class="rep-label">Prepared by <input class="form-ctl" id="repPreparedBy" value="${escapeHtml(preparedBy)}" placeholder="ชื่อผู้จัดทำ"></label>
        <div class="rep-btns">${formatButtons("host")}</div>
      </div>
      <p class="muted small">PDF / PNG สร้างด้วย Edge/Chrome บนเครื่องที่รันโปรแกรม · HTML เปิดแล้วสั่ง Print → Save as PDF ได้ทันที</p>
    </section>

    <section class="panel">
      <div class="paneltitle">🗂 Application Report — สรุปรายชื่อเครื่องใน Application <span class="source">เลือกหลายเครื่องได้</span></div>
      <div class="rep-row">
        <div class="ac" data-ac="repApp" style="min-width:280px"><input class="form-ctl" id="repApp" placeholder="เลือก Application (appid : appname)..." autocomplete="off" style="width:100%"><div class="ac-menu" hidden></div></div>
        <button class="secondary" id="repEvaluate">⟳ ประเมินทุกเครื่อง</button>
        <span class="source" id="repSelBadge" style="align-self:center;font-size:11px">เลือก 0/0 เครื่อง</span>
        <div class="rep-btns">${formatButtons("app").replace(/<button[^>]*data-fmt="(png|json)"[^>]*>[^<]*<\/button>/g, "")}</div>
      </div>
      <div class="tablewrap"><table class="data"><thead><tr>
        <th style="width:36px;text-align:center"><input type="checkbox" id="repSelectAll" checked title="เลือกทั้งหมด / ยกเลิกทั้งหมด" style="cursor:pointer"></th>
        <th>Host</th><th>OS</th><th>OS %</th><th>Software %</th><th>Overall</th><th>Verdict</th><th>Inventory</th><th></th>
      </tr></thead>
        <tbody id="repRows"><tr><td colspan="9" class="empty-cell">เลือก Application แล้วกด "ประเมินทุกเครื่อง"</td></tr></tbody></table></div>
    </section>`;

  setupAutocomplete('[data-ac="repApp"]', {
    getItems: (q) => appLabels.filter((l) => !q || l.toLowerCase().includes(q.toLowerCase())),
    onSelect: () => renderReportHosts(true)
  });
  $("#repApp").addEventListener("change", () => renderReportHosts(true));
  $("#repEvaluate").addEventListener("click", evaluateReportHosts);

  $("#repSelectAll")?.addEventListener("change", (e) => {
    if (e.target.checked) {
      reportAppHosts.forEach((h) => selectedReportHostIds.add(h.hostid));
    } else {
      selectedReportHostIds.clear();
    }
    extra.querySelectorAll(".rep-host-chk").forEach((c) => {
      c.checked = e.target.checked;
    });
    updateReportSelectionUI();
  });

  extra.querySelector("#repRows")?.addEventListener("change", (e) => {
    const chk = e.target.closest(".rep-host-chk");
    if (chk) {
      if (chk.checked) selectedReportHostIds.add(chk.dataset.hostid);
      else selectedReportHostIds.delete(chk.dataset.hostid);
      updateReportSelectionUI();
    }
  });

  extra.querySelectorAll("[data-rep]").forEach((b) => b.addEventListener("click", () => {
    if (b.dataset.rep === "host") {
      downloadReport(currentHost ? [currentHost.hostid] : [], b.dataset.fmt, b);
    } else {
      const targetIds = reportAppHosts.filter((h) => selectedReportHostIds.has(h.hostid)).map((h) => h.hostid);
      if (!targetIds.length) {
        showToast("กรุณาติ๊กเลือกอย่างน้อย 1 เครื่องเพื่อออกรายงาน Artifact", true);
        return;
      }
      downloadReport(targetIds, b.dataset.fmt, b, ($("#repApp").value || "").trim());
    }
  }));

  extra.querySelector("#repRows").addEventListener("click", (e) => {
    if (e.target.classList.contains("rep-host-chk")) return;
    const b = e.target.closest("[data-open-host]");
    if (b) { navTo("dashboard"); selectHost(b.dataset.openHost); }
  });
  if (currentHost && currentHost.appId) { $("#repApp").value = appLabelFor(currentHost); renderReportHosts(true); }
}

function renderReportHosts(resetSelection = false) {
  const appId = appIdFromInput($("#repApp")?.value || "");
  const prevApp = reportAppHosts.length ? reportAppHosts[0].appId : "";
  reportAppHosts = appId ? hosts.filter((h) => h.appId === appId) : [];
  const tbody = $("#repRows");
  if (!tbody) return;
  if (!reportAppHosts.length) {
    selectedReportHostIds.clear();
    updateReportSelectionUI();
    tbody.innerHTML = '<tr><td colspan="9" class="empty-cell">ไม่พบเครื่องใน Application นี้</td></tr>';
    return;
  }
  if (resetSelection || prevApp !== appId || !selectedReportHostIds.size) {
    selectedReportHostIds.clear();
    reportAppHosts.forEach((h) => selectedReportHostIds.add(h.hostid));
  }
  tbody.innerHTML = reportAppHosts.map((h) => {
    const r = reportScores[h.hostid];
    const sw = r ? combineSummary(r.sections.service, r.sections.software) : null;
    const isChecked = selectedReportHostIds.has(h.hostid) ? "checked" : "";
    return `<tr>
      <td style="text-align:center;width:40px"><input type="checkbox" class="rep-host-chk" data-hostid="${h.hostid}" ${isChecked} style="cursor:pointer"></td>
      <td>${escapeHtml(h.name)}</td>
      <td>${r ? escapeHtml(r.os_family.toUpperCase()) : "-"}</td>
      <td>${r ? pctOrDash(r.sections.os.pct) + "%" : "-"}</td>
      <td>${sw ? pctOrDash(sw.pct) + "%" : "-"}</td>
      <td><b>${r ? pctOrDash(r.overall.pct) + "%" : "-"}</b></td>
      <td>${r ? verdictTag(r.verdict, null) : '<span class="muted">ยังไม่ประเมิน</span>'}</td>
      <td>${r ? confidenceTag(r.inventory.confidence) : "-"}</td>
      <td><button class="mini-btn" data-open-host="${h.id}">Open</button></td></tr>`;
  }).join("");
  updateReportSelectionUI();
}

async function evaluateReportHosts(e) {
  if (!reportAppHosts.length) { showToast("กรุณาเลือก Application ก่อน", true); return; }
  const targetHosts = reportAppHosts.filter((h) => selectedReportHostIds.has(h.hostid));
  if (!targetHosts.length) { showToast("กรุณาติ๊กเลือกอย่างน้อย 1 เครื่องเพื่อประเมิน", true); return; }
  const btn = e.currentTarget;
  btn.disabled = true;
  for (const [i, h] of targetHosts.entries()) {
    btn.textContent = `ประเมิน ${i + 1}/${targetHosts.length}...`;
    try { reportScores[h.hostid] = await apiRequest(`/api/host/compliance?hostid=${h.hostid}`); } catch (err) { /* keep going */ }
    renderReportHosts();
  }
  btn.disabled = false;
  updateReportSelectionUI();
}

// =========================================================
// Settings page
// =========================================================
function renderSettings() {
  const p = loadProfile();
  const currentTheme = p.theme === "light" ? "light" : "dark";

  extra.innerHTML = `
    <div class="settings-container">
      <section class="panel">
        <div class="paneltitle">
          <span>⚙️ System &amp; Appearance Settings <span class="source">การตั้งค่าระบบ</span></span>
        </div>
        <p class="muted small" style="margin-top:-6px;margin-bottom:18px">
          ปรับแต่งธีมสีการแสดงผล (ตามภาพต้นแบบ Dashboard มืด/สว่าง) และจัดการข้อมูลผู้ใช้งาน
        </p>

        <!-- Theme Selection Section -->
        <div class="theme-section">
          <div style="font-size:13.5px;font-weight:700;margin-bottom:6px;display:flex;align-items:center;gap:8px">
            <span>🎨 ธีมการแสดงผล (Display Theme)</span>
          </div>
          <p class="muted small" style="margin-bottom:14px">
            สามารถเลือกปรับใช้งานระหว่าง <b>ธีมมืด (Dark)</b> และ <b>ธีมสว่าง (Light)</b> ได้ทันที โดยคลิกที่การ์ดตัวอย่างด้านล่าง
          </p>

          <div class="theme-grid">
            <!-- Dark Theme Card -->
            <div class="theme-card ${currentTheme === "dark" ? "active" : ""}" id="themeCardDark" data-theme-val="dark">
              <div class="theme-card-head">
                <span class="theme-card-title">🌙 ธีมมืด (Dark Theme)</span>
                <span class="theme-badge" id="badgeDark">${currentTheme === "dark" ? "✓ ใช้งานอยู่" : "เลือกใช้งาน"}</span>
              </div>
              <div class="theme-card-desc">โทนสีเข้มล้ำสมัย สบายตา พร้อมประกายแสงนีออน Cyan &amp; Magenta สไตล์ Futuristic Dashboard (ตามภาพด้านบน)</div>
              <div class="theme-preview dark-mock">
                <div class="mock-topbar">
                  <span style="font-size:9.5px;font-weight:700">⌁ Conversion &amp; Revenue</span>
                  <span class="mock-badge">76% Retention</span>
                </div>
                <div class="mock-charts">
                  <div class="mock-funnel">
                    <div class="mock-bar b1"></div>
                    <div class="mock-bar b2"></div>
                    <div class="mock-bar b3"></div>
                    <div class="mock-bar b4"></div>
                  </div>
                  <div class="mock-donut-wrap">
                    <div class="mock-donut">
                      <div class="mock-donut-inner">76%</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Light Theme Card -->
            <div class="theme-card ${currentTheme === "light" ? "active" : ""}" id="themeCardLight" data-theme-val="light">
              <div class="theme-card-head">
                <span class="theme-card-title">☀ ธีมสว่าง (Light Theme)</span>
                <span class="theme-badge" id="badgeLight">${currentTheme === "light" ? "✓ ใช้งานอยู่" : "เลือกใช้งาน"}</span>
              </div>
              <div class="theme-card-desc">โทนสีขาวสะอาด คมชัด มินิมอล โมเดิร์น พร้อมสีสันสดใส High-Contrast สบายตากลางวัน (ตามภาพด้านล่าง)</div>
              <div class="theme-preview light-mock">
                <div class="mock-topbar">
                  <span style="font-size:9.5px;font-weight:700">⌁ Conversion &amp; Revenue</span>
                  <span class="mock-badge">76% Retention</span>
                </div>
                <div class="mock-charts">
                  <div class="mock-funnel">
                    <div class="mock-bar b1"></div>
                    <div class="mock-bar b2"></div>
                    <div class="mock-bar b3"></div>
                    <div class="mock-bar b4"></div>
                  </div>
                  <div class="mock-donut-wrap">
                    <div class="mock-donut">
                      <div class="mock-donut-inner">76%</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div style="margin-top:14px;display:flex;align-items:center;gap:12px;flex-wrap:wrap">
            <label style="font-size:12px;color:var(--muted);font-weight:600">หรือเลือกจากเมนูดรอปดาวน์:
              <select class="form-ctl" id="profTheme" style="margin-left:8px;padding:6px 12px;font-size:12px">
                <option value="dark" ${currentTheme === "dark" ? "selected" : ""}>🌙 ธีมมืด (Dark Theme)</option>
                <option value="light" ${currentTheme === "light" ? "selected" : ""}>☀ ธีมสว่าง (Light Theme)</option>
              </select>
            </label>
          </div>
        </div>

        <div style="margin:22px 0 16px;border-top:1px solid var(--line)"></div>

        <!-- User Profile Section -->
        <div style="font-size:13.5px;font-weight:700;margin-bottom:12px">👤 ข้อมูลผู้ใช้งาน (User Profile)</div>
        <div class="settings-grid" style="margin-bottom:14px">
          <label>ชื่อผู้ใช้งาน (Display Name)
            <input class="form-ctl" id="profName" maxlength="60" placeholder="เช่น admin, DevOps Engineer" value="${escapeHtml(p.name || "")}">
          </label>
          <label>การเชื่อมต่อ Zabbix Server
            <input class="form-ctl" disabled value="${escapeHtml(($("#loginUrl")?.value) || "http://127.0.0.1/zabbix")}" style="opacity:.7">
          </label>
        </div>

        <p class="muted small">การตั้งค่าธีมและชื่อผู้ใช้จะถูกบันทึกไว้ในเบราว์เซอร์ของคุณ และทำงานอัตโนมัติทุกครั้งที่เข้าใช้งาน</p>
        <div class="row-actions" style="margin-top:16px">
          <button id="profSave">💾 บันทึกการตั้งค่า</button>
          <button class="secondary" id="profLogout">🚪 ออกจากระบบ</button>
        </div>
      </section>
    </div>`;

  function setAndApplyTheme(newTheme, showFeedback = true) {
    applyTheme(newTheme);
    const prof = loadProfile();
    prof.theme = newTheme;
    saveProfile(prof);

    // Update UI elements
    const isDark = newTheme === "dark";
    $("#themeCardDark")?.classList.toggle("active", isDark);
    $("#themeCardLight")?.classList.toggle("active", !isDark);
    if ($("#badgeDark")) $("#badgeDark").textContent = isDark ? "✓ ใช้งานอยู่" : "เลือกใช้งาน";
    if ($("#badgeLight")) $("#badgeLight").textContent = !isDark ? "✓ ใช้งานอยู่" : "เลือกใช้งาน";
    if ($("#profTheme")) $("#profTheme").value = newTheme;

    if (showFeedback) {
      showToast(isDark ? "เปลี่ยนเป็นธีมมืด (Dark Theme) แล้ว 🌙" : "เปลี่ยนเป็นธีมสว่าง (Light Theme) แล้ว ☀");
    }
  }

  // Card clicks
  $("#themeCardDark")?.addEventListener("click", () => setAndApplyTheme("dark"));
  $("#themeCardLight")?.addEventListener("click", () => setAndApplyTheme("light"));

  // Dropdown change
  $("#profTheme")?.addEventListener("change", (e) => setAndApplyTheme(e.target.value));

  // Save button
  $("#profSave")?.addEventListener("click", () => {
    const profile = {
      name: ($("#profName")?.value || "").trim(),
      theme: $("#profTheme")?.value === "light" ? "light" : "dark"
    };
    saveProfile(profile);
    applyTheme(profile.theme);
    applyProfileName(profile.name);
    showToast("บันทึกการตั้งค่าโปรไฟล์เรียบร้อยแล้ว");
  });

  $("#profLogout")?.addEventListener("click", () => $("#logoutLink")?.click());
}



// Application & Server filter block (kept for backward compatibility)
function mappingFilterHTML() {
  return "";
}

function bindMappingFilter() {
  // Main filter is already bound globally
}

async function mappingSelectHost(serverName) {
  const host = hostFromInput(serverName);
  if (!host) {
    showToast("ไม่พบ Server ที่ตรงกับการค้นหา", true);
    return;
  }
  await selectHost(host.id);
  if (currentPage && !["dashboard", "os", "software"].includes(currentPage)) {
    renderCurrentPage();
  }
}

// =========================================================
// Profile (Name + Theme) — stored locally in the browser
// =========================================================
const PROFILE_KEY = "mz_profile";

function loadProfile() {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (raw) return { name: "", theme: "dark", ...JSON.parse(raw) };
  } catch (e) { /* ignore */ }
  return { name: "", theme: "dark" };
}

function saveProfile(profile) {
  try { localStorage.setItem(PROFILE_KEY, JSON.stringify(profile)); } catch (e) { /* ignore */ }
}

function applyTheme(theme) {
  const root = document.documentElement;
  if (theme === "light") root.setAttribute("data-theme", "light");
  else root.removeAttribute("data-theme");
}

// Reflect the profile name on the top bar; keep the Zabbix version suffix if present.
function applyProfileName(name) {
  const label = $("#userLabel");
  if (!label) return;
  const suffix = label.dataset.suffix || "";
  const display = (name && name.trim()) || "admin";
  label.textContent = suffix ? `${display} · ${suffix}` : display;
}

// Apply the saved theme as early as possible (before auth check) to avoid a flash.
applyTheme(loadProfile().theme);

function initSidebarCollapse() {
  const topBtn = $("#sidebarToggleBtn");
  const chevronBtn = $("#sidebarChevronBtn");
  const logoBadge = $("#zabbixLogoBadge");
  const aside = $("#mainSidebar") || $("aside");
  if (!aside) return;

  const setCollapsedState = (collapsed) => {
    aside.classList.toggle("collapsed", collapsed);
    if (topBtn) topBtn.classList.toggle("collapsed", collapsed);
    if (chevronBtn) {
      chevronBtn.setAttribute("title", collapsed ? "เปิดค้างไว้ (Keep Open / Pin Sidebar)" : "พับเก็บเมนูด้านข้าง (Collapse Sidebar)");
    }
    try {
      localStorage.setItem("mz_sidebar_collapsed", String(collapsed));
    } catch (e) { /* ignore */ }
  };

  const toggleSidebar = () => {
    const isNow = !aside.classList.contains("collapsed");
    setCollapsedState(isNow);
  };

  const expandSidebar = () => {
    if (aside.classList.contains("collapsed")) {
      setCollapsedState(false);
    }
  };

  const isCollapsed = localStorage.getItem("mz_sidebar_collapsed") === "true";
  setCollapsedState(isCollapsed);

  if (topBtn && topBtn.dataset.bound !== "1") {
    topBtn.dataset.bound = "1";
    topBtn.addEventListener("click", toggleSidebar);
  }
  if (chevronBtn && chevronBtn.dataset.bound !== "1") {
    chevronBtn.dataset.bound = "1";
    chevronBtn.addEventListener("click", toggleSidebar);
  }
  if (logoBadge && logoBadge.dataset.bound !== "1") {
    logoBadge.dataset.bound = "1";
    logoBadge.addEventListener("click", () => {
      if (aside.classList.contains("collapsed")) {
        expandSidebar();
      } else {
        toggleSidebar();
      }
    });
  }

  // Section Accordions (Zabbix, Elastic, System)
  document.querySelectorAll(".nav-section[data-toggle-group]").forEach((sec) => {
    if (sec.dataset.bound === "1") return;
    sec.dataset.bound = "1";

    const groupKey = sec.dataset.toggleGroup;
    const targetId = groupKey === "zabbix" ? "navGroupZabbix" : (groupKey === "elastic" ? "navGroupElastic" : "navGroupSystem");
    const groupEl = $("#" + targetId);

    // Restore saved fold state
    const isGroupCollapsed = localStorage.getItem(`mz_group_${groupKey}`) === "true";
    if (isGroupCollapsed && groupEl) {
      sec.classList.add("collapsed");
      groupEl.classList.add("collapsed");
    }

    sec.addEventListener("click", () => {
      // If aside is in mini-collapsed mode, clicking section expands the whole sidebar
      if (aside.classList.contains("collapsed")) {
        expandSidebar();
        return;
      }
      if (!groupEl) return;
      const isNowCol = groupEl.classList.toggle("collapsed");
      sec.classList.toggle("collapsed", isNowCol);
      try {
        localStorage.setItem(`mz_group_${groupKey}`, String(isNowCol));
      } catch (e) { /* ignore */ }
    });
  });
}

// =========================================================
// Init
// =========================================================
document.addEventListener("DOMContentLoaded", () => {
  const p = loadProfile();
  applyTheme(p.theme);
  initSidebarCollapse();
  updateBrandTitle(currentPage || "dashboard");
  checkAuthStatus();
});
