# Changelog - Zabbix & Elastic Host Manager

บันทึกประวัติการปรับปรุง แก้ไข และพัฒนาฟีเจอร์ในระบบ

---

## [v63 / ZabbixV3] - 2026-11-04

### 1. หน้า Login โทนสีน้ำเงินเข้มเรียบหรู & Direct Zabbix Authentication
- **Plain Deep Navy Login UI (`web/styles.css`, `web/index.html`):**
  - ปรับพื้นหลังหน้า Login (`#loginOverlay`) เป็นสีน้ำเงินเข้มทึบเรียบหรู (`#071126`) ไม่มีลวดลายกวนสายตา และเน้นกล่อง Login (`.login-card`) ด้วยโทนสี Royal Sapphire (`#132852` ➔ `#0d1d3d`) ขอบเรืองแสงสีฟ้าชัดเจน
- **Direct Zabbix User/Pass & API Token Authentication (`zabbix_api.py`, `app.py`):**
  - รองรับการเข้าสู่ระบบผ่าน `user.login` (ดึงข้อมูลผู้ใช้จริงจาก Zabbix ตาม URL ที่ระบุ) และ `API Token`
  - รองรับทั้ง Zabbix 7.0+ (`Authorization: Bearer <token>`) และ Zabbix รุ่นก่อนหน้า (`"auth"` parameter) พร้อมระบบสลับโหมดอัตโนมัติและรองรับ Self-Signed SSL

### 2. การปรับปรุงหน้า Dashboard & Server Information
- **ค้นหาได้ทั้ง `AppID : AppName` และ `Group` (`web/app.js`, `zabbix_api.py`):**
  - รองรับ `selectHostGroups` สำหรับ Zabbix 7.0+ และดึงรายชื่อ Host Groups ทั้งหมดจาก Zabbix เพื่อให้ช่องค้นหา Application / Group กรองข้อมูลได้ครบถ้วน
- **ปรับตาราง Server Information (`web/app.js`):**
  - นำแถว `Technical Name` ออกตามความต้องการของผู้ใช้
  - เพิ่มการดึงข้อมูล **Zabbix Proxy / Proxy Group** (`proxy.get` และ `proxygroup.get`) ที่แต่ละ Server เกาะอยู่ และจัดวางแถว `Zabbix Proxy` ต่อจาก `OS Template`

### 3. Single-File Standalone HTML & Hybrid Browser-Direct Engine
- **สร้างไฟล์ `Zabbix_Monitoring_Standalone.html` (`build_standalone.py`, `web/standalone_engine.js`):**
  - รวม HTML, CSS, JS และ Zabbix JSON-RPC Client ไว้ในไฟล์เดียว สามารถก๊อปปี้ไปเปิดบนเครื่องอื่น (เช่น เครื่องที่ต่อ VPN ธนาคาร) ด้วย Chrome/Edge ได้ทันทีโดยไม่ต้องติดตั้ง Python

---

## [v57] - 2026-10-31

### 1. Trigger Explorer & UI Full-Width Extension (ขยายเต็มจอฝั่งขวา)
- **HTML Container Fix (`web/app.js`):**
  - แก้ไขการปิดแท็ก `</div>` ของ `.trig-toolbar` ก่อนคอนเทนเนอร์ `#trigResultsContainer` ป้องกันไม่ให้ผลลัพธ์ของการ์ดตกไปอยู่ใน Flex container บรรทัดเดียวกัน ซึ่งเดิมส่งผลให้การ์ดถูกบีบให้แคบและเหลือพื้นที่ว่างด้านขวา
- **CSS Grid & Width Expansion (`web/styles.css`):**
  - กำหนด `width: 100%; box-sizing: border-box;` ให้กับ `.trig-explorer`, `#trigResultsContainer`, `.trig-correlate-list`, และ `.trig-correlate-card`
  - ปรับ Grid ภายใน `.trig-card-grid-compact` เป็น `grid-template-columns: minmax(260px, 30%) 1fr;` ส่งผลให้คอลัมน์ฝั่งขวา (**3. TRIGGER & เงื่อนไขแจ้งเตือน**) ยืดเต็มพื้นที่ด้านขวาอย่างสมดุล
  - ปรับขนาดของ Snippet สูตร Expression (`.trig-expr-snippet`) ให้ขยายได้สูงสุดถึง `88%` พร้อมโฮเวอร์ไฮไลต์ชัดเจน

### 2. Trigger Explorer Modern & Compact Redesign (ปรับการ์ดให้กระชับ สะอาดตา)
- **Top Ribbon (Step 1):** รวมข้อมูล Template, จำนวน Metrics และจำนวน Triggers ไว้ในแถบด้านบน (`.trig-card-topbar`) ในบรรทัดเดียว
- **2-Column Split:** แบ่งโครงสร้างชัดเจนระหว่างฝั่งซ้าย (Items ที่ตรวจวัด) และฝั่งขวา (Trigger & Actions) พร้อม Scrollbar ขนาดกะทัดรัด
- **Card Accordion / Folding:** สามารถคลิกส่วนหัวของการ์ด (`.trig-card-head`) เพื่อย่อ/ขยาย (Fold/Unfold) ซ่อนเนื้อหาเพื่อความสะอาดตา

### 3. Interactive Help Dropdowns (`?`) (คำอธิบายส่วนต่างๆ)
- ซ่อนข้อความอธิบายยาวๆ ในหน้าทั้งหมดไว้ในปุ่ม `?` ท้ายชื่อหัวข้อ (`.section-help-btn`)
- รองรับการเปิด/ปิด Accordion แบบลอยตัว (`.section-help-box`) โดยไม่กระทบหรือเปลี่ยนแปลงเมนูหลักด้านซ้าย (Left Sidebar)
- รองรับครอบคลุมทุกหน้า:
  - Dashboard (Server Information, Resource Utilization, KPI Compliance, Monitoring Health)
  - Template Mapping (App Servers, Official Template, Custom Monitor, Trigger Explorer)
  - Reports
  - Elastic Overview, Elastic Config, Elastic Indices
  - System Settings

### 4. Cache-Busting Version Bump
- อัปเดต version query string ใน `web/index.html` เป็น `?v=57` ทั้งไฟล์ CSS และ JS
